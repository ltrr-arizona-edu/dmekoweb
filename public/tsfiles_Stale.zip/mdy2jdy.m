function jday=mdy2jdy(month,day)
% mdy2jdy: convert month, day, to julian day (sequential day in 366-day year)
% CALL: jday=mdy2jdy(month,day);
%
% Last Revised 2016-12-31
%
%********************  IN 
%
% month (? x 1)i month of year (1==jan)
% day (? x 1)i  day of month 
%
%***************** OUT 
%
% jday (? x 1)i  Julian day (Jan 1 ==1, Dec 31 == 366)
%
%
%*** NOTES
%
% Revised 2016-12-31. To accept and handle month and day as col vectors as
% well as scalars.


bef = [0 31 29 31 30 31 30 31 31 30 31 30]';
bef = cumsum(bef); % increment of days 


jday = day + bef(month);
