function [x,yrx,numser,other]=groupts1(X,yrX,iuse,kmeth,kunits,kspan,refpd)
% groupts1: group multiple time series with variable time coverage into a single time series
% [x,yrx,numser,other]=groupts1(X,yrX,iuse,kmeth,kunits,kspan,refpd);
% Last revised 9-10-01
%
% Converts a time series matrix of multiple series into a single time series by any one of several 
% possible methods. Methods include: 
%   arithmetic mean of original variables,
%   PCA=scores of first principal component of correlation or covariance matrix 
%   STZA=arithmetic mean of individual standardized anomalies
% Depending on choice of method (option khow), output time series might cover either the period in common to
% all series or the full period spanned by composite series.
%
%
%*** INPUT
%
% X (mX x nX)r  input time series matrix;  year NOT included as one of the columns.
% yrX (mX x 1)i year vector for X
% iuse (? x 1)i  index to columns (series) in X to be used in forming the group time series x
% kmeth (1 x 1)i method for forming group variable
%   ==1 arithmetic mean of original series
%   ==2 PCAa: PCA on correlation matrix
%   ==3 PCAb: PCA on covariance matrix
%   ==4 STZA: standardized anomalies, converted back to original units
% kunits (1 x 1)i  units for output
%   ==1 original units 
%   ==2 output forced to mean 0 and standard deviation 1
% kspan (1 x 1)i time span of output
%   ==1 common period to all input series
%   ==2 from start of earliest input to end of latest (valid only for standardized-anomaly method)
% refpd (1 x 2)i or []:  start and end year of reference period to be used by STZA method to get means
%   and standard deviations of individual series.  (see notes)
%
%
%*** OUTPUT
%
% x (mx x 1)r output (group) time series
% yrx (mx x1)r year vector for x
% numser (mx x 1)i number of series contributing to the group series each year (sample size)
% other.  structure variable with supplementary information on the group variable and intermediate data
%
%
%*** REFERENCES --NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED -- NONE
%
%
%*** NOTES
%
% iuse.  Included to allow selection of a subset of the variables in X to be used in the group time series.  For
% example, say X may has 500 tree-ring chronologies scattered over the US and you want to compute a regional series
% for E Coloarado, and say the E Colorado series are in columns 5-8 and 34 of X. Set iuse to [5 6 7 8 34].
%
% STZA.  Output series optionally covers the period in common to all series or the maximun period
% spanned by any combination of the series.  A reference period must be specified for this method. 
% and the reference period must be covered with valid data by all series.  The arithmetic mean of the 
% individual means and standard deviations for the reference period are used to convert the output time series
% from standardized anomalies to original units.
%
% kunits.  Choosing kunits==1 (original units) is valid only for the arithmetic mean and STZA options on kmeth.  In this
% case the units of x are the same as the units on the individual input serie X, and you are assumed to know that all
% variables in X should have the same units.  
%
% kspan.  For PCA methods, kspan must be set to 1, as correlation or covariance matrix is computed on common period. For
% arithmetic mean of original variables, kspan usually is set to 1, as jumps in the output can result from site to site
% differences in the means and standard deviations of the individual series (user beware here).  For STZA method, 1 or 2 is
% a reasonable choice for kspan.
%
% refpd.  The reference period should be set to [] for all except method STZA.  If [] for method STZA, the reference
% period defaults to the period in common to all series
%
% Missing values.  Input series are assumed to have no missing values imbedded within the period of valid data.  Missing
% values on the ends of the series are OK.  Missing values in the input X must be coded as NaN.
%
% Same-sign constraint on PCA loadings.  In PCA methods, all variables must have the same sign of loading on the first PC. 
% This is because we are assuming the series covary.  Why else average them into a regional series?  The function ends with an 
% error message is all PCA loadings on PC#1 do not have the same sign.
%
% Sign-switching on PC #1 scores.  If needed, the sign of the score time series of PC#1 is switched so that positive departures
% from the mean of the original series go with positive departures from the mean of the output series x.
%
% Common period vs reference period.  Common period is defined as period with data at all selected series iuse.  Reference
% period is specified period (refpd) for computation of means and standard deviations for use in method STZA.  All iuse 
% series must have valid data for reference period.  Reference period might be the same as the common period -- for example,
% if refpd ==[].  PCA methods use the common period for computation of correlation or covariance matrix, and generate an
% output time series x that covers that common period.  refpd is really only used in the STZA method.

% INPUT CHECKS

% Size of X
[mX,nX]=size(X);
if nX<2 | mX<10; %
    error('X should be a tsm with variables as the columns; X has fewer than 10 rows or fewer than 2 columns'); 
end;
% Size and content of iuse
[mtemp,ntemp]= size(iuse); 
if ntemp~=1 | mtemp<1;
    error('iuse should be a cv of length at least 1');
end;
if any(iuse<1) | any(iuse>nX);
    error('iuse elements outside range of column numbers of X');
end;
% size and increment of yrX
[mtemp,ntemp]=size(yrX);
if ntemp~=1 | mtemp~=mX;
    error('yrX must be cv of same row size as X');
end;
if ~all(diff(yrX)==1);
    error('yrX does not increment by 1 throughout');
end;
clear mtemp ntemp;

% internal NaNs in X?
for n =1:nX;
    xtemp=X(:,n);
    m = intnan(xtemp);
    if m==1;
        error(['Column ' int2str(n) ' of X  has internal NaN']);
    end;
end;

% Pull col subset of X
X = X(:,iuse);
nser = length(iuse);
nX=size(X,2); % number of series for group

% Pull common-period row subset of X
if nser>1;
    L=(~any(isnan(X')))'; % rv to part of X with no missing values at any iuse series
    
else; % X has just one series
    L=~isnan(X);
end;
Xc = X(L,:); % common-period slab of X
yrXc = yrX(L);



other.Describe={'Supplementary info on call to groupts1.m'};
other.CommonPeriod=[min(yrXc) max(yrXc)];

% kmeth
[mtemp,ntemp]=size(kmeth);
if ~(mtemp==1 & ntemp==1);
    error('kmeth must be scalar');
else;
    if ~any(kmeth==[1 2 3 4]);
        error('kmeth must be 1 ,2, 3 or 4');
    end;
end;

% kunits
[mtemp,ntemp]=size(kunits);
if ~(mtemp==1 & ntemp==1);
    error('kmeth must be scalar');
else;
    if ~any(kunits==[1 2 ]);
        error('kunits must be 1 or 2');
    end;
end;

% kspan
[mtemp,ntemp]=size(kspan);
if ~(mtemp==1 & ntemp==1);
    error('kmeth must be scalar');
else;
    if ~any(kspan==[1 2 ]);
        error('kspan must be 1 or 2');
    end;
end;

% refpd
Lempty = isempty(refpd);
if ~Lempty;
    [mtemp,ntemp]=size(refpd);
    if ~(mtemp==1 & ntemp==2);
        error('refpd must be empty or 1 x 2');
    else;
        if any(refpd > max(yrX)) | any(refpd < min(yrX));
            error('refpd must be 1 or 2 and not be outside range of yrX');
        end;
    end;
end


% ref period must not have NaNs
if ~Lempty;
    Lref = yrX>=refpd(1) & yrX<=refpd(2);
    Xr = X(Lref,:);
    yrXr = yrX(Lref);
    if any(any(isnan(Xr)));
        error(['A NaN in reference period ' int2str(refpd)]);
    end;
else;
    Xr=Xc;
    yrXr=yrXc;
end;
other.ReferencePeriod=[min(yrXr) max(yrXr)];



%--- COMPUTE REF-PERIOD MEANS AND STANDARD DEVIATIONS
if Lempty;
    Xr = Xc;
    yrXr = yrXc;
end
xmean = mean(Xr);
xstd = std(Xr);
other.RefPeriodMeans=xmean;
other.RefPeriodStd=xstd;


%-- COMPUTE GROUP TIME SERIES

% Recall that 
% X,yrX now hold the original time series, reduced to the iuse series
% Xc, yrXc hold the common-period data
% Xr, yrXr hold the reference-period data
% xmean, xstd hold the series means and standard deviations computed for the reference period

switch kmeth; % method
case 1; % arithmetic mean
    other.Method='Arithmetic mean of input series';
    if kunits~=1;
        error('For arith mean, output must be in original units');
    else;
        if kspan==1; % % output over common period only
            if nser>1;
                x=(mean(Xc'))';
            else;
                x=Xc;
            end;
            yrx = yrXc;
            numser = size(Xc,2);
        elseif kspan==2; % output over full available period of data
            if nser>1;
                x=(nanmean(X'))';
            else;
                x=X;
            end;
            yrx=yrX;
            % Computer number of valid stations each year
            L=~isnan(X);
            if nser>1;
                numser = (sum(L'))';
            else;
                numser=+L; % removes logical attribute
            end;
            % Check for internal NaN
            m=intnan(x);
            if m==1;
                error('Imbedded NaN in group-average series; check series coverages');
            else;
            end;
            % Trim off leading and trailing NaNs
            L = ~isnan(x);
            x=x(L);
            yrx=yrx(L);
            numser=numser(L);
        end;
    end;
case 2; % PCA on correl mtx
    other.Method='PCA on correlation matrix';
    if kunits==1; 
        error('For PCA methods, output is allowed only in standardized units (kunits==2)');
    else;
        if kspan~=1;
            error('For PCA methods, output must be over common period (kspan==1)');
        else; % kspan==1;
            if nser>1;
                % eigenvector analysis
                kopt=1; % want correl mtx in call to eigen1
                [R,V,L,S,F,B]=eigen1(Xc,kopt); % score time series in F, eigenvectors in V
                v1=V(:,1); % loadings of PC1;
                other.PC1VarFract=L(1,1)/sum(diag(L));
                if all(v1>0); % loading all positive
                    x=zscore(F(:,1)); 
                elseif all(v1<0); % loading all negative
                    x=-1.0 * zscore(F(:,1));
                else; 
                    error('Loadings on PC1 not all of same sign; inappropriate series to group as a region by PC1');
                end;
            else;
                x=zscore(Xc);
                R=[]; V=[]; S=[]; F=[]; B=[]; v1=[]; L=[];
            end;
            yrx=yrXc;
            numser=size(Xc,2);
        end; % if kspan~=1;
    end; %if kunits==1;
    other.PCLoadings=v1;
    other.PCEigValues=L;
    other.PCCorrMtx=R;
case 3; % PCA on covar mtx
    other.Method='PCA on covariance matrix';
    if kunits==1; 
        error('For PCA methods, output is allowed only in standardized units (kunits==2)');
    else;
        if kspan~=1;
            error('For PCA methods, output must be over common period (kspan==1)');
        else; % kspan==1;
            if nser>1;
                % eigenvector analysis
                kopt=2; % want covar mtx in call to eigen1
                [R,V,L,S,F,B]=eigen1(Xc,kopt); % score time series in F, eigenvectors in V
                v1=V(:,1); % loadings of PC1;
                other.PC1VarFract=L(1,1)/sum(diag(L));
                if all(v1>0); % loading all positive
                    x=zscore(F(:,1)); 
                elseif all(v1<0); % loading all negative
                    x=-1.0 * zscore(F(:,1));
                else; 
                    error('Loadings on PC1 not all of same sign; inappropriate series to group as a region by PC1');
                end;
            else;
                x=zscore(Xc);
                R=[]; V=[]; S=[]; F=[]; B=[]; v1=[]; L=[];
            end;
            yrx=yrXc;
            numser=size(Xc,2);
        end; % if kspan~=1;
    end; %if kunits==1; 
    other.PCLoadings=v1;
    other.PCEigValues=L;
    other.PCCovMtx=R;
case 4; % mean of standarized anomalies
    other.Method='Arithmetic mean of standardized anomalies';
    % Compute average mean and average standard deviation for reference period
    basemn =mean(xmean);
    basestd=mean(xstd);
    other.GlobalMean=basemn;
    other.GlobalStd=basestd;
    % Convert full-length series to standardized anomalies, using ref period means and std devs
    D = X-repmat(xmean,mX,1);
    D = D ./ repmat(xstd,mX,1);
    x = (nanmean(D'))'; % standardized anomaly output
    yrx=yrX;
    Lgood = ~isnan(D); % mark valid data
    if nser>1;
        numser = (sum(Lgood'))'; % number of valid series each year
    else;
        numser=+Lgood;
    end;
    
    % spans action
    if kspan ==1; % output just for period common to all series
        L=yrx>=min(yrXc) & yrx<=max(yrXc);
        x=x(L);
        yrx=yrx(L);
        numser=numser(L);
    else;
        % no action needed
    end;
    
    % units option
    if kunits==1; % original units
        x = (x * basestd) + basemn; % mult by global std dev and add back global mean
    else; % z-score inits
        % Re-scale ave standardized anomalies to zero mean unit variance
        x= (x - nanmean(x)) ./ nanstd(x);
    end;
    
otherwise;
    error('Should not get here in switch kmeth');
end;

% Check for internal NaN
m=intnan(x);
if m==1;
    error('Internal NaN in x');
else;
    
    % Strip leading and trailing NaN
    L=isnan(x);
    if any(L);
        x(L)=[];
        yrx(L)=[];
        numser(L)=[];
    end;
end;
