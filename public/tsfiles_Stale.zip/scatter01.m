function S=scatter01(x,y,yrx,yry,uinf);
% scatter01: scatterplot for two time series
% scatter01(x,y,yrx,yry,uiinf);
% Last revised: 1-3-02
%
% Scatterplot for two time series, with tercile partitions (on x) and option for analysis period 
%
%*** INPUT 
%
% x (mx x 1)r  time series 1
% y (my x 1)r  time series 2
% yrx (mx x 1)i year vector for x
% yry (my x 1)i year vector for y
% uinf{} miscellaneous user information
%   {1} {} string ids for x and y (e.g., {'Series 1','Series 2'})
%   {2} {} data labels for x and y (e.g., {'Indwx','Precipitation'})
%   {3} {} data units for x and y (e.g., {'dimensionless','in'})
%   {4} (1 x ?)s time label (e.g., 'Year')
%   {5} (1 x 2)i start and end year of desired analysis period ([] if full overlap)
%
%*** OUTPUT
% 
% No output arguments
% Graphics windows
%
%
%*** REFERENCES
%
% None
%
%
%*** UW FUNCTIONS CALLED 
%
% acf -- autocorrelation function
% pearsign -- significance of correlation coefficient
%
%*** TOOLBOXES NEEDED
%
% Statistics
%
%*** NOTES
%
% Minimum allowable analysis period (overlap of the two series) is n=5
% Autocorrelation adjustment.  Effective sample size (adjusted for lag-1 autocorrelation) used if 
%   firs-order autocorrelation coefficient signifant at 0.05 level for BOTH series


%---- Hard Code
minn=15; % minimum allowable length of analysis period; allow for min of 5 obs in each tercile


%---------  CHECK INPUT

% x, y and their year vectors
[mx,nx]=size(x);
mtemp=size(yrx,1);
if mtemp~=mx | nx~=1;
    error('x should be col vector, and yrx should be same length');
end;
[my,ny]=size(y);
mtemp=size(yry,1);
if mtemp~=my | ny~=1;
    error('y should be col vector, and yry should be same length');
end;

% Cull common period x and y
yrgo = max([yrx(1) yry(1)]);
yrsp = min([yrx(end) yry(end)]);
yr1 = (yrgo:yrsp)';
nyr1 = length(yr1);
if nyr1<minn;
    error(['Overlap less than ' num2str(minn)]);
else;
    L=yrx>=yrgo & yrx<=yrsp;
    x1=x(L);
    L=yry>=yrgo & yry<=yrsp;
    y1=y(L);
end;
yrs1 = [yrgo yrsp]; % common period of x and y, also the default analysis period 
% x1, y1, yr1, nyr1 now hold overlap data


if isempty(uinf);
    id1='Series 1';
    id2='Series 2';
    labx ='Variable x';
    laby='Variable y';
    unitsx ='units';
    unitsy = 'units';
    labtime = 'Year';
    yrs2 = [yrgo yrsp];
    
else;
    id1 = uinf{1}{1};
    id2 = uinf{1}{2};
    labx = uinf{2}{1};
    laby = uinf{2}{2};
    unitsx = uinf{3}{1};
    unitsy = uinf{3}{2};
    labtime=uinf{4};
    yrs2 = uinf{5};
    if isempty(yrs2);
        yrs2=yrs1;
    else
    end;
   
end;

% Check that analysis period within common period
if yrs2(1)<yrs1(1) | yrs2(1)>yrs1(2);
    error('Analysis period not within overlap period of the two series');
end;

% CULL ANALYSIS-PERIOD DATA -- PUT IN   x2, y2, with year vector yr2 and length nyr2
if all(yrs2==yrs1);
    x2=x1;
    y2=y1;
    yr2=yr1;
    nyr2=nyr1;
else;
    L=yr1>=yrs2(1) & yr1<=yrs2(2);
    x2=x1(L);
    y2=y1(L);
    nyr2=length(x2)
    yr2=(yrs2(1):yrs2(2))';
end;
clear L;

% Initial default window width
if nyr2<minn;
    error(['Analysis period ' int2str(yrs2) ' shorter than ' int2str(minn) ' yr']);
else;
end;


% Autocorrelation 
[rx1,SE2,rx195]=acf(x2,5); % of series zx2, to lag 5
[ry1,SE2,ry195]=acf(y2,5); % of series zx2, to lag 5
rx1=rx1(1);
ry1=ry1(1);
if rx1>rx195 & ry1>ry195;
    rho=[rx1 ry1];
    nyr2prime = nyr2 * (1-rx1*ry1)/(1+rx1*ry1);
else;
    nyr2prime= nyr2;
    rho=[0 0];
end;



% FULL PERIOD CORRELATION ANALYSIS
r = corrcoef([x2 y2]);
r=r(1,2);
[rcrit95,dummy1,dummy2]=pearsign(r,nyr2,1,0.05,0,rho); % critical level, assuming alpha=acur; using r(1) adjustment if...
nyr2this=nyr2prime;

sinf1{1}='SETTINGS';
sinf1{2}=[' Series1=' id1 '; series2=' id2];
sinf1{3}=[' Full Period = ' int2str(yrs2) ';   N = ' int2str(nyr2)];

sinf1{10}=  'Lag-1 autocorrelations and effective sammple size (for full period';

fmta='%5.2f';
fmtb='%6.0f';
sinf1{11}=['     First series r1=' num2str(rx1,fmta) ';  (' num2str(rx195,fmta) ' required for 95% sig'];
sinf1{12}=['     Sec.  series r1=' num2str(ry1,fmta) ';  (' num2str(ry195,fmta) ' required for 95% sig'];
sinf1{13}=['     Effective sample size, N* = ' num2str(nyr2this,fmtb)];
sinf1{14}='CORRELATION RESULTS';
sinf1{15}=['    r= ' num2str(r,fmta) '  (' num2str(rcrit95,fmta) ' needed for sign. at .05 level)'];


% STRING TO ANNOTATE CORRELATION -- all data
str4a='\itN=\rm';
if nyr2prime==nyr2; % if no reduction in effective sample size
    str4='\itN=\rm';
else;
    str4='\itN''=\rm';
end;
str2=num2str(nyr2prime,'%5.0f');
str1='\it{r}=';
str5=['\it{r}\rm =  '   num2str(r,'%5.2f') ' ('];
str6=['\it{r}_{.05}\rm = '  num2str(rcrit95,'%5.2f') ', '];
str8=[str4 str2 ') '];
strall=['All Data, ' str5 str6 str8 ]; 
clear str1 str2 str5 str6 str8 ;

% Check that enough unique values to allow separation of x data into terciles
if (prctile(x2,100/3) == prctile(x2,100/2)) | (prctile(x2,100/3) == prctile(x2,200/2));
    error(['No separation between terciles 1 and 2 (or 2 and 3) for this x data -- possibly too many zeros in data']);
end;



% Make subsets of x2, y2 for the lower, middle and upper tercile of observations ranked on x2
dx=[prctile(x2,100/3) prctile(x2,100/2)  prctile(x2,200/3)];
dy=[prctile(y2,100/3) prctile(y2,100/2)  prctile(y2,200/3)];
L1=x2<dx(1);
L2=x2>=dx(1) & x2<=dx(3);
L3=x2> dx(3);

xa=x2(L1);
xb=x2(L2);
xc=x2(L3);
ya=y2(L1);
yb=y2(L2);
yc=y2(L3);


% STRING TO ANNOTATE CORRELATION -- lowest tercile data
nyra=length(xa);
ra = corrcoef([xa ya]);
ra=ra(1,2);
[rcrit95a,dummy1,dummy2]=pearsign(ra,nyra,1,0.05,0,[]); % critical level
str2=num2str(nyra,'%5.0f');
str1='\it{r}=';
str5=['\it{r}\rm =  '   num2str(ra,'%5.2f') ' ('];
str6=['\it{r}_{.05}\rm = '  num2str(rcrit95a,'%5.2f') ', '];
str8=[str4a str2 ') '];
stra=['Lowest Tercile, ' str5 str6 str8 ]; 
clear str1 str2 str5 str6 str8 ;



% STRING TO ANNOTATE CORRELATION -- middle tercile data
nyrb=length(xb);
rb = corrcoef([xb yb]);
rb=rb(1,2);
[rcrit95b,dummy1,dummy2]=pearsign(rb,nyrb,1,0.05,0,[]); % critical level
str2=num2str(nyrb,'%5.0f');
str1='\it{r}=';
str5=['\it{r}\rm =  '   num2str(rb,'%5.2f') ' ('];
str6=['\it{r}_{.05}\rm = '  num2str(rcrit95b,'%5.2f') ', '];
str8=[str4a str2 ') '];
strb=['Middle Tercile, ' str5 str6 str8 ]; 
clear str1 str2 str5 str6 str8 ;


% STRING TO ANNOTATE CORRELATION -- upper tercile data
nyrc=length(xc);
rc = corrcoef([xc yc]);
rc=rc(1,2);
[rcrit95c,dummy1,dummy2]=pearsign(rc,nyrc,1,0.05,0,[]); % critical level
str2=num2str(nyrc,'%5.0f');
str1='\it{r}=';
str5=['\it{r}\rm =  '   num2str(rc,'%5.2f') ' ('];
str6=['\it{r}_{.05}\rm = '  num2str(rcrit95c,'%5.2f') ', '];
str8=[str4a str2 ') '];
strc=['Upper Tercile, ' str5 str6 str8 ]; 
clear str1 str2 str5 str6 str8 ;



% Set up plots

strxlab = [labx '(' unitsx ')'];
strylab = [laby '(' unitsy ')'];

S={'SCATTERPLOT SUMMARY',...
        ['   x variable = ' strxlab],...
        ['   x variable = ' strxlab]};
        

subplot(2,2,1); % 
plot(x2,y2,'.');
xlabel(id1);
ylabel(id2);
title(strall);
lsline;
ylims=get(gca,'YLim');
xlims=get(gca,'XLim');
xmn=mean(x2);
ymn=mean(y2);
% Plotting points for quadrant labels
p1x=(xlims(2)+xmn)/2;
p1y=(ylims(2)+ymn)/2;
p2x=(xlims(1)+xmn)/2;
p2y=(ylims(2)+ymn)/2;
p3x=(xlims(1)+xmn)/2;
p3y=(ylims(1)+ymn)/2;
p4x=(xlims(2)+xmn)/2;
p4y=(ylims(1)+ymn)/2;
tq1=text(p1x,p1y,'I','VerticalAlignment','Middle','HorizontalAlignment','Center','FontSize',14);
tq2=text(p2x,p2y,'II','VerticalAlignment','Middle','HorizontalAlignment','Center','FontSize',14);
tq3=text(p3x,p3y,'III','VerticalAlignment','Middle','HorizontalAlignment','Center','FontSize',14);
tq4=text(p4x,p4y,'IV','VerticalAlignment','Middle','HorizontalAlignment','Center','FontSize',14);


line([mean(x2) mean(x2)],ylims,'LineStyle',':');
%line([dx(3) dx(3)],ylims,'LineStyle',':');
%line(xlims,[dy(1) dy(1)],'LineStyle',':');
line(xlims,[mean(y2) mean(y2)],'LineStyle',':');

subplot(2,2,2); % 
plot(xb,yb,'o');
xlabel(id1);
ylabel(id2);
lsline;
title(strb);

subplot(2,2,3); % 
plot(xa,ya,'>');
xlabel(id1);
ylabel(id2);
lsline;
title(stra);

subplot(2,2,4); % 
plot(xc,yc,'<');
xlabel(id1);
ylabel(id2);
lsline;
title(strc);
set(gcf,'Name','Scatterplots');

