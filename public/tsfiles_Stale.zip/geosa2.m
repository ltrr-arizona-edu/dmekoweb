% geosa2.m  -- time series plot, probability distribution, basic statistics 
%
% Last revised 2018-12-20
%
%*** UW FUNCTIONS CALLED
%
% sfields -- check for existence of required fields in structure for GEOS 585A 
%
%*** TOOLBOXES NEEDED
%
% STATS

% Rev20121220:  lillietest function with the ready-made lookup table
% sometimes bombs out
%
% Rec 2016-12-04-14  Cosmetic changes only.  


clear;
close all; % close any open figure windows

%********  INTRODUCTORY MSG

message1 = {'Probability Distribution',...
    '',...
    'Illustrates the empirical probability distribution and Lilliefors',...
    'test for normality.  You will select one time series from either',...
    'the V1, V2 or V3 data, and can set the time period for analysis.',...
    ' ',...
    'Figure Windows produced: ',...
    '   Fig 1: time series plot',...
    '   Fig 2: box plot, normal-probability plot, and histogram ',...
    '       with normal density function superposed',...
    '   Fig 3: plots from Lilliefors goodness of fit test for',...
    '       normal distribution',...
    '',...
    'Matlab functios ''std'' and ''iqr'' may also be useful in tis assignment',...
    ''....
    'Any message box with title ''messagen'', where n=1, 2, .... in this and subsequent scripts can be re-read after',...
    'running the script by going to the command window and typing, for message1, say:',...
    '>> char(message1)'};
    
    msgbox1(message1,'message1');
    
    
    % Hard code
datfile='Spring19'; % default .mat file with input data

% Prompt for data filemame
prompt={'Enter name of input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string

%--- Load the input file
pf1=file1;  % renemed filename 
eval(['load ' pf1]);  

%--- The data should be in a structure variables V1, V2, V2 
%  Check that required structures exist in the workspace
if ~all([exist('V1')==1  exist('V1')==1  exist('V1')==1]);
   error([pf1 ' does not contain V1, V2 and V3']);
end

% Check that V1, V2 and V3 are structures with required fields
for n =1:3; % loop over structures
    eval(['V = V' int2str(n) ';']);
    if ~isstruct(V); 
        error(['V' int2str(n) ' must be structure']); 
    else; % check for required fields
        sfields(V);
    end;
end;


% Menu to choose type of variable for analysis 

kv = menu('Time series will be selected from which data (choose one)',...
    'V1 -- output data',...
    'V2 -- input data',...
    'V3 -- trend data');
if kv==1;
    V=V1;
elseif kv==2;
    V=V2;
else;
    V=V3;
end;


% Compute number of series in input structure
nsites = size(V.name,1);
Lpick = logical(zeros(nsites,1)); % pointer to picked series
pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not
nwant = 1; % want 1 series

%*********  MENU TO CHOOSE SERIES

tmen = V.seriesmenu;  % menu of series, with column number
tmen1=tmen;
tmen1{nsites+1}='Accept selection';
tmen1 = char(tmen1);
tmen2=[tmen1 pflag];
[mtmen2,ntmen2]=size(tmen2);
 
sitenos=repmat(NaN,nwant,1); % to store index to selected sites

kwh1=1;
strchoose='Select a series';
kthis=[];
while kwh1==1;
   kmen1=menu(strchoose,cellstr(tmen2));
   if ~any(Lpick) & kmen1== nsites+1;
       msgbox1('None selected yet -- select again','Message');
   elseif kmen1==nsites+1;
       sitenos=kthis;;
       kwh1=0;
   else;
       Lpick=logical(zeros(nsites,1)); 
       pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not
       pflag(kmen1,3)='*';
       Lpick(kmen1)=1;
       kthis=kmen1;
       tmen2=[tmen1 pflag];
       
   end;
 
end;


% Find start and end year of valid data for series
YRS = repmat(NaN,nwant,2);
%nchars1 = size(V.name{sitenos}teinf,2);
L = ~isnan(V.tsm(:,sitenos));  % logical pointer to valid entries 
disp(blanks(1));
disp('Start and end time of valid data for series');
fmt1 = '%50s  %4.0f-%4.0f\n';
j = sitenos;
yrtemp = V.time(L);
YRS(1,1)=min(yrtemp);
YRS(1,2)=max(yrtemp);


% Display name of selected series and info
clc;  % clear the command window
strmess1={['Type of data: ' V.what ],...
        [' ID: ' V.id{sitenos}],...
        [' Name: ' V.name{sitenos}],...
        [' Time coverage: ' int2str(YRS)]};
msgbox1(strmess1,'Message');
    


% Set a few labels
ylab1=[V.label{sitenos} ' (' V.units{sitenos} ')'];
ylab2a = ylab1;
ylab2b='Frequency';
ylab2c='ylab1';

xlab1=V.increment;
xlab2a = V.id{sitenos};
xlab2b =[V.label{sitenos} ' (' V.units{sitenos} ')'];
xlab2c = xlab2b ;

id=V.id{sitenos};




%**********  INPUT DIALOG TO SELECT PERIOD FOR ANALYSIS
titlepmt = 'Select period for analysis';
prompt = {'Enter start time',...
	'Enter end time'};
lineNo=1;
deflt = {int2str(max(YRS(:,1))),int2str(min(YRS(:,2)))};
answer=inputdlg(prompt,titlepmt,lineNo,deflt); % answer as char in cells
% convert answer to double
yrgo = str2num(answer{1});
yrsp = str2num(answer{2});
nobs=yrsp-yrgo+1;


% Check that both series cover selected period
if any(YRS(:,1)>yrgo) | any(YRS(:,2)<yrsp);
	error('Selected analysis period inconsistent with period covered by series');
end


%******************** GET SUBSET OF DATA FOR SELECTED PERIOD AND SERIES
L1 = V.time>=yrgo & V.time<=yrsp; % logical pointer to rows of vector tree.yr
yr = V.time(L1);  % year vector for selected period
X = V.tsm(L1,sitenos);  % subset of years, columns with the desired data
	


%**********************  TIME SERIES PLOT
figure(1);  % Want plot in figure window 1

% Find maximum and minimum value for  series.  These
% values to be used to set y-axis limits
xmax = max(max(X));
xmin = min(min(X));

% Find some other statistics
xmean=mean(X);
xmed = median(X);
xstd = std(X);
xskew=skewness(X);

% Store statistics 
S=repmat(NaN,5,1); % allocate
S=[xmean; xmed; xmin; xmax; xstd; xskew];


j = sitenos;
str_title = ['Time Plot of ' V.name{j}];
x=X;
xlims=[min(yr) max(yr)];
hand1=plot(yr,x,[min(yr) max(yr)],[nanmean(x) nanmean(x)]); % plot, saving plot handle
set(gca,'XLim',xlims); % restrict x axis range
legend(id,'Mean');
title(str_title);
% Axes labels for lower plot only
xlabel(xlab1);
ylabel(ylab1);

grid;
%zoom xon; % commented out to avoid matlab bug
set(gca,'YLim',[xmin xmax]); % specify y-axis limits 
set(gcf,'Name',' Time Series Plot');



%*************  PROBABILITY DISTRIBUTION

figure(2);

tit2a = 'BOX PLOT';
tit2b ='HISTOGRAM & NORMAL DENSITY';
tit2c='NORMAL-PROBABILITY PLOT';
tit2d = 'TEST FOR NORMALITY';

% Box plot
subplot(2,2,1);
boxplot(x);
%   positions for annotation
[xlims]=get(gca,'XLim');
[ylims]=get(gca,'YLim');
xdif = diff(xlims);
ydif = diff(ylims);
xpnt = xlims(1)+ 0.65*xdif;
ypnt = ylims(1)+ [0.9 0.8 0.7 0.6 0.5 0.4 0.3]*ydif;
%   ---
xlabel(' ');
ylabel(ylab2a);
title(tit2a);
%   annotate
txttemp={'Mean=','Median=','Min=','Max=','Std=','Skew=','Sample Size='};
for n = 1:7
    if n<7
        txtthis=num2str(S(n));
    else
        txtthis = int2str(length(yr));
    end;
    text(xpnt,ypnt(n),[txttemp{n} txtthis]);
end;
%   ---
set(gca,'XTickLabel',id,'XGrid','off','YGrid','on')

% For ease of reference, store S as structure
S1.timeseries=x;
S1.time=yr;
S1.mean=S(1);
S1.median=S(2);
S1.min=S(3);
S1.max=S(4);
S1.std=S(5);
S1.skew=S(6);
S1.samplesize=nobs;
S=S1;
clear S1;

% Histogram w normal histogram
subplot(2,2,2);
histfit(x);
xlabel(xlab2b);
ylabel(ylab2b);
title(tit2b);

% Normal-probability plot 
subplot(2,2,3);
normplot(x);
xlabel(xlab2c);
%ylabel(ylab2c);
title(tit2c);

% Lilliefors Test for goodness-of-fit to normal distribution 
subplot(2,2,4);


set(gca,'XLim',[0 1],'YLim',[0 1]);
alpha=0.05; % alpha level for test
h=lillietest(x,alpha);

str1={'Null hypothesis: series comes from normal','distribution with unspecified mean and variance'};
str2=['Specified alpha level = ' num2str(alpha)];

if h==1; 
    str6='REJECT Null Hypothesis';
else;
    str6='CANNOT REJECT Null Hypothesis'
end;

text(.02,.92,str1);
text(.2,.75, str2);
text(.2,.60,str6);
title(tit2d);

set(gca,'Visible','off');



%*************  CDF S TO ILLUSTRATE LILLIEFORS TEST
figure(3);
z=sort(zscore(x)); % standardize time series
mz=length(z); % length of series
p=(1:mz)'/(mz+1); % Weibull plotting point for empirical cdf
%P=normcdf(linspace(min(zscore(x)),max(zscore(x)),mz),0,1)
pn = normcdf(z,0,1); % standard normal valies with at same cdf probalities

subplot(2,1,1);
plot(z,p,z,pn);
legend(xlab2a,'Standard Normal');
grid;
% zoom xon; % commented out to avoid matlab bug
xlabel('Standardized Value');
ylabel('Cumulative Probability');
title('CDFs of Sample and Standard Normal Series');

subplot(2,1,2);
plot(z,abs(p-pn));
line([min(z) max(z)],[0 0]);
title('Absolute Value of CDF Difference');
xlabel('Standardized Value');
ylabel('Delta P');
grid;
%zoom xon; % commented out to avoid matlab bug



message2={'Finished! Results are in 3 figure windows',...
    '',...
    'For this script and following scripts, resize by dragging corners.',...
    'Use figure-window menu options to zoom, pan, annotate, save, reload figure.',...
    'If using MS Windows or Mac OS, ''Edit/Copy Figure'' from figure-window menu to copy figure to MS Wordtext box.',...
    '     If using Linus (e.g., Ubuntu), save to a graphics format and insert picture into word processing document.',...
    '',...
    'S is a structure in the workspace, with stored  ',...
    'time series and and year vector,'...
    'sample mean, median, minimim, maximum, standard deviation, skewness',...
    'and sample size. View contents of S by typing S at the command',...
    'prompt, or by opening the Workspace window(through Desktop at top menu of',...
    'Command Window and clicking on S'};
 
msgbox1(message2,'message2');


