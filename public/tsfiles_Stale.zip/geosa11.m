% geosa11.m  regression with time series
%
%
% Last revised 2018-12-23
%
%*** UW FUNCTIONS CALLED
%
% acf: autocorrelation function and approximate 95% confidence bands
% armawht1: residuals from ARMA modeling of time series in matrix
% crospul2: % Makes array of indexes to be used in crossvalidation in regression models
%
% dwstat:  Durbin-Watson statistic on residuals of a MLR model
% durbinwt.mat --  TABLE needed by dwstat
% hatmtx: hat matrix from multiple linear regression
% lagyr3:  build a lagged predictor matrix for a time series matrix
% mce1:  approximation to minimum covering ellipsoid for identifying extrapolations
% menua1:  toggle menu to select subset of names from list of names
% portmant: portmanteau lack-of-fit test on ARMA model residuals
% rederr:  verification statistics for a climate reconstruction
% sepred2:  standard error of prediction and extrapolation indicator for regression
% stepvbl1: choose next variable to enter regression based on maximum R-squared
%
%*** TOOLBOXES NEEDED
%
% STATS
% IDENT
%
%
% Data example: predictand: Sacramento R flow, water-year total
%    predictors: tree-ring chronologies, possibly prewhitened, possibly lagged
% Method: Multiple linear regression (MLR), stepwise so that next variable entered
%    gives maximum R-squared when used with predictors already in model
%
% TOPICS
% -transformation of predictand
% -whitening and lagging of tree-ring chronolgoies as regression predictors
% -analysis of residuals, with special attention to serial correlation
% -calibration statistics: R-squared, adjusted R-squared, RMSE
% -confidence interval for regression weights
% -uncertainty in reconstruction:  standard error of estimate
%
% USER ACTIONS
% -selects the predictand variable (only one possible), and specifies whether
%   to log transform
% -selects up to 5 chronologies to be used to form the predictors
% -specifies whether to use original or prewhitened chronologies
% -specifies no-lag or distributed lag model
% -if distributed-lag model, user specifies maximum positive and negative lag
%   to be allowed on the predictors
% -specify calibration period, or accept full overlap as default
% -specifies whether or not to run in cross-validation mode
% -Interactively prompted whether to add another predictor to model. Predictor
%   entered give highest R-squared in model that already includes the other
%   predictors lready in model
% -specifies whether to save reconstructed time series in a .mat file, and if
%   so, prompted for the file name
%
%
% Data are (1) annual flow (water-year total) of Sacramento River, and
% (2) up to 5 chronologies of the users choice
%
%*** UW FUNCTIONS CALLED
%
% armawht1
% crospul2
% lagyr3
% menudm1
% dwstat
% acf
% portmant
% rederr
% stepvbl1
% durbinwt.mat -- at table
% sepred2
% hatmtx
% mce1
%
% menua1
%
%
%*** MAIN FUNCTIONS USED
% Hard code
%
%*** NOTES
%
% Revised 2015-01-26:  1)  recognize if version 2014B or later of
% Matlab, 2) to fix a problem with call to stem if so,3) raise size of
% symbol for extrapolations, 4) change xlim to limit xaxis in fig 6 to
% range of time coverage of data
%
% Revised 2018-12-23. Cosmetic


clear;
close all; % close any open figure windows


% Hard code
%datdir='c:\geos585a\'; % default directory with class data and scripts
datdir=cd; % directory with input data; assume current directory
datfile='Spring19'; % default .mat file with input data
maxchron=5; % maximum number of chrons to use in regression model
maxparam=3; % maximum allowable sum of AR and MA orders

% Matlab changed the wayfunction "sten" works with release R2014b.  Must
% identify version to use correct code later on
vR2014b='8.4.0.150421 (R2014b)'; 
if verLessThan('matlab',vR2014b)
    kstem =1;
else
    kstem= 2;
end



%********  INTRODUCTORY MSG

message1 = {'Multiple Linear Regression (part 1)',...
    'Validating the Regression Model (part 2)',...
    '',...,
    'Multiple linear regression for the prediction or reconstruction of ',...
    'one time series (predictand) from observations on other time series ',...
    '   (predictors).',...
    '',...
    'In part 1, predictor enter forward stepwise in order of their reduction of ',...
    'residual variance. At each step, you can look over the regression ',...
    'statistics and results of residuals analysis.',...
    '',...
    'In part 2, you initially specify how many steps the model should run, ',...
    'and the predictors enter through that many steps.  At each step, the model',...
    'is cross-validated. Graphs are produced showing change in cross-validation',...
    'accuracy with increasing model complexity.',...
    '',...
    'Cross validation is leave-n-out rather than leave-1-out, where n is ',...
    '1+2*maxlag and maxlag is the maximum positive or negative lag allowed ',...
    'in the model'};
msgbox1(message1,'message1');

kmenpart=menu('Choose',...
    'Part 1 -- Assignment 11 (non-validation mode)',...
    'Part 2 -- Assignment 12 (validation mode)',...
    'Abort');


if kmenpart==1
    part='One';   % part 1 deals with MLR excluding reconstruction,
    % standard error of prediction, validation, extrapolations
elseif kmenpart==2
    part='Two';
else
    return;
end;


% Obsolet Option for wide lines
% wideline=questdlg('Wide-line graphics?');
wideline='No';
if strcmp(wideline,'Yes');
    LW1=2;
    MS1=20;
else;
    LW1=0.5;
    MS1=8;
end;


% store path/directory to data and class scripts
path1=datdir;


clc
windlist = char('Figure Windows:',...
    'TSP1-time series plots (tsp) of observed and reconstructed predictand', ...
    '   for calibration period, along with R-squared and other statistics',...
    'EQN- regression equation, with 99% CI for parameters',...
    'Res1- residuals analysis, non-time-series aspects',...
    'Res2- resisuals analysis, time series aspects',...
    'Valid- cross-validation summary',...
    'REC - time series plot of reconstructiona',...
    ' ');
varlist = char('Key Stored Variables:',...
    'ycm yrc -- calibration period time series of predictand and time vector',...
    'yrec, yrrec-- reconstruction and its time vector',...
    'RE -- reduction-of-error statistic',...
    'RSQ -- R-suared statistic for various steps in stepwise',...
    'RMSEc -- calibration root-mean-square error, step by step',...
    'RMSEv -- validation root-mean-square error, step by step',...
    'rmsev -- validation root-mean-square error, final equation',...
    'seest -- standard error of the estimate, or standard errror of regression',...
    'sep -- standard error of prediction');


% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string
clear answer lineNo dlgTitle def prompt



%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename 
eval(['load ' pf1]);


% Load table with Durbin-Watson prob points (0.01 single sided)
filedurbin='durbinwt.mat';
pfdurbin = fullfile(path1,filedurbin);
eval(['load ' pfdurbin ';']);

% Hard code background of figures
bkgcolor='White';
switch bkgcolor;
    case 'Black';
        whitebg([0 0 0]);
        colnull=[1 1 1];
    case 'White';
        whitebg([1 1 1]);
        colnull=[0 0 0];
end;
close all;


%****** PROMPT FOR WHICH VARIABLE-SET PREDICTAND AND PREDICTORS TO COME FROM

kmenpred = menu('Which data set is predictand to be selected from?',...
    {'V2','V1'});
if kmenpred==1;
    V=V2; % predictand data set (one variable from set will be predictand);
else
    V=V1; % predictand data set (one variable from set will be predictand);
    
end;

kmenpred = menu('Which data set is predictors are to be selected from?',...
    {'V2','V1'});
if kmenpred==1;
    U=V2; % predictor data set (predictors to be selected from this set)
else
    U=V1; % predictor data set (predictors to be selected from this set)
end;


clear V1 V2;



%******* ASSIGN VARIABLE NAMES TO 1) STRUCTURE VARIABLES WITH PREDICTORS AND PREDICTAND, AND
% 2) DATA LABELS FOR PREDICTORS AND PREDICTAND
%
% Note: the names are a bit of a relict from earlier versions in which tree-ring variables were always
% the predictors and  a streamflow variable the predictand. I kept the convention for convenience of
% recoding

strtree= 'U'; % structure with predictors
dltree = U.label; % data label for predictors (e.g., Index)
strflow= 'V'; % structure with predictand
dlflow = V.label; % data label for predictand (e.g., P)


%******* CHOOSE THE PREDICTAND TIME SERIES

Lpick=menua1(V.seriesmenu,'CHOOSE PREDICTAND SERIES',1,1); % menu for series selection
iy = find(Lpick);
clear Lpick;


%--- STORE PREDICTAND AND TIME COVERAGE INFO
y = V.tsm(:,iy); % predictand data, full length
yry = V.time; % time vector for predictand
yunits=V.units{iy};
ylaby=V.label{iy};
yname = V.name{iy};
yid = V.id{iy};

% Pull valid data only
Ltemp = ~isnan(y);
y=y(Ltemp);
yry=yry(Ltemp);
clear Ltemp;

% Set some string info on time coverage
yrgoy=min(yry);  yrspy = max(yry);
nyry=length(yry);
stryry = sprintf('%4.0f-%4.0f',yrgoy,yrspy);
strtemp = sprintf('%3.0f',nyry);
strny = ['\itN\rm = ' strtemp ' ' lower(V.increment)];


%*****************  OPTIONALLY TRANSFORM PREDICTAND

klog = menu(['Tranformation of ' V.what ', ' yname],...
    'No transformation','Log-10 Transformation');
switch klog;
    case 1;
        % no action needed, y is the predictand series
        stry1=ylaby;
        stry2=[stry1 '(' yunits ')'];
    case 2;
        if any(y<=0);
            error([yname ' has data <=0 and so cannot be log transformed']);
        end;
        y=log10(y);
        % label for predictand (e.g., log10(P)
        stry1= ['Log10(' ylaby ')'];
        stry2= ['Log10(' ylaby ')'];
    otherwise;
        error('Invalid choice of klog');
end


%**************** CHOOSE POOL OF POTENTIAL PREDICTORS

clear nms;

nx1 = size(U.tsm,2); % number of series in the input file
Lpick=menua1(U.seriesmenu,'CHOOSE POOL OF POTENTIAL PREDICTORS',nx1,1); % menu for series selection
ixser = find(Lpick);
clear Lpick;

nms = U.id(ixser);
nchron = length(ixser); % number of predictors in pool
X=U.tsm(:,ixser); % time series matrix of pool of predictors
yrX = U.time; % time vector for X
% Assign sequential variable names to the selected predictor series
for n = 1:nchron;
    vblnm{n}=['X' num2str(n) '-' nms{n}];
end;

% Trim all-NaN rows off X
Ltemp = (all( (isnan(X))'))';
if any(Ltemp);
    X(Ltemp,:)=[];
    yrX(Ltemp,:)=[];
end;
yrgoX=min(yrX);
yrspX=max(yrX);
nyrX = length(yrX);



%--------  STATUS
%
% X   is matrix of selected predictor series
% yrX  time vector for X
% y   predictand variable, or its log-transform
% yry   time vector for y
%
% Note:  X and y could have NaNs.  Still need to screen


%-------------  USE ORIGINAL OR WHITENED CHRONS?

answer=questdlg('Prewhiten the Predictors?');
switch answer
    case 'Yes';
        kwhite=1;
        txtwhite='Prewhitened Predictors';
        % Call armawht1.m to do the prewhitening.  Will set arguments as follows:
        %  X -- input time series, defined above
        YRS= []; % which specifies fit whitening model to all available times of data
        %  yrX -- time vector for X, as defined above
        %  maxparam -- maximum allowable p+q order, as hard-coded at start of function
        PQ = []; % , meaning let Akaike FPE pick the best model
        kopt1=[2 1 1];
        %    2 - residuals generated for fitting period only (which here is all data)
        %    1 - allow AR or ARMA models
        %    1 - use FPE as criterion for best model
        [X,mods,varaut,Q,A3,SE2]=armawht1(X,yrX,YRS,maxparam,PQ,kopt1);
        % Returned info:
        % X -- the whitened predictors
        %   Note: if FPE of all tried models greater than variance of original series,
        %     no model is fit, and original chron is returned
        % mods -- cell array of strings telling the model fit
        % varaut -- % variance due to model autocorrelation
        % Q -- portmanteau statistic and its P-value for the acf of the model residuals,
        %    or if no model selected, of the acf of the original chron
        % A3, SE2 -- lags 1-3 of the acf of the model residuals, or if no model selected,
        %   of the original series.  SE2 has large-lag standard errors as defined in acf.m
    case 'No';
        kwhite=2;
        txtwhite='Non-whitened Predictors';
    case 'Cancel';
        error('Why on earth did you pick cancel?');
end


%********************  OPTIONAL LAGGING OF PREDICTORS

answer = questdlg('Include Lagged Predictors?');
switch answer;
    case 'Yes';
        klag=1;

        % Call lagyr3.m to build matrix of lagged predictors.  Order of columns is
        % first the non-lagged, then the -1, -2, ..., then the +1, +2, ...
        kneglag = menu({'Choose number of','negative lags'},...
            '1','2','0');
        kposlag = menu({'Choose number of','positive lags'},...
            '1','2','0');
        if kneglag==3 & kposlag==3;
            error('Cannot specify no neg and no pos lags if picked ''include lagged predictors''');
        end

        if kneglag==3;
            kneglag=0;
        end
        if kposlag==3;
            kposlag=0;
        end


        ndelay=0; % nonzero if an expected delay in time in initial response
        [X,yrdummy] = lagyr3(X,[yrgoX yrspX],[ndelay kneglag,kposlag]);

        % Build the predictor names corresponding to cols of output X
        for k = 1:nchron; % 0 lagged
            if k<=9;
                mtop=2;
            else
                mtop=3;
            end
            prdnm{k}=[vblnm{k}(1:mtop) 'L0'];
        end
        numk=nchron;
        if kneglag>0;
            for klag=1:kneglag;
                for k=1:nchron;
                    if k<=9;
                        mtop=2;
                    else
                        mtop=3;
                    end
                    numk=numk+1;
                    prdnm{numk}=[vblnm{k}(1:mtop) 'N' num2str(klag)];
                end
            end
        end
        if kposlag>0;
            for klag=1:kposlag;
                for k=1:nchron;
                    if k<=9;
                        mtop=2;
                    else
                        mtop=3;
                    end
                    numk=numk+1;
                    prdnm{numk}=[vblnm{k}(1:mtop) 'P' num2str(klag)];
                end
            end
        end
        
    case 'No';
        kneglag=0; kposlag=0;
        for k = 1:nchron; % 0 lagged
            if k<=9;
                mtop=2;
            else
                mtop=3;
            end
            prdnm{k}=[vblnm{k}(1:mtop) 'L0'];
        end
    case 'Cancel';
        error('Why on earth did you cancel from prompts for choosing lags');
end

npotent = size(X,2); % number of potential predictors in pool


%***** Prompt for maximum number of steps to allow model to run
if strcmp(part,'Two');
    prompt={'Stop model after step:'};
    def={int2str(npotent)};
    dlgTitle='Maximum number of steps to run model';
    lineNo=1;
    answer=inputdlg(prompt,dlgTitle,lineNo,def);
    nsteps = str2num(answer{1});
else;
    nsteps=npotent;
end;



%************** STATUS
%
% Have now finished building lagged predictor matrix of original or
% whitened chrons.  Have the following:
%
% X, yrX --  the lagged predictor matrix and its time vector
% prdnm{}   variable codes (e.g., X1L0  X1N1...) for the cols of X
% vblnm{}   chronology names tying X1,X2,... to chronologies
% Miscellaneous output from whitening by armawht1.m
%
% y, yry  -- flow data and time vector
% yrgoy, yrspy -- first and last time in yry
% No screening has been done yet for the variable time coverage by
% the different variables in X



%************** COMPUTE THE  CALIBRATION PERIOD
%
% This longest possible is the period for which all variable (the predictand and the current
% and possibly lagged predictors) have valid data

L1 = yrX>=yrgoy & yrX<=yrspy; % pointer to flow period in rows of X
if npotent>1;
    L2 = (~any(isnan(X')))'; % pointer to rows of X with no NaN in any column
else
    L2=   ~isnan(X);
end

L3 = L1 & L2;  % pointer to longest possible calibration period
yrc = yrX(L3);  % time vector for longest possible calib period
yrgoc=min(yrc); % first time (e.g., year) of ...
yrspc=max(yrc);

% Prompt user to allow to constrain full calibration period
txtp1=['First Year (>=' int2str(yrgoc) ')'];
txtp2=['Last Year (<=' int2str(yrspc) ')'];
prompt={txtp1,txtp2};
def={num2str(yrgoc),num2str(yrspc)};
if strcmp(part,'One');
    titp1='Specify Calibration Period';
elseif strcmp(part,'Two');
    titp1='Specify Calibration Period, press OK; then get a cup of coffee';
end;


lineNo=1;
answer=inputdlg(prompt,titp1,lineNo,def);

yrgoc1 = str2num(answer{1});
yrspc1 = str2num(answer{2});
if yrgoc1<yrgoc | yrspc1>yrspc;
    error('Specified calibration period outside coverage by all variables');
end
if (yrspc1-yrgoc1+1) < 30;
    error('Minimum full calibration period length is 30 yr');
end



if yrgoc1~=yrgoc | yrspc1~=yrspc;
    yrgoc=yrgoc1; yrspc=yrspc1;
    L3=yrX>=yrgoc & yrX<=yrspc;  % revised pointer to full calib period in X
    yrc = yrX(L3);  % time vector for full calib period
end

Lcy = yry>=yrgoc & yry<=yrspc;  % pointer to full calib pd in y
nyrc = length(yrc);



%***************** GET THE CALIBRATION PERIOD TIME SERIES SEGMENTS

yc = y(Lcy);  % predictand
Xc = X(L3,:);



%**********************  WANT TO DO CROSSVALIDATION TOO? (TIME CONSUMING)

%kvalid = questdlg('Validate?','Validation Option','Yes','No','Null');
%if strcmp(kvalid,'Yes');
%   kvalid=1;
%elseif strcmp(kvalid,'No');
%   kvalid=2;
%end
% kvalid==1 specifies to do validation;  kvalid==2 says do not do validation

if strcmp(part,'One');  % no-validaton mode
    kvalid=2;
else; % validation mode
    kvalid=1;
end;


%------------ Initialize storage for crossvalidation variables
RMSEv = repmat(NaN,npotent,1); % validation root-mean-square error
RMSEc = repmat(NaN,npotent,1); %  calibration root-mean-square error
RE = repmat(NaN,npotent,1); % reduction of error, from cross validation
RSQ  = repmat(NaN,npotent,1); % R-squared (calibration)


%******************** STEPWISE CALIBRATION ( & possibly CROSSVALIDATION)

alpha = 0.05; % for confidence interval around the coefficients
Lin=logical(zeros(1,npotent)); % initialize pointer to potental variables in equation
Lmask = logical(zeros(1,npotent)); % do not mask any variables from consideration
iord =repmat(NaN,1,npotent); % keeps track of order of entry
nin=0; % number of predictors now in model

klook=0;
kw1=1;
while kw1==1;
    if strcmp(part,'One');
        strmen2={'Begin modeling or add another predictor',...
            'Review results','Quit'};

    elseif strcmp(part,'Two');
        strmen2={'Begin modeling or add another predictor',...
            'Review results','Generate reconstruction and quit'};
    end;

    if strcmp(part,'One'); % no-validation mode
        kmen2=menu('Choose one',strmen2);
    elseif strcmp(part,'Two');   % validation mode
        if nin==0;
            kmen2=1;

        elseif nin>0 & nin<nsteps;
            if klook==1;
                kmen2=1;
                klook=0;
            else;
                kmen2=2;
                klook=1;
            end;
        else; % nin==nsteps;
            if klook==1;
                kmen2=3;
            else;
                kmen2=2;
                klook=1;
            end;

        end;
    end;






    %kmen2 = menu('Choose one:',...
    %  'Begin Modeling or add another predictor',...
    % 'Review results','Generate Reconstruction');

    if kmen2==1;
        if nin==npotent;
            warndlg('All predictors already in equation');
        else
            % Get pointer to col of Xc (predictor variables) indicating the variable that
            % along with the predictors already in the equation, gives highest R-squared
            ipick = stepvbl1(yc,Xc,Lin,Lmask);
            Lin(ipick)=1;
            Xds =Xc(:,Lin);
            [b,bint,e,eint,s] = regress(yc,[ones(nyrc,1) Xds],alpha);
            XS=[ones(nyrc,1) Xds];
            nin=nin+1;
            iord(ipick)=nin;
            yhshort = [ones(nyrc,1) Xds] * b; % predicted flow for calib period
            eshort = yc -yhshort; % residuals

            % Compute adjusted R-squared
            RSQa = 1 - ((nyrc-1)/(nyrc-nin-1))*(1-s(1));

            % Compute standard error of estimate
            %  (See Weisberg, p. 44, 1985). Sqrt of the residual mean square)
            seest=  sqrt(sum(eshort .* eshort)/(nyrc-1-nin));

            if kvalid==1; % desire crossvalidation
                RSQ(nin)=s(1);

                % square root of mean square error or regression
                RMSEc(nin) =   sqrt( sum(eshort .* eshort)/(nyrc-1-nin));

                % Cross validation
                IX = crospul2(nyrc,kneglag,kposlag); % pointer to crossvalidation rows of yc
                yhcv = repmat(NaN,nyrc,1); % to store crossvalidation predictions
                for ncv = 1:nyrc; % loop over crossvalidation models
                    ix = IX(:,ncv);
                    nsum = sum(ix); % number of time of calibration data for this model
                    ytemp = yc(ix); % predictand
                    Xdcv = [ones(nsum,1) Xds(ix,:)]; % predictor matrix
                    bcv = regress(ytemp,Xdcv);
                    yhcv(ncv) = [1 Xds(ncv,:)] * bcv; % predicted value for this time
                end
                ecv = yc - yhcv; % crossvalidation error time series
                RMSEv(nin) =     sqrt(sum(ecv .* ecv)/nyrc);
                [mae,rmse,re]=rederr(mean(yc),mean(yc),yhcv,yc);
                RE(nin)=re(1);
                rmsev=RMSEv(nin);


            end

            close all;
        end
    elseif kmen2==2; % review results
        figure(1)
        set(gcf,'Name','TSP1');

        subplot(2,1,1);
        % tsp of obs and recon
        hp1a = plot(yrc,yc,yrc,yhshort,[min(yrc) max(yrc)],[mean(yc) mean(yc)]);
        cord=get(gca,'ColorOrder');
        set(hp1a(1),'LineWidth',1.5);
        set(hp1a(3),'Color',colnull);
        legend('Observed','Predicted');
        title(['Calibration Period ' stry1]);
        xlabel('Year');
        ylabel(stry2);
        set(gca,'Xgrid','on');

        % Text summary of calibration information
        subplot(2,1,2);

        txt1b1 = ['Predictors: ' txtwhite];
        txt1b2 = ['# of variables = ' int2str(nchron)];
        txt1b3 = ['# negative lags allowed: ' int2str(kneglag)];
        txt1b4 = ['# positive lags allowed: ' int2str(kposlag)];
        txt1b4a =['# potential predictors: ' int2str(npotent)];

        txt1b5 = sprintf('%4.0f-%4.0f',yrgoc,yrspc);
        txt1b5 = ['Calibration Period: ' txt1b5];

        txt1b6 = ['# of predictors in final equation = ' int2str(nin)];

        txt1b7 = sprintf('%6.3f',s(1));
        txt1b7a = sprintf('%6.3f',RSQa);
        txt1b7a =['\itR_{a}^{2}\rm = ' txt1b7a];


        txt1b7 = ['\itR^{2}\rm = ' txt1b7 ';   '  txt1b7a];

        txt1b8 = sprintf('   F = %6.2f,  p-value = %6.5f',s(2),s(3));

        % RMSE of calibration, which is same as standard error of regression
        txt1b9=sprintf('std error of estimate = %8.4f',seest);

        text(0.05,0.95,txt1b1);
        text(0.05,0.85,txt1b2);
        text(0.05,0.75,txt1b3);
        text(0.05,0.65,txt1b4);
        text(0.05,0.55,txt1b4a);
        text(0.05,0.45,txt1b6);
        text(0.05,0.35,txt1b5);
        text(0.05,0.23,txt1b7);
        text(0.05,0.13,txt1b8);
        text(0.05,0.00,txt1b9);

        if kvalid==1;
            % Reduction of error text
            txtv1 = sprintf('%5.2f',RE(nin));
            txtv1 = ['RE = ' txtv1];

            % RMSE from cross validation
            txtv2 = sprintf('%8.4f',rmsev);
            txtv2 = ['RMSE_{v} = ' txtv2];
            text (0.70,0.25,txtv1);
            text(0.70,0.02,txtv2);
        end
        set(gca,'Visible','off');

        % EQUATION, with 99% CI for parameters
        figure(2);
        j=find(Lin);
        axh2 = axes;
        xlim2=get(gca,'XLim');
        ylim2=get(gca,'YLim');
        strconst= sprintf('Constant  %8.4f   [%8.4f  %8.4f]',b(1), bint(1,:));
        text(0.05,0.8,strconst);
        %inc=diff(ylim2)/10;
        inc=.05;
        for n = 1:nin;
            ypos = 0.78-n*inc;
            prednm =[int2str(n) '(' int2str(iord(j(n))) ')-' prdnm{j(n)}];
            strb = sprintf('%8.4f   [%8.4f  %8.4f]',b(n+1),bint(n+1,:));
            text(0.05,ypos,[prednm '  ' strb]);
        end
        strtemp = sprintf('%5.1f',100*(1-alpha));

        for n = 1:nchron;
            text(0.75,0.95-inc*n,vblnm{n});
        end
        txttit2=['Estmated Coefficients and ' strtemp '% Confidence Interval'];
        text(.1,1.0,txttit2);
        set(gca,'Visible','off');
        set(gcf,'Name','EQN');

        %----------- basic residuals plots and histogram
        figure(3);
        set(gcf,'Name','Res1');


        % Scatter of residuals vs first predictor to enter equation
        subplot(2,2,1);
        jfirst=find(iord==1);
        Xthis=Xc(:,jfirst);
        delx =  abs(range(Xthis)/10);
        dele = abs(range(eshort)/10);
        plot(Xc(:,jfirst),eshort,'o');
        set(gca,'XLim',[min(Xthis)-delx max(Xthis)+delx],...
            'YLim',[min(eshort)-dele max(eshort)+dele]);
        lsline;
        xlabel(prdnm(jfirst));
        ylabel('Residuals');
        title('Resids vs Predictor#1');

        % Scatter of residuals vs second most important predictor
        subplot(2,2,2);
        if nin>1;
            jsecond=find(iord==2);
            Xthis=Xc(:,jsecond);
            delx =  abs(range(Xthis)/10);
            dele = abs(range(eshort)/10);
            plot(Xthis,eshort,'o');
            set(gca,'XLim',[min(Xthis)-delx max(Xthis)+delx],...
                'YLim',[min(eshort)-dele max(eshort)+dele]);
            lsline;
            xlabel(prdnm(jsecond));
            ylabel('Residuals');
        end
        title('Resids vs Predictor #2');

        % Scatter of residuals vs predicted values of flow
        subplot(2,2,3);
        delx =  abs(range(yhshort)/10);
        dele = abs(range(eshort)/10);
        plot(yhshort,eshort,'o');
        set(gca,'XLim',[min(yhshort)-delx max(yhshort)+delx],...
            'YLim',[min(eshort)-dele max(eshort)+dele]);
        lsline;
        xlabel(['Predicted ' stry1]);
        ylabel('Residuals');
        title('Resids vs Predictand');

        % Histogram of residuals
        subplot(2,2,4);
        histfit(eshort);
        title('Histogram of Residuals with Normal Curve');

        %------------- Residuals plots - autocorrelation of residuals
        figure(4);
        set(gcf,'Name','Res2');

        %------ Time series plot of residuals
        
        % trend line to resids
        Xtemp = [ones(length(yrc),1)  yrc];
        [Btemp,BINTtemp,Rtemp,RINTtemp,STATStemp] = regress(eshort,Xtemp);
        se = STATStemp(4) ; % estimate of error variance
        btemp = Btemp(2); % slope (regression coef on time)
        bint = BINTtemp(2,:);
        if sum(sign(bint)) == 0;

            txt_slope = ['slope(red) = ' num2str(btemp) ',  NOT significant at alpha=0.05'];
        else
            txt_slope = ['slope(red) = ' num2str(btemp) ',  significant at alpha=0.05'];
        end
        
        denom =  sum((yrc - mean(yrc)) .^2); % sum of squares of departures of predictor (time)
        b_var = se/denom; % variance of the estimated slope ;
        b_std=sqrt(b_var); % standard deviation of the slope
        t_sample = abs((btemp-0)/b_std); % computed t statistic, assuming population value of 0 for slope
        df = length(yrc-2); % degrees of freedom for test of signif of slope
        p_val = 2*(1-tcdf(t_sample,df));


        yh=Xtemp*Btemp;
        
        ha4a=axes('Position',[.1 .7 .85 .23]);
        if length(yrc)<150;
            plot(yrc,eshort,yrc,eshort,'o');
        else
            plot(yrc,eshort,yrc,eshort);
        end
        hold on;
        plot(yrc,yh,'Color',[1 0 0]);
        xlims = get(gca,'XLim');
        ylims = get(gca,'YLim');
        xpt1 = xlims(1)+0.01*diff(xlims);
        ypt1 = ylims(2)-0.01*diff(ylims);
        line([yrgoc yrspc],[0 0]);
        text(xpt1,ypt1,txt_slope,'HorizontalAlignment','Left','Verticalalignment','Top');
        title(['Time Series Plot of Residuals, p_{slope}=' num2str(p_val)]);
                
        hold off;
        


        % Lagged scatterplot of residuals t vs t-1
        ha4b = axes('Position',[0.1 0.3 0.25 0.3]);
        et = eshort;  et(1)=[];
        etm1 = eshort; etm1(nyrc)=[];
        re = corrcoef([et etm1]);
        re=re(1,2);  % correlation coefficient, e(t) vs e(t-1)
        strre = sprintf('%5.2f',re);
        strre = ['\itr(1)\rm =' strre];
        plot(etm1,et,'.');
        lsline;
        title('Lagged Scatterplot');
        ylabel('\ite(t)\rm');
        xlabel('\ite(t-1)\rm');
        xlim4b=get(gca,'XLim');
        ylim4b=get(gca,'YLim');
        xpnt = xlim4b(2)- 0.4 * (xlim4b(2)-xlim4b(1));
        ypnt = ylim4b(1) + 0.05 * (ylim4b(2) -ylim4b(1));
        text(xpnt,ypnt,strre,'FontSize',8);
        
        % ACF of regression residuals, with  approx 95% CI
        ha4c = axes('Position',[0.5 0.3 0.35 0.3]);
        [r,se2r,r95dum]=acf(eshort,20,[1 1]);
        t = (1:20)';
        if kstem==1;
            hacfa=stem('v6',t,r);
        else
            hacfa=stem(t,r);
        end
        
        hold on;
        hacfb=plot([1 20],[0 0],t,se2r,'r--',t,-se2r,'r--');
        if kstem==1;
            set(hacfa(1),'Color',cord(1,:));
            set(hacfa(2),'Color',cord(1,:));
        else
            hacfa.Color=cord(1,:);
        end
        
        set(hacfb(1),'Color',colnull);
        set(hacfb(2),'Color',cord(2,:));
        set(hacfb(3),'Color',cord(2,:));
        title('ACF of Residuals');
        xlabel('Lag (yr)');
        set(gca,'YLim',[-0.8 0.8]);
        text(5,max(se2r),'95% CI','VerticalAlignment','bottom','FontSize',8);
        hold off;

        % Text axes with portmanteau and durbin-watson statistics
        ha4d = axes('Position',[0.01 0.05 0.9 0.2]);
        if nin<=5; % & length(eshort)<=100;
            [d,choice]=dwstat(eshort,durbin.dat,nin);
            txtdw1=sprintf('Durbin-Watson Statistic = %5.2f',d);
            if strcmp(choice,'R');
                txtdw2='Reject';
            elseif strcmp(choice,'U');
                txtdw2='Uncertain Region';
            elseif strcmp(choice,'A');
                txtdw2='Accept';
            end
            text(0.1,0.45,txtdw1);
            text(0.15,0.22,'H_{0}: Zero first order autocorrelation in residuals');
            text(0.15,0.02,...
                [txtdw2 ';  prob level 0.01 (one-sided), 0.02 level (two-sided)']);
        else;
            %if length(eshort)>100;
            %    text(0.1,0.45,['No Durbin Watson Test Possible: N > 100']);
            %else;
            text(0.1,0.45,['No Durbin Watson Test Possible: more than five predictors']);
            % end;

        end
        
        
        
        

        % Portmanteau Q Statistic -- see Ostrom 1990, p 50
        % As implemented, uses first 10 lags of the acf of the regression residuals
        % Applies chi-squared test with 10 df
        [Qport,pval]=portmant(r,nyrc,0,0,10);
        strq = sprintf('Portmanteau Q = %8.4f,  p-value = %6.5f',Qport,pval);
        text(0.1,0.65,strq);
        set(gca,'Visible','off');

        if kvalid==1; % if cross-validation mode
            %------------- Validation plots

            % Crossvalidation plots
            figure(5);
            valtitle=['Validation, step ' int2str(nin) ' of ' int2str(nsteps)];
            set(gcf,'Name',valtitle);
            subplot(2,1,1);
            tt = (1:npotent)';
            hpcv1=plot(tt,RMSEv,'r.',tt,RMSEc,'bo',tt,RMSEv,'r-',tt,RMSEc,'b-');
            title('Cross-validation vs Calibration Statistics');
            set(hpcv1(1),'Color',cord(2,:));
            set(hpcv1(3),'Color',cord(2,:));
            set(hpcv1(2),'Color',cord(1,:));
            set(hpcv1(4),'Color',cord(1,:));

            legend('Validation RMSE','Calibration RMSE');

            %xlabel('Number of Predictors in Model');
            ylabel('RMSE');
            grid;
            set(gca,'XTick',(1:npotent),'XLim',[0.8 npotent+0.2]);

            % R-Squared (calibration) and RE (validation)
            subplot(2,1,2);
            hpcv2=plot(tt,RE,'r.',tt,RSQ,'bo',tt,RE,'r-',tt,RSQ,'b-');
            set(hpcv2(1),'Color',cord(2,:));
            set(hpcv2(3),'Color',cord(2,:));
            set(hpcv2(2),'Color',cord(1,:));
            set(hpcv2(4),'Color',cord(1,:));


            leg5a = 'Calibration \itR^{2}\rm';
            leg5b = 'Validation RE';
            legend(leg5b,leg5a);
            xlabel('Number of Predictors in Model');
            ylabel('Accuracy');
            grid;
            set(gca,'XTick',(1:npotent),'XLim',[0.8 npotent+0.2]);
        else
            rmsev=[];
        end

        figure(1);
    elseif kmen2==3; % Quit, or Generate reconstruction and quit
        if strcmp(part,'One'); % no-validation mode
            % No action required. Bail out here.
        elseif strcmp(part,'Two'); % validation mode
            if klog==2;
                units = 'Log10(MAF)';
            else
                units = 'MAF';
            end

            % Build long-term predictor matrix
            Xall=[ones(nyrX,1) X(:,Lin)];

            % Generate reconstruction and cull non-NaN part
            yrec = Xall  * b;
            L1 = ~isnan(yrec);
            yrec=yrec(L1);
            yrrec = yrX(L1);
            Xgood=Xall(L1,:);

            % Compute standard error of prediction and related quantities
            Lcull = yrrec>=yrgoc & yrrec<=yrspc;  % points to calib-pd times in Xgood
            [hstar,H,sep,extrap] =sepred2(Xgood,Lcull,seest);

            txtsave = 'Reconstruction summary';
            txtsave=char(txtsave,...
                '  ',...
                'RSQ -- Calibration R-square for each step in stepwise',...
                'RMSEc -- Root mean square error of calibration, stewise results',...
                'RMSEv -- Root mean square error of cross-validation, stepwise results',...
                'rmsev -- root mean square error of cross validation',...
                'seest -- standard error of the estimate',...
                'sep -- standard error of prediction',...
                'units -- units of the reconstruction ',...
                'yc  -- calibration period time series of predictand',...
                'yrc -- time vector for yc',...
                'yrec -- reconstructed variable',...
                'yrrec -- time vector for yrec',...
                'yrgoc, yrspc -- first and last years of calibration period');

            set1a = ' units yrec yrrec  txtsave seest sep rmsev ';
            set1b= ' RMSEc RMSEv RSQ yrgoc yrspc yc yrc  ';
            set1 = [ set1a  set1b];

            figure(6);
            set(gcf,'Name','REC');
            if kvalid==1; % validation mode
                h6=plot(yrrec,yrec,[min(yrrec) max(yrrec)],[mean(yc) mean(yc)],'r-',...
                    yrrec,mean(yc)+1*sep,...
                    [min(yrrec) max(yrrec)],[mean(yc)+1*rmsev  mean(yc)+1*rmsev],...
                    yrrec,mean(yc)-1*sep,...
                    [min(yrrec) max(yrrec)],[mean(yc)-1*rmsev  mean(yc)-1*rmsev]);
                cord=get(gca,'ColorOrder');
                set(h6(1),'LineWidth',LW1);

                set(h6(2),'Color',cord(4,:),'LineWidth',LW1); % mean line
                set(h6(3),'Color',cord(3,:),'LineWidth',LW1); % CI  of 1* sepred
                set(h6(4),'Color',cord(2,:),'LineWidth',LW1);
                set(h6(5),'Color',cord(3,:),'LineWidth',LW1); % CI of 1* rmsev
                set(h6(6),'Color',cord(2,:),'LineWidth',LW1);
            elseif kvalid==2;
            end;

            title('Reconstructed Time Series, with Extrapolations Flagged');
            xlabel(V.increment);
            ylabel([ylaby ' (' yunits ')']);
            % xlim=set(gca,'XLim');
            xlim=[min(yrrec) max(yrrec)];
            set(gca,'XLim',xlim);

            Lextrap = extrap==1;
            if nansum(Lextrap)~=0;
                hold on;
                hpextrap=plot(yrrec(Lextrap),yrec(Lextrap),'m.');

                set(hpextrap,'MarkerSize',MS1);

                hold off;
            else
            end

            if kvalid==1;
                legend('Reconstruction','Calibration Mean',...
                    '\pm1 std error of prediction',...
                    '\pm1 RMSE_{v}');
            elseif kvalid==2;
                legend('Reconstruction','Calibration Mean',...
                    '\pm1 * std error of estimate');
            end
            grid;
            % zoom off; % commented out: bug in some combinations of OS and Matlab version

            % Store Results

            Results.when=['Made by geosa11.m on ' datestr(date)];
            Results.Xc=Xc;
            Results.nms=nms;
            Results.X=X;
            Results.yrX=yrX;
            Results.Lin=Lin;
            Results.yrc=yrc;
            Results.yc=yc;
            Results.units=units;
            Results.yrrec=yrrec;
            Results.yrec=yrec;
            Results.calibpd=[yrgoc yrspc];
            Results.RSQ=RSQ;
            Results.RMSEc=RMSEc;
            Results.RMSEv=RMSEv;
            Results.rmsev=rmsev;
            Results.seest=seest;
            Results.sepred=sep;
            Results.extrap=yrrec(logical(extrap));
            Results.hatmtx=H;
            Results.resids=eshort;
            Results.what=char({['S is a structure of data and statistics from running geosa11 in validation model on ' datestr(date)],...
                'S.when = date analysis done',...
                'S.Xc = time series matrix  of pool of predictors, including any lags',...
                '    Unlagged in first columns, followed by negative lags (relative to yc) in next columns',...
                '    followed by positive lags',...
                '.nms{?x1)s names of the predictor series in first few rows of Xc and X',...
                '.X full time series matrix corresponding to Xc',...
                '.yrX vector of time (e.g., years) for X',...
                'Lin (1x?)L pointer to columns of Xc actually used in model',...
                '.yrc = time vector for calibration period',...
                '.yc = observed predictand for calibration period',...
                '.units = units of the predictand and reconstruction',...
                '.yrrec = time vector for reconstruction',...
                '.calibpd  = start and end time (e.g., year) of calibration period',...
                '.RSQ =  col vector of R-Squared values for steps 1,2 ... in stepwise',...
                '.RMSEc =  col vecotr of root mean square erroros of calibration, stepwise',...
                '.RMSEv =  col vecotr of root mean square erroros of validation, stepwise',...
                '.seest = standard error of the estimate from regression',...
                '.sepred =  standard error of prediction -- a vector same length as yrrec',...
                '.rmsev  = root mean square error of validation, for final model (last step)',...
                '.extrap = times (e.g., years) for which reconstructed values are extrapolations',...
                '.hatmtx =  hat matrix from the regression',...
                '.resids = residuals from final model',...
                '',...
                '>>stepwise(S.Xc,S.yc)  .... to run interactive Matlab stepwise tool on all potential predictors',...
                '>>stepwise(S.Xc(:,S.Lin),S.yc) .... to run it on just the predictors used in the reconstruction model'});
            S=Results;

        end; % if strcmp(part,'One')
        kw1=0;


    end
       
end
if strcmp(part,'One');
    nwindows=4;
else
    nwindows = 6;
end

if strcmp(part,'One') % no-validation mode
    message2={'Finished! ',...
        'After running the script, you will find matrix Xc, vector yc and column-cell nms',...
        'in the workspace. ',...
        'Xc is the matrix of predictor time series you have selected, with non-lagged values',...
        '   in the first columns, negative lags in following columns, and positive lags in remaining columns.',...
        'yc is the predictand variable, and nms has the ids of the predictor time series',...
        '',...
        'This script enters variables in order of their reduction in the variance',...
        'of y explained by variables currently in the model. Predictors are entered into the model but',....
        'are not removed. Another approach is to stepwise regression, in',...
        'which variables are entered or removed at each step depending on results of a t-test on the regression',...
        'coefficients. ',...
        '',...
        '>> stepwise(Xc,yc)  ... to run Matlab''s interactive stepwise tool using full set of potential predictors',...
        '>> stepwise(Xc(:,Lin),yc)  ... to run Matlab''s interactive stepwise tool using just the predictors subset',...
        '    in the regression model'};
    disp('here')
elseif strcmp(part,'Two') % validation mode
    message2={'Finished! ',...
        'After running the script, you will find various statistics on the analysis in',...
        'structure S'};
end


msgbox1(message2,'message2');

