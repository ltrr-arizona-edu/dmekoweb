% geosa9.m  correlation analysis
%
% Last Revised 2018-12-23
%
%*** UW FUNCTIONS CALLED
%
% acf: autocorrelation function and approximate 95% confidence bands
% corrpair -- pairwise correlation between cols of matrices
% menua1 -- user menu
% msgbox1
% pearsign -- significance of pearson correlation
% scatter01 -- scatterplot in tercile partitions
% slidcorr --  compute and plot sliding correlations 
% trailnan.m --  remove trailing NaNs from series
% trimnan.m -- remove leading and trailing NaNs from series
% subfcn01 -- build windowed matrix from time series vector
%
%*** TOOLBOXES NEEDED
%
% Stats
%
% Revised 2016-120-05  Information on function calls to message2
%
% Revised 2018-12-23. Cosmetic. 

clear;
close all;


% Hard code
datfile='Spring19'; % default .mat file with input data
datdir=cd; % directory with input data; assume current directory


% store path/directory to data and class scripts
path1=datdir;


% Bivariate analysis.  One series is arbitrarily assigned as the "input", the
% other as the "output."  For example, a river flow series might the input
% and a tree-ring index the output.  Terciles are made on the sorted input series


% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string
clear answer lineNo dlgTitle def prompt

%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename 
eval(['load ' pf1]);  

% Hard code background of figures
bkgcolor='White';
switch bkgcolor;
case 'Black';
   whitebg([0 0 0]);
   colnull=[1 1 1];
case 'White';
   whitebg([1 1 1]);
   colnull=[0 0 0];
end;
close all;




%********  INTRODUCTORY MSG

strmsgi = {'Correlation',...
        '',...
        'Illustrates correlation analysis of two time series, and dependence of  ',...
        'correlation on time interval (sliding-window correlations) and the range of',...
        'the  variables (correlation by terciles).  Significance of correlation ',...
        'depends on size of window as well as on autocorrelation of individual ',...
        'series. Significance may need to be adjusted for multiple comparisons ',...
        '   (Bonferroni adjustment).',...
        '',...
        'You pick two time series, designated x and y, for analysis',...
        'from any combination of the data sets V1, V2 or V3.  You set the '...
        'period for analysis and optionally transform the series.',...
        '',...
        'Windows produced: ',...
        '   Fig 1: Scatterplots of y vs x for terciles of  x',...
        '   Fig 2: Time series plots of windowed correlation between x and y',...
        '   Fig 3: Text summary of windowed-correlation analysis'};

msgbox1(strmsgi,'geosa9');


%****** PROMPT FOR WHICH VARIABLE-SET x and y series  TO COME FROM

kmenpred = menu('Which data set is y series to be selected from?',...
    {'V1','V2','V3'});
if kmenpred==1;
    V=V1; % predictand data set (one variable from set will be predictand);
elseif kmenpred==2;;
    V=V2; % predictand data set (one variable from set will be predictand);
else;
    V=V3;
end;
kset1= kmenpred;

kmenpred = menu('Which data set is x series to be selected from?',...
    {'V1','V2','V3'});
if kmenpred==1;
    U=V1; % predictor data (x)  from ...
elseif kmenpred==2;
    U=V2; 
else;
    U=V3;
end;
kset2=kmenpred;
clear V1 V2 V3;
%pack;



%--- String for time increment

if strcmp(V.increment,'Year');
    time_str1 ='Year';
    time_str2='yr';
else
    time_str1 = V.increment;
    time_str2= V.increment;
end

%******* ASSIGN VARIABLE NAMES TO 1) STRUCTURE VARIABLES WITH x and y, AND 
% 2) DATA LABELS FOR sameD
%
% Note: the names are a bit of a relict from earlier versions in which tree-ring variables were always
% the predictors and  a streamflow variable the predictand. I kept the convention for convenience of
% recoding

strtree= 'U'; % structure with predictors
dltree = U.label; % data label for predictors (e.g., Index)
strflow= 'V'; % structure with predictand
dlflow = V.label; % data label for predictand (e.g., P)



%******* CHOOSE THE PREDICTAND TIME SERIES

Lpick=menua1(V.seriesmenu,'CHOOSE Y SERIES',1,1); % menu for series selection
iy = find(Lpick);
clear Lpick;


%--- STORE PREDICTAND AND TIME COVERAGE INFO
y = V.tsm(:,iy); % predictand data, full length 
yry = V.time; % time vector for predictand
[y,yry]=trimnan(y,yry);
yunits=V.units{iy};
ylaby=V.label{iy};
yname = V.name{iy};
yid = V.id{iy};
ywhat=V.what;
   

% Set some string info on time coverage
yrgoy=min(yry);  yrspy = max(yry);
nyry=length(yry);
stryry = sprintf('%4.0f-%4.0f',yrgoy,yrspy);
strtemp = sprintf('%3.0f',nyry);
strny = ['\itN\rm = ' strtemp ' ' time_str2];


%*****************  OPTIONALLY TRANSFORM PREDICTAND

klog = menu(['Tranformation of ' V.label{iy} ', ' yname],...
   'No transformation','Log-10 Transformation');
switch klog;
case 1;
   % no action needed, y is the predictand series
   stry1=ylaby;
   stry2=[stry1 '(' yunits ')'];  
   strtrany='None';
case 2;
    if any(y<=0);
        error([yname ' has data <=0 and so cannot be log transformed']);
    end;
    y=log10(y);
    % label for predictand (e.g., log10(P)
    stry1= ['Log10(' ylaby ')']; 
    stry2= ['Log10(' ylaby ')']; 
    strtrany='Log10';
otherwise;
   error('Invalid choice of klog');
end

%--- Feedback on choice of y variable
 str = char({'You picked ' yname ' as ''y'' variable',...
     'Next you will be prompted for the ''x'' variable'});
 uiwait(msgbox(str,'Message','modal'));


%**************** CHOOSE predictor (x)

clear nms;
kwh1=1;
while kwh1==1;

    Lpick=menua1(U.seriesmenu,'CHOOSE X SERIES',1,1); % menu for series selection
    ix = find(Lpick);
    if kset1==kset2 & ix ==iy;
        kwh1=1;
        str = ['You picked ' yname ' as predictand; cannot also be predictor'];
        uiwait(msgbox(str,'Message','modal'));
    else
        kwh1=0;
    end
end
clear kwh1 str Lpick;

nx1 = size(U.tsm,2); % number of series in the input file

x = U.tsm(:,ix); % predictor data, full length 
yrx = U.time; % time vector for predictor
[x,yrx]=trimnan(x,yrx);
xunits=U.units{ix};
ylabx=U.label{ix};
xname = U.name{ix};
xid = U.id{ix};
xwhat=U.what;
 

% Set some string info on time coverage
yrgox=min(yrx);  yrspx = max(yrx);
nyrx=length(yrx);
stryrx = sprintf('%4.0f-%4.0f',yrgox,yrspx);
strtemp = sprintf('%3.0f',nyrx);
strnx = ['\itN\rm = ' strtemp ' ' time_str2];


%*****************  OPTIONALLY TRANSFORM x

klogx = menu(['Tranformation of ' U.what ', ' xname],...
   'No transformation','Log-10 Transformation');
switch klogx;
case 1;
   % no action needed, x is the predictor series
   strx1=ylabx;
   strx2=[strx1 '(' xunits ')'];  
   strtranx='None';
case 2;
    if any(x<=0);
        error([xname ' has data <=0 and so cannot be log transformed']);
    end;
    x=log10(x);
    % label for predictor (e.g., log10(P)
    strx1= ['Log10(' ylabx ')']; 
    strx2= ['Log10(' ylabx ')']; 
    strtranx='Log10';
otherwise;
   error('Invalid choice of klogx');
end



%--------  PICK A ANALYSIS PERIOD

% This by default is the overlap of x and y

yron=max([yrx(1) yry(1)]);
yroff = min([yrx(end) yry(end)]);


% Pull data overlap
Lx = yrx>=yron & yrx<=yroff;
Ly = yry>=yron & yry<=yroff;
x=x(Lx);
y=y(Ly);
yrx=yrx(Lx);
yry=yry(Ly);


% Prompt user to allow to constrain full calibration period 
prompt={'Enter period'};
def={num2str([yron yroff])};
titp1='Specify Analysis Period';
lineNo=1;
answer=inputdlg(prompt,titp1,lineNo,def);

yrgocc=str2num(answer{1});
yrgo1=yrgocc(1);
yrsp1=yrgocc(2);
if yrgo1<yron | yrsp1>yroff;
   error('Specified period outside data coverage');
end
if (yrsp1-yrgo1+1) < 15; 
   error('Minimum analysis period 15 observations');
end


%***************** GET THE CALIBRATION PERIOD TIME SERIES SEGMENTS


L = yrx>=yrgo1 & yrx<=yrsp1;
x=x(L);
y=y(L);
yrx=yrx(L);
yry=yry(L);





%--- SCATTERPLOT


uinf{1}={xid,yid};
uinf{2}={xwhat,ywhat};
%uinf{2}={[xid ' ' U.label],[yid ' ' V.label]};
uinf{3}={xunits,yunits};
uinf{4}=V.increment;
uinf{5}=[yrgo1 yrsp1];

figure(1);
S1=scatter01(x,y,yrx,yry,uinf);

strset1={'Scatterplots Completed:'...
        '   Move on to sliding correlations'};
msgbox1(strset1,'Message');

%------- SLIDING R

uinf{6}=.05;
uinf{7}={strtranx,strtrany};
figure(2);
S2=slidcorr(x,y,yrx,yry,uinf);
set(gcf,'Name','Windowed Correlation');

% Text Summary

figure(3);
text(.1,.5,S2);
set(gca,'Visible','off');
set(gcf,'Name','Text Summary');

% STRUCTURE S

S.what = char({['x and y series (after any culling and transformation for geosa9, saved on ' datestr(date)],....
    'S is a structure with fields:',...
    '',...
    'time -- col vector of time (e.g., year) of each element of x and y',...
    'x --- col vector of x time series',...
    'y --- col vector of y time series'....
    'ids {1x2}s cell with ids of x and y'});
s.time=yrx;
S.x=x;
S.y=y;
S.ids = uinf(1);

%------ CLOSING

message2={'Finished!  The input and output series (after optional truncation and transformation) are ',...
    'available in the workspace in structure S',...
    '',...
    'scatter01 -- lagged scatterplots',...
    'slidcorr --- sliding windowed correlation'}; 
 msgbox1(message2,'message2');