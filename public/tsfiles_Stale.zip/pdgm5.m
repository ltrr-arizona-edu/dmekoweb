function Results=pdgm5(x,yr,uiinf)
% pdgm5:  smoothed periodogram spectral analysis, univariate
% Results=pdgm5(x,yr,uiinf);
% Last Revised 2017-05-06
%
%*** INPUT
%
% x (mx x 1)r   time series
% yr (mx x 1)r   year vector for x
%
% uiinf{}  user-interface input information that can either be passed as
%   input argument, or can be prompted for by pdgm5.m.   If uiinf is [],
%   pdgm5 will prompt you for the information.  Otherwise, the contents
%   of uiinf{} should be as follows:
%
%  {1} name (1 x ?)s   name of series
%  {2} yrsa (1 x 2)i  start and end years of analysis period
%  {3} pdvar (1 x 2)r  longest and shortest period lengths (yr) bracketing
%      period range want percentage of variance computed for (e.g., [inf 5])
%  {4} dan1 (1 x ?)i widths of daniel filters to be used for spectral estimates
%  {5} dan2 (1 x ?)i  widths of daniel filters to be used for null continuum
%  {6} kopt (1 x 4)i  options
%    kopt(1): hypothesis test mode
%       ==1 yes
%       ==0 no
%    kopt(2): null hypothesis mode
%       ==1 Periodogram greatly smoothed interactively by Daniell filter
%       ==2 Red noise (AR(1) process)
%       ==3  AR(2) process
%       ==4  AR(1) or AR(2) process, whichever best fits data by modified
%            Akaike criterion (see whit1.m comments)
%       ==5 white noise
%    kopt(3): Bonferroni adjusted confidence interval on plot
%       ==1 no
%       ==2 yes
%    kopt(4): How bandwidth to be specified
%       ==1 input of Daniell spans
%       ==2 input of desired bandwidth; danwt.m gets spans that approximate
%    kopt(5): option for skipping all graphics
%       ==1 regular graphics
%       ==2 skip all graphics and interactive commands (terse mode)
%    kopt(6): significance level for CI on spectrum (setting matters only
%       if kopt(5) ==2; otherwise will do interactively and be allowed 95%
%       or 99%
%       ==1 50%
%       ==2 90%
%       ==3 95%
%       ==4 99%
%       ==5 99.9%
%  {7} labtime (1 x ?)s time increment (e.g., 'Year')
%  {8} dataunit (1 x ?)s units for labeling y axis of time series plot (e.g., 'Index(dimensionless)')
%  {9} nspans (1x1)i desired number of spans for Daniell filtering (if kopt(4)==2);
%    or [] (if kopt(4)==1) 
%  {10} bwspecified (1x2)i desired bandwidths for spectral estimate and null
%       continuum by smoothed periodogram (e.g., [0.05 0.40]); ignored and
%       can be [] if kopt(4)==1
%  {11} mtap1 [1 x 1]r  total decimal fraction of series analysis period (yrsa, in uiinf) to
%   be padded. One half this fraction will be padded on each end.  For
%   example, if mtap==0.1, 0.05, or 5% of data on each end of series will
%   be tapered
%  {12} kpad [1 x 1]i specifies to what next power of 2 to pad
%        kpad (1x1)i  key to power of 2 to which sample will be padded with zeros.
%            kpad==1:  pad to next power of 2. 
%            kpad==2:  pad to a power of two one higher than next power of 2
%            kpad==3:  pad to power of two two higher, ... etc
%               For example, if analysis period is 50 years, kpad==1 gives padded
%                 length of 64 yrs, kpad==2 gives padded length of 128 yr, kpad==3
%                    gives padded length of 256 yr. 
%
%
%*** OUTPUT
% 
% Results: structure with output data (see Results.what from trial run)
% Figure windows and an optional ascii text file summarizing results
%
%*** REFERENCES 
%
% Bloomfield, P., 2000, Fourier analysis of time series: an introduction, second edition: New York, 
% John Wiley & Sons, Inc., 261 p.
%
% See comments in arspectrum.m for reference on theoretical AR spectra
%
%*** UW FUNCTIONS CALLED
%
% danbw2.m
% danwgt1.m
% danwgtn.m (calls danwgt.m)
% whit1.m
% arspectrum.m 
%
%*** TOOLBOXES NEEDED
%
% Statistics
% System Identification
%
%
%*** NOTES
%
% The mains steps are as follows:
%
% 1. Read in, subtract the mean from, taper, and pad a time series.
% 2. Compute the discrete Fourier transform (DFT) of the series.
% 3. Compute the periodogram from the DFT.
% 4. Smooth the periodogram with a series of Daniell filters to get
%	the estimated spectrum.  
% 5. Smooth the periodogram with a separate set of (broader) Daniell
%	filters to get a smooth null continuum.
% 6. Compute 95% confidence interval around the estimated spectrum using
%	the chi-squared distribution.
% 7. Summarize the spectral peaks in table form.
% 
% * If using theoretical best fit AR(1) or AR(2) models as null continuum, 
%   step 5 is not skipped 
%
% Bonferroni adjustment applied is based on Bernoulli inequalities, and
% assumes that number of independent tests in scanning the [0 0.5] f axis
% is 0.5/bw, where bw is the bandwidth of the spectral estimate. 
%
% Revised 2008-3-5.  Option to use white noise or theoretical AR spectrum as null
% continuum (see kopt(2).  Calls are made to whit1 and arspectrum to fit
% the AR models and get their spectra.  The theroretical AR spectrum is
% scaled such that the area under it is equal to the area under the raw
% periodogram. A commented out debug section checks that the areas under 
% the smoothed spectrum and the AR theoretical spectrum approximately
% match. White noise null continuum is computed as arithmetic average of
% raw periodogram.
%
% Revised 2009-3-3.  Modified to make the options for the null continuum
% work in the "simple call" mode
% Revised 2015-01-15.  XLim set on x-axis  of time plots
% Revised 2016-05-15.  Added option for Bonferroni-adjusted confidence
%   interval, appropriate for universal null hypothesis
% Revised 2016-12-13. Added Results.Bonferonni field for record-keeping
% Revised 2016-12-30. Output field for w, the resultant filter used to
%   smooth periodogram
% Revised 2017-05-06.Optional specifying desired bw and letting danwt.m
%   come up with the spans. New option, for terse mode (no graphics). If
%   specify AR(1) null and turns out lag-1 autocorrelation negative, use
%   white noise as null.

%--- STORE INFORMATION ON GRAPHICS WINDOWS TO BE PRODUCED
%
windlist = 'Windows';
windlist=char(windlist,...
   '1 - tsp of raw time series, analysis period',...
   '2 - tsp of raw time series with mean subtracted',...
   '3 - data taper window',...
   '4 - tsp of tapered, padded data',...
   '5 - discrete Fourier Transform',...
   '6 - raw (before smoothing) periodogram',...
   '7 - current version of smoothed periodogram (spectrum) overlaid on raw pdgm',...
   '8 - current version of null continuum overlaind on raw pdgm',...
   '9 - final version of spectrum, with 95% CI and null continuum',...
   '10 - text summary window');


%--- SIZE TIME SERIES

[m1,n1]=size(x);
[m2,n2]=size(yr);
if n1~=1 || n2~=1 || m1~=m2 || any(isnan(x))
   error('x and yr must be col vectors of same length, and no NaN in x');
end
nyr = length(x);
yrs = [min(yr)  max(yr)];

methsDan={'Daniell spans specified','Daniell spans computed from specified desired bandwidth of spectral estimate'};

%--- OPTIONALLY UNLOAD THE CELL VARIABLE WITH THE INPUT CONTROL SPECIFICATIONS (ALL EXCEPT THE DANIEL FILTER LENGTHS)

if ~isempty(uiinf) % If uiinf is not empty ([]) as input argument, unload the specifications into variables
   kmode=2;
   name = uiinf{1}; % name of time series (used in figure windows)
   yrsa = uiinf{2}; % period for analysis
   nyra=yrsa(2)-yrsa(1)+1;
   pdvar = uiinf{3}; % period range for variance computation
   dan1 = uiinf{4};  % daniel widths for smoothing pdgm into spectrum
   dan2 = uiinf{5}; % daniel widths for smoothing pdgm into null continuum
   kopt = uiinf{6}; % options
   labtime=uiinf{7}; % time increment
   dataunit=uiinf{8}; % data units
   nspans =uiinf{9}; % number of desired Daniell spans (or [] if kopt(4)==1
   bwspecified =uiinf{10};% (1x2) or []; if using danbw.m to get spans, this the desired bandwidth
   %     for spectral estimate and for smoothed pdgm estimate of null
   %     continuum
   mtap1 =uiinf{11}; % total tap decimal fraction (e.g., 0.10)
   kpad =uiinf{12}; % padding: 1= next higher power of 2 above sample length; 2 = next higher power of 2, etc
   
   % Compute padded length
   padlen=(2^nextpow2(diff(yrsa)+1)); % to next power of 2 greater than series length
   if kpad~=1
       padlen = padlen*2^(kpad-1);
   end
   
  
   if kopt(1)==1
       khypo='Yes';
   else
       khypo='No';
   end;
   if kopt(2)==1 % Null continuum settings
       what_null='Interactive Daniell smoothing';
   elseif kopt(2)==2
       what_null = 'AR(1) Process';
   elseif kopt(2)==3
       what_null ='AR(2) Process';
   elseif kopt(2)==4
       what_null ='AR(1) or AR(2) Process, whichever is best-fit by modified Akaike criterion';
   elseif kopt(2)==5
       what_null='White Noise Process';
   else
       error('Illegal kopt(2) specified');
   end
   
   kDan = kopt(4); % 1 for starting with spans; 2 for computing spans from desired bw
   methDan =methsDan(kDan);
   
   if kopt(5)==1
       Lterse=false;
   else
       Lterse=true;
   end
   
   % Desired signifcance level for confidence interval (before any
   % Bonferroni)
   siglevs=[50 90 95 99 99.9];
   siglev = siglevs(kopt(6));
  

else % If uiinf is empty input argument, prompt user for specifications
   kmode=1;
   siglev=95; % default signif leve for CI on spectrum
   Lterse=false; % want all the graphics
   % series name, analysis period, period for variance computation
   prompt={'Enter the series name:','Enter the period for analysis',...
         'Enter the period range (yr) for variance computation:',...
         'Enter the time label','Enter the data units'};
   def={'Series 1',int2str(yrs),'[inf 4]','Year','Index(dimensionless)'};
   titpmt1='Input Information';
   lineNo=1;
   answer=inputdlg(prompt,titpmt1,lineNo,def);
   name = answer{1};
   yrsa = str2num(answer{2});
   nyra=yrsa(2)-yrsa(1)+1;
   pdvar = str2num(answer{3});
   labtime=answer{4};
   dataunit=answer{5};
   
   
   nullmodes ={'Greatly smoothed periodogram',...
       'AR(1) process',...
       'AR(2) process',...
       'AR(1) or AR(2) Process, whichever is best-fit by modified Akaike criterion',...
       'White noise process'};
   knull = menu('Choose method for null continuum',nullmodes);
   what_null=nullmodes{knull};
   kopt(2)=knull;
   
   % Bonferroni?
   Bonfmeths={'No Bonferroni adjustment of CI','Bonferroni adjustment of CI'};
   qbonf = questdlg('Widen CI to account for multiple comparisons?');
   if ~strcmp(qbonf,'Yes')
       Bonfmeth=Bonfmeths{1};
       kopt(3)=1;
   else
       Bonfmeth=Bonfmeths{2};
        kopt(3)=2;
   end
      
      
   %---------- Daniel filter lengths
   
 
   kDan = menu('Choose how Daniell spans to be selected',methsDan);
   methDan = methsDan{kDan};
   
   if kDan==1
       if kopt(2)==1
           prompt={'For smoothing pdgm into spectral estimates:',...
               'For smoothing pdgm into null continuum'};
           % compute default for null continuum daniel filter lengths, ensuring that they odd
           d1 = round(nyra/7); d2=round(nyra/5);
           if mod(d1,2)==0
               d1=d1-1;
           end
           if mod(d2,2)==0
               d2=d2-1;
           end
           def={'[7 11]',['[' int2str([d1 d2]) ']']};
           titpmt2='Input the Daniel Filter Lengths';
           lineNo=1;
           answer=inputdlg(prompt,titpmt2,lineNo,def);
           dan1= str2num(answer{1});
           dan2 = str2num(answer{2});
       else
           prompt={'For smoothing pdgm into spectral estimates:'};
           % compute default for null continuum daniel filter lengths, ensuring that they odd
           def={'[7 11]'};
           titpmt2='Input the Daniel Filter Lengths';
           lineNo=1;
           answer=inputdlg(prompt,titpmt2,lineNo,def);
           dan1= str2num(answer{1});
           dan2 = NaN;
       end
   elseif kDan==2
       if kopt(2)==1
           % Plan to compute the Daniell spans given the desired bandwidth and number
           % of spans. Need input of some info
           dan1= [];
           dan2 = [];
           
           prompt={'Number of spans:',...
               'Bandwidth (target) for spectral estimate:'...
               'Bandwidth (target) bandwidth for smoothed pdgm estimate of null continuum'};
           def={'[3]','[0.05]','[0.40]'};
           titpmt2='Daniel Filter settings';
           lineNo=1;
           answer=inputdlg(prompt,titpmt2,lineNo,def);
           nspans= str2num(answer{1});
           bwa = str2num(answer{2});
           bwb = str2num(answer{3});
           bwspecified=[bwa bwb];
           clear prompt def titpmt2 lineNo bwa bwb answer
       else
           % Plan to compute the Daniell spans given the desired bandwidth and number
           % of spans. Need input of some info
           dan1= [];
           dan2 = [];
           
           prompt={'Number of spans:',...
               'Bandwidth (target) for spectral estimate:'};
           def={'[3]','[0.05]'};
           titpmt2='Daniel Filter settings';
           lineNo=1;
           answer=inputdlg(prompt,titpmt2,lineNo,def);
           nspans= str2num(answer{1});
           bwa = str2num(answer{2});
           bwspecified=[bwa NaN];
           clear prompt def titpmt2 lineNo bwa answer
       end
       
       
   else
   end
   
   khypo = questdlg('Hypothesis Test Mode?');
   
end;

% Build frequency label
if strcmp(lower(labtime),'year');
    labfreq='yr^{-1}';
else
    labfreq=[labtime '^{-1}'];
end;


if ~ischar(name);
   error('Series name not character');
end
if yrsa(1)<min(yr) || yrsa(2)>max(yr);
   error('Specified period for analyis outside time range of time series');
end
yra = (yrsa(1):yrsa(2))'; % time vector for analysis period
if pdvar(1)<=pdvar(2);
   error('pdvar should have longer period as first element');
end
if any(pdvar<2);
   error(['pdvar has a value less than 2 ' labtime 's']);
end

if any(mod(dan1,2)==0) || any(mod(dan2,2)==0);
   error('Lengths of Daniel filters must be odd');
end

% Hypothesis test mode:
if strcmp(khypo,'Yes');
   kmen9 = menu('Frame Hypothesis in Terms of What?',...
      'Period','Frequency');
   if kmen9==1;
      prompt={['H0: Spectrum no different than null continuum at this period (' labtime '):']};
      def={'20'};
      tit='Null Hypothesis';
      lineNo=1;
      answer=inputdlg(prompt,tit,lineNo,def);
      keypd=str2num(answer{1});
      keyfreq = 1/keypd; % frequency (cycles per time unit)
   elseif kmen9==2;
      prompt={['H0: Spectrum no different than null continuum at this frequency (1/' labtime '):']};
      def={'.05'};
      tit='Null Hypothesis';
      lineNo=1;
      answer=inputdlg(prompt,tit,lineNo,def);
      keyfreq=str2num(answer{1});
      keypd = 1/keyfreq; % frequency (cycles per year)
   end
else
   keypd=[];
   keyfreq=[];
end

%******************* GET SEGMENT OF TIME SERIES FOR ANALYSIS

L1 = yr>=yrsa(1) & yr<=yrsa(2);  % pointer to analysis period in x,yr
x = x(L1);
xorig=x; % store for return in Results
yr = yr(L1);

stra1=sprintf('%5.0f-%5.0f',yrsa);
stra1 = ['Analysis Period: ' stra1];
stra2 = ['\itN = \rm' int2str(nyra) ' ' labtime];


%***************** PROMPT FOR HOW MUCH OF ENDS OF SERIES TO TAPER, AND FOR PADDED LENGTH

if isempty(uiinf)
    % taper
    prompt={'Enter total decimal fraction of series to taper: '};
    def={'.10'};
    tit='Taper Fraction';
    lineNo=1;
    answer=inputdlg(prompt,tit,lineNo,def);
    mtap1=str2num(answer{1});
    
    % Padding
    prompt={['Enter desired padded length (' labtime '): ']};
    def={num2str(2^nextpow2(diff(yrsa)+1))};
    tit='Desired Padded Length';
    lineNo=1;
    answer=inputdlg(prompt,tit,lineNo,def);
    padlen=str2num(answer{1});
else
end


%*************** OPTIONALLY COMPUTE THE DANIELL SPANS

if kDan==2
    % for spectral estimate
    bwin =bwspecified(1);
    [dan1,bwout1,df,sos]=danbw(bwin,nspans,length(yr),padlen,mtap1);
    bwin =bwspecified(2);
    if kopt(2)==1
        % for null continuum
        [dan2,bwout2,df,sos]=danbw(bwin,nspans,length(yr),padlen,mtap1)
    else
        dan2=[]; % no smoothed pdgm null continuum
    end
else
    nspans=length(dan1);
end


%*******************  PLOT OF RAW TIME SERIES

% Compute mean, standard dev, and variance of time series
xmn = mean(x);
xstd = std(x);
xvar = var(x); % variance of time series, before tapering

if ~Lterse
    figure(1);
    xlims=[yr(1)-(0.01*(yr(end)-yr(1))) yr(end)+(0.01*(yr(end)-yr(1)))];
    hp1=plot(yr,x);
    set(gca,'XLim',xlims)
    cord=get(gca,'ColorOrder');
    title(['Time Series Plot (' stra1 ')']);
    xlabel(labtime);
    ylabel(dataunit);
    xlim=get(gca,'XLim');
    hl1=line(xlim,[xmn xmn]);
    set(hl1,'color',cord(2,:));
    legend(name,'Mean');
    grid;
    %zoom xon; % matlab bug for some OS/versions
else
end

%*******************  PLOT OF DETRENDED (MEAN SUBTRACTED) TIME SERIES

x=x-xmn; % detrended

if ~Lterse
    figure(2);
    hp1=plot(yr,x);
    set(gca,'XLim',xlims)
    title([name ',  With Mean Subtracted (' stra1 ')']);
    xlabel(labtime);
    ylabel([dataunit ' -- departure from mean' ]);
    xlim=get(gca,'XLim');
    hl1=line(xlim,[0  0]);
    set(hl1,'color',cord(2,:));
    grid;
    %zoom xon; % matlab bug for some OS/versions
else
end


%----- FIT AR MODEL TO BE OPTIONALLY USED AS NULL-CONTINUUM PROCESS
%
% If call for AR(1) model, and coefficient turns out positive (negative
% lag-1 autocorrelation),will want to fit a white noise null line. Flag for
% this with Lblue.

Lblue=false;
if any(kopt(2) == [1 2 5]) % fit red noise model as AR model if you have
    %   decided to use that, white noise, or the Daniell smoothed
    %   periodogram for the  null continuum
    [e,k1,vrat,arcs] = whit1(x,1,[2  2]); % specifies AR(1)
    if  kopt(2)==2 && arcs(1)>0
        Lblue=true; % fitted AR(1) model gives blue spectrum
    end
    
elseif kopt(2)==3 % fit AR(2) model
    [e,k1,vrat,arcs] = whit1(x,2,[2  2]); % specifies AR(2)
elseif kopt(2)==4  % fit whichever of AR(1) or AR(2) best fits data
    [e,k1,vrat,arcs] = whit1(x,2,[1  2]); % specifies BEST-FIT OF AR(2)
else
    error('kopt(2) must be 1,2,3,4 or 5');
end


%--- COMPUTE THEORETICAL AR SPECTRUM (FOR OPTIONAL USE AS NULL CONTINUUM

Results.arcs=arcs;
if k1==1 % AR model fit was order 1
    Result_arspectrum=arspectrum([arcs(1,1) NaN],nanvar(e),length(x),0.001,[1 1]);
else
    Result_arspectrum=arspectrum([arcs(1,1:2)],nanvar(e),length(x),0.001,[1 1]);
end
Results.ar_f=Result_arspectrum.f;
Results.ar_y=Result_arspectrum.y;
Results.ar_A=Result_arspectrum.A;



%****************** PLOT OF DATA TAPER WINDOW

    % Taper mtap1/2 of data on each end.  See Bloomfield, p. 84.
    % Compute data window
    ends= fix((mtap1/2)*nyra);
    dwin=ones(1,nyra);
    t=1:ends;
    btemp=0.5*(1-cos((pi*(t-0.5))/ends));  %intermediate variable
    t=nyra-ends+1:nyra;
    ctemp=0.5*(1-cos((pi*(nyra-t+0.5))/ends));  % intermediate
    
    dwin(1:ends)=btemp;
    dwin(nyra-ends+1:nyra)=ctemp;
    
    if ~Lterse
        figure(3);
        hp3=plot(yr,dwin);
        set(gca,'XLim',xlims)
        title(['Data Taper Window, ' stra1])
        set(gca,'YLim',[0 1.1]);
        set(hp3,'Linewidth',1.5);
        xlabel(labtime);
        ylabel('Weight');
        grid;
        % zoom xon;  % matlab bug for some OS/versions
    else
end


%***************** TSP OF TAPERED DATA


% Taper by applying data window to data
x1=x .* dwin';

if ~Lterse
    figure(4);
    xlims=[yra(1)-(0.01*(yra(end)-yra(1))) yra(end)+(0.01*(yra(end)-yra(1)))];
    hp4=plot(yra,x1);
    set(gca,'XLim',xlims)
    title(['Tapered Time Series ('  stra1 ')']);
    xlabel(labtime);
    ylabel('Departure from Mean');
    grid ;
    % zoom xon; % matlab bug for some OS/versions
else
end

% Compute variance of tapered series
xvartap=var(x1); % 


%***************** PAD TIME SERIES WITH ZEROS ON RIGHT HAND SIDE


atemp=padlen-nyra;
btemp=zeros(atemp,1);
x2=[x1;btemp]; % padded, tapered time series for analysis period

if ~Lterse
    yrsb = [yrsa(1) yrsa(2)+atemp];
    yrb=(yrsb(1):yrsb(2))';
    
    
    figure (5);
    xlims=[yrb(1)-(0.01*(yrb(end)-yrb(1))) yrb(end)+(0.01*(yrb(end)-yrb(1)))];
    plot(yrb,x2);
    set(gca,'XLim',xlims)
    title(['Tapered, Padded Time Series, ' name]);
    xlabel(labtime);
    ylabel('Departure from Mean');
    % zoom xon; % matlab bug for some OS/versions
    grid;
    
    stryr1 = sprintf('%4.0f',nyra);
    stryr2 = sprintf('%4.0f',padlen);
    stryr=['\itN=\rm ' stryr1 ',  \itN_{pad}=\rm ' stryr2];
else
end


%******************* PLOT DISCRETE FFT


% Compute FFT
% Note, what follows is same as in  Ljung Notation
% Bloomfield's squared dft is 1/N times Ljung's DFT.


z=fft(x2,padlen);

t=0:1:padlen;
f=t/padlen;

if ~Lterse
    figure(6);
    plot(f(1:padlen/2),real(z(1:padlen/2)));
    title(['Real Part of Discrete Fourier Tansform of ' name]);
    xlabel(['Frequency (' labfreq ')']);
else
end


%***************** COMPUTE AND PLOT RAW PERIODOGRAM


% Compute periodogram by squaring DFT of tapered, padded series.
% Computation as defined by Ljung by squaring the DFT
% Note: Bloomfield's periodogram is 1/2*pi times Ljung's periodogram.

Pyy = z.*conj(z)/padlen;

if ~Lterse
    figure(7);
    hp7=plot(f(1:padlen/2),Pyy(1:padlen/2),'+g');
    set(hp7(1),'Color',cord(3,:));
    title(['Raw, or Unsmoothed, Periodogram, ' name]);
    xlabel(['Frequency (' labfreq ')']);
else
end

% for convenience, store periodogram (first half) of values in y, and 
% associated frequencies in ff
ff=f(1:padlen/2);
y= Pyy(1:padlen/2);  % put pdgm ordinates ...


%--- COMPUTE WHITE NOISE SPECTRUM AS ARITH MEAN OF PERIODOGRAM

y_white = repmat(nanmean(y),length(ff),1);


%*************** VARIANCE CHECK: COMPARE COMPUTED VARIANCE WITH PDGM SUM
clc;
xvarpdgm = (1/(nyra-1)) * sum(Pyy(1:padlen));
strv1 = sprintf('Variance computed directly from (tapered)time series = %10g',xvartap);
strv2 = sprintf('Variance computed from periodogram = %10g',xvarpdgm);
clear Pyy f


%**************** COMPUTE PERCENTAGE OF VARIANCE IN A PARTICULAR PERIOD RANGE
p1=pdvar(1); % longest period (yr)
p2=pdvar(2); % shortest period (yr)
f1=1.0/p1;    % frequency corresp to longest wavelength of range
f2=1.0/p2;    % frequency corresp to shortest ...
atemp=ones(padlen/2,1);

i1=find(ff>=f1&ff<=f2);  %  subscripts of ff in desired freq range
[m,n]=size(i1);          % n is number of elements found

pct=sum(y(i1))/sum(y);
%revise the "end periods" to agree with frequencies that have pdgm estimates at
if ff(i1(1))==0
   p1=inf;
else
   p1=1.0/ff(i1(1));
end
if ff(i1(n))==0
   p2=inf;
else
   p2=1.0/ff(i1(n));
end
strvpct1=sprintf('%5.1f pct of variance',pct*100);
strvpct2=sprintf('%7.2f yr -%7.2f yr',p1,p2);
strvpct=[strvpct1 ' in period range ' strvpct2];



%*************** EXTEND PERIODOGRAM BEYOND FREQUENCIES 0 AND 0.5 BEFORE SMOOTHING

%  Before smoothing periodogram, want to extend it so that it is 
% symmetric about frequencies 0 and 0.5  /yr
n=length(y);		% first element holds no ordinates in half-pdgm
yrev=y(n(1):-1:1);
yext=[yrev;y;yrev];
%plot(yext)
%title('Extended periodogram, symmetric about ends')
% A symmetric series of length n has been tacked on each end of the pdgm.
% So the original periodogram really covers the elements n+1 through 
% 2n of yext.  And, when convolute with an m-weight Daniell filter, will
% have effect of shifting (m-1)/2 units relative to central weight.  So will
% eventually want to plot and analyze this range of yext as the smoothed 
% periodogram:   n+1+(m-1)/2  thru  2n+(m-1)/2

% Always pick m to have odd number of weights.



%**********************  SMOOTHED PERIODOGRAM

if ~Lterse
    ksfirst=1;
    kwh1 = 1;
    while kwh1==1
        kmen1=menu('Choose 1','Smooth Periodogram or Revise Smoothing',...
            'Accept Spectrum');
        if kmen1==1
            figure(7);
            if ksfirst==1
                daniel1=dan1;
                ksfirst=2;
            else
                if kDan==1
                    prompt={'For smoothing pdgm into spectral estimates:'};
                    def={['[' int2str(daniel1) ']']};
                    tit1='Input the Daniel Filter Lengths';
                    lineNo=1;
                    answer=inputdlg(prompt,tit1,lineNo,def);
                    daniel1= str2num(answer{1});
                elseif kDan==2
                    w = danwgtn(daniel1);
                    mm=length(w); % span of resultant daniel filter
                    % Compute bandwidth and df of the Daniell filter
                    [bw,df]=danbw2(w,nyra,padlen);
                    prompt={'Number of spans:',...
                        'Bandwidth (target) for spectral estimate:'};
                    
                    def ={int2str(nspans),num2str(bw)};
                    titpmt2='Daniel Filter settings';
                    lineNo=1;
                    answer=inputdlg(prompt,titpmt2,lineNo,def);
                    nspans= str2num(answer{1});
                    bw = str2num(answer{2});
                    [daniel1,bw,df,sos]=danbw(bw,nspans,nyra,padlen,mtap1);
                    clear prompt def titpmt2 lineNo answer
                else
                end
            end
            w = danwgtn(daniel1);
            mm=length(w); % span of resultant daniel filter
            % Compute bandwidth and df of the Daniell filter
            [bw,df]=danbw2(w,nyra,padlen);
            nindep = round(0.5/bw,0); % number of independend estimates (for universal H0)
            igo = n+1+(mm-1)/2;
            istop=2*n+(mm-1)/2;
            ysm=conv(yext,w); % smoothed periodogram == spectrum
            hp7b=plot(ff,y,'.g',ff,ysm(igo:istop),'-b');
            set(hp7b(1),'Color',cord(3,:)); % periodogram
            set(hp7b(2),'Color',cord(1,:)); %  spectrum
            
            % Plot bandwidth bar.  Change next 2 lines as needed for formatting
            xlim7=get(gca,'XLim');
            ylim7=get(gca,'YLim');
            delx = diff(xlim7);
            dely = diff(ylim7);
            ybwgo = ylim7(1)+0.83*dely;  % bar 8/10 of way to top of figure
            yinc = dely/150; % vertical width of tick at ends ob bw bar
            xbwgo=xlim7(1)+delx/2 - bw/2;
            xbwsp = xbwgo+bw;
            hlinebar1=line([xbwgo xbwsp],[ybwgo ybwgo]); % the bw bar itself (horiz line)
            hlinebar2=line([xbwgo xbwgo],[ybwgo-yinc/2 ybwgo+yinc/2]); % left side vert line
            hlinebar3=line([xbwsp xbwsp],[ybwgo-yinc/2 ybwgo+yinc/2]); % right side vert line
            set(hlinebar1,'Color',1-get(gca,'Color'));
            set(hlinebar2,'Color',1-get(gca,'Color'));
            set(hlinebar3,'Color',1-get(gca,'Color'));
            
            text(xbwgo+(xbwsp-xbwgo)/2,ybwgo+yinc/2,'BW',...
                'VerticalAlignment','bottom','HorizontalAlignment','center');
            
            xlabel(['Frequency (' labfreq ')']);
            ylabel('Relative Variance');
            grid;
            set(gca,'Position',[0.1300    0.1100    0.7750    0.78]);
            title({['Smoothed Pdgm of ' name ';  ' stryr],...
                ['Spans: [' int2str(daniel1) ']']});
            set(hp7b(2),'LineWidth',1.5);
        elseif kmen1==2;
            kwh1=0;
            ysm=ysm(igo:istop);
        end
    end
else
    daniel1=dan1;
    w = danwgtn(daniel1);
    mm=length(w); % span of daniel filter
    % Compute bandwidth and df of the Daniell filter
    [bw,df]=danbw2(w,nyra,padlen);
    nindep = round(0.5/bw,0); % number of independend estimates (for universal H0)
    igo = n+1+(mm-1)/2;
    istop=2*n+(mm-1)/2;
    ysm=conv(yext,w); % smoothed periodogram == spectrum
    ysm=ysm(igo:istop);
end

%--- SCALE THE AR THEORETICAL SPECTRUM SUCH THAT AREA UNDER IT
% EQUALS THAT UNDER THE RAW PERIODOGRAM
% Use trapezoidal rule and function trapz to integrate
%
% Recall have raw periodogram in ff, y; and AR spectrum in Results_ar.f and
% Results_ar.y

y_ar = Results.ar_y;
f_ar = Results.ar_f;
y_ar = interp1(f_ar,y_ar,ff','linear'); % linear interpolation of AR spectrum to frequencies of raw periodogram

Area_raw = trapz(ff',y);
Area_AR = trapz(ff',y_ar);
fscale = Area_raw/Area_AR;
y_ar = fscale*y_ar;

Area_spectrum= trapz(ff',ysm);
Area_ar = trapz(ff',y_ar);

%
% % Debug plot
% txtcheck=['Areas under: spectrum = ' num2str(Area_spectrum) ';, AR = ' num2str(Area_ar)];
% figure(8)
% hcheck=plot(ff',y,'.',ff',ysm,ff',y_ar);
%
% set(hcheck(1),'Color',[1 0 0]);
% set (hcheck(2),'Color',[0 0 0]);
% set(hcheck(3),'Color',[0 1 0]);
% legend('Raw','Spectrum','AR spectrum');
% title([num2str(arcs(1,:)) ' fscale = ' num2str(fscale) ';  ' txtcheck]);
% return;


%**********************  NULL CONTINUUM

if ~Lterse
    if kopt(2)==1 % interactively using Daniell-smoothing to make null continuum.
        
        ksfirst=1;
        kwh1 = 1;
        while kwh1==1
            kmen1=menu('Choose 1','Make or Revise Null Continuum',...
                'Accept Null Continuum');
            if kmen1==1
                figure(7);
                if ksfirst==1
                    daniel2=dan2;
                    ksfirst=2;
                else
                    prompt={'For smoothing pdgm into null continuum:'};
                    def={['[' int2str(daniel2) ']']};
                    tit1='Input the Daniel Filter Lengths';
                    lineNo=1;
                    answer=inputdlg(prompt,tit1,lineNo,def);
                    daniel2= str2num(answer{1});
                end
                wnull = danwgtn(daniel2);
                mm=length(wnull); % span of daniel filter
                igo = n+1+(mm-1)/2;
                istop=2*n+(mm-1)/2;
                ynull=conv(yext,wnull); % smoothed periodogram == null line
                hp7b=plot(ff,y,'.g',ff,ysm,'-b',ff,ynull(igo:istop),'-m');
                set(hp7b(1),'Color',cord(3,:));
                set(hp7b(2),'Color',cord(1,:));
                set(hp7b(3),'Color',cord(2,:));
                
                % Plot bandwidth bar.  Change next 2 lines as needed for formatting
                xlim7=get(gca,'XLim');
                ylim7=get(gca,'YLim');
                delx = diff(xlim7);
                dely = diff(ylim7);
                ybwgo = ylim7(1)+0.83*dely;  % bar 8/10 of way to top of figure
                yinc = dely/150; % vertical width of tick at ends ob bw bar
                xbwgo=xlim7(1)+delx/2 - bw/2;
                xbwsp = xbwgo+bw;
                hlineb1=line([xbwgo xbwsp],[ybwgo ybwgo]); % the bw bar itself (horiz line)
                hlineb2=line([xbwgo xbwgo],[ybwgo-yinc/2 ybwgo+yinc/2]); % left side vert line
                hlineb3=line([xbwsp xbwsp],[ybwgo-yinc/2 ybwgo+yinc/2]); % right side vert line
                set(hlineb1,'Color',1-get(gca,'Color'));
                set(hlineb2,'Color',1-get(gca,'Color'));
                set(hlineb3,'Color',1-get(gca,'Color'));
                
                text(xbwgo+(xbwsp-xbwgo)/2,ybwgo+yinc/2,'BW',...
                    'VerticalAlignment','bottom','HorizontalAlignment','center');
                
                xlabel(['Frequency (' labfreq ')']);
                ylabel('Relative Variance');
                grid;
                set(gca,'Position',[0.1300    0.1100    0.7750    0.78]);
                title({['Smoothed Pdgm of ' name ';  ' stryr],...
                    ['Spans: [' int2str(daniel1) '], [' int2str(daniel2) ']']});
                set(hp7b(2),'LineWidth',1.5);
                set(hp7b(3),'LineWidth',1.5);
            elseif kmen1==2
                kwh1=0;
                ynull = ynull(igo:istop);
            end
        end
    elseif kopt(2)<5 && ~Lblue % using the AR theoretical null continuum
        ynull=y_ar;
    else
        ynull=y_white;
    end
else
    if kopt(2)==1 % make null continuum.
        daniel2=dan2;
        wnull = danwgtn(daniel2);
        mm=length(wnull); % span of daniel filter
        igo = n+1+(mm-1)/2;
        istop=2*n+(mm-1)/2;
        ynull=conv(yext,wnull); % smoothed periodogram == null line
        ynull = ynull(igo:istop);
    elseif kopt(2)<5  && ~Lblue % using the AR theoretical null continuum
        ynull=y_ar;
    else
        ynull=y_white;
    end

end

%********* CONDIDENCE INTERVAL AROUND SPECTRAL ESTIMATES  ******
%
% A chi-sq test is used.  Degrees of freedom depends on (1) original 
% series length,  (2) padded length, (3) proportion of data tapered,
% and (4) filter weights.

% Compute the factor gsq, that depends on the above four items.  First
% handle tapering.  See Bloomfield, p. 194.
ufact=0.5*(128-93*mtap1)/((8-5*mtap1)*(8-5*mtap1));

% Variance depends on filter weights.
% Compute sum of squares of weights.
wfact=w'*w;

% Bring adjustment for padding (Bloomfield, p. 192) into computation of
% complete variance adjustment for spectral estimates (Bloomfield, p.
% 195, eq. 12).
gsq = ufact*wfact*padlen/nyra;

% Compute degrees of freedom for spectral estimates
vdf = 2/gsq;   



%********************* FINISHED SPECTRAL PLOT

% find the row number of freq in ff closest to key freq
if strcmp(khypo,'Yes')
   d = ff - keyfreq;
   [ymin,imin]=min(abs(d));
else
   ymin=[]; imin=[];
end


if ~Lterse
    kwhl2=1;
    while kwhl2==1
        kmen2=menu('Choose 1',...
            'Make or revise final spectral plot',...
            'Satisfied -- quit program');
        
        if kmen2==1 % make or revise
            kmen3=menu('Choose one',...
                'Spectrum with 95% CI',...
                'Spectrum with 99% CI',...
                'Spectrum without CI');
            if kmen3==1
                pp1=0.025;
                if kopt(3)==1
                    strci='95% CI';
                else
                    pp1 = pp1/nindep;
                    strci='95% CI -- bonferroni-adjusted';
                end
                pp2=1-pp1;
                chi1 = chi2inv(pp2,round(vdf));
                chi2 = chi2inv(pp1,round(vdf));
                % Construct confidence intervals around the spectral estimates  using
                % the chi-sq distribution (Bloomfield p. 196)
                
            elseif kmen3==2
                pp1=0.005;
                if kopt(3)==1
                    strci='99% CI';
                else
                    pp1 = pp1/nindep;
                    strci='99% CI -- bonferfoni-adjusted';
                end
                pp2=1-pp1;
                chi1 = chi2inv(pp2,round(vdf));
                chi2 = chi2inv(pp1,round(vdf));
                
            elseif kmen3==3
                chi1=[];
                chi2=[];
                strci=[];
                ysmlo=[]; ysmhi=[];
                
            end
            if kmen3==1 || kmen3==2
                figure(8);
                ysmlo = vdf/chi1 * ysm;
                ysmhi = vdf/chi2 * ysm;
                hp8=plot(ff',ysm,'-b',ff',ynull,'-m',ff',ysmlo,'-m',ff',ysmhi,'-m');
                set(hp8(1),'Color',cord(1,:));
                set(hp8(2),'Color',cord(2,:));
                set(hp8(3),'Color',cord(2,:));
                set(hp8(4),'Color',cord(2,:));
                
                % Plot bandwidth bar.  Change next 2 lines as needed for formatting
                xlim8=get(gca,'XLim');
                ylim8=get(gca,'YLim');
                delx = diff(xlim8);
                dely = diff(ylim8);
                ybwgo = ylim8(1)+0.83*dely;  % bar 8/10 of way to top of figure
                yinc = dely/150; % vertical width of tick at ends ob bw bar
                xbwgo=xlim8(1)+delx/2 - bw/2;
                xbwsp = xbwgo+bw;
                hb1=line([xbwgo xbwsp],[ybwgo ybwgo]); % the bw bar itself (horiz line)
                hb2=line([xbwgo xbwgo],[ybwgo-yinc/2 ybwgo+yinc/2]); % left side vert line
                hb3=line([xbwsp xbwsp],[ybwgo-yinc/2 ybwgo+yinc/2]); % right side vert line
                set(hb1,'Color',1-get(gca,'Color'));
                set(hb2,'Color',1-get(gca,'Color'));
                set(hb3,'Color',1-get(gca,'Color'));
                
                text(xbwgo+(xbwsp-xbwgo)/2,ybwgo+yinc/2,'BW',...
                    'VerticalAlignment','bottom','HorizontalAlignment','center');
                
                % Complete figure
                xlabel(['Frequency (' labfreq ')']);
                ylabel('Relative Variance');
                set(gca,'Position',[0.1300    0.1100    0.7750    0.78]);
                if kopt(2)==1;
                    title({['Smoothed Pdgm of ' name ';  ' stryr],...
                        ['Spans: [' int2str(daniel1) '], [' int2str(daniel2) ']']});
                elseif kopt(2)<5;
                    title({['Smoothed Pdgm of ' name ';  ' stryr],...
                        ['Spans: [' int2str(daniel1) '], Null is AR(' int2str(k1) ') ']});
                else
                    title({['Smoothed Pdgm of ' name ';  ' stryr],...
                        ['Spans: [' int2str(daniel1) '], Null is white noise']});
                end
                set(hp8(1),'LineWidth',1.5);
                set(hp8(2),'LineWidth',1.5);
                if kopt(2)==1;
                    textnull='Null Continuum';
                elseif kopt(2)<5;
                    textnull=['AR(' num2str(k1) ') Null Continuum'];
                else
                    textnull='White Noise Null Continuum';
                end
                legend('Spectrum',textnull,strci);
                
                % Add vertical line at test frequency
                if strcmp(khypo,'Yes');
                    hlinetest=line([keyfreq keyfreq],ylim8);
                    set(hlinetest,'Color',cord(3,:));
                end
                
                
            else
                figure(8);
                hp8=plot(ff,ysm,'-b', ff,ynull,'-m');
                set(hp8(1),'Color',cord(1,:));
                set(hp8(2),'Color',cord(2,:));
                % Plot bandwidth bar.  Change next 2 lines as needed for formatting
                xlim8=get(gca,'XLim');
                ylim8=get(gca,'YLim');
                delx = diff(xlim8);
                dely = diff(ylim8);
                ybwgo = ylim8(1)+0.83*dely;  % bar 8/10 of way to top of figure
                yinc = dely/150; % vertical width of tick at ends ob bw bar
                xbwgo=xlim8(1)+delx/2 - bw/2;
                xbwsp = xbwgo+bw;
                hb1=line([xbwgo xbwsp],[ybwgo ybwgo]); % the bw bar itself (horiz line)
                hb2=line([xbwgo xbwgo],[ybwgo-yinc/2 ybwgo+yinc/2]); % left side vert line
                hb3=line([xbwsp xbwsp],[ybwgo-yinc/2 ybwgo+yinc/2]); % right side vert line
                set(hb1,'Color',1-get(gca,'Color'));
                set(hb2,'Color',1-get(gca,'Color'));
                set(hb3,'Color',1-get(gca,'Color'));
                
                text(xbwgo+(xbwsp-xbwgo)/2,ybwgo+yinc/2,'BW',...
                    'VerticalAlignment','bottom','HorizontalAlignment','center');
                
                % Complete figure
                xlabel(['Frequency (' labfreq ')']);
                ylabel('Relative Variance');
                set(gca,'Position',[0.1300    0.1100    0.7750    0.78]);
                if kopt(2)==1;
                    title({['Smoothed Pdgm of ' name ';  ' stryr],...
                        ['Spans: [' int2str(daniel1) '], [' int2str(daniel2) ']']});
                elseif kopt(2)<5;
                    title({['Smoothed Pdgm of ' name ';  ' stryr],...
                        ['Spans: [' int2str(daniel1) '], Null is AR(' int2str(k1) ') ']});
                else
                    title({['Smoothed Pdgm of ' name ';  ' stryr],...
                        ['Spans: [' int2str(daniel1) '], Null is white noise']});
                end
                
                set(hp8(1),'LineWidth',1.5);
                set(hp8(2),'LineWidth',1.5);
                
                
            end
            
        elseif kmen2==2;
            kwhl2=0;
        end
    end
else
    
    %  'Spectrum with CI'
    % corresponding probability point of cdf of Chi squared distribution
    pp1=  (1 -siglev/100)/2;
    if kopt(3)==2 % want Bonferroni
        pp1=pp1/nindep;
        strci=[num2str(siglev) '% CI-- bonferroni-adjusted'];
    else
        strci =[num2str(siglev) '% CI'];
    end
    pp2=  1 -pp1;
    chi1 = chi2inv(pp2,round(vdf));
    chi2 = chi2inv(pp1,round(vdf));
    ysmlo = vdf/chi1 * ysm;
    ysmhi = vdf/chi2 * ysm;
    
end

%---- STORE RESULTS FOR LATER ACCESS

Results.what=char({'Results.t = time vector for time series',...
        '.x = vector of original time series',...
        '.times = start and end times of observations for analysis period',...
        '.N1 = length of original time series',...
        '.N2 = length after padding',...
        '.taper = decimal fraction of series to taper (half this on each end)',...
        '.fspace=frequency spacing',...
        '.f = frequencies for spectral estimates',...
        '.s = spectral estimates',...
        'ysmlo  = lowere CI (see strci) for s',...
        'ysmhi = upper CI  (see strci) for s',...
        'strci = label for CI; defines and says if Bonferroni adjusted',...
        '.what_null = what was used for null continuum',...
        '.nullc = null continuum',...
        '.white = white noise spectrum; used as null continuum if kopt(2)==5',...
        '.spans1 = spans for smoothing pdgm into spectrum',...
        '.spans2 = spans for smoothing pdgm into null continuum, or [] if theoretical AR process or white',...
        '   noise uses as null continuum',...
        '.ar_order = order of AR model that fits the time series (optionally used as null continnum if .spans2 is [])',...
        '.ar_coeffs = autoregressive coefficient(s) of AR model fit to time series.  If AR(1), this is a 1 x 2 column',...
        '   vector, with the coefficient in row 1 and twice its standard error in row 2.  If AR(2), this is 2 x 2, with',...
        '   the coeffs in row 1 and twice their standard errors in row 2. Signs of coefficients follow Ljung convention,',...
        '   such that model is expressed as',...
        '   y(t) +a1*y(t-1) + a2*y(t-2) = e(t) is model and a1,a2 are the coefficents.  Thus, for a',...
        '   series with positive first-order autocorrelation, a1 is negative.',...
        '.bw = bandwidth for spectral estimates',...
        '.w = weights of resultant filter used to smooth raw periodogram',...
        '.variance_check = variance of series as computed from 1) tapered time series, 2) summing periodogram',...
        '.fband = start and end frequency of specified band for which pctg series variance is computed',...
        '.pct = percentage of variance in frequency band Results.fband',...
        '.cycletest = setting for hypothesis test for periodicity (or [] if no test called for)',...
        '.sigpeaks = table summarizing locations of spectral estimates significantly above null continuum, with local peaks flagged',...
        '.nindep = number of independent smoothed-spectral estimates in [0 0.5] frequency range',...
        '.Bonferroni == Yes or No: confidence interval widened for fishing expedition? Adjustment by Bonferroni method,'...
        '     assuming nindep test have been run',...
        '.methDan = method for setting the Daniell spans for smoothing raw periodogram'});
Results.t=yr;
Results.x=xorig; % time series
Results.times=yrsa; % start and end times of observations for analusis
Results.N1=nyra; % length of time series (before any padding)
Results.N2=padlen; % length of time series (before any padding)
Results.taper =mtap1; % decimal fraction of series to taper (half this on each end)
Results.fspace=1/padlen; % frequency spacing
Results.f = ff'; % frequencies for spectrum
Results.s=ysm; %  estimated spectrum
Results.slo=ysmlo; % lower confidence limit (see strci))
Results.shi=ysmhi; % upper confidence limit (see strci))
Results.strci = strci; % label defining CI
Results.what_null = what_null; 
Results.nullc=ynull; % null continuum
Results.white=y_white; % white noise spectrum
Results.spans1 = daniel1; % spans for smoothing pdgm into spectrum
Results.methDan=methDan; % how spans set
if kopt(2)==1
    Results.spans2=daniel2; % spans for smoothing pdgm into null cont
else
    Results.spans2=[];
end
Results.ar_order =k1;
Results.ar_coeffs = arcs; % AR coeffs of model fit to time series for possible use as null continuum
Results.bw = bw; % bandwidth for spectral estimate
Results.w=w; % weights of filter used to smooth raw periodogram
Results.variance_check=[xvartap xvarpdgm]; % variance computed from time series and from periodogram

Results.fband=[1/p1 1/p2];  % Frequency pct variance desired for
Results.pct = pct; % percentage of variance in frequency band Results.fband
        

if strcmp(khypo,'Yes')
    strtest=char({['Specified frequency of hypothesized periodicity = ' num2str(keyfreq,'%8.5f')],...
            ['      Actual frequency for test =' num2str(ff(imin),'%8.5f')],...
            ['      Specified period for test = ' num2str(keypd,'%8.5f') '  '  labtime],...
            ['      Actual period for test = '      num2str(1/ff(imin),'%8.5f')]});
else
    strtest=[];
end;
Results.cycletest=strtest;
Results.nindep = nindep;
if kopt(3)==2;
    Results.Bonferroni='Yes';
else
    Results.Bonferroni='No';
end
    


%************** ascii output



if ~isempty(strci)
    
    Lsig = ynull<ysmlo; % pointer to spectral estimates sig greater than null contin
    sum1 = sum(Lsig); % number of significant spectral ordinates
    
    % Mark if ysm is a local peak
    ysma=[(ysm(1)-eps);    ysm(1:(end-1))];
    Lup = ysm>ysma;  % 1 if spectrum rose from next lowest freq
    ysma=[(ysm(2:end));    ysm(end)-eps];
    Ldn= ysm>ysma;  % 1 if spectrum falls to next lowest freq
    Lpeak = Lup & Ldn;
    
    if sum1>0
        
        sigpeaks=cell(sum1+1,1);
        sigpeaks{1}=['Spectral estimates significantly greater than null continnum at ',strci];
        sigpeaks{2}='Columns: 1) seq number, from lowest freq to highest';
        sigpeaks{3}='     2) frequency,  3) period, 4) spectral estimate';
        sigpeaks{4}='     1) a local maximum 0) not a local maximum';
        
        ff = ff(Lsig);
        ysm=ysm(Lsig);
        ysmlo=ysmlo(Lsig);
        per = 1 ./ ff;
        
        peakmark=Lpeak(Lsig);
        
        for nn = 1:sum1
            pk=num2str([nn ff(nn) per(nn) ysm(nn)  peakmark(nn)],5);
            sigpeaks{nn+4}=pk;
        end
        Results.sigpeaks=char(sigpeaks);
    else
        Results.sigpeaks=[];
    end
    
end



