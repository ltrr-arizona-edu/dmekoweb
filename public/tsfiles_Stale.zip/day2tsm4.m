function D = day2tsm4(S)
% day2tsm4: PRISM csv daily climate data to daily tsm
% D = day2tsm4(S);
% Last Revised 2016-12-31
%
% PRISM csv daily climate data to daily tsm
%
%*** INPUT
%
% S{} col-cell of PRISM daily data, with metadata at front
%
%
%*** OUTPUT
%
% D = structure of results
%    .meta:  various metadat fields, self evident from names (see Notes
%       below)
%    .X (mX x 5): year, month, day, Julian Day, data value
%
%
%*** REFERENCES -- NONE
%
%
%*** UW FUNCTIONS CALLED -- NONE
%
%*** NOTES
%
%Innput S assumed to have 11 metadata lines followed by data. Example:
%     'PRISM Time Series Data'
%     'Location:  Lat: 32.2217   Lon: -110.9265   Elev: 2507ft'
%     'Climate variable: tmin'
%     'Spatial resolution: 4km'
%     'Period: 2010-01-01 - 2016-12-20'
%     'Dataset: AN81d'
%     'PRISM day definition: 24 hours ending at 1200 UTC on the day shown'
%     'Grid Cell Interpolation: Off'
%     'Time series generated: 2016-Dec-22'
%     'details: http://rma.nacse.org/documents/PRISM_datasets.pdf'
%     'Date,tmin (degrees F)'
%     '2010-01-01, 38.1'
%     '2010-01-02, 41.0'
%     '2010-01-03, 37.4'
% 


%----- METADATA STORAGE

% First digits of each metadata field
s1={'PRISM Time Series Data',...
    'Location',...
    'Climate variable',...
    'Spatial resolution',...
    'Period',...
    'Dataset',...
    'PRISM day definition',...
    'Grid Cell Interpolation',...
    'Time series generated',...
    'details',...
    'Date'};
nchar=[22 8 16 18 6 7 20 23 21 7 4];

[ms1,ns1]=size(s1);
for n =1:ns1
    s1this=s1{n};
    L=strncmp(S,s1this,nchar(n));
    if sum(L)~=1
        error(['Not exactly one row with first ' num2str(nchar(n)) ' digits matching ' s1this]);
    else
        i1=find(L);
    end
    
    if n==2 % location
        s=S{i1};
        i2=strfind(s,'Lat:');
        s(1:(i2+3))=[]; % trim off before numeric latitude
        i2= strfind(s,'Lon:');
        skey = s(1:(i2-1));
        D.meta.Lat  = str2double(skey); % Lat stored
        s(1:(i2+3))=[];
        i2= strfind(s,'Elev:');
        skey = s(1:(i2-1));
        D.meta.Lon  = str2double(skey); % Lon stored
        s(1:(i2+4))=[];
        i2=strfind(s,'ft');
        if isempty(i2)
            error('Expected ''ft'' in field for elev of site');
        end
        D.meta.UnitsElev='ft';
        s(i2:end)=[];
        skey=s;
         D.meta.Elev  = str2double(skey); % Elev stored
    elseif n==3 % climate variable
        s=S{i1};
        i2=strfind(s,':');
        s(1:i2)=[];
        skey=strtrim(s);
        D.meta.Variable= skey; % Name of clime variable stored
    elseif n==4 % Spatial resolution
        s=S{i1};
        i2=strfind(s,':');
        s(1:i2)=[];
        skey=strtrim(s);
        i2=strfind(s,'km');
        if isempty(i2)
            error('Expected ''km'' in field for spatial resolution');
        end
        D.meta.UnitsSpatialResolution='km';
        s(i2:end)=[];
        skey=s;
        D.meta.SpatialResolution  = str2double(skey); % Spatial Resolution stored
        
    elseif n==5
        s=S{i1};
        i2=strfind(s,':');
        s(1:i2)=[];
        skey=strtrim(s);
        D.meta.Period  = skey; % Period store
    elseif n==6
        s=S{i1};
        i2=strfind(s,':');
        s(1:i2)=[];
        skey=strtrim(s);
        D.meta.Dataset  = skey; % Dataset
    elseif n==7
        s=S{i1};
        i2=strfind(s,':');
        s(1:i2)=[];
        skey=strtrim(s);
        D.meta.PRISMDayDefinition  = skey; % PRISM Day Definition
    elseif n==8
        s=S{i1};
        i2=strfind(s,':');
        s(1:i2)=[];
        skey=strtrim(s);
        D.meta.GridCellInterpolation  = skey; % Grid Cell interpolation
    elseif n==9
        s=S{i1};
        i2=strfind(s,':');
        s(1:i2)=[];
        skey=strtrim(s);
        D.meta.TimeSeriesGeneratedDate  = skey; % when prism generated its time series
        
    elseif  n==10
          s=S{i1};
        i2=strfind(s,':');
        s(1:i2)=[];
        skey=strtrim(s);
        D.meta.DetailsURL  = skey; % URL for details on the PRISM data
        
    elseif n==11
         s=S{i1};
         i2a=strfind(s,'(');
        i2b=strfind(s,')');
        igo = i2a+1;
        isp = i2b-1;
        skey = s(igo:isp);
        D.meta.UnitsData=skey;
        
    elseif n~=1
        error('How got here?')
        
    end
end
S(1:11)=[]; % trim off leading metadata
if ~strcmp(class(S),'cell')
    error('S should be cell');
end
[mS,nS]=size(S);
if nS~=1;
    error('S should be col-cell');
end
Sdate=char(S);



%--- DAILY DATA -- year, month day
%
% expect in cols 1-2, with col 5 as '-'

s = Sdate(:,5);
if ~all(s=='-')
    error('Some row of Sdate does not have ''-'' in col 5');
end

disp('Converting year to numeric');
Syr = Sdate(:,1:4);
yr =str2num(Syr);
disp('Converting month to numeric');
Smonth = Sdate(:,6:7); 
monthe= str2num(Smonth);
disp('Converting day to numeric');
Sday = Sdate(:,9:10); 
day=str2num(Sday);
N=size(day,1);

% Compute first and last year for target daily tsm; 
yrgo = yr(1);
yrsp =yr(end);
nyrX = yrsp-yrgo+1;

% Allocate tsm for daily data and for quality flag
nlines = nyrX*366; % number of lines
X=repmat(NaN,nlines,5); % for data


%----  BUILD FIRST 4 COLS OF X

% Build calendar year vector
i1 = 0:1:(nyrX-1);
I1=repmat(i1,366,1);
J1= yrgo + I1;
yrvec = J1(:); % year vector
clear i1 I1 J1 ;
% Build month vector;
j=[repmat(1,31,1); repmat(2,29,1);  repmat(3,31,1);  repmat(4,30,1); ...
        repmat(5,31,1);  repmat(6,30,1);  repmat(7,31,1);  repmat(8,31,1);...
        repmat(9,30,1);  repmat(10,31,1);  repmat(11,30,1); repmat(12,31,1)];
J=repmat(j,1,nyrX);
mon = J(:);
clear J;
% Build day of month vector
j=[1:31   1:29   1:31 1:30 1:31 1:30 1:31 1:31 1:30 1:31 1:30 1:31]';
J=repmat(j,1,nyrX);
daymon= J(:);
clear J;
% Build day vector
j=(1:366)';
J=repmat(j,1,nyrX);
dayseq = J(:);

X(:,1:4)=[yrvec mon daymon dayseq];
[mX,nX]=size(X);




%--- DAILY DATA -- data itself
%
% expect in precedd by ',' in col 11

s = Sdate(:,11);
L = s==',';
if ~all(L)
    error('Expected '','' in col 11 preceding data values');
end

S=Sdate(:,12:end); % strip off all date inf
x = str2num(S); % numeric climatic value in each row of S
mx=length(x);
[mS,nS]=size(S);

jday = mdy2jdy(monthe,day); % computed julian day of each row of data in S



%--- INSERT IN PROPER ROW OF X
% Recall:  yr, monthe and day are the year, month and day of data in x
% Compute insertion index

for n =1:mx
    xthis=x(n);
    L = (X(:,1)==yr(n)) & (X(:,4)==jday(n));
    if sum(L)~=1;
        error('Not exactly 1 match for day')
    end
    X(L,5)=xthis;
end

D.X=X;