% Tsp_examples: script to make time series plots of 11 sample types of time series 


% Some initial steps convenient at start of a script
clear;
close all;
clc

% Student option: disregards my path and operating system differences and
% lets people run script on their own laptop assuming script, functions and
% data files in their current working directory


qstudent=questdlg('Ignore DM''s'' paths and run with all needed files in current working directory?');
if strcmp(qstudent,'Yes')
else
    % Specify folders input data is to be found in. The "if" statement allows
    % Matlab to recognize if you are using windows vs Linux. Serves no purpose
    % here because I use Matlab under Linux only
    a=OStell;
    if strcmp(a.OS,'Linux')
        pathcurr='/home/dave/geos19/Data_19';
        pathseries='/home/dave/Data/TimeSeriesGeos585a';
        pathlion='/home/dave/Projects/ay2/TreeData_Recon_ay2/Master_ay2';
        pathclass='/home/dave/geos19';
        pathsnow='/home/dave/Projects/ay1/Snow_ay1';
        pathCI='/home/dave/Data/Climate_Indices';
    else
        error('not yet coded for windows')
    end
    
    %-- A "message box" -- a wWarning about where this script must be
    strwarn = {'This script must reside in same folder ',...
        'as where the output will go. Otherwise will bomb'};
    uiwait(msgbox(strwarn,'Warning','modal'));
    
end


%--- HARD CODE

nmmons={'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'};

fls1={'PRISM_tmin_early_4km_20100101_20161220_32.2217_-110.9265.csv','PRISM_tmin_30yr_normal_4km_monthly_normals_32.2217_-110.9265.csv',...
    'Clemente.xlsx','LCUM#e_s.crn','LCUM#e.rwl','CO2Monthly.mat','yearssn.mat','Fire_data_Dave.xlsx','quinn15251987.dat',...
    'SC5SensorGroupDataSC5_Apr1'};


%******* REMAINING CODE GETS THE DATA AND MAKES THE PLOTS. 
%
% I use a few different functions, some in Matlab, some I wrote, for this:
%    load -  if data in "mat" file, or is all numeric matrix or scalar ascii
%       text
%    xlsread - if data from spreadsheet
%    textread - if data a mixture of numeric and non-numeric
%    crn2vec2 - user-written, for tree-ring site chronologies, in "crn"
%       file
%    rwlinp - user-written, for ring-width measurements in "rwl" file
%    day2tsm4 -- to read daily PRISM data and store in time series matrix




%**** MINIMUM DAILY T AT TUCSON

if strcmp(qstudent,'Yes')
    pf=fls1{1};
else
    pf =fullfile(pathseries,fls1{1});
end

F = textread(pf,'%s','delimiter','\n','whitespace',''); % read PRISM file of daily temperature data
R=day2tsm4(F);  % call user-written function to put that data in a simple time series matrix for plotting

yrstr={'2010','2011','2012','2013','2014','2015','2016'};

figure (4);
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);

x = R.X(:,5);
yearx=R.X(:,1);
jday = R.X(:,4);
dayx=R.X(:,3);
monthx=R.X(:,2);
mx=length(x);
t = (1:mx)';
t1=t;

[x,t]=trimnan(x,t);

N=length(x);
strN=['N=' num2str(N)];

L = t1>=t(1) & t1<=t(end);
jday = jday(L); monthx = monthx(L); dayx=dayx(L); yearx=yearx(L);

% text for time coverage
strcover1=[num2str(monthx(1)) '/' num2str(dayx(1)) '/' num2str(yearx(1))];
strcover2=[num2str(monthx(end)) '/' num2str(dayx(end)) '/' num2str(yearx(end))];
strcover =[strcover1 '--' strcover2];

Ljan = jday==1;

xlims = [t(1) t(end)];
h = plot(t,x);
xlabel('Day (1=Jan 1, 2010)');
ylabel('T (deg F)')
ylims = get(gca,'YLim');
set(gca,'XLim',xlims)

% Line at Jan 1
ijan = find(Ljan);
njan = length(ijan);
for n = 1:njan
    h1 = line([ijan(n) ijan(n)],ylims);
    set(h1,'Color',[1 0 0]);
    ht1 = text(ijan(n)+180,12,yrstr{n},'HorizontalAlignment','Center','VerticalAlignment','Bottom');
end

textcorn(strN,'UL',0.02,0.02,14)
title(['Minimum Daily Temperature at Tucson, Arizona, ' strcover])


%--- 30 YEAR NORMALS OF MONTHLY AVERAGE OF DAILY MINIMUM T AT TUCSON

if strcmp(qstudent,'Yes')
    pf=fls1{2};
else
    pf =fullfile(pathseries,fls1{2});
end

F = textread(pf,'%s','delimiter','\n','whitespace','');
mons={'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'};

F(1:11)=[];
x=nan(12,1);
for n = 1:12
    s = F{n};
    i1 = strfind(s,',');
    s(1:i1)=[];
    x(n)=str2num(s);
end




figure(5);
[cL,cB,cW,cH]=figsize(.5,.5);
set(gcf,'Position',[cL cB cW cH]);
j=(1:12)';
strN = ['N=' num2str(length(j))];
h=plot(j,x,'-o');
set(gca,'XLim',[0.5 12.5])
xlabel('Month (1=Jan,12=Dec)');
ylabel('T(deg F)')

textcorn(strN,'UL',0.02,0.02,14)
title('30-yr Monthly Means of Minimum Daily Temperature at Tucson, Arizona')


 
%--- CLEMENTE BATTING AVERAGE

if strcmp(qstudent,'Yes')
    pf=fls1{3};
else
    pf =fullfile(pathseries,fls1{3});
end

[A,B]=xlsread(pf); % reads an Excel spreadsheet

i1=find(strcmp(B(1,:),'Year'));
yrx = A(:,i1);
i1=find(strcmp(B(1,:),'BA'));
x = A(:,i1);
L=~isnan(yrx);
yrx=yrx(L);
x=x(L);
yrgo=yrx(1); yrsp = yrx(end);
ntot = yrsp-yrgo+1;
strN = ['N=' num2str(ntot)];

figure(1)
[cL,cB,cW,cH]=figsize(.5,.5);
set(gcf,'Position',[cL cB cW cH]);

h= plot(yrx,x,'-o');
set(gca,'XGrid','On')
xlabel('Year');
ylabel('Batting Average')

textcorn(strN,'UL',0.02,0.02,14)
stryr=['(' num2str(yrgo) '-' num2str(yrsp) ')'];
title(['Batting Average of Roberto Clemente, ' num2str(yrgo) '-' num2str(yrsp)])

clear x yrx
 

%--- LION CANYON TREE-RING INDEX

if strcmp(qstudent,'Yes')
    pf=fls1{4};
else
    pf =fullfile(pathlion,fls1{4});
end

[x,sx,yrx]=crn2vec2(pf); % user-written function to extract time series from
% an ITRDB-formatted crn data file to time series matrix

x=x/1000;
[x,yrx]=trimnan(x,yrx);
yrgo = yrx(1); yrsp = yrx(end);
ntot = yrsp-yrgo+1;
strN = ['N=' num2str(ntot)];


figure(2)
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);


h = plot(yrx,x);
set(gca,'XLim',[yrgo yrsp]);
hline = line([yrgo yrsp],[1 1],'Color',[1 0 0]);
xlabel('Year');
ylabel('Index (dimensionless)')

stryr=['(' num2str(yrgo) '-' num2str(yrsp) ')'];
textcorn(strN,'UL',0.02,0.02,14)
title(['Tree-Ring Index, Lion Canyon, CA ' stryr]);


%--- LION CANYON RING WIDTH SERIES

if strcmp(qstudent,'Yes')
    pf=fullfile(cd,fls1{5}); % 'cd' assigns the current working directory as a path
    [pf1,x,yrs,nms]=rwlinp(pf);
else
    pf =fullfile(pathlion,fls1{5});
    [pf1,x,yrs,nms]=rwlinp(pf);
end

j=16;
[X,yrX]=sov2tsm(x,yrs,[],[j]);
nm = nms{j};
nm=nm(1:5);

x=X/1000;
yrx=yrX;
[x,yrx]=trimnan(x,yrx);
yrgo = yrx(1); yrsp = yrx(end);
ntot = yrsp-yrgo+1;
strN = ['N=' num2str(ntot)];

figure(3)
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);


h = plot(yrx,x);
set(gca,'XLim',[yrgo yrsp]);
xlabel('Year');
ylabel('Ring Width (mm)')

stryr=['(' num2str(yrgo) '-' num2str(yrsp) ')'];
textcorn(strN,'UL',0.02,0.02,14)
title(['Tree-Ring Width, Lion Canyon, CA, core ' nm ',  ' stryr]);


%--- MAUNA LOA MONTHLY CO2 CONCENTRATION

if strcmp(qstudent,'Yes')
    pf=fls1{6};
    %pf(11:14)=[]; % strip off '.mat' (not sure why need to do)
else
    pf =fullfile(pathCI,fls1{6});
    %pf(38:41)=[]; % strip off '.mat' (not sure why need to do)
end

eval(['load ' pf ';']);

x = X(:,2);
tx = X(:,1);
mx=length(x);

strN=['N=' num2str(mx)];

figure(6)
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);

t=(1:length(x))';
tgo = t(1);
tsp = t(end);
h=plot(t,x);

set(gca,'XLim',[tgo tsp]);
xlabel('Month (1=Feb 1958)')
ylabel('CO_{2}(ppm)')

textcorn(strN,'UL',0.02,0.02,14)
title(['CO_{2} Concentration of Atmposphere, Monthly, at Mauna Loa, Feb 1958 to Aug 2016']);



%--- SUNSPOTS

if strcmp(qstudent,'Yes')
    pf=fls1{7};
else
    pf =fullfile(pathCI,fls1{7});
end

eval(['load ' pf ';']); % reads a simple ascii all-numeric data matrix

x=D.X(:,2);
yrx = D.X(:,1);
[x,yrx]=trimnan(x,yrx);
yrgo=yrx(1); yrsp = yrx(end);
ntot = yrsp-yrgo+1;
strN = ['N=' num2str(ntot)];


figure(7)
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);

h=plot(yrx,x);
xlabel('Year');
ylabel('Sunspot Number');

textcorn(strN,'UL',0.02,0.02,14)
stryr=['(' num2str(yrgo) '-' num2str(yrsp) ')'];
title(['Yearly sunspot number,  ' stryr]);



%--- FIRE OCCURRENCE, ZAIGREVO SITE, SIBERIA: SINGLE TREE (BINARY)

if strcmp(qstudent,'Yes')
    pf=fls1{8};
else
    pf =fullfile(pathseries,fls1{8});
end

[A,B]=xlsread(pf);

yrx = A(:,1);
x = A(:,2);
[x,yrx]=trimnan(x,yrx);
yrgo=yrx(1); yrsp = yrx(end);
ntot = yrsp-yrgo+1;
strN = ['N=' num2str(ntot)];
xlims =[yrgo-3 yrsp+3];
ylims =[0 1.3];

figure(8)
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);


h=stem(yrx,x);
set(gca,'XLim',xlims,'YLim',ylims)
xlabel('Year');
ylabel('Fire Scar');

textcorn(strN,'UL',0.02,0.02,14)
stryr=['(' num2str(yrgo) '-' num2str(yrsp) ')'];
title(['Fire scar (1=Y,0=N) in single tree, Zaigrevo, Siberia,  ' stryr]);


%--- FIRE OCCURRENCE, ZAIGREVO SITE, SIBERIA: NUMBER OF TREES WITH FIRE
% SCAR (COUNT)

yrx = A(:,1);
x = A(:,3);
[x,yrx]=trimnan(x,yrx);
yrgo=yrx(1); yrsp = yrx(end);
ntot = yrsp-yrgo+1;
strN = ['N=' num2str(ntot)];
xlims =[yrgo-3 yrsp+3];
ylims =[0 max(x)+2];

figure(9)
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);


%h=stem(yrx,x);
h=plot(yrx,x,'-o');
set(h,'MarkerSize',2)
set(gca,'XLim',xlims,'YLim',ylims)
xlabel('Year');
ylabel('Count (#)');

textcorn(strN,'UL',0.02,0.02,14)
stryr=['(' num2str(yrgo) '-' num2str(yrsp) ')'];
title(['Number of Sampled Trees with Fire Scar, Zaigrevo, Siberia,  ' stryr]);


%--QUINN INDEX OF EL NINO SEVERITY, 1525-1987 ( NOT PALEO)

if strcmp(qstudent,'Yes')
    pf=fls1{9};
else
    pf = fullfile(pathseries,fls1{9});
end

D=load(pf,'-ascii'); 
yrx =D(:,1); 
x=D(:,2);

[x,yrx]=trimnan(x,yrx);
yrgo=yrx(1); yrsp = yrx(end);
ntot = yrsp-yrgo+1;
strN = ['N=' num2str(ntot)];
xlims =[yrgo-3 yrsp+3];
ylims =[0 max(x)+2];

figure(10)
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);


h=plot(yrx,x,'-o');
set(h,'MarkerSize',2)
set(gca,'XLim',xlims,'YLim',ylims)
xlabel('Year');
ylabel('Severity');

textcorn(strN,'UL',0.02,0.02,14)
stryr=['(' num2str(yrgo) '-' num2str(yrsp) ')'];
title(['Quinn Index of El Nino Severity, ' stryr]);



%--APRIL 1 SWE, SNOW COURSE HUYSINK

icol=12; % Huysink
if strcmp(qstudent,'Yes')
    pf=fls1{10};
else
    pf = fullfile(pathsnow,fls1{10});
end

eval(['load ' pf ';']);  % Loads a file I had previously organized snow data in
D=Result;
x= D.W(:,icol);
yrx=D.year;

[x,yrx]=trimnan(x,yrx);
yrgo=yrx(1); yrsp = yrx(end);
ntot = yrsp-yrgo+1;
strN = ['N=' num2str(ntot)];
xlims =[yrgo-3 yrsp+3];
ylims =[0 max(x)+2];

figure(11)
[cL,cB,cW,cH]=figsize(.7,.5);
set(gcf,'Position',[cL cB cW cH]);

h=plot(yrx,x,'-o');
set(h,'MarkerSize',4)
set(gca,'XLim',xlims,'YLim',ylims)
xlabel('Year');
ylabel('Water Content (in)');

textcorn(strN,'UL',0.02,0.02,14)
stryr=['(' num2str(yrgo) '-' num2str(yrsp) ')'];
title(['April 1 Snow Water Equivalent, Huysink Snow Course, American River Basin, CA, ' stryr]);

%-- Warning about where this script must be

strwarn = {'This script must reside in same folder',...
    'as where the output will go. Otherwise will bomb'};
uiwait(msgbox(strwarn,'Warning','modal'));

