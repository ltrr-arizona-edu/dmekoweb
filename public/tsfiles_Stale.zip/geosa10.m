% geosa10.m  lagged relationships
%
%
% Last Revised 2018-12-23
%
%*** UW FUNCTIONS CALLED
%
% lagscat2 -- lagged scatterplots
% menua1 -- user menu
% msgbox1
% pearsign -- significance of pearson correlation
% trailnan.m --  remove trailing NaNs from series
% trimnan.m -- remove leading and trailing NaNs from series

%
%*** TOOLBOXES NEEDED
%
% Statistics
% System identification
%
% Revised 2015-01-16.  xlims to restrict time axis range on time plots
% Revised 2016-12-10. Optional log-10 transformation of output; minor
%   changes to message boxes
% Revised 2017-03-18. CI on ccf of original (no whitening of series) ccf
%   now computed by new user-written functon quenouille. Previously no
%   adjustment of the CI for autocorrelation in individual series, although
%   Matlab's cra function does do an adjustment in putting the 99% CI on the
%   irf
%
% Revised 2018-12-23.  Cosmetic.

clear;
close all;

% Hard code
datfile='Spring19'; % default .mat file with input data
datdir=cd; % directory with input data; assume current directory
alphlev=   [.10  .05  .01  .001];  % alpha levels for two-tailed test of significance
salphlev= {'0.10','0.05','0.01','0.001'};  % striing equiv for menu
ssig = {'90%','95%','99%','99.9%'};
xcdf=[1.6449    1.96 2.5758  3.2905]; % corresponding normal cdf points

%********  INTRODUCTORY MSG

message1 = {'Lagged Response',...
        '',...
        'Illustrates lagged-correlation analysis: lagged scatterplots',...
        'the cross-correlation function (ccf), and the application of whitening',...
        'to identification of lagged relationships in a bivariate system',...
        '',...
        'You select two time series, u and y, for analysis. The lagged correlation',...
        'of series v to series u is summarized in three ways:',...
        '   1) ccf of the original series',...
        '   2) ccf of the series after individually prewhitening both series',...
        '      with AR(10) models',...
        '   3) ccf in a ''systems'' approach, with u regarded as input',...
        '      and y as output. The ccf is computed between a whitened',...
        '      u and a v filtered with the same AR model used to whiten u',...
        '',...
        'Figure Windows Produced:',... 
        '   Fig 1: Z-score time series plots of y and u for their overlap ',...
        '       period',...
        '   Fig 2: Lagged scatterplots: y lagging u',...
        '   Fig 3: Lagged scatterplots: y leading u',...
        '   Fig 4: acvf and ccf summary, no prewhitening of input',...
        '   Fig 5: acvf and ccf of prewhitened u and prewhitened y',...
        '   Fig 6: acvf and ccf summary, with prewhitening of u, filtering of u'};
msgbox1(message1,'message1');


% store path/directory to data and class scripts
path1=datdir;


% Bivariate analysis.  One series is arbitrarily assigned as the "input", the
% other as the "output."  For example, a river flow series might the input
% and a tree-ring index the output.  Terciles are made on the sorted input series


% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string
clear answer lineNo dlgTitle def prompt

%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename 
eval(['load ' pf1]);  

% Hard code background of figures
bkgcolor='White';
switch bkgcolor;
case 'Black';
   whitebg([0 0 0]);
   colnull=[1 1 1];
case 'White';
   whitebg([1 1 1]);
   colnull=[0 0 0];
end;
close all;



%****** PROMPT FOR WHICH VARIABLE-SET x and y series  TO COME FROM

kmenpred1 = menu('Which data set is y series (the output variable) to be selected from?',...
    {'V1','V2','V3'});
if kmenpred1==1;
    V=V1; 
    Vstr1='V1';
elseif kmenpred1==2;;
    V=V2; 
    Vstr1='V2';
else;
    V=V3;
    Vstr1='V3';
end;
hey1 = {'You have specified the output time series will',...
    ['be selected from dataset  ' Vstr1 '.'],...
    'Next you will be asked what dataset the input will come from'};
uiwait(msgbox(hey1,'Message','modal'));

kmenpred2 = menu('Which data set is u series (the input variable) to be selected from?',...
   {'V1','V2','V3'});
if kmenpred2==1
    U=V1; % predictor data (x)  from ...
elseif kmenpred2==2
    U=V2; 
else
    U=V3;
end;
clear V1 V2 V3;


%******* ASSIGN VARIABLE NAMES TO 1) STRUCTURE VARIABLES WITH x and y, AND 
% 2) DATA LABELS FOR sameD
%
% Note: the names are  a relict from earlier versions in which tree-ring variables were always
% the predictors and  a streamflow variable the predictand. I kept the convention for convenience of
% recoding

strtree= 'U'; % structure with input variables
dltree = U.label; % data label for input variable
strflow= 'V'; % structure with output variables
dlflow = V.label; % data label for output variable



%******* CHOOSE THE OUTPUT TIME SERIES

Lpick=menua1(V.seriesmenu,'CHOOSE OUTPUT SERIES',1,1); % menu for series selection
iy = find(Lpick);
clear Lpick;


%--- STORE OUTPUT SERIES  AND TIME COVERAGE INFO
y = V.tsm(:,iy); % predictand data, full length 
yry = V.time; % time vector for predictand
[y,yry]=trimnan(y,yry);
yunits=V.units{iy};
ylaby=V.label{iy};
yname = V.name{iy};
yid = V.id{iy};
ywhat=V.what;
   

% Set some string info on time coverage
yrgoy=min(yry);  yrspy = max(yry);
nyry=length(yry);
stryry = sprintf('%4.0f-%4.0f',yrgoy,yrspy);
strtemp = sprintf('%3.0f',nyry);
strny = ['\itN\rm = ' strtemp ' ' V.increment];

stry1=ylaby;
stry2=[stry1 '(' yunits ')'];  
strtrany='None';


%*****************  OPTIONALLY TRANSFORM OUTPUT

klogy = menu(['Tranformation of output: ' yname],...
    'No transformation','Log-10 Transformation');
switch klogy
    case 1
        % no action needed, y is the predictand series
        stry1=ylaby;
        stry2=[stry1 '(' yunits ')'];
        strtrany='None';
    case 2
        if any(y<=0)
            error([yname ' has data <=0 and so cannot be log transformed']);
        end;
        y=log10(y);
        % label for predictor (e.g., log10(P)
        stry1= ['Log10(' ylaby ')'];
        stry2= ['Log10(' ylaby ')'];
        strtrany='Log10';
    otherwise
        error('Invalid choice of klogy');
end


%**************** CHOOSE INPUT SERIES (x)

clear nms;

nx1 = size(U.tsm,2); % number of series in the input file
kwh2=1;
while kwh2==1;
    Lpick=menua1(U.seriesmenu,'CHOOSE INPUT SERIES',1,1); % menu for series selection
    ix = find(Lpick);
    if ix==iy & kmenpred1==kmenpred2;
        kwh2=1;
        hey1 ={[yname ' has already been'],...
            'selected as the output series.  Not allowed',...
            'to also select it as the input series. Pick again'};
        uiwait(msgbox(hey1,'Message','modal'));

    else
        kwh2=0;
    end
end

clear Lpick;

x = U.tsm(:,ix); % Input data, full length
yrx = U.time; % time vector for input
[x,yrx]=trimnan(x,yrx);
xunits=U.units{ix};
ylabx=U.label{ix};
xname = U.name{ix};
xid = U.id{ix};
xwhat=U.what;


% Set some string info on time coverage
yrgox=min(yrx);  yrspx = max(yrx);
nyrx=length(yrx);
stryrx = sprintf('%4.0f-%4.0f',yrgox,yrspx);
strtemp = sprintf('%3.0f',nyrx);
strnx = ['\itN\rm = ' strtemp ' ' U.increment];


%*****************  OPTIONALLY TRANSFORM INPUT

klogx = menu(['Tranformation of input: ' xname],...
    'No transformation','Log-10 Transformation');
switch klogx
    case 1
        % no action needed, x is the predictor series
        strx1=ylabx;
        strx2=[strx1 '(' xunits ')'];
        strtranx='None';
    case 2
        if any(x<=0)
            error([xname ' has data <=0 and so cannot be log transformed']);
        end;
        x=log10(x);
        % label for predictor (e.g., log10(P)
        strx1= ['Log10(' ylabx ')'];
        strx2= ['Log10(' ylabx ')'];
        strtranx='Log10';
    otherwise
        error('Invalid choice of klogx');
end



%--------  PICK A ANALYSIS PERIOD

% This by default is the overlap of x and y

yron=max([yrx(1) yry(1)]);
yroff = min([yrx(end) yry(end)]);


% Pull data overlap
Lx = yrx>=yron & yrx<=yroff;
Ly = yry>=yron & yry<=yroff;
x=x(Lx);
y=y(Ly);
yrx=yrx(Lx);
yry=yry(Ly);


% Prompt user to allow to constrain full calibration period 
prompt={'Enter period'};
def={num2str([yron yroff])};
titp1='Specify Analysis Period';
lineNo=1;
answer=inputdlg(prompt,titp1,lineNo,def);

yrgocc=str2num(answer{1});
yrgo1=yrgocc(1);
yrsp1=yrgocc(2);
if yrgo1<yron | yrsp1>yroff;
   error('Specified period outside data coverage');
end
if (yrsp1-yrgo1+1) < 15; 
   error('Minimum analysis period 15 observations');
end


%***************** GET THE CALIBRATION PERIOD TIME SERIES SEGMENTS

L = yrx>=yrgo1 & yrx<=yrsp1;
x=x(L);
y=y(L);
yrx=yrx(L);
yry=yry(L);
nyr1=yrsp1-yrgo1+1; % number of observations in analysis period

% Warn that for class assignment should be windowing in on period of no
% longer than 100 observations
if nyr1>100;
    str_warn1 ={'For class assignment, you should be restricting the analysis period',...
        'to a period of no more than 100 observations.  The restriction',...
        'is made to enable details of time series plots from observation',...
        'to observation to be seen clearly in the figures.',...
        '',...
        'You have violated this restriction by having ' num2str(nyr1) ' observations',...
        'in the specified analysis period.  The script will still run, but if being',...
        'used for class assignment, please abort and start over, picking a shorter',...
        'analysis period.  Regardless, click OK to close this box'};
    uiwait(msgbox(str_warn1,'Warning','modal'));
    kquest1 = questdlg('Abort?');
    if strcmp(kquest1,'Yes');
        return
    end;
else
end



%----  TIME SERIES PLOTS OF Z-SCORES OF INPUT AND OUTPUT

figure(1);
xlims=[yrx(1)-(0.01*(yrx(end)-yrx(1))) yrx(end)+(0.01*(yrx(end)-yrx(1)))];
hp1=plot(yrx,zscore(x),yry,zscore(y),[min(yrx) max(yrx)],[0 0]);
set(gca,'XLim',xlims);
if nyr1<=100;
    set(hp1(1),'Marker','o');
    set(hp1(2),'Marker','x');
end;
xlims=get(gca,'XLim');
ylims=get(gca,'YLim')';
xpt1=xlims(1) + 0.01* diff(xlims);
ypt1 = ylims(1)+0.99*diff(ylims);
txtthis = {['u=' xid ' (' ylabx ')'],...
        ['y=' yid ' (' ylaby ')']};
text(xpt1,ypt1,txtthis,'VerticalAlignment','Top','HorizontalAlignment','Left');
ylabel('Z-scores');
xlabel('Time');
legend('u','y');
%title(['x=' xwhat '(' xname ');  y=' ywhat '(' yname ')']);
set(gcf,'Name','Time Series Plots')


%--- LAGGED SCATTERPLOTS OF Y VS X

uinf{1}={xid,yid};
uinf{2}={xwhat,ywhat};
%uinf{2}={[xid ' ' U.label],[yid ' ' V.label]};
uinf{3}={xunits,yunits};
uinf{4}=V.increment;
uinf{5}=[yrgo1 yrsp1];

figure(1);
m=3;
lagscat2(x,yrx,y,yry,m,1);



%****************** CROSS CORRELATON ANALYSIS


%--- COMPUTE COMMON PERIOD AND CULL THAT DATA

% Trim any leading and trailing NaN
[u,yru]=trimnan(x,yrx);
[v,yrv]=trimnan(y,yry);

% Imbedded NaN?
if any(isnan(u)) | any(isnan(v));
    error('u or v has NaNs imbedded');
end;

yrgo = max([yru(1) yrv(1)]);
yrsp = min([yru(end) yrv(end)]);

Lu = yru>=yrgo & yru<=yrsp;
Lv = yrv>=yrgo & yrv<=yrsp;
u=u(Lu);
v=v(Lv);
yr = (yrgo:yrsp)';


% Find the maximum and minimum of the series so that can set the 
% x and y axis limits same for each figure
umax = max(u);
umin = min (u);
vmax = max(v);
vmin = min (v);


% Organize data.  Input might be river flow, output a tree-ring series
Z=[v-mean(v) u-mean(u);]; %  subtract means and put vectors into matrix


 
figure(4);
set(gcf,'Name','acvf''s and ccf of original data');
nlags=10; % number of lags
nar = 0; % No prewhitening

[IR0,R0,CL0] = cra(detrend(Z),nlags,nar,2);  % ccf and irf by function cra

[rq,pq,rcq,Nq,kq]=quenouille(detrend(Z(:,2)),detrend(Z(:,1)),nlags)


cc=get(gcf,'Children');
for nn=1:4;
    cca = get(cc(nn),'Children');
    if nn==1;
        set(cca(3),'Marker','o');
    else;
        set(cca(1),'Marker','o');
    end;
    
end;

CC=get(gca,'ColorOrder');
c=get(gcf,'Children');
c1=c(4); % upper left
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['acvf for output, y']);
axes(c1);
line([-nlags nlags],[0 0],'Color',CC(2,:));

c1=c(3); % upper right
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['acvf for input, u']);
axes(c1);
line([-nlags nlags],[0 0],'Color',CC(2,:));

c1=c(2); % lower left
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['ccf from u to y']);
axes(c1)
line([-nlags nlags],[0 0],'Color',CC(2,:));


% lines at approx 99% confidence interval
% Revised 2017-03-18 to use new function quenounille. Previously (commented
% out) bars computed with no adjustment of sample size for autocorrelaton
% in individual series
% cupper = 2.5758/sqrt(length(u));
% clower=-cupper;

cupper=rcq(2);
clower=-cupper;


ylims=get(gca,'YLim');
if ylims(2)>cupper
    line([-nlags nlags],[cupper  cupper],'Color',CC(3,:),'LineStyle','--');
    text(-nlags+1,cupper,'99%','VerticalAlignment','Top');
end;
if ylims(1)<clower
    line([-nlags nlags],[clower  clower],'Color',CC(3,:),'LineStyle','--');
    text(-nlags+1,clower,'99%','VerticalAlignment','Bottom');
end;

c1=c(1); % lower right
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['Impulse response estimate #1']);
axes(c1)
line([-nlags nlags],[0 0],'Color',CC(2,:));
delete(gca);


%----   EQUAL FOOTING ANALYSIS
figure(5)
%
% 1) whiten u with AR(10) model
% 2) whiten v with AR(10) model
% 3) use cra to plot acvf's of whitened u and y, and ccf between those
%   whitened series

% Model u as AR(10) and estimate residuals
w = u;
wmean = mean(u);
w1 = w-wmean; % mean-subtracted time series
dat1 =iddata(w1,[],1); % convert to iddata object
th=ar(dat1,10);   % fit AR(10) model
w1hat=predict(th,dat1,1,'zero'); % one-step ahead prediction of w1
eu = w1-w1hat.OutputData; % residuals of AR or ARMA model
eu=eu-mean(eu);
clear w wmean dat1 th w1hat

% Model v as AR(10) and estimate residuals
w = v;
wmean = mean(v);
w1 = w-wmean; % mean-subtracted time series
dat1 =iddata(w1,[],1); % convert to iddata object
th=ar(dat1,10);   % fit AR(10) model
w1hat=predict(th,dat1,1,'zero'); % one-step ahead prediction of w1
ev = w1-w1hat.OutputData; % residuals of AR or ARMA model
ev=ev-mean(ev);
clear w wmean dat1 th w1hat


set(gcf,'Name','acvf''s and ccf of prewhited input and output');
nlags=10; % number of lags
nar = 0; % No prewhitening
Ze =[ev eu]; % organize output and input series

[IR0,R0,CL0] = cra(detrend(Ze),nlags,nar,2); 
cc=get(gcf,'Children');
for nn=1:4;
    cca = get(cc(nn),'Children');
    if nn==1;
        set(cca(3),'Marker','o');
    else;
        set(cca(1),'Marker','o');
    end;
    
end;

CC=get(gca,'ColorOrder');
c=get(gcf,'Children');
c1=c(4); % upper left
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['acvf for output, y']);
axes(c1);
line([-nlags nlags],[0 0],'Color',CC(2,:));

c1=c(3); % upper right
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['acvf for input, u']);
axes(c1);
line([-nlags nlags],[0 0],'Color',CC(2,:));

c1=c(2); % lower left
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['ccf from u to y']);
axes(c1)
line([-nlags nlags],[0 0],'Color',CC(2,:));
% lines at approx 99% confidence interval
cupper = 2.5758/sqrt(length(u));
clower=-cupper;
ylims=get(gca,'YLim');
if ylims(2)>cupper;
    line([-nlags nlags],[cupper  cupper],'Color',CC(3,:),'LineStyle','--');
    text(-nlags+1,cupper,'99%','VerticalAlignment','Top');
end;
if ylims(1)<clower;
    line([-nlags nlags],[clower  clower],'Color',CC(3,:),'LineStyle','--');
    text(-nlags+1,clower,'99%','VerticalAlignment','Bottom');
end;

c1=c(1); % lower right
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['Impulse response estimate #1']);
axes(c1)
line([-nlags nlags],[0 0],'Color',CC(2,:));
delete(gca);


%****************** IRF -- COMPUTED USING INPUT WHITENED WITH AR(10) MODEL
% AND OUTPUT FILTERED WITH THAT SAME MODEL

figure(6);
set(gcf,'Name','acvf''s and ccf of filtered data');;
nlags=10; % number of lags
nar = 10; % prewhitening input with AR(10) model

[IR0,R0,CL0] = cra(detrend(Z),nlags,nar,2); 

cc=get(gcf,'Children');
for nn=1:4
    cca = get(cc(nn),'Children');
    if nn==1
        set(cca(3),'Marker','o');
    else
        set(cca(1),'Marker','o');
    end
    
end;

c1=cc(4); % upper left
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['acvf for filtered output']);
axes(c1);
line([-nlags nlags],[0 0],'Color',CC(2,:));


c1=cc(3); % upper right
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['acvf for prewhitened input']);
axes(c1);
line([-nlags nlags],[0 0],'Color',CC(2,:));

c1=cc(2); % lower left
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['ccf from prewh u to filtered y']);
axes(c1)
line([-nlags nlags],[0 0],'Color',CC(2,:));
% lines at approx 99% confidence interval
cupper = 2.5758/sqrt(length(u));
clower=-cupper;
ylims=get(gca,'YLim');
if ylims(2)>cupper;
    line([-nlags nlags],[cupper  cupper],'Color',CC(3,:),'LineStyle','--');
    text(-nlags+1,cupper,'99%','VerticalAlignment','Top');
end;
if ylims(1)<clower;
    line([-nlags nlags],[clower  clower],'Color',CC(3,:),'LineStyle','--');
    text(-nlags+1,clower,'99%','VerticalAlignment','Bottom');
end;
 
c1=cc(1); % lower right
ctit=get(c1,'Title');
ctits = get(ctit,'String');
set(ctit,'String',['Impulse response est. #2']);
axes(c1)
line([-nlags nlags],[0 0],'Color',CC(2,:));
delete(gca);



%------ CLOSING

message2={'Finished!',...
    'The key Matlab function used is cra, which applies correlation analysis to',...
    'estimate the impulse response function for a specified input series and output series.',...
    'The means, computed for the period of analysis, are subtracted from the series as a ',...
    'preliminary step. Any linear trend is removed by applying function detrend in the call',...
    '',...
    'Transformation (log10 only) of input and output series is optional. Series are transformed before ',...
    'subtracting means.',...
    '',...
    'A 2-col matrix Z, with the mean-subtracted ouput (col 1) and input (col 2) is in the ',...
    'workspace after running the script. Type ''>>help cra'' for information on the call to cra.',...
    'Refer to the code in this script to see that the call to cra is made with ''detrend(Z)''',...
    'as an input argument.'} ;
   
msgbox1(message2,'Message2');
