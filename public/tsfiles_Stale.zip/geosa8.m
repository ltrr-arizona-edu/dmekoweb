% geosa8.m   Lowpass filter design
%
% Last revised 2018-12-23
%
%
%*** UW FUNCTIONS CALLED
%
% filter1
% fltplay2
% fltplay3
% freqres1
% pltext
% respoint
% sfields
% specbt1
% wtsgaus
% wtsbinom
%
%*** TOOLBOXES NEEDED
%
% Statistics
% System identification
% Signal processing
%
%
% Lowpass filter design.  Prompted to select a series. Optional
% filter design and filtering by 1)Gaussian filter, 2) binomial
% filter, 3) Hamming filter
%
% Figure windows:
% 1- time series plot of original time series
% 2- spectrum of original time series, before filtering 
% 3- time series plots of original and filtered series superposed, with variance annotated
% 4- amplitude function of frequency response of the filter
% 5- plot of filter weights
% 6- spectra of original and filtered series superposed
%
% Revised 2015-01-15. Changed some plot colors and line types. Set xlims to
% control range of time axes in plots; also did that in called functions
% fltplay2 and fltplay3
%
% Revised 2018-12-23: Cosmetic, mainly dealing with change to Matlab's
% legend command

% Close windows and clear all workspace variables
close all;
clear;

% Hard code
datfile='Spring19'; % default .mat file with input data
datdir=cd; % directory with input data; assume current working directory
path1=datdir; % store path/directory
nwant = 1; % number of series to analyzeResu
nsers = 1; % ditto


message1 = {'Filtering',...
        '',...
        'Illustrates design of a low-pass filter for smoothing a time series.',...
        'Possible filter types include binomial, Gaussiam, and Hamming. ',...
        '',...
        'You are initially prompted to select a single time series.  This series may be',...
        'from data any of the sets V1, V2 or V3.',...
        '',...
        'Do not specify desired 50% wavelength <5 observations',...
        '',...
        'Figure windows produced:',...
        '   Fig 1: time series plot of original series',...
        '   Fig 2: spectrum of original series',...
        '   Fig 3: time series plots of original and filtered series',...
        '   Fig 4: frequency response function of selected filter',...
        '   Fig 5: graph of filter weights',...
        '   Fig 6: spectra of original and filtered series'};
msgbox1(message1,'message1');


%-------    GENERAL INPUT CONTROL

% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string

%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename into one string variable
eval(['load ' pf1])


%--- The data should be in a structure variables V1, V2, V2 
%  Check that required structures exist in the workspace
if ~all([exist('V1')==1  exist('V1')==1  exist('V1')==1]);
    error([pf1 ' does not contain V1, V2 and V3']);
end

% Check that V1, V2 and V3 are structures with required fields
for n =1:3; % loop over structures
    eval(['V = V' int2str(n) ';']);
    if ~isstruct(V); 
        error(['V' int2str(n) ' must be structure']); 
    else; % check for required fields
        sfields(V);
    end;
end;

% --- CHOOSE DATA SET THE TIME SERIES IS TO BE SELECTED FROM  

kv = menu('Time series will be selected from which data (choose one)',...
    ['V1 -- output data: ' V1.what],...
    ['V2 -- input data: ' V2.what],...
    ['V3 -- trend data: ' V3.what]);
if kv==1;
    V=V1;
elseif kv==2;
    V=V2;
else;
    V=V3;
end;

% Compute number of series in structure
nsites = size(V.name,1);

% Time increment
tinc = V.increment;

%*********  MENU TO CHOOSE SERIES

Lpick = logical(zeros(nsites,1)); % pointer to picked series
pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not

tmen = V.seriesmenu;  % menu of series, with column number
tmen1=tmen;
tmen1{nsites+1}='Accept selection';
tmen1 = char(tmen1);
tmen2=[tmen1 pflag];
[mtmen2,ntmen2]=size(tmen2);

sitenos=repmat(NaN,nwant,1); % to store index to selected sites

kwh1=1;
strchoose='Select a series';
kthis=[];
while kwh1==1;
    kmen1=menu(strchoose,cellstr(tmen2));
    if ~any(Lpick) & kmen1== nsites+1;
        msgbox1('None selected yet -- do again','Message');
    elseif kmen1==nsites+1;
        sitenos=kthis;;
        kwh1=0;
    else;
        Lpick=logical(zeros(nsites,1)); 
        pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not
        pflag(kmen1,3)='*';
        Lpick(kmen1)=1;
        kthis=kmen1;
        tmen2=[tmen1 pflag];
        
    end;
    
end;

j1 = sitenos(1);



% Find start and end time of valid data for series

YRS = repmat(NaN,nwant,2);
L = ~isnan(V.tsm(:,sitenos));  % logical pointer to valid entries 
disp(blanks(1));
disp(['Start and end ' lower(tinc) ' of valid data for series']);
fmt1 = '%50s  %4.0f-%4.0f\n';
jsite = sitenos;
yrtemp = V.time(L);
YRS(1,1)=min(yrtemp);
YRS(1,2)=max(yrtemp);


id1=V.id{jsite};


%**********  INPUT DIALOG TO SELECT PERIOD FOR ANALYSIS

titlepmt = ['Select the start and end ' lower(tinc) ' year for analysis'];
prompt = {['Enter start ' lower(tinc)],...
        ['Enter end ' lower(tinc)]};
lineNo=1;
deflt = {int2str(max(YRS(:,1))),int2str(min(YRS(:,2)))};
answer=inputdlg(prompt,titlepmt,lineNo,deflt); % answer as char in cells
% convert answer to double
yrgo = str2num(answer{1});
yrsp = str2num(answer{2});
% Store string with analysis period
txtyr = sprintf('%4.0f-%4.0f',yrgo,yrsp);


% Check that both series cover selected period
if any(YRS(:,1)>yrgo) | any(YRS(:,2)<yrsp);
    error(['Selected analysis period inconsistent with start, end ' lower(tinc) ' of series']);
end


% Display name of selected series and info
clc;  % clear the command window
strmess1={['Type of data: ' V.what ],...
        [' ID: ' V.id{sitenos}],...
        [' Name: ' V.name{sitenos}],...
        [' Time coverage: ' int2str([yrgo yrsp])]};
msgbox1(strmess1,'Selection:');

n1size=yrsp-yrgo+1; % length of selected period
% Store string with sample size, for use in later printing in figure titles.
% Note the use of \it to italicize N, of \rm to return to normal (not italic)
% font before printing the number.  This demonstrates use of TeX langauage,
% which lets you add greek characters, mathematical symbols, etc., to 
% text.  See info for the 'text' command under the html help for more on 
% TeX.  
txtna = sprintf('%5.0f',n1size);
txtn  = ['\itN = \rm' txtna]; 


%******************** GET SUBSET OF DATA FOR SELECTED PERIOD AND SERIES
L1 = V.time>=yrgo & V.time<=yrsp; % logical pointer to rows of vector tree.yr
yr1 = V.time(L1);  % time vector for selected period
X = V.tsm(L1,jsite);  % subset of times, columns with the desired data

% Check that no gaps in years (inplying no internal NaNs)
if    any(diff(yr1)~=1) ;
   error('Series has an internal NaN');
end

% Store time series for desired analysis period in x1 
x1=X(:,1);
nyr=length(x1); 

% Rename for convenience
x=x1;
yr=yr1;
nyr=nyr

% Status update
% x, yr == time series and year vector
% nyr = length of series
% yrgo, yrsp -- start abd end years 

% A y-axis label for time series
labtime=V.increment;
labtime1 = labtime ; % short label
if strcmp(lower(V.increment),'year');
    labfreq='yr^{-1}';
    labtime1 = 'yr';
else;
    labfreq=[V.increment  '^{-1}'];
    labtime1=V.increment;
end;
laby1 = [V.label{sitenos} '(' V.units{sitenos} ')'];


%***** DATA STATS
xmean=nanmean(x);


%**** TIME SERIES PLOT OF ORIGINAL DATA
figure(1);
set(gcf,'Name','Time Series Plot of Original Data');
xlims=[yr(1)-(0.01*(yr(end)-yr(1))) yr(end)+(0.01*(yr(end)-yr(1)))];
plot(yr,x,[min(yr) max(yr)],[xmean xmean]);
set(gca,'XLim',xlims)
ylabel(laby1);
xlabel(V.increment);
title(['Time Series Plot: ' id1 ';  Analysis Period: ' txtyr]);
cord=get(gca,'ColorOrder');
legend('Time Series','Long-Term Mean');
grid;
zoom xon; % commented out: bug in some matlab versions for some operating systems


%*** SPECTRUM OF ORIGINAL SERIES

figure(2)
set(gcf,'Name','Spectrum of original series');
tlab='dope';
% Set up input args to specbt1.m
prevwind=1; % preserve windows thru this one
kopt(1)=2; % non-interactive mode

M= round(nyr/6); % truncation point of lag window

f = 0:1/nyr:0.5; % frequencies for spectral estiamtes

% Call user-written function specbt1.m to get spectral estimates
Gx=specbt1(x,M,f,prevwind,'dummy',kopt,tlab); % spectrum of output
ytype='Linear'; %y axis linear by default

kwh1=1;
while kwh1; % allows toggling of spectrum axis
    
    if strcmp(ytype,'Linear')
        h5p2=plot(Gx(:,1),Gx(:,3),...
            Gx(:,1),Gx(:,4),Gx(:,1),Gx(:,5));
    elseif strcmp(ytype,'Log')
        h5p2=semilogy(Gx(:,1),Gx(:,3),...
            Gx(:,1),Gx(:,4),Gx(:,1),Gx(:,5));
    end
    
%     
%     % Plot spectrum with its 95% confidence band
%     h5p2=plot(Gx(:,1),Gx(:,3),...
%         Gx(:,1),Gx(:,4),Gx(:,1),Gx(:,5));
    
    set(h5p2(1),'Color',cord(1,:));
    set(h5p2(2),'Color',cord(1,:));
    set(h5p2(3),'Color',cord(1,:));
    set(h5p2(2),'LineStyle','--');
    set(h5p2(3),'LineStyle','--');
    set(h5p2(1),'LineWidth',2); % thicken line for spectrum of input
    grid;
    zoom xon; % commented out: bug in some matlab versions for some operating systems
    
    txt5a = ['  \itM/N \rm= ' int2str(M) '/' int2str(nyr)]; % string for M/N
    
   hleg2= legend(['Spectrum, ' txt5a],'95% CI');
    
    % Set axes postion to allow for 2 lines in title
    set(gca,'Position',[0.1300    0.1100    0.7750    0.80])
    
    
    title(['Spectrum of ' id1 ' Before Filtering']);
    xlabel(['Frequency (' labfreq ')']);
    ylabel('Relative Variance');
    
    %Compute and plot bandwidth
    bw = 4/(3*M);  % see Ljung (1987, p. 155), Chatfield (1975, p. 154)
    % Note that the "Hamming" window as defined in system ident toolbox and Ljung
    % is identical to Chatfield's Tukey Window
    % Put bandwidth bar 0.3 from top of figure, centered
    ylims = get(gca,'Ylim');
    yrng = abs(ylims(2)-ylims(1));
    
    
    if strcmp(ytype,'Linear');
        ypoint = ylims(2)-0.3*yrng;
        line([0.25-bw/2 0.25+bw/2], [ypoint ypoint]);
        line([0.25-bw/2  0.25-bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
        line([0.25+bw/2  0.25+bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
        htt = text(0.25+bw,ypoint+yrng/100,'Bandwidth');
    elseif strcmp(ytype,'Log');
        dlog=log10(ylims(2))-log10(ylims(1));
        dlog5=dlog/5;
        dfact = 10^(-dlog5);
        ypoint = dfact*ylims(2);
        line([0.25-bw/2 0.25+bw/2], [ypoint ypoint]);
        htt = text(0.25+bw,ypoint,'Bandwidth');
    end;
    
    % Clean up legend for compatibility with Matlab R2018b
    hleg2.String(3:end)=[];
    
    ypoint = ylims(2)-0.3*yrng;
    
    km = menu('Choose one:','Toggle y-axis log/linear',...
        'Accept Spectrum');
    if km==1; % toggle 
        if strcmp(ytype,'Log');
            ytype='Linear';
        else;
            ytype='Log';
        end;
        kwh1=1
    elseif km==2;
        kwh1=0;
    end
    
end; % while kwh1;


%**************  DESIGN AND CHOOSE FILTER

prevwind=2;

kmen1=menu('Choose type of filter',...
    'Low-Pass, Gaussian',...
    'Low-Pass, Binomial',...
    'Low-Pass, Windowing Method (Hamming)');
if kmen1==1;
    ftype='Gaussian';
elseif kmen1==2;
    ftype='Binomial';
elseif kmen1==3;
    ftype='Windowing Method (Hamming)';
else;
    error('Invalid kmen1');
end;


% Design filter
switch ftype;
case 'Gaussian';
    [b,p50,y,yry]=fltplay3(x,yr,prevwind,1);   
case 'Binomial';
    [b,p50,y,yry]=fltplay3(x,yr,prevwind,2);   
case 'Windowing Method (Hamming)';
    [b,p50,y,yry]=fltplay2(x,yr,prevwind);   
end;


% Turn on zoom for the smoothed plots, and put id in title
figure(3)
zoom xon ;  % commented out: bug in some matlab versions for some operating systems 
h4t1=get(gca,'title');
strold = get(h4t1,'string');
set(h4t1,'string',[id1 '-- ' strold]);
xlabel(V.increment);
ylabel(laby1);
grid;



figure(3);
set(gcf,'Name','Time series plots');
figure(4); 
set(gcf,'Name','Frequency response of filter');
figure(5);
set(gcf,'Name','Filter weights');





%*****************   SPECTRA OF ORIGINAL AND FILTERED SERIES

% Hard code truncation point
M = floor(nyr/6);

f = 0:1/nyr:0.5; % frequencies for spectral estiamtes

kopt(1)=2;
G1x=specbt1(x,M,f,prevwind,'dummy',kopt,tlab);
G1f=specbt1(y,M,f,prevwind,'dummy',kopt,tlab);

figure(6) ;
set(gcf,'Name','Spectra of original and filtered series');
% Set up input args to specbt1.m
prevwind=1; % preserve windows thru this one
kopt(1)=2; % non-interactive mode

ytype='Linear';
kwh2=1;
while kwh2;
    
    if strcmp(ytype,'Linear');
        hp6=plot(G1x(:,1),G1x(:,3),G1f(:,1),G1f(:,3));
    elseif strcmp(ytype,'Log');
        hp6=semilogy(G1x(:,1),G1x(:,3),G1f(:,1),G1f(:,3));
    end
    
    set(hp6(1),'Color',cord(1,:),'LineStyle','--');
    set(hp6(2),'Color',cord(2,:),'LineWidth',2);
    
    % string for M/N
    txt3a = ['\itM/N \rm= ' int2str(M) '/' int2str(nyr)];
    
    title(['Spectra of ' id1 ',  ' txt3a]);
    hleg6=legend('Original Series','Filtered Series');
    xlabel(['Frequency (' labfreq ')']);
    ylabel('Relative Variance');
    
    %Compute and plot bandwidth
    bw = 4/(3*M);  % see Ljung (1987, p. 155), Chatfield (1975, p. 154)
    % Note that the "Hamming" window as defined in system ident toolbox and Ljung
    % is identical to Chatfield's Tukey Window
    % Put bandwidth bar 0.3 from top of figure, centered
    ylims = get(gca,'Ylim');
    yrng = abs(ylims(2)-ylims(1));
    
    if strcmp(ytype,'Linear');
        ypoint = ylims(2)-0.3*yrng;
        line([0.25-bw/2 0.25+bw/2], [ypoint ypoint]);
        line([0.25-bw/2  0.25-bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
        line([0.25+bw/2  0.25+bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
        htt = text(0.25+bw,ypoint+yrng/100,'Bandwidth');
    elseif strcmp(ytype,'Log');
        if ylims(1)<=0;
            dlog=log10(ylims(2))-0;
        else;
            dlog=log10(ylims(2))-log10(ylims(1));
        end;
        dlog5=dlog/5;
        dfact = 10^(-dlog5);
        ypoint = dfact*ylims(2);
        line([0.25-bw/2 0.25+bw/2], [ypoint ypoint]);
        htt = text(0.25+bw,ypoint,'Bandwidth');
    end;
    
    hleg6.String(3:end)=[];
    
    km = menu('Choose one:','Toggle y-axis log/linear',...
        'Accept Spectra');
    if km==1; % toggle
        if strcmp(ytype,'Log');
            ytype='Linear';
        else;
            ytype='Log';
        end;
        kwh2=1
    elseif km==2;
        kwh2=0;
    end
    
    
end ; % while kwh2;

Results.when=datestr(date);
Results.t=yr; % time vector for original series (selected analysis period)
Results.x=x; % original time series, times t
Results.ts=yry; % time vector for filtered series (selected analysis period)
Results.xs=y; % filtered times series, times ts
Results.N=nyr; % number of observations in original series (before filtering)
Results.Ns=length(y); % number of observations in filtered series
Results.how = ftype; % filtering method
Results.weights=b; % filter weights
Results.period50=p50; % period at which amplitude of frequency response of filter is 0.5

Results.what=char({'Results.when = date analysis done',...
        '.t = time vector for original series (selected analysis period)',...
        '.x = original time series, times t',...
        '.ts = time vector for filtered series (selected analysis period',...
        '.xs  =  filtered times series, times ts',...
        '.N =  number of observations in original series (before filtering)',...
        '.Ns =  number of observations in filtered series',...
        '.how  = filtering method',...
        '.weights =  filter weights',...
        '.period50  = period at which amplitude of frequency response of filter is 0.5'});

    S=Results;
message2={'Finished! S is a structure with data and statistics from the analysis',...
    'S.what defines the fields in stucture S',...
    '',...
    'Interactive user-written functions fltplay3 (for binomial and Gaussian) and fltplay2 (for windowed, or Hamming',...
    'are used by this script in the filter design. Refer to comment sections in those functions if you want to use',....
    'the filters outside this script'};  
 
msgbox1(message2,'message2');
