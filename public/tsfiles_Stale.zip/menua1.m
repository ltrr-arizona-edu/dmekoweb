function Lpick=menua1(snames,str1,maxn,kopt)
% menua1:  toggle menu to select subset of names from list of names
% Lpick=menua1(snames,str1,maxn,kopt);
% Last revise 11-17-01
%
% Toggle menu to select subset of names from list of names.  Utility function for selecting variables 
% from large list of variables. One use is in class script geosa11.m to select predictand and 
% potential predictors for regression.
%
%*** INPUT
%
% snames{nser x 1}  cell of strings that are series names for full set of nser series
% str1 (1 x ?)s first line of prompt (e.g., CHOOSE PREDICTAND SERIES)
% maxn (1 x 1)i  maximum number of series allowed to be selected 
% kopt (1 x 1)i  option for starting point for selection
%   ==1 no series initially selected
%   ==2 first maxn of nser series initially selected
%
%
%*** OUTPUT
%
% Lpick (nser x 1)L  logical indicator of series selected (1) or not (0)
%
%
%*** REFERENCES -- none
%*** UW FUNCTIONS CALLED -- none
%*** TOOLBOXES NEEDED -- none
%
%*** NOTES


% CHECK INPUT

if ~iscell(snames);
    error('snames must be cell');
end;
nser = length(snames); % number of series to choose from

if maxn>nser;
    error('maxn cannot be larger than nser');
end;


% INITALIZE LOGICAL POINTER

if kopt==1;
    L=zeros(nser,1);
    yesv=repmat(blanks(2),nser);
else;
    if maxn==nser;
        L=ones(nser,1);
        yesv=repmat('Y-',nser,1);
    else;
        L=[ones(maxn,1); zeros((nser-maxn),1)];
        yesv1 = repmat('Y-',maxn,1);
        yesv2= repmat(blanks(2),(nser-maxn),1);
        yesv = [yesv1; yesv2];
    end;
end;
L=logical(L);
nsum = sum(L);

strtitle = {str1,['(' int2str(nsum) ' selected so far, ' int2str(maxn) ' allowed)']};

yesc=cellstr(yesv);
yesc{nser+1}='  ';
s1=snames;;
s1{nser+1}='SATISFIED!';
mchoice=cellstr([char(yesc)  char(s1)]);


kwh1=1;
while kwh1;
    kmen=menu(strtitle,mchoice);
    if kmen==(nser+1) & nsum==0;
          uiwait(msgbox('None selected yet -- Select!','Message','modal'));
      elseif kmen==(nser+1) & nsum>maxn;
          uiwait(msgbox('Too many selected. Toggle one off!','Message','modal'));
      elseif kmen==(nser+1); 
          kwh1=0;
      else; 
          if L(kmen)==0;
              L(kmen)=1;
              yesc{kmen}='Y-';
          else;
              L(kmen)=0;
              yesc{kmen}='  ';
          end;
          nsum = sum(L);
          strtitle = {str1,['(' int2str(nsum) ' selected so far, ' int2str(maxn) ' allowed)']};
          mchoice=cellstr([char(yesc)  char(s1)]);
      end;
end;

Lpick=L;
