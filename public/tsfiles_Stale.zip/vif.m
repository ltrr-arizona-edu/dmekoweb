function Result = vif(X,k)
% vif: variance inflation factor
% Result = vif(X,k);
% Last revised 2005-4-5
%
% Compute variance inflation factor for a matrix of predictor variables to be
% used in linear regression.   
%
%*** INPUT
% 
% X(mX x nX)r matrix of mX observations on nX predictor variables
% k (1 x 1)i  options
%   k(1) optional graphics output 
%       ==1 no graphics output
%       ==2 graphics output (see OUTPUT)
%
%*** OUTPUT
%
% Result -- structure of results
%   .d (nX x 1)r  variance inflation factor for each of the variables in X
%   .dmean (1 x 1)r  mean vif over all predictors
%   .R2 = coefficient of multiple determination of each predictor regressed on all other predictors
%
%
%*** REFERENCES -- none
%
% Haan C. T. (2002) Statistical methods in Hydrology, second edition. Iowa State University Press, Ames, Iowa
%
%*** UW FUNCTION CALLED -- none
%
%
%*** TOOLBOXES NEEDED -- none
%
%*** NOTES
%
% Variance inflation factor is defined as 
%
% VIF = 1 / (1-R(i)^2), 
%   where R(i)^2 is the multiple coefficient of determination between X(i) and all the other X's in
%   the regression equations.  If R(i)^2 is zero, the VIF is 1.0, and the X's are linearly independent.
%   At the other extreme, if R(i)^2=1, VIF is unbounded.  Large VIF indicates multicollinearity.  
%   What is considered "large"  depends on investigator.  Some use a value of 5 and tother 10.  
%
%   Some use the average  VIF of all predictors and consider and aveage VIF "considerably" larger than
%   one as evidence of multicollinearity
%
%   Some computer packages give the "tolerance", which is 1/VIF.


%--- CHECK INPUT

if any(any(isnan(X)));
    error('NaNs not allowed in X');
end;
[mX,nX]=size(X);

if ~(isscalar(k) & (k==1 |k==2));
    error('k must be 1 or 2');
end;

%--- ALLOCATE

d=repmat(NaN,nX,1); % to hold VIF of each predictor
r2=repmat(NaN,nX,1);
j=1:nX;

%---COMPUTE

for n=1:nX;
    j1=setdiff(j,n);
    x=X(:,n);
    X1=[ones(mX,1) X(:,j1)];
    [b,bint,r,rint,stats] = regress(x,X1);
    b1=X1\x;
    r2(n)=stats(1);
    d(n)=1/(1-stats(1));
end;

Result.what=char({'Fields of Result:',...
    'R2 = coefficient of multiple determination of each predictor regressed on all other predictors',...
    'vif = variance inflation factor of each predictor',...
    'vif_mean = mean variance inflation factore (average over all predictors)'});
Result.R2=r2;
Result.vif=d;
Result.vif_mean=mean(d);


