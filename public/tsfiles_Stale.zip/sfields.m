function sfields(V)
% sfields:  check for existence of required fields in structure variable for time series course
% sfields(V); 
% Last revise 11-15-01
%
% Check for existence of required fields in structure variable for time series course
%
%*** INPUT
%
% V structure variable to be checked
%
%
%*** OUTPUT
%
% No arguments.
% Error message if any required field missing.
%
%*** REFERENCES -- NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED  -- NONE
%
%*** NOTES
%
% The field names are hard coded


% Hard code

% Expected field names
fnneed = {'txtfile','sourcefile','what','label','units','increment','msscode','catname',...
        'startcolumn','tsm','time','tvalid','id','seriesmenu','category','name', 'lat',...
        'lon','elev','description'};
  

% Check that V is a structure
if ~strcmp(class(V),'struct');
    error('V is not a structure');
end;


% Get the fieldnames
fn = fieldnames(V); % stored in cell

n1=length(fn);
for n = 1:n1;
    fnthis = fn{n};
    i1 = strmatch(fnthis,fnneed);
    if isempty(i1);
        error(['Field  ' fnthis ' not found in structure']);
    end;
end;




