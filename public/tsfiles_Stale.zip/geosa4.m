% geosa4 -- spectral density function
%
% Last revised 2018-12-23
%
% UW functions called
%
%  acf -- autocorrelation function
%  specbt1 -- spectrum by Blackman-Tukey method
%  sfields -- check that required structures available
%
% Toolboxed needed
%  statistics
%  system identification
%
% Revised 2016-12-04:  structure S output
% Revised 2018-12-23:  cosmetic changes & some labeling changes in specbt1

% Close any open windows and clear variables from workspace
close all; % close any currently open figure windows
clear all;

% Hard code
datfile='Spring19'; % default .mat file with input data
datdir=cd; % directory with input data; assumed to be current directory
path1=datdir; % store path/directory
nwant = 1; % number of series to analyze


%********  INTRODUCTORY MSG

message1 = {'Spectrum',...
        '',...
        'This script illustrates the sample spectrum.  The estimation method is ',...
        'Fourier tranformation of the autocovariance function.  A window-closing',...
        'approach is taken, with user control of size of the lag window',...
        '',...
        'You will be prompted to select a single time series for analysis. ',...
        'Generally, this series should come from the V1 or V2 data sets because',...
        'the spectral estimation assumes stationarity.',...
        '',...
        'Figure windows produced:',...
        '   Fig 1: Time series plot',...
        '   Fig 2: Autocorrelation function and 95% confidence interval',...
        '   Fig 3: Sample spectrum, with 95% CI and ',...
        '       bandwidth'};
msgbox1(message1,'message1');



% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string

%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename 
eval(['load ' pf1])


%--- The data should be in a structure variables V1, V2, V2 
%  Check that required structures exist in the workspace
if ~all([exist('V1')==1  exist('V1')==1  exist('V1')==1]);
   error([pf1 ' does not contain V1, V2 and V3']);
end

% Check that V1, V2 and V3 are structures with required fields
for n =1:3; % loop over structures
    eval(['V = V' int2str(n) ';']);
    if ~isstruct(V); 
        error(['V' int2str(n) ' must be structure']); 
    else; % check for required fields
        sfields(V);
    end;
end;



% Menu to choose type of variable for analysis 

kv = menu('Time series will be selected from which data (choose one)',...
    'V1 -- output data',...
    'V2 -- input data',...
    'V3 -- trend data');
if kv==1;
    V=V1;
elseif kv==2;
    V=V2;
else;
    V=V3;
end;

% Compute number of series in structure
nsites = size(V.name,1);

% Time increment
tinc = V.increment;


%*********  MENU TO CHOOSE SERIES

Lpick = logical(zeros(nsites,1)); % pointer to picked series
pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not

tmen = V.seriesmenu;  % menu of series, with column number
tmen1=tmen;
tmen1{nsites+1}='Accept selection';
tmen1 = char(tmen1);
tmen2=[tmen1 pflag];
[mtmen2,ntmen2]=size(tmen2);
 
sitenos=repmat(NaN,nwant,1); % to store index to selected sites

kwh1=1;
strchoose='Select a series';
kthis=[];
while kwh1==1;
   kmen1=menu(strchoose,cellstr(tmen2));
   if ~any(Lpick) & kmen1== nsites+1;
       uiwait(msgbox('None selected yet -- do again','Message','modal'));
   elseif kmen1==nsites+1;
       sitenos=kthis;;
       kwh1=0;
   else;
       Lpick=logical(zeros(nsites,1)); 
       pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not
       pflag(kmen1,3)='*';
       Lpick(kmen1)=1;
       kthis=kmen1;
       tmen2=[tmen1 pflag];
       
   end;
 
end;

j1 = sitenos(1);



% Find start and end time of valid data for series

YRS = repmat(NaN,nwant,2);
L = ~isnan(V.tsm(:,sitenos));  % logical pointer to valid entries 
disp(blanks(1));
disp(['Start and end ' lower(tinc) ' of valid data for series']);
fmt1 = '%50s  %4.0f-%4.0f\n';
jsite = sitenos;
yrtemp = V.time(L);
YRS(1,1)=min(yrtemp);
YRS(1,2)=max(yrtemp);


%**********  INPUT DIALOG TO SELECT PERIOD FOR ANALYSIS

titlepmt = ['Select the start and end ' lower(tinc) ' for analysis'];
prompt = {['Enter start ' lower(tinc)],...
	['Enter end ' lower(tinc)]};
lineNo=1;
deflt = {int2str(max(YRS(:,1))),int2str(min(YRS(:,2)))};
answer=inputdlg(prompt,titlepmt,lineNo,deflt); % answer as char in cells
% convert answer to double
yrgo = str2num(answer{1});
yrsp = str2num(answer{2});
% Store string with analysis period
txtyr = sprintf('%4.0f-%4.0f',yrgo,yrsp);


% Check that both series cover selected period
if any(YRS(:,1)>yrgo) | any(YRS(:,2)<yrsp);
	error(['Selected analysis period inconsistent with start, end ' lower(tinc) ' of series']);
end


% Display name of selected series and info
clc;  % clear the command window
strmess1={['Type of data: ' V.what ],...
        [' ID: ' V.id{sitenos}],...
        [' Name: ' V.name{sitenos}],...
        [' Time coverage: ' int2str([yrgo yrsp])]};
msgbox1(strmess1,'Selected');


n1size=yrsp-yrgo+1; % length of selected period
% Store string with sample size, for use in later printing in figure titles.
% Note the use of \it to italicize N, of \rm to return to normal (not italic)
% font before printing the number.  This demonstrates use of TeX langauage,
% which lets you add greek characters, mathematical symbols, etc., to 
% text.  See info for the 'text' command under the html help for more on 
% TeX.  
txtna = sprintf('%5.0f',n1size);
txtn  = ['\itN = \rm' txtna]; 


% SET LABELS, TITLES FOR PLOTS

ylab1=[V.label{sitenos} ' (' V.units{sitenos} ')'];
xlab1=V.increment;
tit1 = ['Time Series Plot, ' txtyr ', '  txtn];  

id=V.id{jsite};


%******************** GET SUBSET OF DATA FOR SELECTED PERIOD AND SERIES
L1 = V.time>=yrgo & V.time<=yrsp; % logical pointer to rows of vector tree.yr
yr = V.time(L1);  % time vector for selected period
X = V.tsm(L1,jsite);  % subset of times, columns with the desired data
	

% Store time series for desired analysis period in x1 

x1=X(:,1);

%**********************  TIME SERIES PLOTS

figure(1);  % Want plots in figure window 1
set(gcf,'Name','Time Series Plot');

% Make plot

xlims=[yr(1)-(0.01*(yr(end)-yr(1))) yr(end)+(0.01*(yr(end)-yr(1)))];
h1=plot(yr,x1,[min(yr) max(yr)],[mean(x1) mean(x1)]); %  series amd ,meam
% h1 is handle to plot -- in case needed later
set(gca,'XLim',xlims)
xlabel(xlab1);
ylabel(ylab1);
% Add legend and title
legend(V.id{jsite},'Mean');
title([V.name{jsite},', ' txtyr ',  ' txtn]);
grid; % turn on grid
%zoom xon;  % use of xon means retains full range of y axis while zooming


%*********************  AUTOCORRELATION FUNCTION, WITH LARGE-LAG 2 STANDARD RRORS

nlag = 20 ;   % will want acf at lags 1-20 yr

% Compute the acf and related quantities. To do this, will call the user-written
% function acf.m
% Large-lag standard error from p. 35, Box and Jenkins (1976)
% Prob point for one-tailed test from p. 60,  WMO (1966) (cliate change methods)plot(x
[rho,SE2,r95]=acf(x1,nlag);  
% rho is the acf at lags 1-20, as a row vector
% SE2 is 2* large lag standard error of the acf estimates, as row vector
% r95 is the size of the first order autocorrelation coefficient significant
% at the 95% level in a one-sided test according to WMO(1966)


% Plot the acf and its large-lag standard error as stem plot
figure(2);
set(gcf,'Name','ACF');
subplot(1,1,1);
tlag = (1:20);
hacf = stem(tlag,rho);
line([1 20],[0 0]); % add horiz line at zero
hold on; % Set hold to on to add the error bars
hleg=plot(tlag,SE2,'r--',tlag,-SE2,'r--');
if strcmp(tinc(end),'s');
    xlabel(['lag(' lower(tinc) ')']);
else;
   xlabel(['lag (' lower(tinc) 's)']);
end;

ylabel('Autocorrelation');
set(gca,'YLim',[-1 1]);

% Build title
txt1 = ['ACF,  ' V.name{jsite} ';  ' txtn];
title(txt1);

% Legend
legend([hacf(1); hleg(1)],'ACF estimates','2 * Large-Lag SE');

hold off

clc;
disp(strmess1);



% SAMPLE SPECTRUM, BLACKMAN-TUKEY METHOD

prevwind=2; % previous window. do not want to overwrite



% Compute frequencies for estimates
nyr=length(x1);
f = 0:1/nyr:0.5;

% set default lag window at length nyr/4
M = round(nyr/4);


% Call user-written function specbt1.m to compute and plot spectrum
kopt=1;  % plot on lineary-axis scale. will be prompted for optional log scale
if strcmp(tinc(end),'s');
    tlab=tinc;
else;
    tlab=[tinc 's']; % period label
end;
G = specbt1(x1,M,f,prevwind,V.id{j1},kopt,tlab);
varlist='Spectrum from geosa4.m ';
varlist = char(varlist,'G -- multi-column matrix of spectral results from specbt1.m:',...
   '   col 1- frequency points for spectral estimates',...
   ['   col 2- corresponding period (in ' lower(tinc) ')'],...
   '   col 3- the spectral estimates',...
   '   col 4- lower bound of 95% confid interval on spectrum',...
   '   col 5- upper bound of 95% confid interval on spectrum',...
   '',...
   'This script calls my function spectbt1 (which you have) to do the spectral computations.',...
   'See comments in spectbt1 if you are want to call it from one of your own scripts.');

% Add analysis period to title
titget=get(gca,'Title');
tt1=get(titget,'String');
tt2=[tt1 ', ' txtyr];
set(titget,'String',tt2);

set(gcf,'Name','Sample Spectrum');
%zoom xon; % enable zooming-- bug in some matlab/OS combinations


% Store output structure S
S.what=char({['Results of script geosa4 run on ' datestr(date)],...
    'S is structure with fields:',...
    '',...
    'tsm (?x2)r time and time series for period of analysis',...
    'M (1x1)i number of lags used in the spectral analysis',...
    'G -- matrix with spectrum and confidence interval',...
    'varlist --- definitions of columns of G'});
S.tsm=[yr x1];
S.M = M;
S.G=G;
S.varlist=varlist;



clc;

message2={'Finished! Results of the spectral analysis are store in a structure, S, ',...
    'which can be used for subsequent analysis outside this script',...
    '',...
    'This script calls function spectbt1 (which you have) to do the spectral computations.',...
    'See comments in spectbt1 if you are want to call it from one of your own scripts.'};
msgbox1(message2,'message2');



