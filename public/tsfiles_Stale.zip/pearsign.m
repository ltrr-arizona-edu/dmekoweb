function [rcrita,pvalue,unused,Nprime]=pearsign(r,N,m,alph1,bonf,rho)
% pearsign: p-value and critical level of Pearson correlation
% [rcrita,pvalue,unused,Nprime]=pearsign(r,N,m,alph1,bonf,rho);
% Last revised 2011-8-3
%
% P-value and critical level of Pearson correlation coefficient between two time series.  
% Adjustment to effective sample size from first order autocorrelations of the two series.
% Optional adjustment for autocorrelation and multiple comparisons  (Bonferrroni)
%
%*** INPUT
% r (1 x 1)r  computed correlation coefficient; if [], p-value will be returned as []
% N (1 x 1)i sample size
% m (1 x 1)i number of correlations scanned simultaneously for significance; set m=1 if no multiple comparisons
% alph1 (1 x 1)r alpha level for significance (e.g. 0.05 for 2-tailed test at .05 alpha level)   (see notes)
% bonf (1 x 1)L  option for bonferroni adjustment
%   ==1 Yes
%   ==0 No
% rho (1 x 2)r first order autocorrelation coefficients of the two series; if rho is [], rho=[0 0]
% is assumed, which leads to no adjustment of sample size for autocorrelaion
%
%*** OUTPUT
%
% rcrita (1 x 1)r  critical level of correlaton for specified alpha level (alph1) and sample size N
% pvalue (1 x 1)r p-value for r, applicable for two tailed test with H0: rho=0;  if r is [], pvalue returned
%   as []
% rcritc (1 x 1)r unused: reserved for future; returned as []
% Nprime(1x 1)i  effective sample size, computed following Dawdy and Matalas (1964) (see notes)
%
%*** REFERENCES
%
%
% Snedecor, G.W., and Cochran, William G., 1989, Statistical methods, eighth edition, Iowa State
% University Press, Ames, Iowa, 803 p (see page 167 -- Bonferroni adjustment)
%
% Dawdy, D.R., and Matalas, N.C., 1964, Statistical and probability analysis of hydrologic data, 
% part III: Analysis of variance, covariance and time series, in Ven Te Chow, ed., Handbook of 
% applied hydrology, a compendium of water-resources technology: New York, McGraw-Hill 
% Book Company, p. 8.68-8.90. (sample size adjustment for first-order autocorrelation)
% 
%
%*** UW FUNCTIONS CALLED -- NONE
%
%*** TOOLBOXES NEEDED 
%
% Statistics
%
%*** NOTES
%
% The two populations are assumed to be jointly normally distributed with zero correlation.  The
% null hypothesis is that the correlation is zero.  The alt. hypothesis is that the correlation is
% not zero.  
%
% The test statistic  t=r*sqrt(N-2)/sqrt(1-r*r),  has N-2 degrees of freedom
% where r is the computed sample correlation and N is the sample size (possibly adjusted for autocorrelation)
% If r is not [], the t statistic is computed for the given r and sample size;  if p is the corresponding
%   probability point of the t cdf, the p-value is reported as 2(1-p).  This gives the p-value applicable
%   for a two-tailed test of H0: rho=0.  For example, if p=0.975, pvalue=0.05
% The critical threshold (rcrita) for the specified sample size and alpha level (two tailed) is
%   computed by solving the equation for the test statistic for r. In this solution, N is the sample size, 
%   and t is the t-statistic with cdf value 1-alph1/2 and degrees of freedom N
%
% alph1.  The alpha level is appropriate for a two-tailed test.  Thus an alpha level of 0.05 is appropriate
% for the the 95% significance level. Null hypothesis is that the population correlation is zero.  Alt hypothesis is that
% correlation is not zero
%
% Nprime. This effective sample size depends on the original sample size and the first-order autocorrelation
% coefficients passed as input arguments rho. User should make certain first-order autocorrelation significant
% before passing those r(1) coefficients in rho.  If both are NOT significant, set rho=[], which specifies
% DO NOT adjust sample size for autocorrelation. 
%
% Bonferroni adjustment.  No Bonferroni adjustment is done if bonf=0.  The Bonferroni adjustment will have 
% no effect if m=1 even if bonf=1. 
%
%
% Mod 2005-4-11;  Revised to exclusively use the more generally applicable t-distribution rather than normal
% approximation and to return the p-value in addition to the critical r for specifed alpha
% Revision 2011-8-3.  Added code to set rho to [0 0] if happens that eight
%   lag-1 autocorrelation is negative.  This avoids the possible bogus
%   generation of an effective sample size LARGER than the original

% Sample size
[mN,nN]=size(N);
if mN~=1 | nN~=1;
    error('Sample size N must be a scalar');
end;

% number of evaluated correlations
[mm,nm]=size(m);
if mm~=1 | nm~=1;
    error('Number of evaluated correlations m must be a scalar');
end;

% Autocorrelation
% If input rho is empty, you have decided not to make any adjustment to
% effective sample size because of autocorrelation in the individual
% series. If either of the lag-1 autocorrelations is negative, you will now
% want to make and adjustment.  
if isempty(rho)| any(rho<0)
    rho=[0 0];
else;
    if any(rho<-1) | any(rho>1);
        error ('rho out of range');
    end;
end;

% Alpha
if alph1<0 | alph1>0.5;
    error ('alph1 should be between zero and 0.5, and is usually .01 or 0.05');
end;


% Sample size adjustment
Nprime = round(N * (1-rho(1)*rho(2))/(1+rho(1)*rho(2)));


% Bonferroni
if bonf==0; % no adjustment wanted
else
    alph1 = alph1/m;
end;


%--- COMPUTE t statistic -- only if input argument r not []

if ~isempty(r)
    tstat=r * sqrt(Nprime-2)/sqrt(1-r*r);   % t-value corresponding to observed r
    if tstat<0
        tstat=-1.0*tstat;
    end;
    p=tcdf(tstat,Nprime-2); % cdf of t dist at the computed t stat
    pvalue=2*(1-p); % p-value applicable to two-tailed test of H0: rho=0.
else
    pvalue=[]; % no r has been passed as input, so no p-value can be computed
end;


%--- COMPUTE CRITICAL r FOR SPECIFIED ALPHA

tcrit = tinv(1-(alph1/2),Nprime-2);

% Solve the test statistic equation for critical r: equivalent to
% t/sqrt(N-2+t*t), where N is sample size (adjusted for autocorrelation if
% needed), and t is tcrit

c=tcrit/sqrt(Nprime-2);
cc = c*c;
rsqcrit = cc/(1+cc);
rcrita= sqrt(rsqcrit);
if r<0;
    rcrita=-rcrita;
end;

%--- STORE THE OUTPUT ARG RESERVED FOR FUTURE USE

unused=[];


