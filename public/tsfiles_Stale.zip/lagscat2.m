function lagscat2(x,yrx,y,yry,m,nfigs)
% lagscat2: lagged scatterplots two time series
% lagscat2(x,yrx,y,yry,m,nfigs);
% Last revised  10-30-02
%
% Lagged scatterplots are scatterplots of y(t) vs x(t-k). Plots are made 
% for lags k=1,...m.  m may set as high as N/3, where N is the sample size
%
%*** IN ********************
%
% x (mx x 1)r  time series #1 , m1 observations
% yrx (mx x 1)i year vector for x
% y (my x 1)r  time series #1 , m1 observations
% yry (my x 1)i year vector for x
% m (1 x 1)i  number of maximum lags for scatterplots 
% nfigs (1 x 1)i <optional>  start new figure windows at window nfigs+1
%
%*** OUT ********************
%
% No output arguments
% Plots are created in windows nfigs+1, nfigs+2,....
% Four pairs of axes are produced in each figure window
%
%*** REFERENCES 
%
% Benjamin,J.R., and Cornell, C.A., 1970.  Probability, Statistics and decision for civil engineers. 
% McGraw-Hill Book Company (see p. 417 for test of significance of correlation)
%
% Dawdy, D.R., and Matalas, N.C., 1964, Statistical and probability analysis of hydrologic data, 
% part III: Analysis of variance, covariance and time series, in Ven Te Chow, ed., Handbook of 
% applied hydrology, a compendium of water-resources technology: New York, McGraw-Hill 
% Book Company, p. 8.68-8.90. (sample size adjustment for first-order autocorrelation)
%
%
%*** UW FUNCTIONS CALLED 
% pearsign
%
%*** TOOLBOXES NEEDED 
% statistics
%
%*** NOTES
%
% More on the input:
%  m: maximum allowable value is 13
%
%  nfigs:  allows you to retain nfigs existing figure windows when calling 
%  lagscat from another function that has generated graphics you do not want 
%  to overwrite.  For example, if calling function has 6 
%  figure windows you want to retain, set nfigs=6 in calling lagscat.  
%
%  Approximate 99% confidence level for correlation coefficient is computed following 
%  Benjamin and Cornell (1970), with adjustment for autocorrelation of the individual series
%  following Dawdy and Matalas (1964).



%*******************  CHECK INPUTS

% If only 2 input args, assume you want scatterplots to start in figure 1
if nargin==2; 
   nfigs=0;
end;

[mx,nx]=size(x);
if nx~= 1;
   error('x should be a column vector');
end
nsize  = mx; % number of observations
[mtemp,ntemp]=size(yrx);
if mtemp~= mx | ntemp~=1
   error('yrx should be a column vector, same size as x');
end

[my,ny]=size(y);
if ny~= 1;
   error('y should be a column vector');
end
nsize  = my; % number of observations
[mtemp,ntemp]=size(yry);
if ntemp~= nx | ntemp~=1;
   error('yry should be a column vector, same size as y');
end


%--- COMPUTE COMMON PERIOD AND CULL THAT DATA

% Trim any leading and trailing NaN
[x,yrx]=trimnan(x,yrx);
[y,yry]=trimnan(y,yry);

% Imbedded NaN?
if any(isnan(x)) | any(isnan(y));
    error('x or y has NaNs imbedded');
end;

yrgo = max([yrx(1) yry(1)]);
yrsp = min([yrx(end) yry(end)]);
nlap = yrsp-yrgo+1;
if m>nlap/3;
   error('m not allowed to be greater than 1/3 the overlpap length');
end; 

Lx = yrx>=yrgo & yrx<=yrsp;
Ly = yry>=yrgo & yry<=yrsp;
x=x(Lx);
y=y(Ly);
yr = (yrgo:yrsp)';


% Find the maximum and minimum of the series so that can set the 
% x and y axis limits same for each figure
xmax = max(x);
xmin = min (x);
ymax = max(y);
ymin = min (y);


%********************** BUILD LAGGED TIME SERIES MATRIX, y lagging x (output lagging input)
kwind=0;
for n  = 0:3;
   if rem(n,4)==0;
      kwind=kwind+1;
      k = 1;
      figure(kwind+nfigs); % open figure window, with fig number adjusted by nfigs
   else
      k=k+1;
   end
   
   % Get series segments
   u = x(1:(nsize-n));   
   v = y((n+1):nsize);
   
   nyr = length(u) ;  % number observations for the scatterplot
   strn = sprintf('%4.0f',nyr);
   
   
   % Compute correl coef
   rpear = corrcoef([u v]);
   rpear = rpear(1,2);
   strr = sprintf('%4.2f',rpear);
   
   %--- COMPUTE 99% SIGNIFICANCE LEVEL OF CORRELATION
   
   % need first-order autocorrelation coefficients of the individual series
   u1=u(1:(end-1));
   u2=u(2:end);
   v1=v(1:(end-1));
   v2=v(2:end);
   ru1=corrcoef(u1,u2);
   ru1=ru1(2);
   rv1=corrcoef(v1,v2);
   rv1=rv1(2);
   rho=[ru1 rv1];  % first-order autocorr coeffs of u and v
   
   % Set other pearsign arguments
   alph1=0.01; % desired alpha level, approp for 2-tailed test
   bonf=0; % no bonferroni adjustment needed
   mscan=1; % only 1 correl coef scanned
   
   % Compute critical level of correlation and the effective sample size
   [rcrita,pvalue,unused,nprime]=pearsign([],nyr,mscan,alph1,bonf,rho);
   strnprime = sprintf('%4.0f',nprime);
   r99=rcrita;
   str99 = sprintf('%4.2f',r99);
   
   % Build string for title
   str1 = ['\itr=\rm' strr ',  \itN=\rm' strn ' (N''=' strnprime '),  \itr_{99} = \rm' str99];
   
   
   subplot(2,2,k);
   plot(u,v,'.');   
   lsline; % plot best fit straight line
   txtx = ['u(t-' int2str(n) ')'];
   txty = 'y(t)';
   title(str1,'FontSize',8);
   
   xlabel(txtx);
   ylabel(txty);
   
   % Set axis limits
   set(gca,'Xlim',[xmin xmax],'Ylim',[ymin ymax]);
   
   % Make the plot box square instead of rectangular
   set(gca,'PlotBoxAspectRatio',[1 1 1]);
end
set(gcf,'Name','Lagged scatter: y lagging u')
[cL,cB,cW,cH]=figsize(.4,.6);
  set(gcf,'Position',[cL cB cW cH]);


%********************** BUILD LAGGED TIME SERIES MATRIX, x lagging y (input lagging output)

kwind=1;
for n  = 0:3;
   if rem(n,4)==0;
      kwind=kwind+1;
      k = 1;
      figure(kwind+nfigs); % open figure window, with fig number adjusted by nfigs
   else
      k=k+1;
   end
   
   % Get series segments
   u =  x((n+1):nsize);            
   v =  y(1:(nsize-n));                 
   
   nyr = length(u) ;  % number observations for the scatterplot
   strn = sprintf('%5.0f',nyr);
   
   
   % Compute correl coef
   rpear = corrcoef([u v]);
   rpear = rpear(1,2);
   strr = sprintf('%4.2f',rpear);
   
   %--- COMPUTE 99% SIGNIFICANCE LEVEL OF CORRELATION
   
   % need first-order autocorrelation coefficients of the individual series
   u1=u(1:(end-1));
   u2=u(2:end);
   v1=v(1:(end-1));
   v2=v(2:end);
   ru1=corrcoef(u1,u2);
   ru1=ru1(2);
   rv1=corrcoef(v1,v2);
   rv1=rv1(2);
   rho=[ru1 rv1];  % first-order autocorr coeffs of u and v
   
   % Set other pearsign arguments
   alph1=0.01; % desired alpha level, approp for 2-tailed test
   bonf=0; % no bonferroni adjustment needed
   mscan=1; % only 1 correl coef scanned
   
   % Compute critical level of correlation and the effective sample size
   [rcrita,pvalue,unused,nprime]=pearsign(rpear,nyr,mscan,alph1,bonf,rho);
   strnprime = sprintf('%4.0f',nprime);
   r99=rcrita;
   str99 = sprintf('%4.2f',r99);
   
   % Build string for title
   str1 = ['\itr=\rm' strr ',  \itN=\rm' strn ' (N''=' strnprime '),  \itr_{99} = \rm' str99];
   
      
   subplot(2,2,k);
   plot(u,v,'.');   
   lsline; % plot best fit straight line
   txtx = ['u(t+' int2str(n) ')'];
   txty = 'y(t)';
   title(str1,'FontSize',8);
   
   xlabel(txtx);
   ylabel(txty);
   
   % Set axis limits
   set(gca,'Xlim',[xmin xmax],'Ylim',[ymin ymax]);
   
   % Make the plot box square instead of rectangular
   set(gca,'PlotBoxAspectRatio',[1 1 1]);
   set(gcf,'Name','Lagged scatter: y leading u');
   [cL,cB,cW,cH]=figsize(.4,.6);
   set(gcf,'Position',[cL cB cW cH]);
   %set(gcf,'Position',[302   443   678   517]);
end