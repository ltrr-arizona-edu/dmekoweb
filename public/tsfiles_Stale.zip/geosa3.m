% geosa3.m  --  lagged scatterplot and autocorrelation function
%
% Last revised 2018-12-23
%
%*** UW FUNCTIONS CALLED
%
% lagscat -- lagged scatterplot
% acf -- autocorrelation function
%
%*** TOOLBOXES NEEDED
%
% STATS 
% SYSTEM IDENTIFICATION
%
% revised 2016-12-04: Output structure S; and cosmetic changes

% Close any open windows and clear variables from workspace
close all; % close any currently open figure windows
clear all;

% Hard code
datfile='Spring19'; % default .mat file with input data
datdir=cd; % default directory for input data; use current working directory
path1=datdir; % store path/directory
nwant = 1; % number of series to analyze


%********  INTRODUCTORY MSG

message1 = {'Autocorrelation',...
        '',...,
        'This script illustrates the lagged scatterplot and the ',...
        'sample autocorrelation function as graphical tools for describing the ',...
        'autocorrelation in a time series.',...
        '',...
        'You will be prompted to select a single time series for analysis. ',...
        'Generally, this series should come from the V1 or V2 data sets because',...
        'the autocorrelation function assumes stationarity.',...
        '',...
        'Figure windows produced:',...
        '   Fig 1: time series plot',...
        '   Fig 2: Lagged scatterplots for lags k=1-4',...
        '   Fig 3: Lagged scatterplots for lags k=5-8',...
        '   Fig 4: Autocorrelation function and pproximate 95% confidence interval'};
    msgbox1(message1,'message1');
%uiwait(msgbox(strmsgi,'geosa3','modal'));




% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string

%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename into one string variable
eval(['load ' pf1])


%--- The data should be in a structure variables V1, V2, V2 
%  Check that required structures exist in the workspace
if ~all([exist('V1')==1  exist('V1')==1  exist('V1')==1]);
   error([pf1 ' does not contain V1, V2 and V3']);
end

% Check that V1, V2 and V3 are structures with required fields
for n =1:3; % loop over structures
    eval(['V = V' int2str(n) ';']);
    if ~isstruct(V); 
        error(['V' int2str(n) ' must be structure']); 
    else; % check for required fields
        sfields(V);
    end;
end;


% Menu to choose type of variable for analysis 

kv = menu('Time series will be selected from which data (choose one)',...
    'V1 -- output data',...
    'V2 -- input data',...
    'V3 -- trend data');
if kv==1;
    V=V1;
elseif kv==2;
    V=V2;
else;
    V=V3;
end;

% Compute number of series in structure
nsites = size(V.name,1);


%*********  MENU TO CHOOSE SERIES
Lpick = logical(zeros(nsites,1)); % pointer to picked series
pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not

tmen = V.seriesmenu;  % menu of series, with column number
tmen1=tmen;
tmen1{nsites+1}='Accept selection';
tmen1 = char(tmen1);
tmen2=[tmen1 pflag];
[mtmen2,ntmen2]=size(tmen2);
 
sitenos=repmat(NaN,nwant,1); % to store index to selected sites

kwh1=1;
strchoose='Select a series';
kthis=[];
while kwh1==1;
   kmen1=menu(strchoose,cellstr(tmen2));
   if ~any(Lpick) & kmen1== nsites+1;
       uiwait(msgbox('None selected yet -- do again','Message','modal'));
   elseif kmen1==nsites+1;
       sitenos=kthis;;
       kwh1=0;
   else;
       Lpick=logical(zeros(nsites,1)); 
       pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not
       pflag(kmen1,3)='*';
       Lpick(kmen1)=1;
       kthis=kmen1;
       tmen2=[tmen1 pflag];
       
   end;
 
end;

% Find start and end timeof valid data for series

YRS = repmat(NaN,nwant,2);
L = ~isnan(V.tsm(:,sitenos));  % logical pointer to valid entries 
disp(blanks(1));
disp('Start and end time of valid data for series');
fmt1 = '%50s  %4.0f-%4.0f\n';
jsite = sitenos;
yrtemp = V.time(L);
YRS(1,1)=min(yrtemp);
YRS(1,2)=max(yrtemp);




%**********  INPUT DIALOG TO SELECT PERIOD FOR ANALYSIS

titlepmt = 'Select the start and end time for analysis';
prompt = {'Enter start time',...
	'Enter end time'};
lineNo=1;
deflt = {int2str(max(YRS(:,1))),int2str(min(YRS(:,2)))};
answer=inputdlg(prompt,titlepmt,lineNo,deflt); % answer as char in cells
% convert answer to double
yrgo = str2num(answer{1});
yrsp = str2num(answer{2});
% Store string with analysis period
txtyr = sprintf('%4.0f-%4.0f',yrgo,yrsp);


% Check that both series cover selected period
if any(YRS(:,1)>yrgo) | any(YRS(:,2)<yrsp);
	error('Selected analysis period inconsistent with start, end times of series');
end

% Display name of selected series and info
clc;  % clear the command window
strmess1={['Type of data: ' V.what ],...
        [' ID: ' V.id{sitenos}],...
        [' Name: ' V.name{sitenos}],...
        [' Time coverage: ' int2str([yrgo yrsp])]};
msgbox1(strmess1,'Selection');


n1size=yrsp-yrgo+1; % length of selected period
% Store string with sample size, for use in later printing in figure titles.
% Note the use of \it to italicize N, of \rm to return to normal (not italic)
% font before printing the number.  This demonstrates use of TeX langauage,
% which lets you add greek characters, mathematical symbols, etc., to 
% text.  See info for the 'text' command under the html help for more on 
% TeX.  
txtna = sprintf('%5.0f',n1size);
txtn  = ['\itN = \rm' txtna]; 


% SET LABELS, TITLES FOR PLOTS

ylab1=[V.label{sitenos} ' (' V.units{sitenos} ')'];
xlab1=V.increment;
tit1 = ['Time Series Plot, ' txtyr ', '  txtn];  

id=V.id{jsite};



%******************** GET SUBSET OF DATA FOR SELECTED PERIOD AND SERIES
L1 = V.time>=yrgo & V.time<=yrsp; % logical pointer to rows of vector tree.yr
yr = V.time(L1);  % time vector for selected period
X = V.tsm(L1,jsite);  % subset of times, columns with the desired data
	

% Store time series for desired analysis period in x1 
x1=X(:,1);


%**********************  TIME SERIES PLOTS

figure(1);  % Want plots in figure window 1
set(gcf,'Name','Time Series Plot');

% Make plot
xlims=[yr(1)-(0.01*(yr(end)-yr(1))) yr(end)+(0.01*(yr(end)-yr(1)))];
h1=plot(yr,x1,[min(yr) max(yr)],[mean(x1) mean(x1)]); %  series amd ,meam
% h1 is handle to plot -- in case needed later
set(gca,'XLim',xlims);
xlabel(xlab1);
ylabel(ylab1);
% Add legend and title
legend(V.id{jsite},'Mean');
title([V.name{jsite},', ' txtyr ',  ' txtn]);
grid; % turn on grid




%**********************  LAGGED SCATTERPLOT, LAGS 1=8, IN 2 WINDOWS

figure; % new figure
lagscat(x1,8,1);  % call user-written function to make plot
set(2,'Name','Lagged Scatterplots');
set(3,'Name','Lagged Scatterplots');


%*********************  AUTOCORRELATION FUNCTION, WITH LARGE-LAG 2 STANDARD RRORS

nlag = 20 ;   % will want acf at lags 1-20 yr

% Compute the acf and related quantities. To do this, will call the user-written
% function acf.m
% Large-lag standard error from p. 35, Box and Jenkins (1976)
% Prob point for one-tailed test from p. 60,  WMO (1966) (cliate change methods)plot(x
[rho,SE2,r95]=acf(x1,nlag);  
% rho is the acf at lags 1-20, as a row vector
% SE2 is 2* large lag standard error of the acf estimates, as row vector
% r95 is the size of the first order autocorrelation coefficient significant
% at the 95% level in a one-sided test according to WMO(1966)


% Plot the acf and its large-lag standard error as stem plot
figure(4);
set(gcf,'Name','ACF');
subplot(1,1,1);
tlag = (1:20);
hacf = stem(tlag,rho);
line([1 20],[0 0]); % add horiz line at zero
hold on; % Set hold to on to add the error bars
hleg=plot(tlag,SE2,'r--',tlag,-SE2,'r--');
['lag(' V.increment ') ']
tempxlab=['lag(' V.increment ') '];
xlabel(tempxlab);
%xlabel('lag(yr)');
ylabel('Autocorrelation');
set(gca,'YLim',[-1 1]);

% Build title
txt1 = ['ACF,  ' V.name{jsite} ';  ' txtn];
title(txt1);

% Legend
legend([hacf(1); hleg(1)],'ACF estimates','2 * Large-Lag SE');

hold off

clc;


%---- Structure S output

S.what = char({['Finished! Output estimated acf and two standard errors of the estimate, from script geosa3 on ' datestr(date)],...
    'S.X is matrix with columns: 1-lag, 2-autocorrelation, 3-two standard errors of estimated autocorrelation (large-lag method)'});
S.X=[tlag' rho' SE2'];


message2={'Access to the acf and its ''large-lag'' 2SE possible with',...
    'structure S, available in workspace after running this script.'};
msgbox1(message2,'message2'); 

