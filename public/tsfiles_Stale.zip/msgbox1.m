function msgbox1(strmess,messtitle,fwidth,fheight)
% msgbox1: Write modal message box with width and height as fraction of screen width and height
% msgbox1(strmess,messtitle,fwidth,fheight);
% Last Revised 2008-8-30
%
% Write modal message box with width and height as fraction of screen width and height
%
%****   INPUT 
%
% strmess {}s or []s  The desired content of message box
% messtitle (1 x ?)s string title for message box
% fwidth (1 x 1)r   figure width as decimal fraction of screen width
% fheight (1 x 1)r  figure height as decimal fraction of screen height
%
%*** OUTPUT
%
% No output
% Action: writes a message box using uiwait 
%
%*** REFERENCES --- none
%
%*** TOOLBOXES NEEDED -- none
%
%*** UW FUNCTIONS CALLED 
%
% figsize
%
%*** NOTES
%

if nargin==4;
    [cL,cB,cW,cH]=figsize(fwidth,fheight); % Get screen coordinates in pixels

    hmsg=msgbox(strmess,messtitle,'modal');   % make prelim message box
    set(hmsg,'Position',[cL cB cW cH]); % Set the box position; the /2 seems necessary to center
    uiwait(hmsg);  % user must kill box before can do anything else

else
   
    hmsg=msgbox(strmess,messtitle,'modal');   % make prelim message box
    uiwait(hmsg);  % user must kill box before can do anything else

end


