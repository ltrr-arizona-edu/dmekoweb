% geosa6  -- Spectral analysis -- smoothed periodogram method
%
%
% Last revised 2018-12-23
%
%*** UW FUNCTIONS CALLED
%
% pdgm5
% danwgtn
% danbw2
% danwgt1
%
%*** TOOLBOXES NEEDED
% 
% stats
%
%   
% TOPICS
% -smoothed periodogram method of spectral analysis
%   Sequenc of data processing steps:
%      1. subtract sample mean
%      2. taper
%      3. pad
%      4. Fourier transform
%      5. raw periodgram
%      6. smoothed periodogram
%      7. null continuum
%      8. confidence bands around spectrum
%
%
% Revised 2015-01-15.  Cosmetic only.  But XLim now set in called program
% pdgm5 such that time plots have restricted x axis range
%
% Revised 2016-12-04.  Modified kopt argument for calling pdgm5 because in
% summer 2015 I added option in that function for crude Bonferroni
% adjustment of CI. Now this script prompts for optional use of the
% adjustment
%
% Revised 2018-12-23. To be able to used pdgm5, which I modified after the
% 2017 class to have more kopt options and to allow specification of the
% desired bandwidth as an option to specifying the spans. This script
% stilll uses specified spans

close all;
clear;

% Hard code
datfile='Spring19'; % default .mat file with input data
datdir=cd; % directory with input data; assume current directory
path1=datdir; % store path/directory
nwant = 1; % number of series to analyze
nsers = 1; % ditto


message1 = {'Spectral Analysis -- smoothed periodogram method',...
        '',...
        'This script illustrates spectral analysis of a time series by the ',...
        'smoothed-periodogram method and the distinction between use of spectral ',...
        'analysis as a descriptive tool and for testing for perodicity.',...
        '',...
        'You are initially prompted to select a single time series.  This series ',...
        'should be from data sets V1 or V2 as spectral analysis is invalid for ',...
        'nonstationary series.',...
        '',...
        'Figure windows produced:',...
        '   Fig 1: time series plot, original time series',...
        '   Fig 2: time series plot , mean-adjusted time series',...
        '   Fig 3: data-taper window',...
        '   Fig 4: time series plot, tapered mean-adjusted series',...
        '   Fig 5: time series plot, tapered, adjusted, zero-padded series',...
        '   Fig 6: Fourier transform (real part) of series plotted in figure 5',...
        '   Fig 7: Raw and smoothed periodogram',...
        '   Fig 8: Smoothed periodogram with confidence bands'};
msgbox1(message1,'message1');


% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string

%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename 
eval(['load ' pf1])


%--- The data should be in a structure variables V1, V2, V2 
%  Check that required structures exist in the workspace
if ~all([exist('V1')==1  exist('V1')==1  exist('V1')==1]);
   error([pf1 ' does not contain V1, V2 and V3']);
end

% Check that V1, V2 and V3 are structures with required fields
for n =1:3; % loop over structures
    eval(['V = V' int2str(n) ';']);
    if ~isstruct(V); 
        error(['V' int2str(n) ' must be structure']); 
    else; % check for required fields
        sfields(V);
    end;
end;


% Menu to choose type of variable for analysis 

kv = menu('Time series will be selected from which data (choose one)',...
    'V1 -- output data',...
    'V2 -- input data',...
    'V3 -- trend data');
if kv==1;
    V=V1;
elseif kv==2;
    V=V2;
else;
    V=V3;
end;

% Compute number of series in structure
nsites = size(V.name,1);

% Time increment
tinc = V.increment;



%*********  MENU TO CHOOSE SERIES

Lpick = logical(zeros(nsites,1)); % pointer to picked series
pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not

tmen = V.seriesmenu;  % menu of series, with column number
tmen1=tmen;
tmen1{nsites+1}='Accept selection';
tmen1 = char(tmen1);
tmen2=[tmen1 pflag];
[mtmen2,ntmen2]=size(tmen2);
 
sitenos=repmat(NaN,nwant,1); % to store index to selected sites

kwh1=1;
strchoose='Select a series';
kthis=[];
while kwh1==1;
   kmen1=menu(strchoose,cellstr(tmen2));
   if ~any(Lpick) & kmen1== nsites+1;
      msgbox1('None selected yet -- do again','Message');
   elseif kmen1==nsites+1;
       sitenos=kthis;;
       kwh1=0;
   else;
       Lpick=logical(zeros(nsites,1)); 
       pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not
       pflag(kmen1,3)='*';
       Lpick(kmen1)=1;
       kthis=kmen1;
       tmen2=[tmen1 pflag];
       
   end;
 
end;

j1 = sitenos(1);



% Find start and end time of valid data for series

YRS = repmat(NaN,nwant,2);
L = ~isnan(V.tsm(:,sitenos));  % logical pointer to valid entries 
disp(blanks(1));
disp(['Start and end ' lower(tinc) ' of valid data for series']);
fmt1 = '%50s  %4.0f-%4.0f\n';
jsite = sitenos;
yrtemp = V.time(L);
YRS(1,1)=min(yrtemp);
YRS(1,2)=max(yrtemp);



%**********  INPUT DIALOG TO SELECT PERIOD FOR ANALYSIS

titlepmt = ['Select the start and end ' lower(tinc) ' year for analysis'];
prompt = {['Enter start ' lower(tinc)],...
	['Enter end ' lower(tinc)]};
lineNo=1;
deflt = {int2str(max(YRS(:,1))),int2str(min(YRS(:,2)))};
answer=inputdlg(prompt,titlepmt,lineNo,deflt); % answer as char in cells
% convert answer to double
yrgo = str2num(answer{1});
yrsp = str2num(answer{2});
% Store string with analysis period
txtyr = sprintf('%4.0f-%4.0f',yrgo,yrsp);


% Check that both series cover selected period
if any(YRS(:,1)>yrgo) | any(YRS(:,2)<yrsp);
	error(['Selected analysis period inconsistent with start, end ' lower(tinc) ' of series']);
end

% Display name of selected series and info
clc;  % clear the command window
strmess1={['Type of data: ' V.what ],...
        [' ID: ' V.id{sitenos}],...
        [' Name: ' V.name{sitenos}],...
        [' Time coverage: ' int2str([yrgo yrsp])]};
msgbox1(strmess1,'Selection');


n1size=yrsp-yrgo+1; % length of selected period
% Store string with sample size, for use in later printing in figure titles.
% Note the use of \it to italicize N, of \rm to return to normal (not italic)
% font before printing the number.  This demonstrates use of TeX langauage,
% which lets you add greek characters, mathematical symbols, etc., to 
% text.  See info for the 'text' command under the html help for more on 
% TeX.  
txtna = sprintf('%5.0f',n1size);
txtn  = ['\itN = \rm' txtna]; 


% SET LABELS, TITLES FOR PLOTS

ylab1=[V.label{sitenos} ' (' V.units{sitenos} ')'];
xlab1=V.increment;

% Frequency label
if strcmp(lower(V.increment),'year');
    labfreq = 'yr^{-1}';
    labinc1='yr';
else;
    labfreq=  [V.increment '^{-1}'];
    labinc1=V.increment;
end;

tit1 = ['Time Series Plot of ' V.what ', ' txtyr ', '  txtn];  

id=V.id{jsite};




%******************** GET SUBSET OF DATA FOR SELECTED PERIOD AND SERIES
L1 = V.time>=yrgo & V.time<=yrsp; % logical pointer to rows of vector tree.yr
yr = V.time(L1);  % time vector for selected period
X = V.tsm(L1,jsite);  % subset of times, columns with the desired data
	

% Store time series for desired analysis period in x1 
x1=X(:,1);
nyr=length(x1); 



%***************  SPECTRAL ANALYSIS ON FULL PERIOD OF DATA

% Set information for call to pdgm5
uiinf{1}=id; % series id
uiinf{2}=[yrgo yrsp]; % analysis period
uiinf{3}=[inf 10]; % longest and shortest period lengths (yr) bracketing
uiinf{4}=[7 11]; % default starting spans for spectrum

% compute default starting null continuum daniel filter lengths, ensuring that they odd
d1 = round(nyr/7); d2=round(nyr/5);
if mod(d1,2)==0;
    d1=d1-1;
end
if mod(d2,2)==0;
    d2=d2-1;
end
uiinf{5}=[d1 d2];


%--- Option for null continuum

kopt = [ NaN NaN];
nullopts = {'White Noise','Red Noise (AR(1))','AR(2)','Greatly smoothed periodogram'}'
knull = menu('Choose null continuum',nullopts);
if knull==1;
    kopt(2)=5;
elseif knull==2;
    kopt(2)=2;
elseif knull==3;
    kopt(2)=3;
elseif knull==4;
    kopt(2)=1;
else
    error('invalid null continuum option');
end

%--- Option for Bonferroni expansion of CI
qbonf =questdlg('Bonferroni expansion of confidence interval?');
if strcmp(qbonf,'Yes')
    kopt(3)=2; 
else
    kopt(3)=1;
end

% Additional kopt  options for call to pdgm5 needed with revisions to pdgm5 since
% 2017 version of class
%    kopt(4): How bandwidth to be specified
%       ==1 input of Daniell spans
%       ==2 input of desired bandwidth; danwt.m gets spans that approximate
%    kopt(5): option for skipping all graphics
%       ==1 regular graphics
%       ==2 skip all graphics and interactive commands (terse mode)
%    kopt(6): significance level for CI on spectrum (setting matters only
%       if kopt(5) ==2; otherwise will do interactively and be allowed 95%
%       or 99%
kopt(4)=1;
kopt(5)=1;
kopt(6)=1;




%---- Option for "hypothesis-test mode"
if strcmp(qbonf,'Yes')
    khyo = 'No';
    kopt(1)=0;
else
    strp = {'You chose not to use the option of Bonferroni expansion of the confidence interval (CI).',...
        'Accordingly, the plotted CI is not suitable for ''fishing'' expeditions for significant spectral peaks.',...
        'Strictly, for use of the plotted CI you should begin the analyis with a particular wavelength to be',...
        'tested for periodidicity, perhaps consistent with some physical theory (e.g., 18.6 year lunar nodal cycle ',...
        'influencing aclimate time series). As a graphical guide, you can optionally add a vertical line to the spectrum',...
        'at the ''test'' wavelength. You can choose not to add the vertical line, but the caveat on interpretation'....
        'of ''significance'' of peaks holds.'};
     uiwait(msgbox(strp,'Notice','modal'));
    % Hypoth-test mode?
    khypo = questdlg('Add a vertical line?');
    if strcmp(khypo,'Yes')
        kopt(1)=1;
    else
        kopt(1)=0;
    end;
    
end

uiinf{6}=kopt; % store options

% Time step
uiinf{7}=V.increment;

% Label for y axis of time series plot
uiinf{8}=[V.label{sitenos} ' (' V.units{sitenos} ')'];

% Addtonal uiinf elements needed after revision of pdgm5 since 2017
% semester
uiinf{9}=[];  % .... because I am not specifying the NUMBER of spans, but the spans themselves
uiinf{10}=[]; % .... because I am not specifying the desired bandwidth, but am specifying the spans
uiinf{11}=0.10; % .... will taper 5% on each end of time series
uiinf{12}=1; % ... this option specifies that padding is to next power o 2 higher than sereis length
    

Results=pdgm5(x1,yr,uiinf);
S=Results;

message2={'Finished!  S is a structure with data and statistics from the analysis',...
    'S.what lists the fields in S',...
    '',...
    'Function pdgm5 is the main user-written function used by this script.',...
    'You can run smoothed periodogram spectral analysis outside this script',...
    'by calling pdgm5 directly from your own script. Refer to comment section',...
    'in pdgm5 for instruction on the calling arguments'};

msgbox1(message2,'message2');



