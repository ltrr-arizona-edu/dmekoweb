function S1=slidcorr(x,y,yrx,yry,uinf);
% slidcorr: sliding correlation coefficient between two time series
% S1=slidcorr(x,y,yrx,yry,uiinf);
% Last revised: 2017-04-11
%
% Sliding correlation coefficient between two time series.  Correlation coefficient computed in a sliding
% window whose width and sliding interval are selected by user.  
%
%*** INPUT 
%
% x (mx x 1)r  time series 1
% y (my x 1)r  time series 2
% yrx (mx x 1)i year vector for x
% yry (my x 1)i year vector for y
% uinf{} miscellaneous user information
%   {1} {} string ids for x and y (e.g., {'Series 1','Series 2'})
%   {2} {} data labels for x and y (e.g., {'Index','Precipitation'})
%   {3} {} data units for x and y (e.g., {'dimensionless','in'})
%   {4} (1 x ?)s time label (e.g., 'Year')
%   {5} (1 x 2)i start and end year of desired analysis period ([] if full overlap)
%   {6} (1 x 1)r desired alpha level (e.g., 0.05)
%   {7} {} transformations applied to x and y (e.g., {'none' ,'log10'}
%
%*** OUTPUT
% 
% S1: Character matrix with summary information on test results
% Graphics windows
%
%
%*** REFERENCES
%
% None
%
%
%*** UW FUNCTIONS CALLED 
%
% corrpair -- pairwise correlation between cols of matrices
% pearsign -- significance of pearson correlation
% acf -- autocorrelation fucntion
% subfcn01 -- build windowed matrix from time series vector
%
%*** TOOLBOXES NEEDED
%
% Statistics
% System ident. 
%
%*** NOTES
%
% Minimum allowable analysis period (overlap of the two series) is n=50 years
% Maximum allowable window width is m=n/2, where n is the analysis period
% Mininum allowable window width is 20
%
% Default (starting) window width is n/5 or 20, whichever is larger
% Default offset, or shift, is m, the window width
%
% Confidence band: Bonferonni and regular are plotted
%
% Revised: 2017-04-11:
% 1) error in code for calls to Pearsign. Called for critical r at 1/2 the
% value of alpha it should have (e.g., returned critical r at alpha=0.025 when
% wanted it at 0.05
% 2) error in code that resulted in not always refreshing the table value
% of critical value for windowed r. Problem only came up with specific
% combination of toggling on and off the autocorrelation adjustment. CI on
% plots was correct, but did not match critical r listed in Figure 3


%---- Hard Code
minn=50; % minimum allowable length of analysis period
minm = 20; % minimum allowable window size

Pposit={'ENDING','CENTRAL'}; % Toggle for plotting points relative to windowed period
Alevel={.05,.01}; % toggle for alpha level
sigr = {'95%','99%'};
Sadjust={'ON','OFF'}; % toggle for adjusting sample size for lag-1 autocorrelation
Badjust={'ON','OFF'}; % Toggle for confidence band
pcur=Pposit{1};
pprev=Pposit{2};
acur=Alevel{1};
aprev=Alevel{2};
scur=Sadjust{1};
sprev=Sadjust{2};
bcur=Badjust{1};
bprev=Badjust{2};


% plot positions
pos3 = [.1  .1  .8  .28]; % bottom
ytween  = 0.02;
pos2 = [pos3(1)      pos3(2)+pos3(4)+ytween   pos3(3)      pos3(4)];  % middle
pos1 = [pos3(1)      pos2(2)+pos3(4)+ytween   pos3(3)      pos3(4)]; % top


%---------  CHECK INPUT


% x, y and their year vectors
[mx,nx]=size(x);
mtemp=size(yrx,1);
if mtemp~=mx | nx~=1;
    error('x should be col vector, and yrx should be same length');
end;
[my,ny]=size(y);
mtemp=size(yry,1);
if mtemp~=my | ny~=1;
    error('y should be col vector, and yry should be same length');
end;

% Cull common period x and y
yrgo = max([yrx(1) yry(1)]);
yrsp = min([yrx(end) yry(end)]);
yr1 = (yrgo:yrsp)';
nyr1 = length(yr1);
if nyr1<minn;
    error(['Overlap less than ' num2str(minn)]);
else;
    L=yrx>=yrgo & yrx<=yrsp;
    x1=x(L);
    L=yry>=yrgo & yry<=yrsp;
    y1=y(L);
end;
yrs1 = [yrgo yrsp]; % common period of x and y, also the default analysis period 
% x1, y1, yr1, nyr1 now hold overlap data


if isempty(uinf);
    id1='Series 1';
    id2='Series 2';
    labx ='Variable';
    laby='Variable';
    unitsx ='units';
    unitsy = 'units';
    labtime = 'Year';
    strtranx='None';
    strtrany='None';
    yrs2 = [yrgo yrsp];
    alph=0.05; % default alpha level
else;
    id1 = uinf{1}{1};
    id2 = uinf{1}{2};
    labx = uinf{2}{1};
    laby = uinf{2}{2};
    unitsx = uinf{3}{1};
    unitsy = uinf{3}{2};
    labtime=uinf{4};
    yrs2 = uinf{5};
    alph=uinf{6};
    strtranx=uinf{7}{1};
    strtrany=uinf{7}{2};
end;
vlist{1}=['id1 id2 - series names for first and second series'];

if ~isempty(yrs2);
    % Check that analysis period within common period
    if yrs2(1)<yrs1(1) | yrs2(1)>yrs1(2);
        error('Analysis period not within overlap period of the two series');
    end;
else;
    yrs2=yrs1;
end;

% CULL ANALYSIS-PERIOD DATA -- PUT IN   x2, y2, with year vector yr2 and length nyr2
if all(yrs2==yrs1);
    x2=x1;
    y2=y1;
    yr2=yr1;
    nyr2=nyr1;
else;
    L=yr1>=yrs2(1) & yr1<=yrs2(2);
    x2=x1(L);
    y2=y1(L);
    nyr2=length(x2)
    yr2=(yrs2(1):yrs2(2))';
end;
clear L;

% Initial default window width
if nyr2<minn;
    error(['Analysis period ' int2str(yrs2) ' shorter than ' int2str(minn) ' yr']);
else;
    m=max([floor(nyr2/5) minm]); % starting window width
    toffset=m; % starting offset or shift
end;


% Convert series to z scores
zx2=zscore(x2);
zy2=zscore(y2);
vlist{2}='x2,y2,yr2 -- first and second series and year vector, for analysis period';
vlist{3}='yrs2 -- first, last year of analysis period';

% Autocorrelation 
[rx1,SE2,rx195]=acf(zx2,5); % of series zx2, to lag 5
[ry1,SE2,ry195]=acf(zy2,5); % of series zx2, to lag 5
rx1=rx1(1);
ry1=ry1(1);
if rx1>rx195 & ry1>ry195;
    rho=[rx1 ry1];
    nyr2prime = nyr2 * (1-rx1*ry1)/(1+rx1*ry1);
else;
    nyr2prime= nyr2;
    rho=[0 0];
end;
vlist{4} = 'rx1, rx195, ry1, ry195 -- first-order autocorr. coeff and critical level for 95% signif, for series 1 and 2';
vlist{5} ='nyr2, nyr2prime -- sample size, original and adjusted for first order autocorr in each series';

% FULL PERIOD CORRELATION ANALYSIS
rfull = corrcoef([zx2 zy2]);
rfull=rfull(1,2);
if strcmp(scur,'ON');
    rhothis=rho;
else;
    rhothis=[0 0];
end;

[rfcrit(1),dummy1,dummy2]=pearsign(rfull,nyr2,1,acur,0,rho); % critical level, assuming alpha=acur; using r(1) adjustment if...
[rfcrit(2),dummy1,dummy2]=pearsign(rfull,nyr2,1,aprev,0,rho); % ...  alpha is other level, using r(1) adjustment if r(1)s high enout
[rfcrit(3),dummy1,dummy2]=pearsign(rfull,nyr2,1,acur,0,[0 0]); %... alpha=acur, no autocorr adjustment , regardless of r(1)s
[rfcrit(4),dummy1,dummy2]=pearsign(rfull,nyr2,1,aprev,0,[0 0]); % ... alpha= other setting, no autocorr adjustment , regardless of r(1)s
rfcritnow=rfcrit(1);
nyr2this=nyr2prime;

sinf0={['X Series=' id1 ],...
        ['  Data type:' labx],...
        ['  Original units: ' unitsx],...
        ['  Transformation: ' strtranx],...
        ['Y series=' id2]...
        ['  Data type:' laby],...
        ['  Original units: ' unitsy],...
        ['  Transformation: ' strtrany]};
sinf1{1}=' ';
sinf1{2}=' ';
sinf1{3}=[' Analysis Period = ' int2str(yrs2) ';   N = ' int2str(nyr2)];
sinf1{4}='  Windows:';
sinf1{6}=['  Alpha Level for conf. bands: = ' num2str(acur)]; 
sinf1{7}=['      Bonferrroni Adjustment = ' bcur];
sinf1{8}=['      Autocorrelion Adjustjment = ' scur];
sinf1{9}=[' Plotting position=' pcur];
sinf1{10}=  'Lag-1 autocorrelations and effective sammple size (for full period';

fmta='%5.2f';
fmtb='%6.0f';
sinf1{11}=['     First series r1=' num2str(rx1,fmta) ';  (' num2str(rx195,fmta) ' required for 95% sig'];
sinf1{12}=['     Sec.  series r1=' num2str(ry1,fmta) ';  (' num2str(ry195,fmta) ' required for 95% sig'];
sinf1{13}=['     Effective sample size, N* = ' num2str(nyr2this,fmtb)];
sinf1{14}='CORRELATION RESULTS';
sinf1{15}=['    Full period: r= ' num2str(rfull,fmta) '  (' num2str(rfcritnow,fmta) ' needed for sign. at ' num2str(acur) ' level)'];
sinf1{16}=['    Windows:'];



%-- INITIAL PLOTS

xlims =[yrs2(1)-2 yrs2(2)+2];
hax1=axes;
set(hax1,'Position',pos1);
hax2=axes;
set(hax2,'Position',pos2);
hax3=axes;
set(hax3,'Position',pos3);


%---------- TIME SERIES PLOT OF ORGINAL SERIES

kfirst=1;

kwh1=1; % outer while loop control
while kwh1==1; 
    
    kmen1=menu('Choose','Make or revise plots','Accept plots');
    
    if kmen1==2 & kfirst==1;
        kmen1=1;
        kfirst=0;
        msgbox1({'You chose to accept nonexistent plots.',...
                'So your choice is nullified and changed to the other option'},...
            'Message',.18,.10);
    end;
    
    
    if kmen1==1; % make or revise
        
        %--------- BUILD WINDOWED SERIES
        
        
        axes(hax1);
        H1=plot(yr2,zx2,yr2,zy2,[min(yr2) max(yr2)],[0 0]);
        if length(zx2)<120;
            set(H1(1),'Marker','o','MarkerSize',5);
            set(H1(2),'Marker','^','MarkerSize',5);
        else
        end
        ylabel('Z-score')
        set(gca,'XLim',xlims)
        set(H1(2),'LineWidth',1.0);
        xlim1=get(hax1,'XLim');
        ylim1=get(hax1,'YLim');
        ybig=max(abs([zx2; zy2]));
        set(hax1,'YLim',[-ybig-0.6*ybig  ybig+0.6*ybig]);
        ylim1=get(hax1,'YLim');
        
        txt1a = ['Z-Scores of Original Series'];
        p1y = ylim1(1)+0.92*diff(ylim);
        text(yr2(3),p1y,txt1a);
        legend(id1,id2);
        set(hax1,'XTickLabel',[]);
        
        
        %-----------TIME SERIES PLOT OF m-YEAR MEANS
        
        axes(hax2);
        
        % Unsampled means and year vectors
        X=subfcn01(zx2,m);
        xmn = (mean(X))';
        yr2mn = yr2(m:nyr2);
        Y=subfcn01(zy2,m);
        ymn = (mean(Y))';
        
        % Sample at intervals keyed to ending year and offset by toffset
        if strcmp(upper(pcur),'ENDING');
            i1 = fliplr((length(yr2mn):-toffset:1));
            i2 = fliplr((length(yr2mn):-toffset:1)); 
            tuv= yr2mn(i2);
        else; % plotted points at midpoint of window
            if mod(m,2)==0;
                error('Plotting at central year invalid if window width even');
            end;
            i1 = fliplr(     ((length(yr2mn)-(m-1)/2):-toffset:1)      ); % index to year
            i2 = fliplr((length(yr2mn):-toffset:1)); % index to means or correlatkons 
            tuv= yr2mn(i2)-(m-1)/2; % 
        end;
        %tuv = yr2mn(i1);
        u= xmn(i2);
        v= ymn(i2);
        sinf1{5}=['     Width = ' int2str(m) ';  Offset= ' int2str(toffset) ';  Number = ' int2str(length(tuv))];
        H2=plot(tuv,u,'o',tuv,v,'^',[min(yr2) max(yr2)],[0 0]);
        ylabel('Z-score')
        
        txt2a = ['Sliding ' int2str(m) '-yr Means of Z-Scores (\Deltat = ' int2str(toffset) ' ' labtime 's)'];
        htxt2a=text(yr2(3),p1y,txt2a);
        legend(id1,id2);
        set(hax2,'XTickLabel',[]);
        set(hax2,'XLim',xlim1);
        set(hax2,'YLim',ylim1);
        
        
        %-----------TIME SERIES PLOT OF SLIDING CORRELATIONS 
        axes(hax3);
        
        r = corrpair(X,Y); % compute correlations
        ruv=r(i2);
        
        % Critical level for correlation         
        if strcmp(bcur,'ON');
            bonf=1; % want Bonferrroni
        else;
            bonf=0;
        end;
        if strcmp(scur,'ON');
            rhothis=rho;
        else;
            rhothis=[0 0];
        end;
        [rcrit,dummy1,dummy2]=pearsign(median(ruv),m,length(tuv),acur,bonf,rhothis);
        
        sinf1{17}=['        Median r = ' num2str(median(ruv),'%6.2f')];
        sinf1{18}=['        Min,Max r = ' num2str(min(ruv),'%6.2f') ',   ' num2str(max(ruv),'%6.2f')];
        sinf1{19}=['        Critical r = '  num2str(rcrit,'%6.2f')];
        
        
        H3=plot(tuv,ruv,'-o',[min(tuv)  max(tuv)],[rcrit rcrit],[min(tuv) max(tuv)],[-rcrit -rcrit],[min(yr2) max(yr2)],[0 0]);
        xlabel([pcur ' ' upper(labtime) ' OF WINDOW']); 
        ylabel('r')
        
        
        txt3a=['Sliding Correlation'];
        text(yr2(3),.85,txt3a);
        
        % Label of CI
        if acur==0.05;
            sigstr=' 95% CI ';
        elseif acur==.01;
            sigstr=' 99% CI ';
        else;
            error('sigstr invalid');
        end;
        htxt3b=text((yr2mn(1)+yr2mn(end))/2,rcrit,sigstr,'VerticalAlignment','bottom');
        
        
        colord=get(gca,'ColorOrder');
        set(H3(2),'Color',colord(2,:),'LineStyle','--');
        set(H3(3),'Color',colord(2,:),'LineStyle','--');
        set(H3(4),'Color',colord(3,:));
        
        set(hax3,'XLim',xlim1);
        set(hax3,'YLim',[-1 1]);
        
        mprev=m;
        
        
        % Prompt for window width
        kq1=questdlg(['Revise Window Width from ' int2str(mprev)]);
        kwh4=1;
        while kwh4==1;
            if strcmp(kq1,'Yes');
                prompt={'Enter desired width:'};
                def={int2str(mprev)};
                dlgTitle='Input for Window Width';
                lineNo=1;
                answer=inputdlg(prompt,dlgTitle,lineNo,def);
                m = str2num(answer{1});
                
                % Check m for validity
                if m>floor(nyr2/2) | m<20;
                    m=mprev;
                    %msgbox(['Try again!  Width must be in range ' num2str([20 floor(nyr2/2)]) ],'Message',.18,.10);
                    uiwait(msgbox(['Width must be in range ' num2str([20 floor(nyr2/2)]) ],'Whoops','modal'));

                else;
                    toffset=m;
                    sinf{4}=['  Window width = ' int2str(m) ' yr'];
                    sinf{5}=['  Window offset = ' int2str(toffset) ' yr'];
                    kwh4=0;
                    
                    
                    % Build new matrices using revised window
                    
                    axes(hax2);
                    % Unsampled means and year vectors
                    X=subfcn01(zx2,m);
                    xmn = (mean(X))';
                    yr2mn = yr2(m:nyr2);
                    Y=subfcn01(zy2,m);
                    ymn = (mean(Y))';
                    
                    % Sample at intervals keyed to ending year and offset by toffset
                    if strcmp(upper(pcur),'ENDING');
                        i1 = fliplr((length(yr2mn):-toffset:1));
                        i2 = fliplr((length(yr2mn):-toffset:1)); 
                        tuv= yr2mn(i2);
                    else; % plotted points at midpoint of window
                        if mod(m,2)==0;
                            error('Plotting at central year invalid if window width even');
                        end;
                        i1 = fliplr(     ((length(yr2mn)-(m-1)/2):-toffset:1)      ); % index to year
                        i2 = fliplr((length(yr2mn):-toffset:1)); % index to means or correlatkons 
                        tuv= yr2mn(i2)-(m-1)/2; % 
                    end;
                    %tuv = yr2mn(i1);
                    u= xmn(i2);
                    v= ymn(i2);
                    
                    sinf1{5}=['     Width = ' int2str(m) ';  Offset= ' int2str(toffset) ';  Number = ' int2str(length(tuv))];
                    H2=plot(tuv,u,'o',tuv,v,'^',[min(yr2) max(yr2)],[0 0]);
                    
                    txt2a = ['Sliding ' int2str(m) '-yr Means of Z-Scores (\Deltat = ' int2str(toffset) ' ' labtime 's)'];
                    htxt2a=text(yr2(3),p1y,txt2a);
                    
                    legend(id1,id2);
                    
                    
                    set(hax2,'XTickLabel',[]);
                    set(hax2,'XLim',xlim1);
                    set(hax2,'YLim',ylim1);
                    ylabel('Z-score')
                    
                    
                    %-----------TIME SERIES PLOT OF SLIDING CORRELATIONS 
                    axes(hax3);
                    
                    r = corrpair(X,Y); % compute correlations
                    ruv=r(i2);
                    
                    %-- threshold of correlation
                    
                    if strcmp(bcur,'ON');
                        bonf=1; % want Bonferrroni
                    else;
                        bonf=0;
                    end;
                    if strcmp(scur,'ON');
                        rhothis=rho;
                    else;
                        rhothis=[0 0];
                    end;
                    [rcrit,dummy1,dummy2]=pearsign(median(ruv),m,length(tuv),acur,bonf,rhothis);
                    
                    sinf1{17}=['        Median r = ' num2str(median(ruv),'%6.2f')];
                    sinf1{18}=['        Min,Max r = ' num2str(min(ruv),'%6.2f') ',   ' num2str(max(ruv),'%6.2f')];
                    sinf1{19}=['        Critical r = '  num2str(rcrit,'%6.2f')];
                    
                    
                    H3=plot(tuv,ruv,'-o',[min(tuv)  max(tuv)],[rcrit rcrit],[min(tuv) max(tuv)],[-rcrit -rcrit],[min(yr2) max(yr2)],[0 0]);
                    xlabel([pcur ' ' upper(labtime) ' OF WINDOW']); 
                    ylabel('r')
                    
                    
                    txt3a=['Sliding Correlation'];
                    text(yr2(3),.85,txt3a);
                    
                    % Label of CI
                    if acur==0.05;
                        sigstr=' 95% CI ';
                    elseif acur==.01;
                        sigstr=' 99% CI ';
                    else;
                        error('sigstr invalid');
                    end;
                    htxt3b=text((yr2mn(1)+yr2mn(end))/2,rcrit,sigstr,'VerticalAlignment','bottom');
                                        
                    colord=get(gca,'ColorOrder');
                    set(H3(2),'Color',colord(2,:),'LineStyle','--');
                    set(H3(3),'Color',colord(2,:),'LineStyle','--');
                    set(H3(4),'Color',colord(3,:));
                    
                    set(hax3,'XLim',xlim1);
                    set(hax3,'YLim',[-1 1]);
                    
                    mprev=m;
                    kfirst=0;
                                        
                    % End Build new matrices using revised window
                end;
                
                sinf{4}=['  Window width = ' int2str(m) ' yr'];
                
            else;
                kwh4=0;
                kfirst=0;
                
            end;
        end; % while kwh4==1;
        
        %--------- COMPUTE CORRELATIONS (if new or initial width)
        
        %---------- COMPUTE CONFIDENCE LEVELS (if new or initial width)
        
        
        kwh2=1;
        while kwh2==1;
            
            kmen2=menu('Choose',...
                'Revise offset',...
                ['Toggle plotting position from -- ' pcur ' -- to -- ' pprev],...
                ['Toggle Bonferonni adjustment from ' bcur ' to ' bprev],...
                ['Toggle alpha level from ' num2str(acur) ' to ' num2str(aprev)],...
                ['Toggle persistence adjustment from ' scur ' to ' sprev],...
                'Accept');
            %             
            %             Padjust={'Ending','Central'}; % Toggle for plotting points relative to windowed period
            %             Alevel={'95','99'}; % toggle for confid level
            %             Sadjust={'Adjust','Do Not Adjust'}; % toggle for adjusting sample size for lag-1 autocorrelation
            %             Badjust={'No Bonferroni Adjustment','Bonferroni Adjustment'}; % Toggle for confidence band
            %             jp=1;
            %             ja=1;
            %             js=1;
            %             jb=1;
            
            
            if kmen2==1; % Revise offset
                kwh6=1;
                while kwh6==1;
                    toffprev=toffset;
                    maxoff = m;
                    minoff=1;
                    prompt={['Enter offset (' int2str(1) ' <= delta <- ' int2str(m) '):'] };
                    def={int2str(toffset)};
                    dlgTitle=['Revise offset from ' int2str(toffprev) ];
                    lineNo=1;
                    answer=inputdlg(prompt,dlgTitle,lineNo,def);
                    toffset=str2num(answer{1});
                    if toffset<1 | toffset>m;
                        uiwait(msgbox({'Offset invalid',...
                                'Cannot be less than 1 or greater than window width'},'Message','modal'));
                        toffset=toffprev;
                    else; % valid ofset
                        txt2a = ['Sliding ' int2str(m) '-yr Means of Z-Scores (\Deltat = ' int2str(toffset) ' ' labtime 's)'];
                        set(htxt2a,'String',txt2a);
                        
%                         % STOPPED HERE
%                         
%                         not really, but somehow get error on line 444.  Also see that plot 2 top text gets reset
%                         when I toggle the plotting point.
%                         
                        % CODE FOR PLOT OF MEANS SAMPLING COMPUTED MEANS AND TIME PLOT VECTOR
                        
                        axes(hax2);
                        % Sample at intervals keyed to ending year and offset by toffset
                        if strcmp(upper(pcur),'ENDING');
                            i1 = fliplr((length(yr2mn):-toffset:1));
                            i2 = fliplr((length(yr2mn):-toffset:1)); 
                            tuv = yr2mn(i1);
                        else; % plotted points at midpoint of window
                            i1 = fliplr(((length(yr2mn)-(m-1)/2):-toffset:1)); % index to year
                            i2 = fliplr((length(yr2mn):-toffset:1)); % index to means or correlatkons 
                            tuv= yr2mn(i2)-(m-1)/2; % 
                            
                        end;
                        %tuv = yr2mn(i1);
                        u= xmn(i2);
                        v= ymn(i2);
                        
                        sinf1{5}=['     Width = ' int2str(m) ';  Offset= ' int2str(toffset) ';  Number = ' int2str(length(tuv))];
                        H2=plot(tuv,u,'o',tuv,v,'^',[min(yr2) max(yr2)],[0 0]);
                        ylabel('Z-score')
                        
                        txt2a = ['Sliding ' int2str(m) '-yr Means of Z-Scores (\Deltat = ' int2str(toffset) ' ' labtime 's)'];
                        htxt2a=text(yr2(3),p1y,txt2a);
                        legend(id1,id2);
                        set(hax2,'XTickLabel',[]);
                        set(hax2,'XLim',xlim1);
                        set(hax2,'YLim',ylim1);
                        
                        axes(hax3);
                        ruv=r(i2);
                        
                        
                        % Recalc critical r because Bonferroni size might have changed
                        if strcmp(bcur,'ON');
                            bonf=1; % want Bonferrroni
                        else;
                            bonf=0;
                        end;
                        if strcmp(scur,'ON');
                            rhothis=rho;
                        else;
                            rhothis=[0 0];
                        end;
                        
                        [rcrit,dummy1,dummy2]=pearsign(median(ruv),m,length(tuv),acur,bonf,rhothis);
                        
                        sinf1{17}=['        Median r = ' num2str(median(ruv),'%6.2f')];
                        sinf1{18}=['        Min,Max r = ' num2str(min(ruv),'%6.2f') ',   ' num2str(max(ruv),'%6.2f')];
                        sinf1{19}=['        Critical r = '  num2str(rcrit,'%6.2f')];
                        
                        
                        H3=plot(tuv,ruv,'-o',[min(tuv)  max(tuv)],[rcrit rcrit],[min(tuv) max(tuv)],[-rcrit -rcrit],[min(yr2) max(yr2)],[0 0]);
                        xlabel([pcur ' ' upper(labtime) ' OF WINDOW']); 
                        
                        
                        txt3a=['Sliding Correlation'];
                        htxt3a=text(yr2(3),.85,txt3a);
                        htxt3b=text((yr2mn(1)+yr2mn(end))/2,rcrit,' 95% CI ','VerticalAlignment','bottom');
                        
                        
                        colord=get(gca,'ColorOrder');
                        set(H3(2),'Color',colord(2,:),'LineStyle','--');
                        set(H3(3),'Color',colord(2,:),'LineStyle','--');
                        set(H3(4),'Color',colord(3,:));
                        
                        set(hax3,'XLim',xlim1);
                        set(hax3,'YLim',[-1 1]);
                        
                        
                        kwh6=0;
                    end; % if toffset<1 | toffset>m;
                    
                end; %while kwh6==1;
                
                
            elseif kmen2==2; % Toggle plot position
                if mod(m,2)==0 & strcmp(upper(pcur),'ENDING');
                    uiwait(msgbox({'Even window length invalid',...
                            'for central plotting --> must use odd length'},'Message','modal'));
                else;
                    ptemp = pcur;
                    pcur=pprev;
                    pprev=ptemp;
                    clear ptemp;
                end;
                
                % Revise xlabel
                axes(hax3);
                h1 = get(hax3,'XLabel');
                set(h1,'String',[pcur ' ' upper(labtime) ' OF WINDOW']);
                
                if strcmp(upper(pcur),'CENTRAL')
                    i1 = fliplr(     ((length(yr2mn)-(m-1)/2):-toffset:1)      ); % index to year
                    i2 = fliplr((length(yr2mn):-toffset:1)); % index to means or correlatkons 
                    tuv= yr2mn(i2)-(m-1)/2; % 
                elseif strcmp(upper(pcur),'ENDING');
                    i1 = fliplr((length(yr2mn):-toffset:1));
                    i2 = fliplr((length(yr2mn):-toffset:1)); 
                    tuv = yr2mn(i1);
                else;
                    error('Invalid pcur string');
                end;
                %tuv = yr2mn(i1);
                sinf1{9}=[' Plotting position=' pcur];
                u= xmn(i2);
                v= ymn(i2);
                set(H2(1),'XData',tuv);
                set(H2(2),'XData',tuv);
                set(H3(1),'XData',tuv);
                set(H3(2),'XData',[min(tuv) max(tuv)]);
                set(H3(3),'XData',[min(tuv) max(tuv)]);
                
            elseif kmen2==3; % Toggle Bonferroni
                btemp = bcur;
                bcur=bprev;
                bprev=btemp;
                clear btemp;
                
                % Recalculate confidence limits
                if strcmp(bcur,'ON');
                    bonf=1; % want Bonferrroni
                else;
                    bonf=0;
                end;
                if strcmp(scur,'ON');
                    rhothis=rho;
                else;
                    rhothis=[0 0];
                end;
                [rcrit,dummy1,dummy2]=pearsign(median(ruv),m,length(tuv),acur,bonf,rhothis);
                
                % Update sinf
                sinf1{7}=['      Bonferrroni Adjustment = ' bcur];
                sinf1{17}=['        Median r = ' num2str(median(ruv),'%6.2f')];
                sinf1{18}=['        Min,Max r = ' num2str(min(ruv),'%6.2f') ',   ' num2str(max(ruv),'%6.2f')];
                sinf1{19}=['        Critical r = '  num2str(rcrit,'%6.2f')];
                
                % Re-plot CI on axes 3
                axes(hax3);
                set(H3(2),'YData',[rcrit rcrit]);
                set(H3(3),'YData',[-rcrit -rcrit]);
                
                % Re-position text on CI
                postemp = get(htxt3b,'Position');
                postemp(2)=rcrit;
                set(htxt3b,'Position',postemp);
                
                
            elseif kmen2==4; % Toggle alpha level
                
                % Make new alpha-level current
                atemp = acur;
                acur=aprev;
                aprev=atemp;
                clear atemp;
                
                % Recalculate confidence limits
                [rcrit,dummy1,dummy2]=pearsign(median(ruv),m,length(tuv),acur,bonf,rhothis);
                
                % Update sinf
                sinf1{6}=['  Alpha Level for conf. bands: = ' num2str(acur)]; 
                sinf1{19}=['        Critical r = '  num2str(rcrit,fmta)];
                if strcmp(upper(scur),'ON');
                    if acur==0.05;
                        rfcritnow=rfcrit(1);
                    elseif acur==0.01;
                        rfcritnow=rfcrit(2);
                    else; 
                        error('Invalid acur');
                    end;
                elseif strcmp(upper(scur),'OFF'); 
                    if acur==0.05;
                        rfcritnow=rfcrit(3);
                    elseif acur==0.01;
                        rfcritnow=rfcrit(4);
                    else; 
                        error('Invalid acur');
                    end;
                end;
                sinf1{15}=['    Full period: r= ' num2str(rfull,fmta) '  (' num2str(rfcritnow,fmta) ' needed for sign. at ' num2str(acur) ' level)'];
                
                % Re-plot CI on axes 3
                axes(hax3);
                ylabel('r')
                set(H3(2),'YData',[rcrit rcrit]);
                set(H3(3),'YData',[-rcrit -rcrit]);
                
                % Change label of significance level and re-position text on CI
                
                % Label of CI
                if acur==0.05;
                    sigstr=' 95% CI ';
                elseif acur==.01;
                    sigstr=' 99% CI ';
                else;
                    error('sigstr invalid');
                end;
                
        
                postemp = get(htxt3b,'Position');
                postemp(2)=rcrit;
                
                set(htxt3b,'Position',postemp,'String',sigstr);
                
            elseif kmen2==5; % Toggle persistence adjustment
                
                % Make new persistence-adjustment option current
                stemp = scur;
                scur=sprev;
                sprev=stemp;
                clear stemp;
                
                
                % Update sinf
               
                if strcmp(upper(scur),'ON');
                    if acur==0.05;
                        rfcritnow=rfcrit(1);
                    elseif acur==0.01;
                        rfcritnow=rfcrit(2);
                    else; 
                        error('Invalid acur');
                    end;
                    rhothis=rho;
                    nyr2this=nyr2prime;
                elseif strcmp(upper(scur),'OFF'); 
                    if acur==0.05;
                        rfcritnow=rfcrit(3);
                    elseif acur==0.01;
                        rfcritnow=rfcrit(4);
                    else; 
                        error('Invalid acur');
                    end;
                    rhothis=[0 0];
                    nyr2this=nyr2;
                end;
                
                % Recalculate confidence limits
                [rcrit,dummy1,dummy2]=pearsign(median(ruv),m,length(tuv),acur,bonf,rhothis);
                
                sinf1{19}=['        Critical r = '  num2str(rcrit,fmta)];
                sinf1{8}=['      Autocorrelion Adjustjment = ' scur];
                sinf1{13}=['     Effective sample size, N* = ' num2str(nyr2this,fmtb)];
                sinf1{15}=['    Full period: r= ' num2str(rfull,fmta) '  (' num2str(rfcritnow,fmta) ' needed for sign. at ' num2str(acur) ' level)'];
                
                % Re-plot CI on axes 3
                axes(hax3);
                ylabel('r')
                set(H3(2),'YData',[rcrit rcrit]);
                set(H3(3),'YData',[-rcrit -rcrit]);
                
                % re-position text on CI
                postemp = get(htxt3b,'Position');
                postemp(2)=rcrit;
                set(htxt3b,'Position',postemp,'String',sigstr);
                
                
            elseif kmen2==6; % Accept
                
                kwh2=0;
            end;
            
        end; % while kwh2==1; 
    elseif kmen1==2;
        
        kwh1=0;
        
    end;
    
end; % while kwh1==1; 
[cL,cB,cW,cH]=figsize(0.6,.6);
set(gcf,'Position',[cL cB cW cH]);


S0=sinf0;
S1=sinf1;
S1(1:2)=[];
S1=[S0 S1];
S1=char(S1);
%uiwait(msgbox(sinf1,'Information (see sinf1)','modal'));
msgbox1(sinf1,'Information (see sinf1)');
%uiwait(msgbox(vlist,'Information','modal'));

% SUBFUNCTIONS

function X=subfcn01(x,m)
% Build windowed matrix from time series vector
% m is the window width
% x is the time series as col vector
% X is tsm. Col 1 holds x(1:m), col 2 holds x(2:(m+1)) ... last col holds x((mx-m+1):mx)
[mx,nx]=size(x);
if nx~=1;
    error('x must be cv');
end;

if m>=mx;
    error('window width must be shorter than time series');
end;

% Make index to end times
i2 = fliplr(mx:-1:m);

% Expand to mtx
A = repmat(i2,m,1);
[mA,nA]=size(A);

% increment vector
b = (0:1:(m-1))';
B=repmat(b,1,nA);

C=A-B;
C=flipud(C);
X=x(C);
