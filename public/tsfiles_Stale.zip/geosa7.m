% geosa7.m  detrending
%
% Last revised 2018-12-23
%
%
%*** UW FUNCTIONS CALLED
%
% figsize
% msgbox1
% specbt1
% splfres
% cfspl
% splinep
%
%*** TOOLBOXES NEEDED
%
% System Identification
% Statistics
% curve-fitting
%
%*** NOTES
% Detrending.  Prompted to select a ring-width measurment series for
% one of 7 cores from Cirque Peak, CA, site (Pinus Balfouriana (PIBA)).
% Two detrending lines are fit:
%   least squares straight line
%   spline curve --user interactively fits spline detrending
%
% Figure windows:
% 1- time series plot, with superposed trend lines for straight line and spline
% 2- time series plots detrended series 
% 3- normalized spectra of : original series, straight line detrended, spline-detrended
% 4- frequency response function of the selected spline
%
% Revised 2015-01-15.  xlims to control range of time axis;  changed
% colors on plot to deal with changes in default color order under R2014b
%
% Revised 2016-12-04. Minor cosmetic  changes, including structure S
% output.
%
% Revised 2018-12-23. Cosmetic: to deal with Matlab version changes in
% handling of legends.

% Close windows and clear all workspace variables
close all;
clear;

% Hard code
datfile='Spring19'; % default .mat file with input data
datdir=cd;  % directory with input data; assume current working directory
path1=datdir; % store path/directory
nwant = 1; % number of series to analyze
nsers = 1; % ditto

message1 = {'Detrending',...
        '',...
        'Detrending of a time series. Comparison of two alternative methods:',...
        '   1 Least squares fit straight line',...
        '   2 Cubic smoothing spline',...
        'Illustrates :',...
        '       -frequency response function of cubic smoothing spline',...
        '       -effect of detrending on spectrum',...
        '       -ratio vs difference detrending',...
        '       -quantifying importance of trend',...
        '       -use of normalized spectra',...
        '',...
        'You are initially prompted to select a single time series.',...
        'This series may be from data any of the sets V1, V2 or V3.',...
        'V3 is the logical choice since that is supposed to be your',....
        'trendy data.   You have interactive control over the spline ',....
        'over the spline flexibility through the spline parameter.',...
        '',...
        'Figure windows produced:',...
        '   Fig 1: time series plots: original time series, alternative ',...
        '       trend lines',...
        '   Fig 2: amplitude of frequency response function of selected ',...
        '       detrending spline',...
        '   Fig 3: time series plots of detrended series',...
        '   Fig 4: normalized spectra of detrended series'};
msgbox1(message1,'geosa7');



% Hard code
k1=1;  % for detrending


%-------    GENERAL INPUT CONTROL

% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string

%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename into one string variable
eval(['load ' pf1])


%--- The data should be in a structure variables V1, V2, V2 
%  Check that required structures exist in the workspace
if ~all([exist('V1')==1  exist('V1')==1  exist('V1')==1]);
    error([pf1 ' does not contain V1, V2 and V3']);
end

% Check that V1, V2 and V3 are structures with required fields
for n =1:3; % loop over structures
    eval(['V = V' int2str(n) ';']);
    if ~isstruct(V); 
        error(['V' int2str(n) ' must be structure']); 
    else; % check for required fields
        sfields(V);
    end;
end;


% --- CHOOSE DATA SET THE TIME SERIES IS TO BE SELECTED FROM  

kv = menu('Time series will be selected from which data (choose one)',...
    ['V1 -- output data: ' V1.what],...
    ['V2 -- input data: ' V2.what],...
    ['V3 -- trend data: ' V3.what]);
if kv==1;
    V=V1;
elseif kv==2;
    V=V2;
else;
    V=V3;
end;

% Compute number of series in structure
nsites = size(V.name,1);

% Time increment
tinc = V.increment;



%*********  MENU TO CHOOSE SERIES

Lpick = logical(zeros(nsites,1)); % pointer to picked series
pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not

tmen = V.seriesmenu;  % menu of series, with column number
tmen1=tmen;
tmen1{nsites+1}='Accept selection';
tmen1 = char(tmen1);
tmen2=[tmen1 pflag];
[mtmen2,ntmen2]=size(tmen2);

sitenos=repmat(NaN,nwant,1); % to store index to selected sites

kwh1=1;
strchoose='Select a series';
kthis=[];
while kwh1==1;
    kmen1=menu(strchoose,cellstr(tmen2));
    if ~any(Lpick) & kmen1== nsites+1;
        msgbox1('None selected yet -- do again','Message',.18,.10);
    elseif kmen1==nsites+1;
        sitenos=kthis;;
        kwh1=0;
    else;
        Lpick=logical(zeros(nsites,1)); 
        pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not
        pflag(kmen1,3)='*';
        Lpick(kmen1)=1;
        kthis=kmen1;
        tmen2=[tmen1 pflag];
        
    end;
    
end;

j1 = sitenos(1);



% Find start and end time of valid data for series

YRS = repmat(NaN,nwant,2);
L = ~isnan(V.tsm(:,sitenos));  % logical pointer to valid entries 
disp(blanks(1));
disp(['Start and end ' lower(tinc) ' of valid data for series']);
fmt1 = '%50s  %4.0f-%4.0f\n';
jsite = sitenos;
yrtemp = V.time(L);
YRS(1,1)=min(yrtemp);
YRS(1,2)=max(yrtemp);



id1=V.id{jsite};


%**********  INPUT DIALOG TO SELECT PERIOD FOR ANALYSIS

titlepmt = ['Select the start and end ' lower(tinc) ' for analysis'];
prompt = {['Enter start ' lower(tinc)],...
        ['Enter end ' lower(tinc)]};
lineNo=1;
deflt = {int2str(max(YRS(:,1))),int2str(min(YRS(:,2)))};
answer=inputdlg(prompt,titlepmt,lineNo,deflt); % answer as char in cells
% convert answer to double
yrgo = str2num(answer{1});
yrsp = str2num(answer{2});
% Store string with analysis period
txtyr = sprintf('%4.0f-%4.0f',yrgo,yrsp);


% Check that both series cover selected period
if any(YRS(:,1)>yrgo) | any(YRS(:,2)<yrsp);
    error(['Selected analysis period inconsistent with start, end ' lower(tinc) ' of series']);
end


% Display name of selected series and info
clc;  % clear the command window
strmess1={['Type of data: ' V.what ],...
        [' ID: ' V.id{sitenos}],...
        [' Name: ' V.name{sitenos}],...
        [' Time coverage: ' int2str([yrgo yrsp])]};
msgbox1(strmess1,'Selection:');




n1size=yrsp-yrgo+1; % length of selected period
% Store string with sample size, for use in later printing in figure titles.
% Note the use of \it to italicize N, of \rm to return to normal (not italic)
% font before printing the number.  This demonstrates use of TeX langauage,
% which lets you add greek characters, mathematical symbols, etc., to 
% text.  See info for the 'text' command under the html help for more on 
% TeX.  
txtna = sprintf('%5.0f',n1size);
txtn  = ['\itN = \rm' txtna]; 




%******************** GET SUBSET OF DATA FOR SELECTED PERIOD AND SERIES
L1 = V.time>=yrgo & V.time<=yrsp; % logical pointer to rows of vector tree.yr
yr1 = V.time(L1);  % time vector for selected period
X = V.tsm(L1,jsite);  % subset of times, columns with the desired data
Results.when=datestr(date);


% Store time series for desired analysis period in x1 
x1=X(:,1);
nyr=length(x1); 
Results.X = repmat(NaN,nyr,4);
Results.X(:,1)=x1;



%----- END OF GENERAL INPUT CONTROL

% A y-axis label for time series
labtime=V.increment;
labtime1 = labtime ; % short label
if strcmp(lower(V.increment),'year');
    labfreq='yr^{-1}';
    labtime1 = 'yr';
else;
    labtime1=V.increment;
    labfreq=[V.increment '^{-1}'];
end;
laby1 = [V.label{sitenos} '(' V.units{sitenos} ')'];




%********* PROMPT FOR RATIO OR DIFFERENCE DETRENDING

kmen2=menu('Choose detrending option',...
    'Difference of data and trend line',...
    'Ratio of data to trend line');
switch kmen2;
case 1; % difference
    howdt='Difference';
    laby3 = ['Difference Departure (' V.units{sitenos} ')'];
case 2; % ratio
    howdt='Ratio';
    laby3= ['Ratio Departure (dimensionless)'];
otherwise;
end;
Results.how=howdt;


%***************** DETRENDING *****************

if k1==1; % Detrending mode   
    
    % Truncate any NaN values from ends of series
    L1 = isnan(x1);
    if any(L1);
        x1(L1)=[];
        yr1(L1)=[];
    end
    clear L1;
    
    % Check that no gaps in time
    if    any(diff(yr1)~=1) ;
        error('One or both series have an internal NaN');
    end
    
    % Compute start and end time of default analysis period
    yrgo1 = min(yr1);
    yrsp1=max(yr1);
    yrcomm=(yrgo1:yrsp1)';
    
     
    yr=yr1; % rename for convenience of using old code
    
    
    
    %*************  TIME SERIES PLOTS FOR INTERACTIVE CHOICE OF SPLINE FLEXIBILITY
    
    figure(1)
    set(gcf,'Name','Time Series Plot of Original Series and Straight-Line Fit');
    kfirst=1; % marker for first time plot appearsylabel('Ring Width (mm)');
    
    % Fit and same least-squares straight line
    T= [yr ones(nyr,1) ]; % predictor matrix
    b=regress(x1,T);
    x1hat = T*b;
    Rtemp=corrcoef(x1hat,x1);
    R2line=(Rtemp(1,2)) .^2; % R-squared for staight line fit
    % Compute ratio variance of residuals from fitted line to variance
    % of original variable
    vrat1 = 1-(var(x1-x1hat))/var(x1);
    strlinea=sprintf('Least Squares Straight Line, R^{2}=%5.2f',vrat1);
    strlineb=sprintf('Least Squares Straight Line');
    
    
    
    
    kwh1 = 1; 
    while kwh1==1;
        xlims=[yr(1)-(0.01*(yr(end)-yr(1))) yr(end)+(0.01*(yr(end)-yr(1)))];
        h1p=plot(yr,x1,yr,x1hat);
        set(gca,'XLim',xlims);
        xlabel(labtime);
        strnsize = sprintf('%5.0f',nyr);
        strnsize = [',  \itN\rm = ' strnsize];
        title(['Interactive Spline Fitting, ' id1 strnsize]);
        legend('Original Series',strlinea);
        % zoom xon; % bug in some combinations of OS and Matlab version
        grid
        
        % Menu for first time thru
        if kfirst==1;
            prompt={'Specify period of spline:'};
            deflt={num2str(nyr*0.7)};
            tit1='Spline with amplitude of frequency response 0.5';
            lineNo=1;
            answer=inputdlg(prompt,tit1,lineNo,deflt);
            pd1 = str2num(answer{1});
            
            % Spline fitting and overplotting
            p1 = splinep(pd1,0.5);  % spline parameter for chosen spline
            cv1 = (cfspl(p1,yr,yr,x1))'; % values of spline curve
            vrat2=1-(var(x1-cv1))/var(x1);
            txtv =sprintf(', R^{2} = %5.2f',vrat2);
            
            
            
            kfirst=0;
        else
            figure(1);
            set(gcf,'Name','Time Series Plots of Original Data and Two Trend Lines');
            xlims=[yr(1)-(0.01*(yr(end)-yr(1))) yr(end)+(0.01*(yr(end)-yr(1)))];
            h1p=plot(yr,x1,yr,x1hat,yr,cv1);
            set(gca,'XLim',xlims)
            xlabel(labtime);
            ylabel(laby1);
            strnsize = sprintf('%5.0f',nyr);
            strnsize = [',  \itN\rm = ' strnsize];
            title(['Interactive Spline Fitting, ' id1 strnsize]);
            
            % Thicken lines for spline curve
            set(h1p(3),'Linewidth',1);
            
            % Legends for spline fits 
            fract1 = sprintf('%4.2f',pd1/nyr); % spline "length" as fraction of series length
            txtfr1 = ['(' fract1 '\itN\rm)'];
            txtv =sprintf(', R^{2} = %5.2f',vrat2);
            legd1a = [sprintf('%5.1f-yr spline',pd1 ) txtfr1 txtv];
            legd1b = [sprintf('%5.1f-yr spline',pd1 ) txtfr1];
            
            %legend('Ring Width',legd1a,legd1b);
            legend(V.label{sitenos},strlinea,legd1a);
            
            zoom xon; % bug in some combinations of OS and Matlab version
            grid
            
            
            % Frequency response for spline
            fvec=[0 min([3*1/pd1 0.5]) 100]';
            u=splfres(p1,fvec);
            
            % Check that ampl o freq response monontonically decreasing;  otherwise, not valid as smoothing function
            
            figure(2);
            set(gcf,'Name','Amplitude of Frequency Response of Spline');
            plot(u(:,1),u(:,2));
            grid;
            xlabel('Frequency');
            ylabel('Response');
            strparam=sprintf('%E',p1);
            title(['Spline Frequency Response, Spline Parameter = ' strparam]);
            
            if any(diff(u(:,2))>=0);
                msgbox1({'Pick a stiffer spline','Freq. response not monotonic nonincreasing'},'WARNING');
            end;
            
            
            kmen1 =menu('Choose One:','Change Spline','Accept Spline');
            if kmen1==1;
                prompt={'Specify period of spline:'};
                deflt={num2str(pd1)};
                tit1='Revise Spline:';
                lineNo=1;
                answer=inputdlg(prompt,tit1,lineNo,deflt);
                pd1 = str2num(answer{1});
                
                % Spline fitting 
                p1 = splinep(pd1,0.5);  % spline parameter for first choice
                cv1 = (cfspl(p1,yr,yr,x1))'; % values of spline curve
                vrat2=1-var(x1-cv1)/var(x1);
                
                
            else
                kwh1=0;
            end
        end % if kfirst=1
    end % kwh1a
    
    %***********  TIME SERIES PLOTS OF DETRENDED RING WIDTH (RATION INDICES)
    % FOR THE TWO SELECTED SPLINE FITS
    figure(3);
    set(gcf,'Name','Time Series Plots of Detrended Series');
    colord=get(gca,'ColorOrder');
    
    Results.X(:,2)=x1hat;
    Results.X(:,3)=cv1;
    
    %------------ Detrend by ratio
        
    if any(x1hat<=0) | any(cv1<=0) | any(x1<0);
        if strcmp(howdt,'Ratio');
            uiwait(msgbox('Ratio detrending invalid: trend line not >0 everywhere','FATAL ERROR','modal'));
            msgbox1('Ratio detrending invalid: trend line not >0 everywhere','FATAL ERROR');
            error('Cannot use ratio detrending: trend line not >0 everywhere, or one or more data values negative');
        else;
            r1=repmat(NaN,length(yr),1);
            r2=repmat(NaN,length(yr),1);
            msgbox1({'The difference-detrended version of the series is fine, ',...
                'but the ratio-detrended version of the series has been set to NaN ',...
                'because the original series or fitted trend line goes negative',...
                'at some point'},'Message');
        end;
    else;
        r1 = x1 ./ x1hat;
        r2 = x1 ./ cv1; 
        
    end;
        
    
    %------------- Detrend by difference 
    
    d1=x1-x1hat;
    d2=x1 -cv1;
    
    if strcmp(howdt,'Ratio');
        Results.X(:,4)=r1;
        Results.X(:,5)=r2;
    else;
        Results.X(:,4)=d1;
        Results.X(:,5)=d2;
    end;
    
    % Plot indices
    xlims=[yr(1)-(0.01*(yr(end)-yr(1))) yr(end)+(0.01*(yr(end)-yr(1)))];
    if strcmp(howdt,'Ratio');
        h2p=plot(yr,r1,yr,r2);
        set(gca,'XLim',xlims)
        title([howdt '-Detrended Series']);
        baseline=1.0;
    else;  % difference
        h2p=plot(yr,d1,yr,d2);
        set(gca,'XLim',xlims)
        title([howdt '-Detrended Series']);
        baseline=0;
    end;
    ytag=laby3;
    ylabel(ytag);
    xlabel(V.increment);
    
    set(h2p(1),'Color',colord(1,:));
    set(h2p(2),'Color',colord(2,:),'LineWidth',1);
    hleg=legend(strlineb,legd1b);
    
    % Put horiz line at index of 1.0
    xlim2 = get(gca,'Xlim'); % get xaxis limits
    p2line=line(xlim2,[baseline baseline]);
    set(p2line,'color',[0 0 0]);
    hleg.String{3}='Mean';
    
    % Enable zoom and turn on grid
    zoom xon;  % bug in some combinations of OS and Matlab version
    grid
    
    %************** COMPARISON OF SPECTRA OF INDICES DERIVED BY DIFFERENT SPLINE 
    % SETTINGS
    ytype='Linear'; % intitialize to linear scale for spectrum
    kwhile1=1;
    kfirst = 1;
    while kwhile1==1;
        
        figure(4);
        set(gcf,'Name','Normalized Spectra of Detrended Series');
        
        % Set up input args to specbt1.m
        prevwind=2; % preserve windows thru this one
        kopt(1)=2; % non-interactive mode
        if kfirst==1;
            M= round(nyr/8); % lag window, default first time around
        else
        end
        
        f = 0:1/nyr:0.5; % frequencies for spectral estiamtes
        tlab='joker';
        
        if strcmp(howdt,'Ratio');
            G1=specbt1(zscore(r1),M,f,prevwind,'dummy',kopt,labtime); % spectrum of index by s. line
            G2=specbt1(zscore(r2),M,f,prevwind,'dummy',kopt,labtime); % spectrum of index by spline
        else;
             G1=specbt1(zscore(d1),M,f,prevwind,'dummy',kopt,labtime); % spectrum of index by s. line
            G2=specbt1(zscore(d2),M,f,prevwind,'dummy',kopt,labtime); % spectrum of index by spline
        end;
    
    
        if strcmp(ytype,'Linear');
            hspec=plot(G1(:,1),G1(:,3),G2(:,1),G2(:,3));
        elseif strcmp(ytype,'Log');
            hspec=semilogy(G1(:,1),G1(:,3),G2(:,1),G2(:,3));
        end;
        
        
        set(hspec(1),'Color',colord(1,:));
        set(hspec(2),'Color',colord(2,:),'LineWidth',1);
        grid;
        
        % Set axes postion to allow for 2 lines in title
        set(gca,'Position',[0.1300    0.1100    0.7750    0.80])
        
        % string for M/N
        txt3a = ['\itM/N \rm= ' int2str(M) '/' int2str(nyr)];
        
        title({['Normalized Spectra of Detrended Series, ' id1  ', '   txt3a],...
                'Effect of Spline Choice'});
        hleg4=legend(strlineb,legd1b);
        xlabel(['Frequency (' labfreq ')']);
        ylabel('Relative Variance');
        
        %Compute and plot bandwidth
        bw = 4/(3*M);  % see Ljung (1987, p. 155), Chatfield (1975, p. 154)
        % Note that the "Hamming" window as defined in system ident toolbox and Ljung
        % is identical to Chatfield's Tukey Window
        % Put bandwidth bar 0.3 from top of figure, centered
        ylims = get(gca,'Ylim');
        yrng = abs(ylims(2)-ylims(1));
        if strcmp(ytype,'Linear');
            ypoint = ylims(2)-0.3*yrng;
            line([0.25-bw/2 0.25+bw/2], [ypoint ypoint]);
            line([0.25-bw/2  0.25-bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
            line([0.25+bw/2  0.25+bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
            htt = text(0.25,ypoint+yrng/100,'Bandwidth');
        elseif strcmp(ytype,'Log');
            dlog=log10(ylims(2))-log10(ylims(1));
            dlog5=dlog/5;
            dfact = 10^(-dlog5);
            ypoint = dfact*ylims(2);
            line([0.25-bw/2 0.25+bw/2], [ypoint ypoint]);
            htt = text(0.25,ypoint,'Bandwidth');
        end;
        set(htt,'HorizontalAlignment','Center','VerticalAlignment','bottom');
         hleg4.String(3:end)=[];
        
        km = menu('Choose one:','Change Lag Window',...
            'Toggle y-axis log/linear',...
            'Accept Spectrum');
        if km==1; % change lag window
            prompt={'Enter value for M:'};
            deflt={num2str(M)};
            tit1='Length of Lag Window for Smoothing Spectrum';
            lineNo=1;
            answer=inputdlg(prompt,tit1,lineNo,deflt);
            M=str2num(answer{1});
            kwhile1=1;
            kfirst=0;
        elseif km==2
            if strcmp(ytype,'Log');
                ytype='Linear';
            else;
                ytype='Log';
            end;
            kwhile=1;
        elseif km==3;
            kwhile1=0;
        end
        
        hleg4.String(3:end)=[];
        
    end; % of while kwhile==1
end;

%---- STORE RESULTS FOR LATER ACCESS

Results.lamda=p1;
Results.phalf=pd1;
Results.t=yr;
Results.what=char({'S.when = date analysis done',...
        '.t = time vector for time series and trend lines',...
        '.N = length of time series (selected analysis period',...
        '.X = time series matrix with columns:',...
        '   1-original series',...
        '   2-linear (least squares) trend line',...
        '   3-cubic smoothing spline trend line',...
        '   4-detrended series -- by least squares straight line',...
        '   5-detrended series -- by cubic smoothing spline',...
        '.lamda -- spline parameter',...
        '.phalf -- period at which selected spline has frequency response 1/2',...
        '.how = option for detrending (ratio or difference)'});

    
  message2={'Finished! S is a structure with data and statistics from the analysis',...
    'S.what lists the fields in S'};
S=Results;    

msgbox1(message2,'message2');


