function message1=geosa1
% geosa1:  Build structure variable with class data stored in tab-separated ascii txt file
% geosa1;
% Last revised 2018-12-20
%
% Reads time series and metadata from previously prepared  1) tab-separated ascii txt file of a time series, matrix, and
% 2) ascii file of metatdata, with "$" as separator.  Purpose is to prepare an ouput structure variable for use in 
% GEOS585a and store hthat structure in a mat file. 
%
%*** INPUT
%
% No input arguments.  User prompted to click on data files.  User should prepare files of input time series and site
% information beforehand (see notes).
%
%
%*** OUTPUT
%
% No output args.  User prompted for filename to store output.
%
%
%*** REFERENCES -- none
%
%*** UW-FUNCTIONS CALLED
%
% intnan -- check for internal missing values
% msgbox1 -- message box
%
%*** TOOLBOXES NEEDED -- none
%
%*** NOTES
%
% The GEOS585A class uses three sets of time series -- V1, V2 and V3.  V1 and V2 are assumed to not require detrending, or to
% have been detrended beforehand.  In a causal system V1 series would be output or response variables, and V2
% series would be input variables. V3 time series are intended to demonstrate detrending, and so would usually
% contain trend and not have been detrended beforehand. 
%
% For the GEOS585A class, at least three time series should be included in each of the sets V1, V2 and V3.
% There is no upper limit on the number of time series for each data set.
%
% In dendroclimatology, V1 might be standard index chronologies at several tree-ring sites, V2 might be annual precipitation
% at several stations, and V3 might be ring width series for several cores.  It is acceptable to mix types of
% variables within each set.  For example, V2 might include time series of annual precipitation, annual mean
% temperature, and annual mean dewpoint at a station.  
%
% In hydrology/climatology,  V1 might be gaged streamflow, V2 might be water-year precipitation, and V3 might be a
% January mean temperature at a station influenced by urban warming.
%
% All time series in V1, V2 and V3 must have a time step of 1 time unit, and that unit must be the same for all series in V1, V2 and
% V3.  For example, a yearly time step applies to time series of summer mean temperature, annual tree-ring index, and annual total precipitation.  
%
% The three structures (V1, V2, and V3) are stored together by geosa1 in a .mat file.  Optionally,
% user may generate and store just one or two of the three structures during a single run.  
% This option allows for modifying existing data files -- for example, substituting an updated set of tree-ring 
% chronologies for V1 later in the semester without modifying V2 and V3.
%
% The requirements of the time series are:
%
% 1. time step between observations is 1 (a year, a month, a decade, or whatever)
% 2. series in V1 and V2 overlap in time by at least 30 observations
% 3. series have no internal missing values (unbroken)
% 4. user must input some associated series labels and units 
%
% Before running this function (geosa1), you should store your V1, V2 and
% V3 time series and metadata. For each of these data-types you will
% prepare a tab-separated ascii file with the time series matrix (label in
% row 1) and an ascii file of metatdata for the time series. These files
% will have the filename indicate whether it is the time series matrix or
% the metadaa.  For example, for the V1 series:
%
% V1Data.txt
% V1Meta.txt
%
% Geosa1 will prompt you for your last name, and will code that into the
% .mat filename that is stored.   For example, if your name is "Smith", you
% will get a .mat output file Smith.mat.  For my data (the instructor
% data), I'm using the name "Spring17", which stands for spring semester
% 2017.  But you use your last name.  If you want to have different versions of this
% output file, you could add a letter or number after your name (e.g., Smith1, Smith2).
%
%
%---- THE TAB-SEPARATED ASCII TXT FILE WITH THE DATA (E.G., THE TIME SERIES) 
%
% The time series should be prepared in a tab-delimited txt file that has
% short labels in the first row and all-numeric data in all other rows.
% The first column should be the time variable (e.g., the year), and each
% remaining column should be for a data variable. 
%
% The data headers, or labels, should be short (15 or fewer characters) and contain no
% spaces.  The should also exactly match the labels you specify in the
% metadata file described later.
%
% One way to prepare this file is with Excel.  Excel will let you "save as"
% ascii tab-delimited
%
%
%--------------- THE ASCII TXT FILE WITH METADATA
%
% The metadata file is a short file with some information on the time series.  Thise
% metadata file can be prepared with a text editor.  The first three lines
% shoule contain identifying information applicable to all time series in
% the corresponding  data file. 
%
% 1 Name of the accompanying data file <V1Data.txt>
% 2 Time increment of observations <Year>
% 3 Missing value code <NaN>.... this can be any number, or "NaN" that confused with data (e.g., -999)
%
% The remaining lines should contain identifying information specific to each series -- one line per time series.
% Each field of metadata (the pieces of information on a line) should be separated from other fields by the
% symbol "$".  The elements, or fields, required for each series are:
%
% 1 short name, for labeling series, 15 or fewer chars, exactly matching
%   the labels in row 1 of the data file (geosa1 checks for this match)
% 2 more desciptive, longer, name of series, 40 or fewer chars
% 3 y-axis label for variable  (type of data -- e.g., "Precipitation), 20 characters or fewer
% 4 units of variable, 13 or fewer characters (e.g., "inches")
%
% Below is an example of a .txt file (say, V1Meta.txt) that might accompany a time series matrix in
% a paired data file (say, V1Data.txt).  
%
% V1Data.txt
% Year                                                                      
% NaN                                                                          
% MEAF-PSME $ Mesa Alta Fir PSME, standard index     $ Index $ Dimensionless
% MEAP-PIST $ Mesa Alta Pine PIST, standard index    $ Index $ Dimensionless
% BCWF-PSME $ Bear Can W Fir PSME, standard index    $ Index $ Dimensionless
% BCWP-PIST $ Bear Can W Pine PIST, standard index   $ Index $ Dimensionless
% FEN-PIPO  $ Fenton Lake PIPO, standard index       $ Index $ Dimensionless
% EAU-PSME  $ Echo Amphitheater PSME, standard index $ Index $ Dimensionless
%
%
%--- REVISION HISTORY
%
%  Rev2012_10-18:  built the option inputing the time series matrix as
%  space-separated ascii txt file.  Previously, only xls file was accepted.
%  Because Matlab has had increasingly severe problems with compatibility
%  reading xls spreadsheets (I know this for unix systems), I decided the
%  most trouble-free approach for users in general (Linus, Mac, Windows)
%  would be to cut the tie to Excel and go to simple ascii text-file input.
%  
%

clear;
close all;
clc;


% Hard code
ngroup1 = 3; % number of lines applicable to all series
mobs=30; % minimum # obs overlap required between at least one V1 series and one V2 series

%--- Prompt for last name (to be coded into output filename)

prompt={'Enter your last name (e.g., ''Smith''):'};
name='Last name';
numlines=1;
defaultanswer={'Spring19'};

LastName=char(inputdlg(prompt,name,numlines,defaultanswer));
fileout = [LastName '.mat'];



%********  INTRODUCTORY MSG

message1 = {'Geosa1 organizes previously prepared time series in structure variables',...
    '',...
    'You should have previously organized your V1, V2 and V3 time series',...
    'in tab-delimited ascii txt files, and the the corresponding metadata',...
    'in ascii txt files, as described in comment section of geosa1.m.',...
    '',...
    'You must run this script from the same folder holding the V1, V2, and V3 ',...
    'data files and metadata files',...
    '',...
    ['Geosa1 will produce a file ' fileout ' that has your data and metadata '],...
    'in matlab structures V1, V2 and V3.  Geosa1 will also produce three figure windows: ',...
    '',...
    ' Fig 1: summary of V1 data -- nominally the output from a causal system',...
    ' Fig 2: summary of V2 data -- nominally the input to a causal system',...
    ' Fig 3: summary of V3 data -- ''trendy'' data used to illustrate detrending'};

msgbox1(message1,'message1')



kwh1=1; % while control for inputting another variable type
while kwh1==1;

    % SELECT INPUT DATA TO PREPARE

    kmen1 = menu('Select Type of Data or Quit',...
        'V1 data -- (nominally the output in causative model (e.g., index chronologies))',...
        'V2 data -- (nominally the input in causative model (e.g., annual precipitation))',...
        'V3 data -- (series to illustrate detrending (e.g., ring-width measurements)',...
        'Quit');
    if kmen1==1;
        dkind ='V1'; % name of structure variable to be produced
    elseif kmen1==2;
        dkind ='V2'; % name of structure variable to be produced
    elseif kmen1==3;
        dkind ='V3'; % name of structure variable to be produced
    elseif kmen1==4;
        kwh1=0;
    end;
    clear kmen1;

    if kwh1==0;
        return;
    end;

    
    
    % READ THE .TXT FILE WITH THE TEXT INFO ON THE INPUT TIME SERIES. READS
    % FROM CURRENT WORKING DIRECTORY (cwd)
    
    d=cd;  % get cwd
    kwh2=1;
    while kwh2;
        pause(0.2)
        [file1,path1]=uigetfile([dkind '*.txt'],'Pick the .txt file with metadata');
        % Make sure you have clicked on a file in the current working directory
        if ~strcmp(path1(1:(end-1)),d)
            uiwait(msgbox([path1 ' is not your current working directory'],'Message','modal'));
            return
        else
            kwh2=0;
            pf1=file1;
            clear d;
        end
    end
    D= textread(pf1,'%s','delimiter','\n','whitespace','');
    nlines=size(D,1);  % number of lines in files
    jgo = ngroup1+1; % first line with code for an individual  time series
    jsp = nlines; % last line ....
    nser = jsp-jgo+1; % number of series


    % Name of file with timeseries matrix
    fndata = deblank(D{1});
    fndata=fliplr(deblank(fliplr(fndata)));
    pf2=fndata;
       
    % Store source filename in structure
    eval([dkind '.txtfile = pf1;']);
    eval([dkind '.sourcefile =pf2;']);

    
    % Begin string information variable
    s=['Type of data (V1, V2 or V3) is ' dkind];
    s=char(s,'');
    s=char(s,[pf1 ' is the textfile with series identification']);

    
    % TYPE OF FILE WITH INPUT TIME SERIES MATRIX -- ASSUMED TO BE txt
    [dope,suffix]=strtok(fndata,'.');
    ftype = 'txt';
    s=char(s,'Input time series matrix is an ascii txt (should be tab-delimited)');
    clear dope;
    suffix=lower(suffix);
    switch suffix;
        case '.txt';
        otherwise;
            error([fndata ' must have suffix .txt']);
    end;


    s=char(s,[pf2 ' is the infile with your time series matrix']);
    s=char(s,[int2str(nser) ' is the number of time series in ' pf2]);
    s=char(s,'');
    
    % TIME STEP
    dinc= deblank(D{2});
    dinc=fliplr(deblank(fliplr(dinc)));
    s=char(s,['Time increment: ' dinc]);
    eval([dkind '.increment =dinc;']);
    
    % MISSING VALUE CODE
    msscode= deblank(D{3});
    msscode=fliplr(deblank(fliplr(msscode)));
    if ~isempty(msscode)
        s=char(s,['Missing-value code: ' msscode]);
    else
        s=char(s,['Missing-value code: ''blank''']);
    end
    msscode=str2double(msscode);
    if isnan(msscode);
        eval([dkind '.msscode =''blank'';']);
    else
         
        eval([dkind '.msscode =(msscode);']);
    end
    
    
    %-- STRIP OFF FIRST 3 LINES OF TXT FILE, LEAVING INDIVIDUAL SERIES INFO
    D(1:3)=[];
    
    
    %-- Check that exactly 3 "$"  on each line
    Dc = char(D); % cell to char
    L=Dc=='$';
    nL = sum(L');
    if ~all(nL==3);
        error(['All lines after line 3 of ' file1 ' should have exactly three occurrences of ''$''']);
    end
    clear Dc L nL

    
    
    %--- STORE THE SHORT NAME, LONG NAME, YLABEL AND UNITS LABEL FOR EACH SERIES
    
    % Initialize
    tvalid=repmat(NaN,nser,2); % first, last
    G=cell(nser,4);
    
    for n =1:nser; % loop over series
        d=D{n};
        i1 = find (d=='$');
        igo=[1 i1+1];
        isp=[i1-1 length(d)];
        for j = 1:length(igo); % loop over fields
            ia = igo(j);
            ib = isp(j);
            dthis = d(ia:ib);
            G{n,j}=strtrim(dthis);
            
        end
       
    end; %  for n =1:nser; % loop over series
    id=G(:,1);
    name=G(:,2);
    ylabel=G(:,3);
    units=G(:,4);
    clear G dthis ia ib j igo isp i1 d
    

    % STORE SOME INFO IN STRUCTURE V1 V2 OR V3
    
    dwhat='GEOS585A data'; % a dummy that will no longer be used to describe all series
    eval([dkind '.what =dwhat;']);
    eval([dkind '.id =id;']);
    eval([dkind '.name =name;']);
    eval([dkind '.label =ylabel;']); % y-axis labels for series
    eval([dkind '.units =units;']);
    
    clc;
    disp(s);
    kmen4=menu('Look over Info in the Command Window and Choose One',...
        'Displayed info is correct, continue with setup',...
        ['Abort --user go back and correct ' pf1]);
    if kmen4==1;
        % no action needed
    else
        close all;
        return;
    end;



    % Build series-menu cell variable
    seriesmenu=cell(nser,1);
    for n = 1:nser;
        idthis=id{n};
        cthis = [int2str(n) ' ' idthis];
        seriesmenu{n}=cthis;
    end;


    h = ['STRUCTURE FIELDS of ' dkind  ' data'];
    h=char(h,'');
    h=char(h,'txtfile: filename of the input .txt file with series information (e.g., series labels):');
    h=char(h,'sourcefile: filename of tab-delimited ascii txt file with input time series matrix. ');
    h=char(h,'what: a now obsolete data tag that applies to all series');
    h=char(h,'increment: time increment of the time series (e.g. year)');
    h=char(h,'msscode: code used for missing data values (e.g., NaN)');
    h=char(h,'tsm: the time series matrix, one time series per column ');
    h=char(h,'time: time vector for the time series matrix ');
    h=char(h,'Following Data Individualized for Each Time Series');
    h=char(h,'   period: first and last time observations (e.g., years) of the non-missing data in each series');
    h=char(h,'   id: short identification of series, 12 or fewer chars');
    h=char(h,'   seriesmenu: id prefaced by sequential number -- used in screen menus to select series');
    h=char(h,'   label: short name of type of time series data, used in labeling plots (e.g., Index)');
    h=char(h,'   units: units of the time series data (e.g., dimensionless)');
    h=char(h,'   category values (3 categories) for the series');
    h=char(h,'   name: description of series (more detailed than id)');
    h=char(h,'   tvalid: first, last time obs with valid data for each series ');


    % READ THE TIME SERIES MATRIX

    % Recall that fndata is the filename of the file with the tsm, and ftype is the type of file.
    % Matrix must be all-numeric.
    % The first column should be the time (e.g., year).
    % Each element of the matrix should have either data or a missing value code.
    % The number of time series should be nser.

    if ~exist(fndata,'file')==2;
        error([fndata ' is not an existing file']);
    end;

    switch ftype;
        case 'txt'; % ascii, tab-delimited; headings in row 1
            A=tdfread(fndata);  % A is structure with fields as the individual time series
            headings = fields(A);
            nfields = length(headings);
            
            
            %-- Check that headings match metadata series lables
            % recall had ids (col-cell of strings)
            B=[V1.increment; id]; % this information from the meta file must match the headings in the daa files
            [mB,nB]=size(B);
            if mB ~=nfields;
                error(['Meta file says expect ' num2str(mB-1) ' series, but data file has only ' num2str(nfields-1)]);
            else
            end
            for n = 1:mB;
                headthis = headings{n};
                Bthis = B{n};
                if n==1;
                    if ~strcmp(Bthis,headthis);
                        error(['Meta files says time is ' Bthis ' , but time heading in Data file is ' headthis]);
                    else
                    end
                else
                    if ~strcmp(Bthis,headthis);
                        error([num2str(n) 'th series in Meta file is ' Bthis ',  but ' num2str(n) 'th Data heading is ' headthis]);
                    else
                    end
                end
            end
            
            
            %--------
            
            fld1 = headings{1};
            eval(['x = A.' fld1]);
            mX = length(x);
            nX = nfields;
            X = nan(mX,nX);
            for j = 1:nfields
                fldthis = headings{j};
                eval(['x = A.' fldthis]);
                X(:,j)=x;
            end
            
            tsm=X;
            %tsm=load(fndata);

        case 'Mat';  % .mat file
            % For .mat file, you will need to specify the name of the variable with the tsm
            g=load(fndata);
            gfields=fields(g);
            glen=length(gfields);
            if glen==1;
                vname=gfields{1};
            else
                kmen3=menu(['Choose the variable in ' fndata ' holding the desired time series matrix'],gfields);
                vname = gfields(kmen3);
            end;
            vname=char(vname);
            eval(['tsm = g.' vname ';'])
            clear vname g gfields glen kmen3;

        case 'Xls'; % xls (excel) spreadsheet
            [tsm, B] = xlsread(fndata) ; % tsm is the time series matrix;  B is possible header
            if ~isempty(B);
                mB=size(B,1);
                % Code added 2-4-03  to handle bug when xlsread takes in xls file with headers and NaNs
                if mB>1;
                    B=B(1,:); % get rid of all rows of alphanumeric matrix except for row 1
                end;
                B(1)=[]; % get rid of year header
                
                
                
                %--- CHECK CONSISTENCY OF SERIES NAMES IN TXT VS XLS FILE
                
                if size(B,2)~=size(D,1);
                    error('Number of series headers in xls file row 1 different than number of series specified in txt file');
                end
                d_ids = cell(size(D,1),1); % to store the short names from txt file
                for k = 1:size(D,1); % loop over series
                    dbingo = D{k};
                    dbingo=strtok(dbingo,'$');
                    dbingo=strtrim(dbingo);
                    d_ids{k}=dbingo;
                end;% for k = 1:size(D,1); % loop over series
                clear dbingo k;
                strtmp =char({'Check that series order in .xls file matches',...
                    'order in .txt file'});
                txtcheck =char('.txt file','------',char(d_ids));
                xlscheck = char('.xls file','------',char(B'));
                mtemp = size(txtcheck,1);
                strQC = char(strtmp,[xlscheck repmat(' == ',mtemp,1) txtcheck]);
               msgbox1(strQC,'Message');
              
                
                kquest=questdlg('Order OK?');
                if strcmp(kquest,'Yes');
                else
                     uiwait(msgbox('Revise either txt or xls and try again','Message','modal'));
                return;
                end
                clear kquest strQC mtemp xlscheck txtcheck strtmp d_ids;
                
            end;
            clear  kmen2;
        otherwise;
            error('File type must be dat, mat or xls');
    end;

    % Check that correct number of columns in tsm
    time = tsm(:,1);
    tsm(:,1)=[];  % strip off year column
    ntsm=size(tsm,2);
    if ntsm~=nser;
        error('Number of columns of time series matrix not equal to nser');
    end;

    % Replace any missing value codes with NaN
    % If missing values already coded as NaN, no action taken. Otherwise, check that value
    % not within eps of the missing  value code.
    if isnan(msscode); % no action needed replacing current missing value codes with NaN
    else
        L=tsm==msscode;
        Lsum = sum(sum(L));
        if Lsum>=0;
            tsm(L)=NaN;
        end;
    end;
    clear L Lsum;

    % Check that tsm all-numeric
    if ~isnumeric(tsm);
        error('Time series matrix is not numeric');
    end;

    % Check that time variable continuous and incrementing by 1
    dtime=diff(time);
    if ~all(dtime==1);
        error('Time variable does not uniformly increment by 1');
    end;

    % Check that no internal NaN
    for n = 1:nser;
        x = tsm(:,n);
        L=intnan(x);
        if L==1;
            error(['Internal NaN in series ' int2str(n) ' of ' fndata]);
        end;
    end;

    % Compute start and end times of valid data
    J=~isnan(tsm);
    for n = 1:nser;
        x = J(:,n);
        jx = find(x);
        tvalid (n,:)=[time(min(jx)) time(max(jx))];
    end;

    % STORE DATA IN STRUCTURE

    eval([dkind '.tsm =tsm;']);
    eval([dkind '.time =time;']);
    eval([dkind '.tvalid =tvalid;']);

    % STORE MORE DATA IN STRUCTURE

    eval([dkind '.id =id;']);
    eval([dkind '.seriesmenu =seriesmenu;']);
    eval([dkind '.name =name;']);
    eval([dkind '.description =h;']);


    % NEXT -- SAVE THE STRUCTURE VARIABLE
    vlist = 'Definitions; note that all listed variables may not be in the file';
    vlist = char(vlist,' ');
    vlist = char(vlist,'V1 -- structure variable with nominal causative output time series');
    vlist = char(vlist,'V2 -- structure variable with nominal causative input time series');
    vlist = char(vlist,'V3 -- structure variable with time series to illustrate detrending');
    
    %-- INPUT DIALOG FOR OUTPUT FILE-  UIPUTFILE BROKEN in MATLAB Version 7.5.0.342 (R2007b)
    prompt = {'Enter output file name:'};
    dlg_title = 'Output .mat storage file -- change this is you want';
    num_lines = 1;
    
    def = {fileout};
    %def = {'spring11.mat'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    file3=answer{1};
        
    
   % Line below stopped makes geosa1 hang up, unless step through the
   % command in debug mode
   % [file3,path3]=uiputfile('*.mat','Specify output .mat file to hold your structure data-- be sure to include the .mat suffix');

    % Warn if the selected output .mat file is the same as the input .mat file with your time series
    if strcmp(file3,fndata);
        w={'NO WAY!.  You picked the same filename that one of your input V1, V2 or V3 data are stored in',...
            'This would cause trouble. Suggest aborting the save at the next dialog'};
        hw = warndlg(w);
        pause(5)
        close(hw);

        kq = questdlg(['Abort the overwriting of ' fndata]);
        switch kq;
            case 'Yes';
                return;
            otherwise;
        end;
    end;
    if exist('hw','var')==1;
        close(hw);
    end;

    pf3=file3;

    % Try to load the output .mat file to see whether it exists, and how many of V1, V2 and V3 are
    % already stored there
    qexist = exist(pf3,'file')==2;
    if ~qexist;
        mess1={[pf3 ' does not yet exist'],...
            ['You will create ' pf3],...
            [' and store ' dkind  ' in it']};
    else
        scheck=load(pf3);
        if any(strcmp(dkind,fields(scheck))); % a prev version of dkind exists in pf3
            mess1 = {['A previous version of ' dkind  ],...
                ['already exists in ' pf3],...
                ['You will replace that ' dkind]};
        else
            mess1={[pf3 ' does not yet contain '],...
                ['the structure ' dkind '.'],...
                ['You will add ' dkind ' to'],...
                pf3};
        end;
    end;
    clear  scheck;
    
    msgbox1(mess1,'Message');
    

    kmen5=menu('Choose',...
        'Continue saving',...
        'Abort');
    if kmen5==1;
        if qexist;
            eval(['save ' pf3 ' ' dkind ' vlist -append;']);
        else
            eval(['save ' pf3 ' ' dkind ' vlist;']);
        end;
    else
        disp('Nothing Saved');
        fclose all;
        clear;
    end;
    clear qexist;

    % LOAD THE STORAGE FOE
    scheck = load(pf3);

    % OVERLAP CHECK OF V1 WITH V2
    % Check that at least one V2 series overlaps at least one V1 series by at least 30 observations
    if any(strcmp('V1',fields(scheck)))  && any(strcmp('V2',fields(scheck))); % both V1 and V2 exist
        % Trim V1 matrix to row-size of V2 matrix
        tgov2 = scheck.V2.time(1);
        tspv2 = scheck.V2.time(length(scheck.V2.time));
        tgov1 = scheck.V1.time(1);
        tspv1 = scheck.V1.time(length(scheck.V1.time));
        tgo = max([tgov2 tgov1]);
        tsp = min([tspv2 tspv1]);
        X1=scheck.V1.tsm;
        X2=scheck.V2.tsm;
        L=scheck.V1.time<tgo | scheck.V1.time>tsp;
        if any(L);
            X1(L,:)=[];
        end;
        L=scheck.V2.time<tgo | scheck.V2.time>tsp;
        if any(L);
            X2(L,:)=[];
        end;
        % X1 and X2 should now cover common years

        % Clear variables
        clear  L tgov1 tspv1 tgov2 tspv2;

        % Number of time series in truncated versions of V1 and V2
        n2=size(X2,2);
        n1=size(X1,2);

        % Loop over the V2 series one by one, each time checking for minimum number of obs (mobs) overlap with
        % at least one V1 series
        mok=0;
        for n = 1: n2;
            u = X2(:,n);
            U = repmat(u,1,n1); % dupe to same number of cols as X1
            L = ~isnan(U) & ~isnan(X1);
            nsum1=sum(L); % rv of # years overlap with each series of X1
            if any(nsum1>=mobs);
                mok=1;
                break;
            else
            end;
        end;
        if mok==0; % insufficient overlap
            error(['At least one V1 series must have a minimum of ' num2str(mobs) ' observations overlap with at least one V1 series']);
        end;
    end;


    % FIGURE WINDOWS

    % Check that at least one V2 series overlaps at least one V1 series by at least 30 observations
    if any(strcmp('V1',fields(scheck)))  && any(strcmp('V2',fields(scheck))) && any(strcmp('V3',fields(scheck))); % V1,3,3 exist

        for k=1:3;
            eval(['figure(' int2str(k) ');']);

            % Data names
            vtxt = ['V' int2str(k)];
            eval([vtxt ' = scheck.' vtxt ';']);
            eval(['VV = ' vtxt ';']);
            set(gcf,'Name',[vtxt ' DATA']);
            
            stxt = [vtxt ' ; time increment = ' VV.increment];
 
            eval(['hthis' int2str(k) ' =axes;']);
            text(.01,.95,stxt);

            nserthis = length(VV.id);
            vblk2=repmat(blanks(2),nserthis,1);
            veq= repmat('=',nserthis,1);
            str1=[char(VV.seriesmenu) veq char(VV.name) vblk2 char(VV.label) vblk2 char(VV.units) vblk2 num2str(VV.tvalid)];
            text(.1,.90,str1,'FontName','Courier','VerticalAlignment','Top')
            set(gca,'Visible','off');
            set(gcf,'Color',[1 1 1]);
        end;


    end;
    clear scheck;

end; % while kwh1==1;