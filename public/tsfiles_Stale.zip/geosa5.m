% geosa5.m  ARMA modeling;  ARMA filtering and prewhitening of chronologies
%
% Last revised 2018-12-23
%
%*** UW FUNCTIONS CALLED
%
% acf
% eq2str01
% msgbox1
% pacf
% portmant
% sfields
% specbt1
%*** TOOLBOXES NEEDED
%
% statistics
% system identification
% 
% Objectives:
%   Introduce the autoregressive-moving-average (ARMA) model
%   Introduce Akaike's Final Prediction Error (FPE), a model-selection criterion 
%		based on loss function (variance of errors) and model complexity 
%	   (order of AR and MA terms)
%   Introduce portmanteau test for randomness of ARMA residuals
%   Define prewhitening
%   Show effects of prewhitening on time series plot and spectrum
%
% User prompted to select a tree-ring chronology and time period for analysis.
% Model to be fit is AR (up to order 5), MA(up to order 3), or ARMA(1,1)
% User has choice of specifying model structure (AR,MA,ARMA) for the chronology,
%   or of letting FPE select model structure and order (fully automated model).
%   No matter how model structure is chosen the model order is selected 
%   automatically by the FPE criterion.
%
% Revised 2016-12-04: Structure S.
% Revised 2018-12-23: Cosmetic. To deal with Matlab version changes in
%     legend command


% Close any open windows and clear variables from workspace
close all; 
clear all;

% Hard code
datfile='Spring19'; % default .mat file with input data
datdir=cd; % directory with input data; assumed as current directory
path1=datdir; % store path/directory
nwant = 1; % number of series to analyze
nsers = 1; % ditto


message1 = {'ARMA Modeling',...
        '',...
        'This script illustrates autoregressive-moving-average modeling of a time',...
        'series.  You are initially prompted to select a single time series.  ',...
        'This series should be from data sets V1 or V2 as ARMA modeling is invalid',...
        'for nonstationary series.',...
        '',...
        'Figure windows produced:',...
        '   Fig 1:  four-part figure, with time series plot at top', ...
        '       acf and pacf of series at lower left, ',...
        '       and spectrum of series at lower right',...
        '   Fig 2: acf of residuals with 99% CI',...
        '       Equation for the AR or ARMA model',...
        '       Portmanteau statistic and its p-value',...        '       
        '   Fig 3: Zoomed time series plots of original time',...
        '       series and ARMA-whitened time series',...
        '   Fig 4: Spectra of original and whitened time series'};
msgbox1(message1,'message1');
    

histr = {'Maximum order of AR model considered is 5',...
        'ARMA models are considered up to maximum p+q of 3',...
        'where p is the AR order and q is the MA order.'};
msgbox1(histr,'Message');


windlist = char('Figure Windows:',...
    '1-time series plots of chronology (top)',...
    '  acf and pacf lower left; spectrum lower right',...
    '2-ACF of residuals of model for chron 1, with annotated equation, portmanteau',...
    '   statistic, and pct variance due to persistence',...
    '3-zoomed time series plots for comparison of original and whitened chronologies',...
    '4-Spectra of original and whitened chron ');

varlist = char('Key Stored Variables:',...
    'id1, -- name of the selected chron',...
    'th1 - model information in theta format (type help theta)',...
    'yrgo, yrsp -- start and end times of analysis period',...
    'yrgo2, yrsp2 -- start and end time of zoom period for detailed plot',...
    'x1,- times series of chronology for analysis period',...
    'yr -- time vector for x1',...
    'y1 -- like x1, but with analysis-period mean subtracted',...
    'x1short -- segment of x1, for the zoom period',...
    'yr2 -- time vector for x1short');


% Prompt for data filemame
prompt={'Enter name of input input data filename (without .mat)'};
def={datfile};
dlgTitle='Input .mat file with data structures';
lineNo=1;
answer=inputdlg(prompt,dlgTitle,lineNo,def);
file1=char(answer); % convert cell to string

%--- Load the input file
pf1=fullfile(path1,file1);  % combine the path and filename into one string variable
eval(['load ' pf1])


%--- The data should be in a structure variables V1, V2, V2 
%  Check that required structures exist in the workspace
if ~all([exist('V1')==1  exist('V1')==1  exist('V1')==1]);
    error([pf1 ' does not contain V1, V2 and V3']);
end

% Check that V1, V2 and V3 are structures with required fields
for n =1:3; % loop over structures
    eval(['V = V' int2str(n) ';']);
    if ~isstruct(V); 
        error(['V' int2str(n) ' must be structure']); 
    else % check for required fields
        sfields(V);
    end;
end;


% Menu to choose type of variable for analysis 

kv = menu('Time series will be selected from which data (choose one)',...
    'V1 -- output data',...
    'V2 -- input data',...
    'V3 -- trend data');
if kv==1;
    V=V1;
elseif kv==2;
    V=V2;
else
    V=V3;
end;

% Compute number of series in structure
nsites = size(V.name,1);

% Time increment
tinc = V.increment;



%*********  MENU TO CHOOSE SERIES

Lpick = logical(zeros(nsites,1)); % pointer to picked series
pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not

tmen = V.seriesmenu;  % menu of series, with column number
tmen1=tmen;
tmen1{nsites+1}='Accept selection';
tmen1 = char(tmen1);
tmen2=[tmen1 pflag];
[mtmen2,ntmen2]=size(tmen2);

sitenos=repmat(NaN,nwant,1); % to store index to selected sites

kwh1=1;
strchoose='Select a series';
kthis=[];
while kwh1==1;
    kmen1=menu(strchoose,cellstr(tmen2));
    if ~any(Lpick) & kmen1== nsites+1;
        msgbox1('None selected yet -- do again','Message')
    elseif kmen1==nsites+1;
        sitenos=kthis;
        kwh1=0;
    else
        Lpick=logical(zeros(nsites,1)); 
        pflag= repmat(blanks(3),nsites+1,1); % flag for picked or not
        pflag(kmen1,3)='*';
        Lpick(kmen1)=1;
        kthis=kmen1;
        tmen2=[tmen1 pflag];
        
    end;
    
end;

j1 = sitenos(1);



% Find start and end time of valid data for series

YRS = repmat(NaN,nwant,2);
L = ~isnan(V.tsm(:,sitenos));  % logical pointer to valid entries 
disp(blanks(1));
disp(['Start and end ' lower(tinc) ' of valid data for series']);
fmt1 = '%50s  %4.0f-%4.0f\n';
jsite = sitenos;
yrtemp = V.time(L);
YRS(1,1)=min(yrtemp);
YRS(1,2)=max(yrtemp);





%**********  INPUT DIALOG TO SELECT PERIOD FOR ANALYSIS

titlepmt = ['Select the start and end ' lower(tinc) ' for analysis'];
prompt = {['Enter start ' lower(tinc)],...
        ['Enter end ' lower(tinc)]};
lineNo=1;
deflt = {int2str(max(YRS(:,1))),int2str(min(YRS(:,2)))};
answer=inputdlg(prompt,titlepmt,lineNo,deflt); % answer as char in cells
% convert answer to double
yrgo = str2num(answer{1});
yrsp = str2num(answer{2});
% Store string with analysis period
txtyr = sprintf('%4.0f-%4.0f',yrgo,yrsp);


% Check that both series cover selected period
if any(YRS(:,1)>yrgo) | any(YRS(:,2)<yrsp);
    error(['Selected analysis period inconsistent with start, end ' lower(tinc) ' of series']);
end


% Display name of selected series and info
clc;  % clear the command window
strmess1={['Type of data: ' V.what ],...
        [' ID: ' V.id{sitenos}],...
        [' Name: ' V.name{sitenos}],...
        [' Time coverage: ' int2str([yrgo yrsp])]};
msgbox1(strmess1,'Selection:');


n1size=yrsp-yrgo+1; % length of selected period
% Store string with sample size, for use in later printing in figure titles.
% Note the use of \it to italicize N, of \rm to return to normal (not italic)
% font before printing the number.  This demonstrates use of TeX langauage,
% which lets you add greek characters, mathematical symbols, etc., to 
% text.  See info for the 'text' command under the html help for more on 
% TeX.  
txtna = sprintf('%5.0f',n1size);
txtn  = ['\itN = \rm' txtna]; 


% SET LABELS, TITLES FOR PLOTS

ylab1=[V.label{sitenos} ' (' V.units{sitenos} ')'];
xlab1=V.increment;

% Frequency label
if strcmp(lower(V.increment),'year');
    labfreq = 'yr^{-1}';
    labinc1='yr';
else
    labfreq=  [V.increment '^{-1}'];
    labinc1=V.increment;
end;

tit1 = ['Time Series Plot of ' V.what ', ' txtyr ', '  txtn];  

id=V.id{jsite};




%******************** GET SUBSET OF DATA FOR SELECTED PERIOD AND SERIES
L1 = V.time>=yrgo & V.time<=yrsp; % logical pointer to rows of vector tree.yr
yr = V.time(L1);  % time vector for selected period
X = V.tsm(L1,jsite);  % subset of times, columns with the desired data


% Store time series for desired analysis period in x1 
x1=X(:,1);
nyr=length(x1); 




%**********  INPUT DIALOG TO SELECT PERIOD FOR ZOOMED FOCUS PERIOD --
%MAXIMUM LENGTH OF 30 OBSERVATIONS; BY DEFALT THE LAST 30

kwh2 = 1;
while kwh2==1;

    titlepmt = ['Select Zoomed Focus Period of maximum length 30'];
    prompt = {['Enter start ' lower(tinc) ' (>=' int2str(yrgo) ')'],...
        ['Enter end ' lower(tinc) ' (<=' int2str(yrsp) ')']};
    lineNo=1;
    % By default, want to zero in on last 30 obs
    yrsp2 = yrsp;
    yrgo2 = max([yrsp2-29 yrgo]);

    deflt = {int2str(yrgo2),int2str(yrsp2)};
    answer=inputdlg(prompt,titlepmt,lineNo,deflt); % answer as char in cells
    % convert answer to double
    yrgo2 = str2num(answer{1});
    yrsp2 = str2num(answer{2});
    yr2 = (yrgo2:yrsp2)';
    nyr2 = length(yr2);
    
    if nyr2>30;
        kwh2=1;
        uiwait(msgbox('Must re-enter: short period cannot exceed 30 observations','Message','modal'));
    else
        kwh2=0;
    end
    
end;




% Store strings with zoom  period 
txtyr2 = sprintf('%4.0f-%4.0f',yrgo2,yrsp2);



%*************  TIME SERIES PLOTS IN ORIGINAL UNITS

% Mean and standard deviation
mn1 = mean(x1);
sd1=std(x1);

figure(1)
set(gcf,'Name','Time Series Plot, ACF, PACF, and Spectrum');

ha1=axes('Position',[.1 .5 .8 .42]); % for time series plots
% store y-axis limits as min and max of data
ylim1 = [min(x1) max(x1)];



xlims=[yr(1)-(0.01*(yr(end)-yr(1))) yr(end)+(0.01*(yr(end)-yr(1)))];
h1p=plot(yr,x1,[yrgo yrsp],[mn1 mn1]);
set(gca,'XLim',xlims);
clear xlims
cord=get(gca,'ColorOrder');
%xlabel('Year');
ylabel(ylab1);
set(gca,'YLim',ylim1);

title(tit1);
legend(V.id{jsite},'Mean');
grid 
%zoom xon; % matlab bug in some OS/version combinations

% Compute ACFs and PACFs
% Chron 1
[rx1,SE2x1,rx195]=acf(x1,20); % acf and 95% CI
[phi1,SE2p1] = pacf(x1,20);  % pacf and 95% CI

% want same y limits for all acf and pcf to facilitate comparison
mintmp=min([rx1 -SE2x1 phi1 -SE2p1  ])-0.05;
maxtmp=max([rx1 SE2x1 phi1 SE2p1 ])+0.05;
ylim14=[mintmp 1.0]; % ylimits for 

t=(1:20)';  % acf and pacf will be at these lags

%------------- ACF AND PACF PLOTS

% ACF plot for chron 1
ha2=axes('Position',[.1 .28 .35 .13]);
hold on;
stem(t,rx1);
line([0 20],[0 0]);
hold on;
plot(t,SE2x1,'Color',cord(2,:)); 
plot(t,-SE2x1,'Color',cord(2,:));
set(gca,'YLim',ylim14);
set(gca,'XTickLabel',[]);
ylabel('ACF');
hold off


% Plot PACF for chron 1
ha4=axes('Position',[0.1 0.1 0.35 0.13]);
hold on;
stem(t,phi1);
line([0 20],[0 0]);
hold on;
plot(t,SE2p1,'Color',cord(2,:));
plot(t,-SE2p1,'Color',cord(2,:));
set(gca,'YLim',ylim14);
xlabel(['Lag (' labinc1 ')']);
ylabel('PACF');
hold off;


%--------------  SPECTRUM PLOT 

ha3=axes('Position',[.55 .10  .35 .31]);
hold on;
% Set up input args to specbt1.m
prevwind=0; % preserve window 0 in call to specbt.m
kopt(1)=2; % non-interactive mode
M= round(nyr/10); % lag window, use 1/20 sample size

f = 0:1/nyr:0.5; % frequencies for spectral estiamtes

% Call user-written function specbt1.m to get spectral estimates chronology
tlab=[tinc 's']; % period labe
tlab='joke';
G1=specbt1(detrend(x1,0),M,f,prevwind,'dummy',kopt,tlab); % spectrum of tree-ring index


% Plot chronology spectrum with its 95% confidence band, and 
% spectrum of the whitened chron
ha3p1=plot(G1(:,1),G1(:,3),...
    G1(:,1),G1(:,4),'r--',G1(:,1),G1(:,5),'r--');

set(ha3p1(1),'LineWidth',1.5); % thicken line for theoretical spectrum
set(ha3p1(2),'Color',cord(2,:));
set(ha3p1(3),'Color',cord(2,:));

% string for M/N
%txt4a = ['\itM/N \rm= ' int2str(M) '/' int2str(nyr)];

%tit4b = [' and of ' mod1 ' residuals'];
%title({['Spectra of ' id1  ', '   txt4a],tit4b});
xlabel(['Frequency (' labfreq ')']);
ylabel('Relative Variance');
set(gca,'XLim',[0 .5]);

%Compute and plot bandwidth
bw = 4/(3*M);  % see Ljung (1987, p. 155), Chatfield (1975, p. 154)
% Note that the "Hamming" window as defined in system ident toolbox and Ljung
% is identical to Chatfield's Tukey Window
% Put bandwidth bar 0.3 from top of figure, centered
ylims = get(gca,'Ylim');
yrng = abs(ylims(2)-ylims(1));
ypoint = ylims(2)-0.3*yrng;
line([0.25-bw/2 0.25+bw/2], [ypoint ypoint]);
line([0.25-bw/2  0.25-bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
line([0.25+bw/2  0.25+bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
htt = text(0.25,ypoint+yrng/100,'Bandwidth');
set(htt,'HorizontalAlignment','Center','VerticalAlignment','bottom');

ypoint2=ylims(2)-0.05*yrng;
text(0.02,ypoint2,'Spectrum (M=N/10) and 95%CI');





%************  ARMA MODELING *******************************
%

% Candidate models
NNar= [1:5]'; % AR  orders
NNarma = [1 1; 1 2; 2 1]; % arma orders

% number of candidate models of each structure
nar = length(NNar);
narma = size(NNarma,1);

% Pre allocate for AIC (or FPE) 
Far = repmat(NaN,nar,1);
Farma = repmat(NaN,narma,1);


% Subtract modeling-period mean from series -- necessary first step before modeling
% Mean and standard deviation of chronology
x1mn = mean(x1);
x1sd = std(x1);
y1 = x1 - x1mn;

% Loop over series to get "best" or selected model 
for n = 1: nsers;
    
    % store the time series (mean subtracted) in y
    eval(['y = y' int2str(n) ';']);
    id = V.id{jsite};
    
    kw2 = 1 ; % control for while loop on model structure
    while kw2 ==1;
        
        km1 = menu(['Choose Model for ' id],...
            'FPE picks structure and order',...
            'AR','ARMA','Satisfied');
        switch km1;
            case 1; % FPE picks structure and order
                for n1 = 1:nar;
                    thar = ar(y,NNar(n1));
                    %Far(n1) = thar(2,1); % store FPE
                    Far(n1) = fpe(thar); % store FPE
                end
                for n2 = 1:narma;
                    tharma = armax(y,NNarma(n2,:));
                    %Farma(n2) = tharma(2,1); % store FPE
                    Farma(n2) = fpe(tharma); % store FPE
                end
                
                % Find best ar model and its FPE
                [Fbest,i] = sort(Far);
                nnar = NNar(i(1));
                Far1 = Fbest(1);
                
                % Find best arma model
                [Fbest,i]= sort(Farma);
                nnarma = NNarma(i(1),:);
                Farma1 = Fbest(1);   
                
                % Find best model from best of ar, arma
                [F1,ii]=sort([Far1 Farma1]);
                if ii(1)==1; % ar
                    modtype='AR';
                    nn  = nnar; 
                    strmoda = sprintf('(%1.0d)',nn);
                    strmod = [modtype strmoda]; % string for model, like AR(1)
                else
                    modtype='ARMA';
                    nn = nnarma;
                    strmoda = sprintf('(%1.0d,%1.0d)',nn);
                    strmod = [modtype strmoda]; % string for model, like ARMA(1,1)
                    
                    
                end
                
            case 2; % AR model specified
                modtype='AR';
                km2 = menu('Choose AR order','1','2','3','4','5');
                nn=km2;
                strmoda = sprintf('(%1.0d)',nn);
                strmod = [modtype strmoda]; % string for model, like AR(1)         
                
            case 3; % ARMA model specified
                modtype='ARMA';
                km2 = menu('Choose ARMA order','(1,1)','(1,2)','(2,1)');
                nn=NNarma(km2,:);
                strmoda = sprintf('(%1.0d,%1.0d)',nn);
                strmod = [modtype strmoda]; % string for model, like AR(1)
                
                
            case 4; % satisfied
                kw2=0;
                
        end; % of switch
        
        % Refit model and get model diagnostics
        dat1 =iddata(y,[],1);
        if strcmp(modtype,'AR');
            th=ar(dat1,nn);
        elseif strcmp(modtype,'ARMA');
            th=armax(dat1,nn);
        end
        yhat=predict(th,dat1,1,'zero'); % one-step ahead prediction of y
        e = y-yhat.OutputData; % residuals of AR or ARMA model
        [r1,SE2,r95]=acf(e,25);
        figure(1+n);
        set(gcf,'Name','ACF of ARMA Residuals');
        hacf =stem((1:25),r1);
        nline1= line([0 25],[0 0]);
        hline2a = line([0 25],[2.58/sqrt(length(y))   2.58/sqrt(length(y))]);
        hline2b = line([0 25],[-2.58/sqrt(length(y))   -2.58/sqrt(length(y))]);
        set(gca,'YLim',[-1 1]);
        set(hline2a,'LineStyle',':','Color',[1 0 0]);
        set(hline2b,'LineStyle',':','Color',[1 0 0]);
        title(['ACF of Resids with 99% CI: ' strmod ' Model fit to ' id ]);
        
        eqstr = eq2str01(th);
        text(1.2,.8,eqstr);
        
        eval(['th' int2str(n) '=  th ;']);
        eval(['mod' int2str(n) '= strmod ;']);
        % pct variance due autocorrelation
        vare = th.NoiseVariance; % estimated noise variance
        vary = var(y);  % variance of chron
        pct= 1 - vare/vary;
        strpct = sprintf('%5.1f ',pct*100);
        strpct = ['Pct Variance Due to Persistence = ' strpct ' %'];
        text(1.2,.70,strpct);
        
        % Portmanteau statistic
        [ree,SE2,r95]=acf(e,20); % acf of model residuals, in ree
        if strcmp(modtype,'AR');
            p = nn;
            q=0;
        else
            p = nn(1); q=nn(2);
        end
        [P,pval]=portmant(ree,nyr,p,q,20);
        strport = sprintf('Portmanteau stat = %8.4f, P-value=%7.5f',P,pval);
        text(2,.6,strport);
        clc
        present(th);
        %figure(n+3);
        set(gcf,'Name','ACF of ARMA Residuals');
        
    end; % of kw2 
    figure(1)
end; %of for over series



%********* RE-FIT SELECTED  MODELS AND  COMPUTE MODEL RESIDUALS
figure(10);
dat2 =iddata(y1,[],1);
yhat=predict(th1,dat2,1,'zero'); % one-step ahead prediction of y
e1 = y1-yhat.OutputData; % residuals of AR or ARMA model
close(10);

% Pull the zoomed in window segments
L4 = yr>=yrgo2 & yr<=yrsp2;
yrshort = yr(L4);
x1short = x1(L4);
e1short = e1(L4);


%********** TIME SERIES PLOTS COMPARING ORIGINAL AND RESIDUAL CHRONS

figure(3);
set(gcf,'Name','Zoomed TS Plots');
h2p=plot(yrshort,x1short,...
    yrshort,e1short+x1mn,[min(yrshort) max(yrshort)],[x1mn x1mn]);
set(h2p(1),'LineWidth',2,'Marker','o')
set(h2p(2),'LineWidth',0.5,'Marker','^')
set(gca,'Position',[0.1300    0.1100    0.7750    0.75])
title([id ': Original and ' mod1 ' Whitened Time Series']); 
title({'Zoomed Time Series Plots of Original and Whitened Series',...
        [id ' Whitened with ' mod1 ' Model']}); 

h2leg=legend('Original','Whitened',['Mean (' txtyr ')']);
set(h2leg,'FontSize');
grid


%************ SPECTRA OF CHRON AND ITS ARMA RESIDUALS

%---------------- Spectrum of chronology and theoretical spectrum of the AR process for the
% fitted model
kwhile1=1;
kfirst = 1;
while kwhile1==1;
    
    
    % Set up input args to specbt1.m
    prevwind=3; % preserve windows thru this one
    kopt(1)=2; % non-interactive mode
    if kfirst==1;
        M= round(nyr/8); % lag window, default first time around
    else
    end
    
    f = 0:1/nyr:0.5; % frequencies for spectral estiamtes
    
    % Call user-written function specbt1.m to get spectral estimates chronology
    G1=specbt1(detrend(y1,0),M,f,prevwind,'dummy',kopt,tlab); % spectrum of tree-ring index
    
    % Call user-written function specbt1.m to get spectral estimates chronology
    Ge1=specbt1(detrend(e1,0),M,f,prevwind,'dummy',kopt,tlab); % spectrum of residual series
    
    
    % Plot chronology spectrum with its 95% confidence band, and 
    % spectrum of the whitened chron
    figure(4);
    set(gcf,'Name','Spectra of Series and its ARMA Residuals');
    
    h4p2=plot(G1(:,1),G1(:,3),...
        Ge1(:,1),Ge1(:,3),G1(:,1),G1(:,4),'r--',G1(:,1),G1(:,5),'r--');
    
    set(h4p2(1),'LineWidth',1.5); % thicken line for theoretical spectrum
    set(h4p2(3),'Color',cord(1,:));
    set(h4p2(4),'Color',cord(1,:));
    
    hleg=legend(id, ['Whitened ' id]);
    
    % Set axes postion to allow for 2 lines in title
    set(gca,'Position',[0.1300    0.1100    0.7750    0.80])
    
    % string for M/N
    txt4a = ['\itM/N \rm= ' int2str(M) '/' int2str(nyr)];
    
    tit4b = [' and of ' mod1 ' residuals'];
    title({['Spectra of ' id  ', '   txt4a],tit4b});
    xlabel(['Frequency (yr^{-1})']);
    ylabel('Relative Variance');
    
    %Compute and plot bandwidth
    bw = 4/(3*M);  % see Ljung (1987, p. 155), Chatfield (1975, p. 154)
    % Note that the "Hamming" window as defined in system ident toolbox and Ljung
    % is identical to Chatfield's Tukey Window
    % Put bandwidth bar 0.3 from top of figure, centered
    ylims = get(gca,'Ylim');
    yrng = abs(ylims(2)-ylims(1));
    ypoint = ylims(2)-0.3*yrng;
    line([0.25-bw/2 0.25+bw/2], [ypoint ypoint]);
    line([0.25-bw/2  0.25-bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
    line([0.25+bw/2  0.25+bw/2],[ypoint+yrng/100 ypoint-yrng/100]);
    htt = text(0.25,ypoint+yrng/100,'Bandwidth');
    set(htt,'HorizontalAlignment','Center','VerticalAlignment','bottom');
    
    % Modify legend
    hleg.String{3}='95% CI';
    hleg.String(4:end)=[];
    
    kwhile2=1;
    while kwhile2==1;
        km = menu('Choose one:','Change Lag Window','Accept Spectrum');
        if km==1; % change lag window
            Mprev=M;
            prompt={'Enter value for M:'};
            deflt={int2str(M)};
            tit1='Length of Lag Window for Smoothing Spectrum';
            lineNo=1;
            answer=inputdlg(prompt,tit1,lineNo,deflt);
            M=str2num(answer{1});
            kwhile1=1;
            kfirst=0;
            if M>=nyr;
                strmess1 = ['M must be less than ' int2str(nyr)];
                msgbox1(strmess1,'Rejected!');
                M=Mprev;
                kwhile2=1;
                
            elseif (M/nyr)<(1/20) | (M/nyr)>1/3;
                strmess1 = ['Note that M/N=' int2str(M) '/' int2str(nyr) ' is outside the range 1/20 to 1/3'];
                msgbox1(strmess1,'Warning');
                kwhile2=0
            else
                kwhile2=0;
            end;
            
        elseif km==2;
            kwhile1=0;
            kwhile2=0;
        end
    end; %while kwhile2==1;
end
Results.what=char({'orig=time series of original data',...
        'mean = mean of original data',...'
        'resids=time series of model resids',...
        't = time vector for orig and resids',...
        'model = estimated model (use present(Results.model) to view details);',...
        'pctvar = percentage of variance of time series due to modeled persistence',...
        'portmantea:{1}=Portmanteau Q statistic, {1} its p-value'}); 
        
Results.pctvar=pct;
Results.model=th;
Results.portmanteau={P,pval};
Results.resids=e1;
Results.orig=x1;
Results.mean=x1mn; 
Results.t=yr;
S=Results;

clc;

message2={'Finished! Statistics on the modeling are available in structure S.',...
    '',...
    'This script relies much on Matlab''s System Identification Toolbox.',...
    'Typically you will store data using function ''iddata'' to make use of that',...
    'toolbox. Use ''>> help idddata'' to learn more, and see code in this script',...
    'as an example of usage'};

msgbox1(message2,'message2');
