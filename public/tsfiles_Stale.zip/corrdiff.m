function Result=corrdiff(r1,r2,n1,n2)
% corrdiff: test  that two independent correlations are estimates of the same population correlation
% Result=corrdiff(r1,r2,n1,n2);
% Written 2004-4-13
%
% Tests  that two independent correlations are estimates of the same population correlation. 
% Essentially a test for difference between two sample correlations.  
%
%*** INPUT ARGUMENTS
%
% r1 (1 x 1)r first correlation coefficient
% r2 (1 x 1)r second correlation coefficient
% n1 (1 x 1)r sample size (adjusted for autocorrelaton if needed) for computation of r1
% n2 (1 x 1)r sample size (adjusted for autocorrelaton if needed) for computation of r2
%
%*** OUTPUT ARGUMENTS
% Result: structure with fields 
%   z1 Fisher transformation of r1
%   z2 Fisher transformation of r2
%   diff   difference of z1 and z2
%   v (3 x 1)r  variances of z1, z2, and d
%   p (1 x 1)r  p-value for significance of difference (from 0)
%   what: definition of fields
%   
%*** REFERENCES
%
% Snedecor, G. W., and Cochranm W. G., 1989, Statistical Methods, eigth edition,
% Iowa State University Press, Ames, p. 189
%
%*** UW FUNCTIONS CALLED -- none
%
%
%*** TOOLBOXES NEEDED -- 
%
% Statistics
%
%*** NOTES  ****************************************
%
% Results applicable to two-tailed test with null hypothesis that difference between rho1 and rho2 is zero.
%
%  User assumed to reduce sample sizes if needed beforehand to adjust for autocorrelation
%
% Fisher's transformation converts correlation coefficient r to new variable z that is distributed almost normally with
% variance 1/(n-3), where n is sample size


% ------------  Make sure inputs are scalars
[m,n]=size(r1); % m rows, n columns
if ~(m==1 & n==1)
	error('r1 must be scalar')
end
[m,n]=size(r2); % m rows, n columns
if ~(m==1 & n==1)
	error('r2 must be scalar')
end
[m,n]=size(n1); % m rows, n columns
if ~(m==1 & n==1)
	error('n1 must be scalar')
end
[m,n]=size(n2); % m rows, n columns
if ~(m==1 & n==1)
	error('n2 must be scalar')
end


%-------  Make sure r within range

if r1<-1 | r1>1 | r2<-1 | r2>1;
    error('r1 or r2 not within range -1 to 1');
end;

%-------  Make sure sample sizes reasonable

if n1<3 | n2<3;
    error('n1 or n2 is less than 3');
end;



%******************* Fisher tranformation

z1=0.5* (log(1+r1)-log(1-r1));
z2=0.5* (log(1+r2)-log(1-r2));

%****************** Difference of transformed variables

d=z1-z2;


%****************** variances

v(1)=1/(n1-3);
v(2)=1/(n2-3);
v(3)=v(1)+v(2);


% Test statistic
tstat = d / sqrt(v(3));

% Compute p-value for test statistic, applicable to two-tailed test 
cdfprob = normcdf(tstat,0,1);
if cdfprob>0.5;
    p=(1-cdfprob)*2;  % prob of getting this diff or large by chance 
else;
    p=cdfprob*2;
end;
    



%************  Store results

Result.z1=z1;
Result.z2=z2;
Result.diff=d;
Result.variance=v;
Result.pvalue=p;
Result.what=char({'.z1 = Fisher transformation of r1',...
        '.z2 = Fisher transformation of r2',...
        'diff =  difference of z1 and z2',...
        'v (3 x 1)r  variances of z1, z2, and d',...
        'pvalue (1 x 1)r  p-value for significance of difference (from 0)',...
        '   For example, a pvalue of 0.048 means only 4.8% chance observed difference in r could arise from',...
        '   sampling r1 and r2 from same population'});

