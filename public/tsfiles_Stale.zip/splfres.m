function u=splfres(p,fvec)
% splfres: frequency response for spline of specified spline parameter, Matlab function csaps compatible
% u=splfres(p,fvec);
% Last revised 2005-5-31
% 
% Frequency response for spline of specified spline parameter, Matlab function csaps compatible
%
%*** INPUT ARGUMENTS
%
% p smoothing parameter for spline
% fvec (3x1) starting frequency for freq response
%         ending   frequency 
%         number of frequency points resp desired at
%
%***  OUTPUT ARGUMENTS
%
% u (mux2)  freqencies (1/year) and corresp frequency response
%
%*** REFERENCES
%
% No published reference as yet.  Function revised in response to email from Jean-Luc Dupouy, 5-27-2005
% Jean-Luc gave the function for the parameter of the 50% spline.  I generalized from that and tested
% the function on trial synthetic input sinusoids. 
%
%*** USER-WRITTEN FUNCTIONS NEEDED -- NONE
%*** TOOLBOXES NEEDED -- NONE

if ~(p>0 & p<1);
    error('Do not call this function if want straight line fit or an interpolating spline');
end


f=linspace(fvec(1), fvec(2), fvec(3));   %  form vector of frequencies
w=2.0*pi*f;  %  angular frequencies

% Make two terms that depend on cosine of frequency
costerm=cos(w');
term1=   (costerm+2);
term2=   6*(costerm-1) .^2;

% Note.  Should nt be calling this function for the null case of a straight-line least squares fit
if p==0;
    error('Do not call splfres with spline parameter 0');
end

term3= 1+((1-p)/p) * (2*term2 ./ term1);

u=repmat(NaN,length(f),2); % allocate to hold frequency and amp of response
u(:,1)=f';

% Remove any term3==0 to avoid division by 0
L=term3==0;
f(L)=[];
u(L,:)=[];
term1(L)=[];
term2(L)=[];
term3(L)=[];

% Compute frequency response
u(:,2) = 1 ./ term3;
