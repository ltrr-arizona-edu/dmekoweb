function [S1,S2,s]=rwlmod1
% rwlmod1: Modify measurements of a series in an rwl file.
% [S,s]=rwlmod1;
% Last revised 2018-10-24
%
% Modify measurements of a series in an rwl file.
% Can truncate, resulting later start year or earlier end year. Or can
% replace one or a series of consecutive measurements.
%
%*** INPUT
%
% No input arguments.  User clicks on source rwl file.
%
%*** OUTPUT
%
% An rwl file "xxx.rwl" is created.  This file is identical to the original
% input rwl, except modified by truncation of series of replacement of one
% or a consecutive series of measurements
%
% S1: a character version of the rwl for the series worked in before modify
% S2: ... after modify
% s: a string recording the change (can copy/paste this to a log file)
%
%*** REFERENCES -- NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED -- NONE
%
%
%*** NOTES
%
% Assume "key" series is to have data modified, and "predictor" series are
% to provide estimation.
%
% Replace done by mean-ratio method, assuming default  of mhalf years
% before gap and after gap to compute mean ratio. Method assumes that the
% width for the year to be predicted is the same percentage of local mean
% width as the width in same year for a the predictor series. Means are
% computed on the subset of years with data at both predictor and key
% series in the window from mhalf years before the "gap" to mhalf years
% after the gap.  mhalf is hard-coded as 5 years at start of function.
%
% If more than one predictor series is used (method A1), the median of the
% mean ratios is used for the estimation.  
%
% Replacement can optionally be done by specifying the replacement 
% widths, in 1000ths of mm, in a 2-col ascii text file you are prompted to click
% on. The ascii% filename is assumed to start with string "rep_" and have suffix "txt"
% (e.g., "rep_KCS04a_1.txt"
%
%
% Use. 
% 1) Have an rwl file you are revising <dog.rwl>
% 2) Make sure in 1000ths of mm <Tellervo>
% 3) Handle any core-id inconsistency <rwlids1, rwlids2>
% 4) <optional> high-grade the rwl file <rwlids3, rwlids4> --->% aaa_rwlids3.rwl
% 5) Fix any remaining dating or measurement problems <lockdown, rwlmod1>
%
% For reproducibility, want to be sure to save initial rwl file, final rwl
% file, and a log file that lists the modification steps. There will be
% intermediate rwl files, but these should be "easy" to regenerate again from
% the intial rwl and the log file. 
%
% Revised 2018-10-24: to allow insertion of a missing ring; code s ==
% mb1970, say, means inserted missing ring as 1979 and shifted beginning
% year of series earlier one year


crwl= [1 8];% crwl (1x2)i  first and last col of id in pfrwl (e.g., [1 8])
mhalf =5; % local half-window for mean-ratio method.

%ctxt = [7 14]  % ctxt (1x2)i  first and last col of id in pftxt  (e.g., [7 14])


%-- SELECT RWL FILE

filterspec={'*.rwl','*.RWL'};
[flnm1,path1,filterindex]=uigetfile(filterspec, 'Choose rwl file to modify');


%--- READ RWL WITH RWLINP

pf = fullfile(path1,flnm1);
[pf2,x,yrs,nms]=rwlinp(pf); % x is all measured series in strung out vector
% nms is cell of core ids, yrs indicates time coverage of each series


%--- READ THE RWL FILE WITH TEXTREAD, AND PULL THE COL-RANGE THAT HOLDS THE IDS
% THEN READ THE IDS AND FIND UNIQUE SET

A = textread(pf,'%s','delimiter','\n','whitespace','');
A1=char(A);
[mA1,nA1]=size(A1);

id1a = A1(:,crwl(1):crwl(2));
id1b =cellstr(id1a);
id1c=unique(id1b);  % col-cell of unique combinations of patterns in the id field of input rwl


%-- CHECK IDS READ IN BY TEXTREAD AGAINST THOSE BY RWLINP

L= ismember(nms,id1c);
if length(id1c) ~= length(nms) | ~all(L);
    error('Series ids by textread and rwlinp do not match');
end


%--- SELECT SERIES TO BE MODIFIED  AND HOW TO MODIFY

mods_how={'Truncate by lopping off years at beginning','Truncate by lopping off years at end',...
    'Replace measurements (single ring or consecutive rings','Insert a missing ring',...
    'Change ending year'};

k1 = menu('Choose series to modify',nms);
nm1 = nms{k1};

k2 = menu('Choose how to modify',mods_how);
mod_how = mods_how{k2};


%--- PUT ALL MEASURED SERIES IN A TIME SERIES MATRIX.

[X,yrX]=sov2tsm(x,yrs,[],[]);


%--- PULL TIME SERIES OF KEY SERIES (TO BE MODIFIED)

x1 = X(:,k1);
yrx1 = yrX;
[x1,yrx1]=trimnan(x1,yrx1);


%--- IF TRUNCATING MEASUREMENT SERIES OR INSERTING MISSING RING, DO NOT NEED TO WORK WITH ANY OTHER SERIES.  IF
% REPLACING ONE OR MORE VALUES, DEPENDS ON WHETHER WANT TO SPECIFY A
% REPLACEMENT VALUE (ONE YEAR ONLY), OR ESTIMATE ONE OR MORE CONSECUTIVE
% VALUES BY MEAN RATION METHOD.
%
% MEAN-RATIO METHOD REQUIRES PULLING THOSE SERIES WITH SUFFICIENT OVERLAP
% AND HAVING DATA PRESENT IN THE GAP,  CONVERTING THOSE TO CORE INDICES,
% FINDING WHICH IS MOST HIGHLY CORRELATED, COMPUTING THE MEAN RATIO, AND
% ESTIMATING.

if k2==3; % replace
    
    % Prompt for years to replace measurements
    kwh1=1;
    while kwh1==1;
        prompt={['Enter year(s) in range '  num2str(yrx1(1)) '-' num2str(yrx1(end)) ' to replace:']};
        name='Replacement of measurements';
        numlines=1;
        defaultanswer={'[NaN NaN NaN]'};
        ans1=inputdlg(prompt,name,numlines,defaultanswer);
        yrrep = str2num(ans1{1}); % a rv
        str_yrrep=ans1{1};
        L1 = any(yrrep<yrx1(1) | yrrep>yrx1(end));
        if L1
            kwh1=1;
            uiwait(msgbox(['Some year outside ' num2str(yrx1(1)) '-' num2str(yrx1(end)) 'time coverage of series'],'Try again','modal'));
        else
            if length(yrrep)>1;
                dyr = diff(yrrep);
                if ~all(dyr==1);
                    kwh1=1;
                    uiwait(msgbox(['Specified years not consecutive'],'Try again','modal'));
                    %uiwait(msgbox(['Specify some year later than ' num2str(yrx1(1))],'Try again','modal'));
                else
                    kwh1=0;
                    
                end
            else
                kwh1=0;
            end
        end % if L1
    end % while
    
    meths_rep ={'Mean-ratio using all overlapping series','Mean-ratio using specified core','Measurments from a .txt file'};
    lettshow ={'A1','A2','B'};
    kmeth = menu('Choose how to replace selected measurements',meths_rep);
    meth_rep = meths_rep{kmeth};
    letthow = lettshow{kmeth};
    
    if kmeth==1; 
        % Find all series that have data for years yrrep and for the mhalf
        % years flanking yrrep;
        % Recall k1 is col of key series
        yrgo1 = min(yrrep)-mhalf;
        yrsp1 = max(yrrep)+mhalf;
        L = yrX>=yrgo1 & yrX<=yrsp1;
        X1 = X(L,:);
        yrX1 = yrX(L);
        
        L = isnan(X1);
        L = ~any(L); % series that can be used as predictors
        L(k1)=false; % cannot use key series as a predictor
        
        w = X1(:,k1); % the key series for the window period
        yrw = yrX1;
        nrep = length(yrrep);
        
        X2 = X1(:,L); % predictor series for window
        yrX2=yrX1;
        
        % Compute the mean width for predictor series over the part of the
        % window excluding years yrrep
        L2=(~ismember(yrX2,yrrep)) & ~isnan(w); % in rwindow, but not in strrep; and also
        %    has data for the key series
        X3 = X2(L2,:);
        x3mean = mean(X3); % rv of means for predictor series for subset of years in 
        % window excluding yrrep
        
        % Expand row vector of predictor means for window to a matrix (or
        % scalar to col vector) whose row-size equals number of years in
        % yrrep
        X4 = repmat(x3mean,nrep,1);
        
        % Make matrix of predictor series values in years
        % yrrep
        Lkey = ismember(yrw,yrrep); % those years in window that ARE in yrrep
        X5=X2(Lkey,:);
        
        % Compute ratios of predictor yrrep values to the flanking means,
        % and compute the median of those ratios for each year yrrep
        xrat1 = X5 ./ X4;
        xrat2 = (median(xrat1'))'; % a cv of the ratios for estimation in each year yrrep
        
        % Replacement
        w_old = w(Lkey); % these to be replaced
        w_flank = w(L2); % these the flanking values (twice mhalf, minus any of those w/o data);
        w_new=round(xrat2*mean(w_flank));
        
        C=num2str([yrw(Lkey) w_old w_new]);
        C = char(['Year  Old    New'],C);
        
        if length(yrrep)>1;
            r = corrcoef([ w_old w_new]);
            r = r(1,2);
            str_r = [' (r=' num2str(r,'%5.2f') ', N=' num2str(length(yrrep)) ')'];
        else
            str_r='';
        end
        
    elseif kmeth==2 % If kmeth: mean ratio method from specified core
        % pull window set from key series
        yrgo1 = max([min(yrrep)-mhalf yrx1(1)]);
        yrsp1 = min([max(yrrep)+mhalf yrx1(end)]);
        
        Lkey = ismember(yrx1,yrrep);
        L = yrx1>=yrgo1 & yrx1<=yrsp1;
        w = x1(L);
        yrw = yrx1(L);
        
        kwh1=1;
        while(kwh1==1);
            Lkill=0;
            kpal = menu(['Choose series to modify ' nm1 ' with'],nms);
            if kpal==k1;
                uiwait(msgbox('Cannot use same series as predictor and predictand','Try again!','modal'));
            else
                nm2 = nms{kpal};
                % pull window data of "pal" series 
                u = X(:,kpal);
                yru=yrX;
                L = yru>=yrgo1 & yru<=yrsp1;
                u1 = u(L);
                yru1 = yru(L); Lkill=1;
                
                % Check that yrrep all represented in predictor series
                Lrep = ismember(yru1,yrrep);
                u2 = u1(Lrep);
                yru2 = yru1(Lrep);
                if any(isnan(u2))
                    uiwait(msgbox([str_yrrep ' in predictor series must be all good (none missing) data'],'Try again!','modal'));
                else
                    % Check that window has at least mhalf years data (out of
                    % 2*mhalf) to compute a mean ratio
                    Lrat = ~Lrep;
                    u3 = u1(Lrat);
                    w3= w(Lrat);
                    yrw3=yrw(Lrat);
                    yru3=yru1(Lrat);
                    Lpass = (~isnan(u3)) & (~isnan(u3)); % none missing in either predictor or predictand
                    npass = sum(Lpass);
                    if npass<mhalf;
                        uiwait(msgbox(['Fewer than ' num2str(mhalf) ' non-nan values to compute mean in predictor window'],'Try again!','modal'));
                    else
                        u4=u3(Lpass); % for computation of mean, predictor
                        w4=w3(Lpass); %..., predictand
                        yrw4=yrw3(Lpass); yru4=yru3(Lpass);
                        mnpred = nanmean(u4); % windowed mean for predictor series for years flanking yrrep
                        xrat2 = u2/mnpred; % mean ratio, ratio of predictor series in yrrep to windowed mean
                        % Replacement
                        w_old = w(Lrep); % these to be replaced
                        w_flank = w4; % these the flanking values (twice mhalf, minus any of those w/o data);
                        w_new=round(xrat2*mean(w_flank));
                        
                        C=num2str([yrw(Lrep) w_old w_new]);
                        C = char(['Year  Old    New'],C);
                        if length(yrrep)>1;
                            r = corrcoef([w_old w_new]);
                            r = r(1,2);
                            str_r = ['(r=' num2str(r,'%5.2f') ', N=' num2str(length(yrrep)) ', from ' nm2 ')'];
                        else
                            str_r=[' , from ' nm2];
                        end
                        kwh1=0;
                    end
                end
            end
            
        end % while
    else % replacement measurments from a 2-col ascii file
            
        % Key series
        w = x1; % the key series for the window period
        yrw = yrx1;
        nrep = length(yrrep);
        
        %--- READ IN THE TXT FILE OF REPLACEMENT MEASUREMENTS AND CHECK
        % DIMENSIONS AND YEARS
        
        filterspec={'rep_*.txt','rep_*.TXT'};
        [flnm2,path1,filterindex]=uigetfile(filterspec, 'Choose 2-col txt file with replacement widths in 1000ths of mm ');
        pf2 = fullfile(path1,flnm2);
        H = load(pf2); % year in col 1, widths, in mmx1000 in col 2
        
        [mH,nH]=size(H);
        if (mH ~=nrep) | nH~=2;
            error(['File ' flnm2 ' should have exactly ' num2str(nrep) ' rows and 2 cols']);
        end
        L = ismember((yrrep'),H(:,1));
        if ~all(L);
            error(['File ' flnm2 ' years do not match those entered to be replaced']);
        end
       
        % Replace
        L = ismember(yrw,yrrep);
        
        w_old = w(L);
        w_new = H(:,2);
        w(L)=H(:,2);
        
        C=num2str([yrw(L) w_old w_new]);
        C = char(['Year  Old    New'],C);
        if length(yrrep)>1;
            r = corrcoef([w_old w_new]);
            r = r(1,2);
            str_r = ['(r=' num2str(r,'%5.2f') ', N=' num2str(length(yrrep)) ', from ' flnm2 ')'];
        else
            str_r=[' , from ' flnm2];
        end
        kwh1=0;
        
        

   end  % kmeth==1;
    
    uiwait(msgbox(num2str(C),'Results of mean-ratio replacement','modal'))
    s = [nm1 ': rep' str_yrrep ' by method ' letthow ', ' str_r]
    
    %-- PUT ESTIMATES BACK IN TARGET SERIES
    L = ismember(yrx1,yrrep);
    x1(L) =w_new;
    
     % Re-form series into an rwl block
    y=tsv2rwl(nm1,x1,yrx1);
    S2=y;
    L = ismember(id1b,nm1);
    S1 = A(L,:);
      
elseif k2==1 || k2==2 % truncating
    if k2==1; % change start
        
        kwh1=1;
        while kwh1==1;
            prompt={'Enter desired beginning year:'};
            name='Start year after truncation';
            numlines=1;
            defaultanswer={num2str(yrx1(1))};
            ans1=inputdlg(prompt,name,numlines,defaultanswer);
            yrgo = str2num(ans1{1});
            if yrgo<=yrx1(1);
                kwh1=1;
                uiwait(msgbox(['Specify some year later than ' num2str(yrx1(1))],'Try again','modal'));
            else
                kwh1=0;
                
            end
        end
        % do the truncation
        L = yrx1>=yrgo;
        yrx1 = yrx1(L);
        x1 = x1(L);
        s = [nm1 ': b' num2str(yrgo)];
    else % change end
        kwh1=1;
        while kwh1==1;
            prompt={'Enter desired end year:'};
            name='End year after truncation';
            numlines=1;
            defaultanswer={num2str(yrx1(end))};
            ans1=inputdlg(prompt,name,numlines,defaultanswer);
            yrsp = str2num(ans1{1});
            if yrsp>=yrx1(end);
                kwh1=1;
                uiwait(msgbox(['Specify some year before' num2str(yrx1(end))],'Try again','modal'));
            else
                kwh1=0;
                
            end
        end
        % do the truncation
        L = yrx1<=yrsp;
        yrx1 = yrx1(L);
        x1 = x1(L);
        s = [nm1 ': e' num2str(yrsp)];
    end
elseif k2==4; % insert missing ring
    % Can insert and shift start year 1 year earlier-- code mb
    % Can insert and shift end year 1 year later -- code me
    kwh1=1;
    while kwh1==1;
        prompt={'Enter year to insert as missing ring:'};
        name='Missing ring';
        numlines=1;
        defaultanswer={num2str(yrx1(1))};
        ans1=inputdlg(prompt,name,numlines,defaultanswer);
        yrmiss = str2num(ans1{1});
        if yrmiss<=yrx1(1) | yrmiss>= yrx1(end);
            kwh1=1;
            uiwait(msgbox(['Specify some year later than ' num2str(yrx1(1)) ' and earlier than ' num2str(yrx1(end))],'Try again','modal'));
        else
            kwh1=0;
        end
    end
    
    % Push to earlier start year or to later end year
    kpush = menu('Choose how to shift series in response to entering missing ring',{'Make start year earlier','Make end year later'});
    if kpush==1
        L1 = yrx1<=yrmiss;
        x1a = x1(L1);
        x1b= x1(~L1);
        x1new = [x1a; 0 ; x1b];
        yrx1new =[(yrx1(1)-1); yrx1];
         s = [nm1 ': mb' num2str(yrmiss)];
    else
          L1 = yrx1<yrmiss;
         x1a = x1(L1);
        x1b= x1(~L1);
        x1new = [x1a; 0 ; x1b];
        yrx1new =[yrx1; (yrx1(end)+1)];
         s = [nm1 ': me' num2str(yrmiss)];
    end
    x1=x1new;
    yrx1=yrx1new;
elseif k2==5 % change ending year
    prompt={'Enter new last year:'};
    name=['Last year = ' num2str(yrx1(end))];
    numlines=1;
    defaultanswer={num2str(yrx1(end))};
    ans1=inputdlg(prompt,name,numlines,defaultanswer);
    yrlast = str2num(ans1{1});
    yrshift =yrlast-yrx1(end);
    yrx1=yrx1+yrshift;
     s = [nm1 ': shift' num2str(yrshift)];
else
   error('Should not get here')
end


% Re-form series into an rwl block
y=tsv2rwl(nm1,x1,yrx1);
S2=y;
L = ismember(id1b,nm1);
S1 = A(L,:);


%---SPLICE BLOCK BACK INTO RWL TO REPLACE LINES WITH KEY SERIES

A2=A1;
L = ismember(id1b,nm1);
i1 = find(L); % rows that key series occupied in source rwl
A2(L,:)=[];

if  i1(1) ==1; % key series was first in the rwl
    A2 =char(y,A2);
elseif i1(end)==size(A1,1); % key series was last in the rwl
    A2=char(A2,y);
else % key series is internal
    ifirst1 = 1;
    ilast1 = i1(1)-1;
    ifirst2 = i1(end)+1;
    ilast2 = size(A1,1);
    A1a = A1(ifirst1:ilast1,:);
    A1b =A1(ifirst2:ilast2,:);
    A2 =char(A1a,y,A1b);
    
end


%--- WRITE OUTPUT xxx.rwl

S1=A1;
S2=A2;

S=S2(:,1:72);
 [mS,nS]=size(S);
 fid = fopen('xxx.rwl','w');
 fmt = '%72s\n';
 for n =1:mS;
     sline = S(n,:);
     fprintf(fid,fmt,sline);
 end
 fclose (fid);
 
 
 
 
 
