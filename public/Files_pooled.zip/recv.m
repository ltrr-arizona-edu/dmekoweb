function Result=recv(y,X,IX)
% recv: reduction of error statistic by leave-m-out cross validation
% Result=recv(y,X,IX);
% Last Revised 2019-06-19
%
% Reduction of error statistic (RE) by leave-m-out cross validation.
% Assumes user has already run in calling function something like
% crosspul.m to generate the matrix IX of row indices specifying the subset
% calibration observations.
% 
%*** INPUT
%
% y (my x 1)r predictand
% X (mX x nX)r predictors, without any added ones column
% IX (my x my)L  pointer to calibration observations
%
%*** OUTPUT
%
% Result =  structure with fields:
%
%   .RE(1x1)r   the reduction of error statistic
%   .ecv (?x1)r  the cross-validation residuals
%   .RMSEcv (1x1)r the root mean square error of CV residuals
%   .yhat(?x1) cross-validation "predictions" for left out observations
%
%*** REFERENCES
% 
% The mae and rmse error are defined in many standard time series and regression texts, 
% for example:
% Weisberg, S., 1985, Applied Linear Regression, 2nd ed., John Wiley, New York.
%
% The re statistic in a tree-ring context is discussed in:
% Gordon, G., 1982, Verification of dendroclimatic reconstructions, In:  
% M.K. Hughes et al. (eds.), Climate from tree rings.  Cambridge University Press,
% Cambridge, UK, 58-61.
%
% The risk, bias and covariance components of RE are described in:
% Fritts, H.C., Guiot, J. and Gordon, G.A. (1990), Verification, in:
% Methods of dendrochronology; applications in the environmental sciences,
% eds E.R. Cook and L.A. Kairiukstis, Kluwer Academic Publshers, Boston
%
%
%*** UW FUNCTIONS CALLED
%*** TOOLBOXES NEEDED
%
%*** NOTES
%
% Assumed that y and X are the same row-size, and have been organized
% beforehand so that they are synchronized in time 
%
% IX.  Each col of IX marks the calibration years for a cross-validation
% model.  Each col has 1 to several zeros, marking the "left-out"
% observations.  
%
% Revised 2019-06-19. Change to use variable calibration means of
% predictand. Each is computed for its calibration-subset of y. 

nyears = length(y);
[mX,nX]=size(X);
ybar = mean(y); % "calibration-period" mean of predictand for full overlap of X and y
ymeancv = nan(mX,1); % to hold calibration means for cv models
yhatcv = nan(mX,1); % to hold cross-validation predictions
U=[ones(nyears,1) X];
for n = 1:mX
    Lcal =IX(:,n);
    Xc = X(Lcal,:);
    [mXc,nXc]=size(Xc);
    Xc = [ones(mXc,1) Xc];
    v=y(Lcal);
    ymeancv(n)=mean(v);
    b=Xc\v;
    yhatcv(n) = U(n,:)*b;
end
ecv = y-yhatcv; % cv residuals 
SSecv = sum(ecv .^2);
%eref = y - mean(y);
eref = y - ymeancv; % residuals from null-recon consisting of calibration mean (varies by left-out year)
SSref = sum(eref .^2);
Result.RE=1 - (SSecv/SSref);
Result.ecv= ecv;
Result.RMSEcv = sqrt(SSecv/nyears);
Result.yhat=yhatcv;
