function Result=corrtrach01(datin,specs)
% corrtrach01: correlation of cell-anatomy quantile series with day-window climate.
% Result=corrtrach01(datin,specs)
% Last revised 2019-09-24
%
% Correlation of cell-anatomy quantile series with day-window climate. 
% Utility function used in conjuction with function trach01 color-mapping
% correlations. Options for Spearman or Pearson, significance theoretical
% or Monte Carlo, tree-ring series adjusted or not for linear dependence on
% tree-ring series in preceding ring portion. 
%
%*** INPUT
%
% datin: structure of input data and related setting
%   .Y (mY x nY)r day-windowed climate series for nY day windows, mY years
%   .yrY(mY x 1)i year vector for Y
%   .X (mX x nX)r quantile-of-ring cell-anatomy variable (e.g., mean lumen  area)
%   .yrX(mX x 1)i year vector for X; need not match yrY
% specs: structure of settings
%   .kopt (1x3)s options
%       (1) analysis period for correlations
%           ==1: maximum overlap in X and Y
%           ==2: user specifies start and end year
%       (2) adjustment of cell-anatomy data in one quantile to remove linear dependence on 
%            cell anatomy data in the preceding quantile
%           ==1: no such adjustment
%           ==2: adjust by simple linear regression (Notes)
%       (3) autocorrelation handling in assessing significance of correlation
%           ==1: Pearson correlation, no adjustment of degrees of freedom
%               for autocorrelation 
%           ==2: Spearman correlation, no adjustment of degrees of freedom
%               for autocorrelation 
%           ==3: Monte-Carlo-based significance of Pearson r using exact simulation.
%               Simulate the tree-ring series many (e.g., 10000) times, and
%               assess significance of the sample correlation by its
%               position in the CDF of correlation of climate series with
%               the simulations. 
%           ==4: Monte-Carlo-based significance of Spearman r using exact simulation.
%               Otherwise, like for option (3) (Notes)
%   .AnalysisPeriod (1x2)i or []:  first and last year of desired period for correlations. If [],
%           corrtrach01 used the full overlap of the series (Notes) 
%   .SimExact -- setting for exact simulation (can be [] if specs.kopt(4) NE 4
%       .nsims (1x1)i number of simulations (e.g., 10000); set [] unless  kopt(3)==4.
%       .knorm (1x1)i  .... dealing with normality assumption of exact simulation
%           ==1: ignore assumption and treat series to be simulated as if normally distributed
%           ==2: apply Lillifore's test and if reject normality at p<0.01, force to normal
%               by quantile mapping; transformed series then adjusted to have same mean and
%               variance as original series, but guaranteed normal
%       .
%
%*** OUTPUT
%
% Result:  structure of results, with fields:
%
%   R (mR x nR)r Pearson correlations of mR quanile cell-anatomy seriesn
%   with nR day-windowed climate (Notes)
%   P (mR x nR)r  p-value for significance of correlation. Two-tailed. 
%   Q (mR x 1)r  or []:  percentage of tree-ring variance explained by
%       regression on the tree-ring series for the preceding quantile. Only
%       applies if specs.kopt(2)==2. Otherwise, [].
%   AC: structure with autocorrelation information
%       .a1X   (mR x 1)r lag-1 autocorrelations, tree-ring series
%       .sig1X  (mR x1)L  whether significant lag-1 (year-to-year) autocorrelation at
%           alpha =0.05 in tree-ring series
%       .a1Y (nR x 1)r lag-1 autocorrelations, day-windowed climate
%       .sig1Y  (nR x 1)L whether significant lag-1 (year-to-year) autocorrelation at
%           alpha =0.05 in day-windowed climate series 
%
%*** REFERENCES
%
%*** UW FUNCTIONS CALLED
%
%
%*** TOOLBOXES NEEDED -- none
%
%
%*** NOTES
%
% specs.kopt(2): This simple linear regression applies to every quantile
%   tree-ring series after the earliest, which is not adjusted.
% Result.R: rows bottom to top from earlies ring portion to latest, and
%       from left to right from earlies to latest day-window
% Result.S: in extreme case where sample correlation outside range of
%   significance table or more extreme than r for any simulation, S(i,j) set
%   to 0
%Transformation of tree-ring series to normality (with any2norm) happens
%   only if using Monte Carlo version of significance, and only if you have
%   specified by options that series that fails Lillietest at alpha=0.1
%   should be transformed. Be aware that if generate the simulations on
%   transformed x, should also use transformed x for the sample
%   correlations with climate.
%
% Autocorrelation adjustment to effective sample size. This is done if you
% choose spearman correlation option. Time series in X and Y for the
% specified correlation period are tested forpositive  significant  (0.05)lag-1
% autocorrelation (one sided test). The lag-1 autocorrelation coefficient is also stored.
% Effective sample size is used for assessing significance if and only if
% both x and y series have significant positive autocorrelation.
%
% Spearman correlation under exact simulation. If not using exact 
% simulation, r is computed with Matlab's corr function. 
% Otherwise, time series in X and Y are first
% converted to ranks and those rank series are converted to normal by
% quantile mapping if they fail Lilliefors test at alpha=0.01. The spearman
% r is then equivalent to the Pearson r between rank series, and is so
% computed. The simulations used for Monte Carlo significance are of the
% rank series, possibly forced to normality. 


%---- HARD CODE

X=datin.X; yrX=datin.yrX;
Y = datin.Y; yrY = datin.yrY;
kopt=specs.kopt;


%---- UNLOAD

yrs = specs.AnalysisPeriod;


%---- SET THE ANALYSIS PERIOD

%--- Find maximum overlap
L = any(any(isnan(X)));
if L
    error('At least one NaN in tree-ring matrix X');
end
L = any(any(isnan(Y)));
if L
    error('At least one NaN in day-windowed climate matrix Y');
end
yrgo = max([yrX(1) yrY(1)]);
yrsp = min([yrX(end) yrY(end)]);

if isempty(yrs)
else
    if yrs(1)<yrgo || yrs(2)>yrsp
        error(['Specified analysis period outside data coverage']);
        yrgo = yrs(1);
        yrsp = yrs(2);
    else
    end
end


% TRIM TSM'S X AND Y TO ANALYSIS PERIOD

L = yrX>=yrgo & yrX<=yrsp;
X=X(L,:);
L = yrY>=yrgo & yrY<=yrsp;
Y=Y(L,:);
[mX,nX]=size(X); 
[mY,nY]=size(Y);



%  OPTIONALLY USE ADJUSTED TREE-RING SERIES X
%
% Remove linear dependence of tree-ring series for one  ring portion, or
% quantile on the previous quantile
if kopt(2)==1
    R2=[];
else
    % adjust
    [X,R2]=subfun01(X);
end


%  AUTOCORRELATION ASSESSMENT
% 
% Significant (0.05, one-sided) positive autocorrelation?  Lag-1
% autocorrelation coefficients. 
ResAC = subfun03(X,Y);



%  OPTIONAL SIMULATION OF TREE-RING SERIES IN X

if kopt(3)>2
    ResSim = subfun02(X,specs.SimExact,kopt(3));
    X=ResSim.T; % with either of the exact simulation options (Pearson or Spearman), 
    % may have converted the time series to normal;  Let X hold the series
    % after transformation. Note that X series are not ranked yet, even if
    % the simulations are.
else
    ResSim=[];
end
% ResSim.W is a cell with the sets of simulated tree-ring series
% ResSim.LillieOut is a 3-col matrix with 1) fail Lillietest?, 2) p-value
%   for test, and 3) whether the corresponding tree-ring series was
%   transformed
% ResSim.T: matrix same size as X, but possible with some series
%    transformed to normality; Series from T, not X, should be used for
%    sample corr



% OPTIONALLY CONVERT X AND Y TO RANK SERIES IN PREP FOR CORRELATION
%
% Will do this only if Spearman r and assessing significance by Monte
% Carlo. If Spearman but not Monte Carlo, Matlab's corr function with
% handle ranking internally
if kopt(3)<4
else
    U=X;
    V =Y;
    for n =1:nX
        x = X(:,n);
        [rx,ntie]=ranktie1(x);
        U(:,n)=rx;
    end
    for n =1:nY
        y = Y(:,n);
        [ry,ntie]=ranktie1(y);
        V(:,n)=ry;
    end
    X=U;
    Y=V;
    clear U V rx ry ntie
end


% MATRICES OF  CORRELATION AND SIGNIFICANCE 

if kopt(3)==1
    [R,P]=corr(X,Y,'Type','Pearson');
elseif kopt(3)==2
    [R,P]=corr(X,Y,'Type','Spearman');
else
end

if kopt(3)>2
    D= subfun04(X,Y,ResSim,kopt);
    R=D.R;
    P=D.P;
    clear D;
end


Result.R=R;
Result.P =P;
Result.AC=ResAC;
Result.Q =R2;


disp('here')
end

function [Y,R2]=subfun01(X)
% Remove linear dependence of quantile cell-anatomy series on previous
% quantil series. Earliest quantile series not adjusted.
% Series adjusted by simple linear regression of (j+1)th series on jth. 
% Residuals than scaled back to mean and variance of original series.
%
% X (mX x nX)r:   mX observation (years) and nX quantile series
% 

[mX,nX]=size(X);
R2=nan(nX,1);
R2(1)=0;
Y=nan(mX,nX);
Y(:,1)=X(:,1);
for n =2:nX
    y=X(:,n);
    x=X(:,(n-1));
    U=[ones(mX,1) x];
    b=U\y; % cv of coefs
    yhat = U*b;
    e = y-yhat;
    
    sst = sum((y-mean(y)) .* (y-mean(y)));
    sse =  sum(e .* e);
    R2(n) = 1 - (sse/sst);
    
    z=zscore(e);
    ybar=mean(y);
    ystd = std(y);
    
    Y(:,n)=ybar+z*ystd;
    
end

end


function  D= subfun02(X,specs,k)
% Exact simulation of quantile cell-anatomy tree-ring series
% To be stored in cells of W for the separate input series in X
%
% D.LilllieOut (nX x 3) gives results of Lillietest and whether x series
%   gets transformed
% D.T: the tsm of observed X series, some optionally transformed to normality
% D.W: cell whose elements contain the simulated tree-ring time series.
%   Number of cells equal to number of tree-ring cell-anatomy quantiles
%   Some of the simulations may have been on tree-ring series transformed
%   to normal by any2norm. Look at 3rd col of D.LillieOut to find those.
% 
% Optionally the simulated time series are converted ranks. This if the
% Spearman option k==4

[mX,nX]=size(X);
T=X; % will hold optionally normal-transformed tree-ring series (before any conversion to ranks)
mT=mX; nT=nX;

W=cell(nX,1);
LillieOut=nan(nX,3); % pass (0) or fail (1); p-value; transformed (1) or not (0)
LillieOut(:,3)=false;
for n = 1:nX
    x=X(:,n);
    
    % test for normality
    [h,p]=lillietest(x,0.01);
    LillieOut(n,[1 2])=[h p];
    
    % Depending on specs and Lillietest results, transform series to normal
    % by quantile mapping.
    if specs.knorm==1
    else % transform to normal if failed Lillietest, or if using rank time series (which is uniform)
        if h==1 || k==4
            G=any2norm(x,false); % false for no graphics
            % G.y is the transformed series
            x=G.y;
            LillieOut(n,3)=true;
            T(:,n)=x;
        else
        end
    end
    Result=pdgmsim(x,specs.nsims,specs.mtaper,specs.kopt_pdgmsim,mX);
    
    %  optionally convert simulated series to ranks
    if k==4
        B = nan(size(X,1),specs.nsims);
        for j =1:specs.nsims
            y = Result.Y(:,j);
            [r,ntie]=ranktie1(y);
            B(:,j)=r;
        end
        D.W{n}=B;
        clear B r ntie y
    else
        D.W{n}=Result.Y;
    end
end
D.LillieOut=LillieOut;
D.T=T;
end

function  D= subfun03(X,Y)
% Lag-1 autocorrelaton coefficients of series in cols of X and Y; Logical
% of whether each series has significant (0.05, one-sided) positive
% autocorrelation
koptAC=[1 1]; % no graphics; typical treatment using global means
nlags=3;

[mX,nX]=size(X)
[mY,nY]=size(Y);

a1X =nan(nX,1);
a1Y = nan(nY,1);
sig1X = false(nX,1);
sig1Y = false(nY,1);

for n = 1:nX;
    x = X(:,n);
    [r,SE2,r95]=acf(x,nlags,koptAC);
    a1X(n)=r(1);
    L = r(1)>0 && abs(r(1))>abs(r95);
    if L
        sig1X(n)=true
    else
    end
end
D.a1X=a1X;
D.sig1X=sig1X;


for n = 1:nY
    x = Y(:,n);
    [r,SE2,r95]=acf(x,nlags,koptAC);
    a1Y(n)=r(1);
    L = r(1)>0 && abs(r(1))>abs(r95);
    if L
        sig1Y(n)=true
    else
    end
end
D.a1Y=a1Y;
D.sig1Y=sig1Y;

end

function  D= subfun04(X,Y,ResSim,kopt)
% Assessment of significance of correlation by exact simulation
% kopt(3)==1  Pearson; kopt(3)==4 Spearman
%
% Because X and Y series are already converted to ranks if using Spearman
% in combination with Monte Carlow simulations, can use "Pearson" option
% for that and still get Spearman r (Pearson on ranks equivalent to
% Spearman on original)

[mX,nX]=size(X);
[mY,nY]=size(Y);

R = nan(nX,nY);
P=nan(nX,nY);


for n=1:nX
   
    % The sample correlations
    x=X(:,n);
    R(n,:) = corr(x,Y,'type','Pearson'); % note that if doing Spearman this works because
    %       series in X and Y already converted to ranks
    
    %--- The significance
    
    W=ResSim.W{n};
    nsim=size(W,2);
    Q=corr(W,Y,'type','Pearson'); % row 1 has r of each of, say, 10,000 simulated
    %       x with observed Y
    
    for j=1:nY
        r = R(n,j); % sample correlations
        q=Q(:,j); % corrs for sims
        
        if r>=max(q) | r<= min(q)
            P(n,j)=0;
        else
            qs=sort(q);
            jsim =(1:nsim)';
            p1=jsim/(nsim+1); % non-exceedance
            
            if r>=median(q)
                L1 = qs<r;
                i1=find(L1);
                i2 =max(i1);
                pthis = 2*(1-p1(i2));
            else
                L1 = qs>r;
                i1=find(L1);
                i2 =min(i1);
                pthis = 2*p1(i2);
            end
            P(n,j)=pthis;
        end
    end
end
D.R=R;
D.P=P;
end