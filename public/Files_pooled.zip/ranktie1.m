function [r,ntie]=ranktie1(x)
% ranktie1:  ranks with ties
% [r,ntie]=ranktie1(x);
% Last revised 2016-01-25
%
% Ranks of values in a time series that might contain ties  
%
%*** INPUT
%
% x (mx x 1)r time series (see Notes)
%
%*** OUTPUT
%
% r (mx x 1)r  ranks of values of x (smallest values has lowest rank)   (see notes) 
% ntie (? x 1)n number of ties of various length 1,2, 3 to maximum (see notes)
%
%*** REFERENCES
%
% Langley, R., 1970, Practical statistics simply explained: New York, Dover Publications, Inc.
%
%*** UW FUNCTIONS CALLED
%
% No functions called.
%
%*** TOOLBOXES NEEDED---none
%
%*** NOTES
% r:  contains ranks of the time series x.  r(1) is rank of x(1), r(2) is rank of x(2), etc. Low values have low ranks, high values have high ranks.
% x: not allowed to contain NaNs
% ntie: number of ties of various length.  ntie(i) is number of ties  of length i.  ntie(1) always set to NaN.  If no ties of any length, ntie==[]
%
% This function called by spearman
%
% Thus function calls matlab's depfun, which is on cutting block. In future
% will need to call matlab.codetools.requiredFilesAndProducts, as in
% d=matlab.codetools.requiredFilesAndProducts('any2norm')

% -- CHECK INPUT

[mx,nx]=size(x);
if nx ~=1
    error('x must be col vector');
end;
if mx<5
    error('x must be a least length 5');
end
if any(isnan(x))
    error('x not allow to contain NaNs');
end


%--- SORT ASCENDING

[y,iy]=sort(x);
my=length(y);


%-- TEST y FOR UNIQUENESS

% Any ties?
u=unique(y); % unique values in y
if length(u)==length(y);
    ktie=0;
    ntie=[];
    
    % Arrange so that ranks associated with x in original order
    [p,ip]=sort(iy);
    r=(1:my)';   % ranks of data values, after sorting small to large
    r = r(ip);  % ranks of data values in original order

    % no need for further action, all values are unique; no ties
    return;
else;
   ktie=1;
end;

% If you got here, have at least 1 tie

Y = repmat(y,1,my);
R = repmat((1:my),my,1);
L2 = Y==Y';

R(~L2)=NaN;
r=(nanmean(R'))';   % ranks adjusted for ties
nmax = max(sum(L2')); % max tie length


% Arrange so that ranks associated with x in original order
[p,ip]=sort(iy);
r = r(ip);


ntie = repmat(NaN,nmax,1); % allocate to store number of ties of 1, 2, 3, ....

% Compute number of ties of various length

for n = 2:nmax
    L3=sum(L2')==n;
    if ~any(L3)
        ntie(n)=NaN;
    else
        ntie(n)= sum(L3)/n;
    end
end




