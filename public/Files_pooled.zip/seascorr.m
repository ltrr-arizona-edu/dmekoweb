function Result=seascorr(x,yrx,P,T,endmo,g,kopt,textinfo,nsim,time_specs)
% seascorr: correlation of tree rings with monthly and seasonal climate 
% Result=seascorr(x,yrx,P,T,endmo,g,kopt,textinfo,nsim,time_specs);
% Last Revised 2014-10-18
%
% Correlation analysis of tree rings with monthly and seasonal climate data.
% The tree-ring climate signal for a primary and secondary climate variable
% is summarized by correlations (primary variable) and partial correlations 
% (secondary variable). Correlations are computed and graphed for 56
% separate seasons, corresponding to 4 different season-lengths and 14
% possible ending months.  You specify the seasonal groupings.
% Significance of correlations and partial correlations is guided by exact
% simulation, or simulation of the tree-ring series such that the
% simulations have roughly the same spectrum as the the observed tree-ring
% series. Default use applies precipitation and temperature as primary and
% secondary climate variables, but these may be switched, or some other
% pair of climate variables used. Temporal stability of relationships
% can be checked by repeated runs of seascorr on early and late
% sub-periods. Further information on temporal stability of strongest
% seasonal correlations for the primary climate variable is given by a test
% of difference of correlation between sub-periods. Seascorr can be run in
% "point and click" mode, in which you are prompted for inputs, or in "driver-
% script" mode.  In "driver-script" mode, you write a driver script that
% prepares the necessary input arguments. Besides the main graphics output, 
% statistics and supporting graphics are produced to summarize properties 
% of the tree-ring and climate series.
%
% Standalone versions for windows 32-bit and windows 54-bit are being
% developed.  These let users who have no access to matlab run Seascorr and
% graphics as well as the most important statistics output. Seach below on
% "STANDALONE VERSIONS"  for info in the notes.
% 
% 
% 
%****  INPUT ARGUMENTS (OPTIONAL)
%
% x (mx x 1)r tree ring index, either standard or residual
% yrx (mx x 1)i year vector for x
% P (mP x 3)r  monthly series of first climate variable, in 3-column format
%   col 1 = calendar year
%   col 2 = month (1==Jan, 12==Dec)
%   Col 3 = data value
% T (mT x 3)r monthly series of second climate variable, in 3-column format
% endmo (1 x 1)i month designated as last month of growth season (e.g., 9 for September)
% g {}i number of months in each of four seasonal groupings.  E.g.,
%   {1,4,6,12} says 1-month, 4-month, 6-monthe and 12-month "seasons"
% kopt (1 x 2)i options
%   kopt(1) color option
%       ==1 color
%       ==2 B/W
%   kopt(2) Allows reversal of usual assignment of primary and secondary 
%       climate variables; say P and T are the climate variables:
%       ==1 correlations on P, partials on T  9
%       ==2 correlations on T, partials on P (reverses normal order)
% textinfo {1X8}S  text for labeling and program control
%   {1} name of primary climate variable (30 or fewer chars)
%   {2} one-letter code for primary climate variable
%   {3} units of primary climate variable (e.g., "mm")
%   {4} how primary climate variable is to be seasonalized (must be
%       one of these: "sum" or "mean"
%   {5} name of secondary climate variable (30 or fewer chars)/home/dmekoLred
%   {6} one-letter code for secondary climate variable
%   {7} units of secondary climate variable (e.g., "mm")
%   {8} how secondary climate variable is to be seasonalized (must be
%       one of these: "sum" or "mean"
% nsim (1x1)r  number of exact simulations desired (e.g., 1000)
% time_specs{}  specification for analysis period(s)
%   {1} (1x2)r  first and last year of desired full analysis period.
%       If [], defaults to the full available overlap of climate and
%       tree-ring data
%   {2} (1x2)r  first and last years of an early sub-period to be
%       used in test of difference of sample correlations ine early and
%       late sub-periods
%   {3} (1x2)r  first and last years of an late sub-period to be
%       used in test of difference of sample correlations ine early and
%       late sub-periods
%
%   Allowable forms of this input (years given as examples only) are:
%   {[],[],[]}  defaults to full period as allowed by overlap of climate
%       and tree-ring data, early period of first half of full period, late
%       period as last half of full period
%   {[], [1903 1934],[1965 1999]}  full-period defaults as above, early and
%       late sub-periods specified.  
%   {[1903 2002],[1910 1940],[1970 2002]} -- complete specification of
%       full-period and sub-periods
%      See "time_specs" under Notes for more information. 
%
%
%*** OUTPUT
%
%
% Output consists of one output argument, "Result" (see below), and 11
% figure windows. 
%
% Main graphic output is Figure 1, bar charts of the Pearson correlation
%   coefficient of tree ring series with primary climate variable and of
%   partial correlations of tree-ring series with secondary climate
%   variable. Statistical significance (see Notes) is color coded
%
% Secondary graphic output is Figure 2-11, and includes:
%   Time series plot of tree-ring series
%   Climograph
%   Autocorrelation function of tree-ring series
%   Sample spectrum of tree-ring series
%   First-order autocorrelations of primary climate variable 
%       (bar chart, 56 seasons)
%   Scatter plots of tree rings on primary climate variable for seasons
%       with highest r, four season-lengths
%   Time plots of tree rings and primary climate variable for those same
%       seasons
%   Summary text of highest correlations for various season-lengths
%   Summary text of test for difference of correlations for the
%       seasonal groupings with highest climate-tree ring correlation for
%       four season-lengths; the test is applied correlations for specified
%       early and late sub-periods
%   
% Result -- structure of results
%   .S {1 x4}s Listing of correlations and partial correlations 
%       (data for figure 1)
%   .H (?x?}s text summary of highest correlations for each of the four
%       season-lengths
%   .r1 (56 x 1)r correlations of x with P
%   .r2 (56 x 1)r partial correlations of x with T. Usual notation is r_T.P
%   .p1 (56 x 1)r  empirical non-exceedance probabilities of r1
%   .p2 (56 x 1)r  empirical non-exceedance probabilities of r2
%   .yrgo (1 x 1)i start year of correlation period
%   .yrsp (1 x 1)i  end year ...
%   .nsim (1 x 1)i number of simulations used in exact simulations
%   .endmo (1 x 1)i  ending month of growth season
%   .g {} 1 x 4 number of months in groupings (see inputs) 
%   .nmos (1 x 1)i number of months in monthly climate window (e.g., 14)
%   .r3 (56 x 1)r  Pearson r between P and T
%   .r4 (56 x 1)r  first order autocorrelation of P
%   .r5 (56 x 1)r first order autocorrelaton of T.P
%   .r6 (5 x 1)r lag 1-5 autocorrelations of x
%   .sub_test = structure with results of test for difference of
%       correlations of tree-ring index with primary climate variable in a
%       specified early and late period.  Refer to field
%       Result.sub_test.what  for list of contents of this structure.
%
% Abbreviated Running Instructions (use one of the methods -- 1 or 2 -- below)
%
% 1) Point-and-Click Mode
%   -Prepare files of monthly climate data for primary and secondary
%    climate variables:  13-column, space-separated, ascii, years as first
%    column, data for Jan, Feb, ..., Dec as columns 2-13. Save these as
%    .txt file (e.g., "Pmonthly.txt" and "Tmonthly.txt")
%   -Prepare file of tree-ring series: acceptable formats are "crn" format
%    used in the International Tree-Ring Data Bank, and 2-column, space-
%    separated ascii, with year as first column and tree-ring value as
%    second column
%   -Make sure the data files above are in your current working directory,
%    and that sescorr and all its dependent functions are on the Matlab
%    path
%   -Key in "Result=seascorr" at the Matlab prompt (without quotes)
%   -Follow prompts to click on files with tree-ring series and monthly 
%    climate data
%   -Change information, if needed, in the two edit boxes for
%    units, etc., of the primary and secondary climate data
%   -Change information, if needed, in the edit box for "Season Settings".
%    This box prompts for the ending month of the tree-growth year and for
%    4 season lengths.  For details, see "endmo" and "g" in the input
%    description below
%   -Respond to menu: choose color or black-and-white graphics output 
%   -Respond to menu: optional switch of roles of primary and secondary
%    climate variables. Choosing to switch the roles leads to the variable
%    read in as "secondary" to be analyzed with product-moment correlation
%    and the variable read in as primary to be analyzed with partial
%    correlations (see Notes below)
%   -Results are in the 10 figure windows and the structure "Results" (see
%    description of output (below))
% 2) Input-argument mode
%   -Write a script to organize the input arguments described below
%   -Within the script, issue the command
%   -   Result=seascorr(x,yrx,P,T,endmo,g,kopt,textinfo);
%   -Results are in the 10 figure windows and the structure "Results" (see
%    description of output (below))
%
% In the above,the following notation is used to describe sizes and classes
% of variables:
% {1xn}s refers to a row cell-vector, length n, of strings 
% {1xn}i refers to a row cell-vector, length n, of integers 
% {?x?}s refers to a character matrix of unspecified row-size and column
%       size
% {nx1)r refers to a column vector of class real (or double), length n
% {1x1}i refers to a scalar (1 row, 1 col) integer
%
%
%*** REFERENCES (alphabetical order)
%
% Bloomfield, P., 2000. Fourier analysis of time series: an introduction, 
% second edition. John Wiley & Sons, Inc., New York. 261 p.
%
% Conover, W., 1980, Practical Nonparametric Statistics, 2nd Edition, John
% Wiley & Sons, New York. 
%
% Dawdy, D.R., and Matalas, N.C., 1964, Statistical and probability analysis of hydrologic data, 
% part III: Analysis of variance, covariance and time series, in Ven Te Chow, ed., Handbook of 
% applied hydrology, a compendium of water-resources technology: New York, McGraw-Hill 
% Book Company, p. 8.68-8.90. (sample size adjustment for first-order autocorrelation)
% Conover, W., 1980, Practical Nonparametric Statistics, 2nd Edition, John
% Wiley & Sons, New York. 
%
% Deitrich, C.R., and Newsam, G.N., 1997. Fast and exact simulation of 
% stationary Gaussian processes through circulant embedding of the 
% covariance matrix. SIAM Journal on Scientific Computing, 18(4): 1088-1107.
%
% Haan C. T. (2002) Statistical methods in Hydrology, second edition. Iowa
% State University Press, Ames, Iowa.
%
% Ljung, L., 1999. System Identification: Theory for the User (2nd
% Edition). Prentice-Hall, Inc., New Jersey
%
% Panofsky, H. A. and Brier, G. W., 1968.  Some Applications of Statistics 
% to Meteorology.  The Pennsylvania State Uniersity, University Park,
% Pennsylvania
%
% Percival, D.B., and Constantine, W.L.B., 2006. Exact simulation of 
% Gaussian time series from nonparametric spectral estimates with 
% application to bootstrapping. Statistics and Computing, 16: 25-35.
% 
% Snedecor, G. W., and Cochranm W. G., 1989, Statistical Methods, eigth edition,
% Iowa State University Press, Ames, p. 189
%
%*** TOOLBOXES NEEDED 
%
% Statistics
% System Ident
%
%
%*** UW FUNCTIONS CALLED 
%
%
% 'seascorr.m'
% 'acf.m'
% 'climgram.m'
% 'crn2vec2.m'
% 'c132tss.m'
% 'corrdiff.m'
% 'corrone.m'
% 'corrpair.m'
% 'mafilt1.m'
% 'nonan1.m'
% 'trimnan.m'
% 'trailnan.m'
% 'pdgmsim.m'
% 'figsize.m'
% 'textcorn.m'
% 'suplabel.m'
% 'arspectrum.m'
% 'specbt1.m'
% 'sseff.m'
% 'whit1.m'
% 'akaike.m'
% 'pdgmraw.m'
% 'wtsbinom.m'
%     
%     
%     
%*** NOTES
%
%
%
% For brevity in the comments and coding below, P and T denote the first and second
% climate variables read in.  Unless switched as specified by kopt(2) these
% are also defined as the the "primary" and "secondary" climate variables for
% the correlatin analysis. If no input arguments, you are prompted for information
% and to click on files with tree ring data, P, and T.  In "no-argument" mode, 
% the P and T files are assumed to in 13-column ascii (year and jan-to-dec data); and
% the tree-ring series is assumed to be in either 2-column ascii (year 
% or in ".crn-file" decade format as supported by the International Tree-Ring Data 
% Bank. A suffix of "crn" or "CRN" identifies the file as ITRDB
% "decade format"
%
% Analysis period is automatically set from the overlap of tree-ring data and
% climate data.  You can override this default period at a prompt. The
% minimum allowable length of analysis period is 31 years. This limitation is
% forced by the needs of the algorithm of exact simulation, but is also 
% reasonable as time series relationships cannnot be identified with very 
% short series.  Early and late sub-periods for the test of difference of 
% correlations (see input, time_specs) by default are the first and last
% halves of the full-analysis period. You may override these, with the 
% with the constraints that a sub-period cannot be shorter than 
% minlen_sub years (hard-coded in seascorr at 15 yr), and that the early and
% late sub-period may not overlap.
% Because leading monthly climate data is required, the
% analysis period cannot begin before the 2nd growth year after the first
% calendar year with complete monthly climate data.
%
% The main and most important output from seascorr is Figure 1, the bar 
% charts summarizing the monthly and seasonal climate signal in the
% tree-ring series.  Ten other figure windows give supporting or
% diagnostic information that may be useful in interpreting the
% correlations in Figure 1.  The correlations and other statistics are
% stored as output in the structure Result (see above). The 11 figure windows
% are described at the end of the opening comments.
%
% Running modes.  Experienced MATLAB users may want to write a driver script
% that organizes inputs and calls seascorr with input arguments. Such a 
% script can make use of functions crn2vec2 (reads ITDRB-format ".crn" file), 
% and c132tss (converts a 13-col ascii climate file to 3-col). Both functions 
% are available in the "Tree-Ring Matlab Toolbox", at 
% http://www.ltrr.arizona.edu/~dmeko/toolbox.html
% Other users may prefer to call seascorr from the command line with no input
% arguments, as:
%> Result=seascorr
% In this mode, seascorr prompts for all input. 
%
% Regardless of the running mode, you must do some prelimary work before calling
% seascorr. This work includes: 1) gathering the climate and tree-ring
% files, in the required formats, 2) deciding on the ending month of
% tree-growth, and 3) deciding on the the 4 season-lengths.  It is
% recommended that 1 month be used as one of the season lengths so that
% correlations of tree rings with monthly climate can be evaluated.
%
% Climate variables. Two types of climate variables are read in.  The first
% by default is designated "primary" and the second "secondary".  This 
% order of assignment can be reversed depeding on input argument kopt(2).
% The distinction is important because the relationship of tree-ring series
% with primary climate variable is summarized by simple correlations and
% the relationship of tree-ring series with secondary climate variable by
% partial correlations.  Typical use would precipitation (P) as
% primary and temperatre (T) as secondary. 
%
% Other pairs of monthly climate variables may be used instead of
% temperature and precipitation (e.g. PDSI and dewpoint). Units are
% prompted for or read among the input arguments. You are also prompted for
% whether variable is to be seasonalized as a "mean" (e.g. temperature) or
% a "sum" (e.g., precipitation).  Be sure the time series are scaled to
% match the units you specify.  For example, if units of one of the climate
% variables is "mm" and you download monhtly data from the web in tenths of mm,
% multiply the data by 0.1 before calling seascorr. The scaling will not
% affect the correlations or partial correlations, but will ensure that the
% time series plots, scatterplots, etc, are labeled properly.
%
% Tree-ring series.  This series is labeled in plots as "index", and typically
% would be a standard or residual site chronology.  But it might also some
% derived series -- such as a principal component score series from a
% network of chronologies. 
% 
% endmo.  With this input you specify the ending month of the growth-year.
% Correlations are computed for sums or averages of climate data
% ending in each of the 14 months leading up to and including endmo. Endmo
% is an integer, with 1 meaning January and 12 December. 
%
% g.  With this input cell variable you specify the four season-lengths.  
% A season-lengthof 1 gives correlations with individual month's climate.
% The monthly grouping should be row-cell of 4 integers. For example, 
% {1,4,6,12} specifies season-lengths of 1 month, 4 months, 6 months and 
% 12 months.  Seascorr computes and plots 14 correlations for each grouping.
% For example, say the growth year is specified to end with September
% (endmo==9) and g=={1,4,6,12}. For the one-month grouping, correlation 
% is between tree rings and P or T for the 14 months from the previous 
% August to current September.  For the 4-month grouping, m correlations are
% for the 4-month total or average climate ending with the 14 months from 
% previous August to current September, and so forth.  The total number of
% "seasons" is 56 because for each of 4 season-lengths there are 14 ending
% months, and 4x14=56.
%
% Correlation scheme.  Say P is the primary climate variable, T the 
% secondary climate variable and x the tree-ring series. Correlations are
% computed between x and the 56 P series. Partial correlations are then
% computed as follows:
%	Regress x on P and get residuals e1
%	Regress T on P and get residuals e2
% The partial correlations are the simple correlations between e1 and e2.
% The motivation behind the partial correlations is to check for any 
% significant relationship between x and T after both have been adjusted
% for possible linear dependence on P.
%
% kopt(2).  This input option lets the you reverse the normal assignment
% of the first climate variable read in as primary and the second as
% secondary.  By setting kopt(2)==2 and reading P as first variable and T
% as second,the user can readily check for a primary T response,
% and whether there is any residual P relation with tree rings after dependence
% on T is removed from the tree-ring index and P.
%
% nsim: the number of simulations must be set to at least 1000.  A small
% number of simulations makes computation of confidence intervals
% problematic. For example, with 50 simulations, significance at 
% alpha=0.01 cannot be evaluated:  one would need the 0.995 probability of
% the cdf of simulation-based correlations, but would only have Weibull
% formula probility points at 1/51, 2/51,...,50/51 and 50/51, and 
% 50/51= 0.9804 is less than 0.995.  
%
% Missing data.  P, T ad tree-ring data should not have any missing values.
% Any missing values should have been filled in with estimated data
% before calling seascorr.
%
% Significance of correlations. Significance is evaluated by a Monte Carlo
% method using exact simulation.  See Percival and Constantine (2006) for
% details on exact simulaitons. Briefly, exact simulation refers to 
% simulations that retain the spectral properties of the series.  In 
% seascorr it is the tree-ring index that is being simulated.  The period
% for analysis of the tree-ring spectrum is not the full length of 
% tree-ring series, but the correlation analysis period.  The tree-ring
% time series is simulated at least 1000 times (default) by a method 
% that preserves the spectral structure of the original tree-ring data.  
% Probability points of the correlations between these simulated series and 
% the climate variables give empirical confidence intervals for the sample
% correlations computed using the actual tree-ring index.  
%
% Significance of partial correlations.  This significance is also 
% estimated with help of exact simulation. For the sake of illustration,
% let us say the number of simulations is 1000.  1) tree-ring series is simulated
% 1000 times, 2) each simulation is regressed on the primary climate variable
% and a residual series computed, 3) the secondary climate series is also
% regressed on the primary climate variable and the residuals computed, 4)
% the series by (3) is correlated with the 1000 series from (2), and the
% empirical cdf of the 1000 correlations is computed by the Weibull formula,
% p=m/(n+1), were m is rank (with 1 smallest) for simulation-based 
% correlations, and n is the number of simulations.  A plot of p on the ranked
% correlations is a cdf plot, also called a nonexceedance probability plot.
%
% The null hypothesis for testing the correlations or partial correlations 
% is that the population correlation is zero.  The alternative hypothesis is
% that the population correlation is non-zero.  The test is therefore two-
% sided.  A sample correlation is judged significant at alpha=0.05 if it is
% lower than the 0.025 or higher than the 0.975 probability point of the cdf 
% of simulation-based correlations.  Likewise, significance at alpha=0.01
% is linked to the 0.005 and 0.995 probability points.  The non-exceedance
% probability cannot be computed if the sample correlation is outside the
% range of all simulation-based correlations.  In that case the
% nonexceedance probability is set at either 1/(n+1) or n/(n+1).  Thus with
% 1000 simulation, we cannot expect a nonexceedance probability greater
% than 1000/(1001)=0.9990. 
% 
% Color coding. Graphics are optionally in color or black and white, depending
% on setting for kopt(1). In Figure 1, the bar chart of correlations and 
% partial correlations, blue is used by default for the primary climate 
% variable and red for the secondary.  The only departure from this rule is
% if temperature (uniquely identived by code T) happens to be used as the
% primary climate variable. Then the scheme is reversed: red used for T, and
% blue for the other climate variable. If B/W mode (kopt(1)==1), bars are
% not shaded, and significance at the 0.01 or 0.05 level is indicated by a
% symbol above or below the bar. 
%
% time_specs. This input argument specifies the time periods for full analyis
% and for testing for stability of correlations from an "early" to a
% "late" sub-period. By default, the full period is the complete overlap of
% climate and tree-ring data, and the sub-periods are the first and last
% halves of the full period. You may override the defaults, but the full
% period must be at least 31 years in length and sub-periods at least 15
% years in length.  Specified sub-periods must be within the full analyis
% period, and must not overlap.  Otherwise the sub-periods can be located
% anytime within the full period. For example, the full period might be
% 1900-2010 and the sub-periods 1910-30 and 1980-2010.  Because of the need for 
% lagged climate data, the full-analysis period cannot actually begin
% before the third year of available monthly climate data.  For example, if
% the monthly climate data start in January 1901, the default full-analysis
% period starts with year 1903.  
%
% Test for temporal stability of relationships.  The relationships tested
% are those of the tree-ring index with the primary climate variable for the
% seasons that the full analysis identifies as "best" by the criterion of
% highest Pearson correlation for a given season-length. Thus the key
% seasons are defined as the highest-correlated seasons for each of the four
% season-lengths.  For each season-length the null hypothesis is that the
% population correlation coefficient is the same for the early and late
% sub-period.  A difference-of-correlations test, following Snedecor and
% Cochran (1989) and Panofsky and Brier (1968) is done, a test statisic
% computed, and a p-value reported.  A p-value less than 0.05, say,
% indicates we should reject the null hypothesis of equal population
% correlations, and suspect the relationship may be stronger or weaker in
% the late period than in the early period.  The test itself uses a Fisher
% transformation of the sample correlation coefficient, as with non-zero
% population correlations the sample correlations cannot be assumed to be
% normally distributed. Required inputs for the test are the two sample
% correlations and the sample sizes used to estimate the correlations. 
% Seascorr uses "effective" sample size, as defined by Dawdy and Matalas
% (1964) to account, if necessary, for loss of degrees of freedom due to
% autocorrelation in the individual time series.  The adjustment to
% effective sample size uses the lag-1 autocorrelations as computed on the
% full analysis period.  Effective sample size comes into play ONLY if both
% time series have positive lag-1 autocorrelation. Otherwise, the original
% sample size is used in computations. 
%
%
% The 11 figure windows are described next.
%
% Figure 1.  Correlations and partial correlations of tree-ring series with
% seasonalized climate variables.  At top are the simple correlations with
% the primary climate variable.  The correlations are represented by 56
% bars (4 season-lengths, 14 ending months).  At bottom are the partial
% correlations of tree-ring index with secondary climate variable -- after
% controlling for influence of first climate variable. Significance of 
% correlations is coded by colors or symbols. The correlations and 
% partial correlations, as well as other program output, are available to
% the use through output argument Result.  Result is a structure variable,
% defined in the comment section. 
%
% Figure 2. Bar chart of bivariate correlations of the primary with the
% secondary climate variable for each of 56 "seasons" (14 different ending
% months and 4 season-lengths).  A high intercorrelation of these variables
% means that simple correlations of tree-ring series with either one of the
% variables will be distorted by intercorrelation.  This distortion is the
% main reason partial correlations are used in seascorr to summarize
% "independent" influence of the secondary climate variable on the tree-ring
% series.  An approximate 95% confidence interval is included on the plot
% of correlations.  This interval is computed as 1.96 times the square root
% of the sample size for time series used in the correlation analysis.  The
% confidence interval is intended as a rough guide: no adjustments have
% been made for non-normality of data or autocorrelation.
%
% Figure 3.  Time plot and histogram of tree-ring series. Time plot can
% draw attention to trend, cycles, outliers and temporal changes in 
% variability. (The tree-ring series is also plotted as z-scores in each of
% the four panels in Figure 9.). Histogram allows visual assessment of
% normality.  This is complemented by a Lilliefors test, whose results are
% annotated on the plot. Normality of the tree-ring series is important in
% seascorr because exact simulation (Percival and Constantine 2006) applies
% to Gaussian time series.  Non-normality can possibly be handled by
% transforming the tree-ring index beforehand.
%
% Figure 4. Sample spectrum of the tree-ring series. The sample spectrum is
% of interest in seascorr because "exact simulation" as used in seascorr  
% generates simulations that attempt to duplicate the spectrum.  Exact 
% simulation is based many (e.g., 10000) simulations of the tree-ring
% index. Each simulation has a sample spectrum similar in shape to that of
% the observed tree-ring series. The plot shows three lines:
%   1) raw periodogram
%   2) smoothed periodogram -- smoothed by 5-weight binomial filter
%   3) horizontal line at mean periodogram ordinate
% The raw periodogram is the highest-resolution estimate of the spectrum,
% and is what exact simulation simulates the spectrum from. The frequencies
% for the raw periodogram are at f=j/N, j=0,1,...,N/2 cycles per year,
% where N is the padded length of the tree-ring serie.  This padded length
% is the next highest power of 2 larger than the original length of the
% series.  For example, if the series length is 100 yr, N=128.  The
% binomial-smoothed periodogram is shown to emphasize the general
% underlying shape of the spectrum.  The horizontal line at the mean
% periodogram ordinate corresponds to the spectrum of a white noise series
% with the same variance as the tree-ring series.
%
% Figure 5. Stem plot of sample autocorrelation function of the tree-ring
% series at lags 0-20. An approximate 95% confidence interval on the plot
% lets you judge whether autocorrelations are significantly different
% than zero (two-tailed test). The autocorrelation function is important 
% in seascorr because it shows the persistence in the tree-ring series. A 
% gross miss-match in persistence of the tree-ring series and 
% climate variable suggests different dynamics are driving the tree growth
% and climate variables.  Correlations that do not include lag effects can
% be misleading in this situation.  If the standard index is much more
% highly autocorrelated than the primary climate variable, you may want to
% try the residual index as the tree-ring time series in seascorr. 
%
% Figure 6. Bar chart of lag-1 autocorrelation of seaonal time series of
% primary climate variable. The 56 bars in the plot represent 4
% season-lengths, each with 14 different ending months. A
% horizontal dotted line marks the lag-1 autocorrelation of the tree-ring
% series.  Horizontal dash-dot lines mark a 95% confidence interval around
% zero for a two-tailed test of significance of first-order
% autocorrelation.  The confidence interval is computed following 
% Haan (2002).  Ideally, the autocorrelation of the tree-ring series is 
% similar to that of the seasonalized climate variable presumed to drive 
% growth.  A gross miss-match in lag-1 autocorrelation might suggest that 
% some other version of the tree ring index (e.g., residual chronology) be
% used to decipher the climate signal in tree rings. You should not be
% concerned about miss-match in autocorrelation if not significantly
% different from zero (outside the plotted 95% confidence interval).
%
% Figure 7. Climograph of the monthly data for the primary and secondary
% climate variables. The box plots in the climograph summarize the
% distributions of the variables. The climograph shows which months may
% have particularly variable (from year to year) climate, and which months
% have little variation.  One would not expect a strong growth-response to
% a monthly climate variable that is almost constant from year to year.
% In other words, climate must vary to drive variations in growth. 
%
% Figure 8. Scatter plots of tree-ring index on seasonalized primary climate
% variable for the highest-correlated season for each of the four specified
% season-lengths. These plots are graphical confirmation of the
% correlations listed in Figure 10. The scatterplots allow a visual assessment of
% 1) possible influence of outliers on the correlations, and 2) possible 
% curature or other form of nonlinearity in the relationship between tree rings and
% climate. A least-squares-fit straight line and the correlation coefficient 
% are annotated on each plot.  
%
% Figure 9.  Z-score time plots of tree-ring variable and primary climate
% variable for the highest-correlated pair of series for each of the four
% season-lengths.  These plots also include annotated results of test for
% linear trend.  Trend is potentially important because high correlations
% between seaonalized climate variable and tree-ring index can sometimes
% be driven by trend. Each time series is regressed on year. At upper right 
% of each plot is annotation summarizing whether the estimated slope of 
% the trend line is significant.  A p-value of less than 0.01 or 0.05 is 
% noted.  If the p-value is greater than 0.05, annotation is "No trend".
% The z-scores for this plot are computed using the means and standard 
% deviations computed for the analysis period annotated at top 
% of figure.  
%
% Figure 10. Summary text of highest correlations for each of 4
% season-lengths. This window lists the seasons or months
% strongest signal, along with the correlations and their significance. 
% User can flip back and forth between windows 1 and 10 to verify that
% the table entries correspond to the highest bars in the Figure 1 plot
% of correlations for the primary climate variable.
%
% Figure 11. Summary table of results of test for difference of sample
% correlations of seasonalized primary climate variable with tree rings in
% early and late sub-periods.  The sub-periods are the first and last
% halves of the full sample period, by dault.  Or the user may specify any
% two non-overlapping periods.  This window lists the sample correlations
% and a difference-of-correlation test, following Snedecor and Cochran
% (1989) and Panofsky (1968).  Effective sample size -- adjusted downward
% to account for persistence (Dawdy and Matalas 1964) -- is used in
% assessment of significance.  The table lists the correlations and the
% p-valued for the test.  A p-value less than 0.05 means reject the null
% hypothesis that the sample correlations for the early and late
% sub-periods are from the same distribution. The test rests on an
% assumption that the pair of time series are from a bivariate normal
% distribution.  User should beware that this assumption may not be
% satisfied. 
%
%
% STANDALONE VERSIONS
%
% Standalone versions that work on 64-bit Linux, 64-bit windows, 32-bit
% are being developed.  These give the graphics, plust two output files
%   OutSeascorr1.txt:  data for Figure 1 as copy/pastable tables
%   OutSeascor2.txt:  56x9 numeric matrix of correlations, partial
%       correlations, nonexceedance probabilities, etc.. The 56 rows
%       correspond to the 56 groupings (14 ending months x 4
%       season-lengths) in the order shown in Figure 1.  The 9 columns 
%       are defined at the top of OutSeascorr2.txt
% These two files are written to the current working directory
%
%---- REVISION HISTORY
%
% Rev2010-7-7.   Changed a few file-name-interpretation functions to be
% get around a possible problem with not automatically recogizing crs vs 2-col
% chronology files.  New version uses fullfile and fileparts functions 
%
% Rev2010-9-29.  Revised to allow some assessment of temporal stability of
% relationships.  First change is to allow user to specify the start and
% end year for analysis rather than have seascorr automatically use the
% full overlap of climate and tree-ring data.  With this change, the user
% can compare the seasonal correlations for two sub-periods by running the
% program twice.  Second change is to include a test for difference of
% correlations for two specified non-overlapping subperiods.  This test is
% done for the seasonal groupings with highest climate-tree ring
% correlation for each of the four season-lengths.  
%
% Revised2013-01-08.  function subfun07 revised.  Call to importdata no
% longer includes second input argument (to specify separator in columns of
% 13-col input climate series.  Previously used call such as
% A=importdata(filename,' ').   This specifies blanks as the separator.
% But if the file had tabs as separator this would return A as a cell
% variable, rather than as a numeric matrix.  Calling as
% A=importdata(filename), without specifying the separator, seems to return
% A as numeric matric regarless of whether the ascii data in file filename
% is separated by blanks or by tabs.
%
% Revised2014-10-18. Matlab changed how function bar works. 1) To deal with
% that, now have code to find out whether version is earlier than R2014b
% and use version of code in subfun06 accordingly.  Search on "kbar" and
% you will find relevant areas of change in main function.  Then subfun06
% has substantial changes on how to draw the bars. 2) changed some code
% in the subfunctions that make figure windows 10 and 11 by reducing the
% text fontsize from 12 to 10.  Looks better under R2014b graphics. 3)
% changed input reading code to (I hope) work with tree-ring data as 2-col
% correctly. 4) Added subfun21 to write two output ascii files so that
% statistics (e.g., the correlations in Fig 1) are available to standalone
% users.


%-- HARD CODE
% 
nmos = 14; % assuming 14-month window for "ending month"
minlen=31; % minimum allowable length of common period of tree-ring and climatic 
% Thelength of the common period is defined as the longest possible period (years) covered both by 
% tree-ring index and current and lagged (2 yr) climate data. Generally,
% two years of leading climate data are needed, such that the overlap of
% tree-ring data and MONTHLY climate data must be at least 33 yr
minlen_sub = 15;  % minimum allowable length of a period for correlation in testing difference
% of correlations between sub-periods
nsim_default=1000;  % Minimum allowable number of simulations
fout1='OutSeascorr1.txt';
fout2='OutSeascorr2.txt';

% Matlab changed the wayfunction "bar" works with release R2014b.  Seascorr
% must identify version to use correct code in subfun06
vR2014b='8.4.0.150421 (R2014b)'; 
if verLessThan('matlab',vR2014b)
    kbar =1;
else
    kbar= 2;
end


if nargin==0     
    %--- GET TREE-RING SERIES
    
    [filetree,pathtree]= uigetfile('*.*','Click on the tree-ring input file (must be .crn or 2-col .txt ascii)');
    pftree=fullfile(pathtree,filetree);
    [pathstr, name, ext] = fileparts(pftree);
    if strcmp(upper(ext),'.CRN')
        [x,s,yr]=crn2vec2(pftree);
        yrx=yr;
        clear s;
    else
        strmess ={[pftree ' is assumed to be 2-column ascii, with no extra leading or trailing rows, and all numeric'],...
            'The columns should be the year and the tree-ring index. '};
        uiwait(msgbox(strmess,'Message','modal'));
%         delimiter=' ';
%         A = importdata(pftree,delimiter);
        A = importdata(pftree);
        if iscell(A);
            A=str2num(char(A));
            yrx=A(:,1);
            x=A(:,2);
        elseif isstruct(A)
            error(['Tree-ring data in ' pftree ' was read in as a structure variable.  Check that the 2 cols are separated by tab for all rows or space for all rows'])
        elseif isnumeric(A);
            yrx=A(:,1);
            x=A(:,2);
        else
            error('A must be numeric or cell');
        end
        
        clear A strmess delimiter
    end
    [x,yrx]=trimnan(x,yrx); % trim of leading and trailing NaN
    
    

    %--- GET CLIMATE SERIES (ASSUMED 13-COL ASCII) AND
    %    CONVERT TO 3-COLUMN (YEAR, MONTH, DATA)
    
    % Primary
    [fileP,pathP]= uigetfile('*.*','Click on the file with primary climate data (e.g., P), assumed 13-col ascii');
    pfP = [pathP fileP];
    P = subfun07(pfP); 
    
    % Secondary
    [fileT,pathT]= uigetfile('*.*','Click on the file with secondary climate data (e.g., T), assumed 13-col ascii');
    pfT = [pathT fileT];
    T = subfun07(pfT);
    
    
   
    %---PROMPT FOR TYPE OF CLIMATE DATA,UNITS, SEASONALING METHOD
    
    kwh1=1;
    while kwh1==1;
        prompt={'Enter type of primary climate data:',...
            'Enter one-letter code for primary data:',...
            'Enter units for primary data (no quotes or parentheses):',...
            'Enter seasonalizing method for primary climate data (sum or mean):'};
        name='Climate Data';
        numlines=1;
        defaultanswer={'Precipitation','P','mm','sum'};
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        name_clim1 = answer{1};
        code_clim1 = answer{2};
        units_clim1 = answer{3};
        meth_clim1 = answer{4};
        if strcmpi(meth_clim1,'SUM')
            kmeth_clim1=1;
            kwh1=0;
        elseif strcmp(upper(meth_clim1),'MEAN')
            kmeth_clim1=2;
            kwh1=0;
        else
            uiwait(msgbox(['Must enter ''mean'' or ''sum'' as seasonalizing method'],'Message','modal'));
        end
        
    end
    
    kwh1=1;
    while kwh1==1;
        prompt={'Enter type of secondary climate data:',...
            'Enter one-letter code for secondary data:',...
            'Enter units for secondary data (no quotes or parentheses):',...
            'Enter seasonalizing method for secondary climate data (sum or mean):'};
        name='Climate Data';
        numlines=1;
        defaultanswer={'Temperature','T','deg C','mean'};
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        name_clim2 = answer{1};
        code_clim2 = answer{2};
        units_clim2 = answer{3};
        meth_clim2 = answer{4};
        if strcmp(upper(meth_clim2),'SUM')
            kmeth_clim2=1;
            kwh1=0;
        elseif strcmp(upper(meth_clim2),'MEAN')
            kmeth_clim2=2;
            kwh1=0;
        else
            uiwait(msgbox(['Must enter ''mean'' or ''sum'' as seasonalizing method'],'Message','modal'));
        end
    end
    if length(code_clim1)~=1 || length(code_clim2)~=1  ||strcmp(code_clim1,code_clim2)
        error(['Codes for climate variables cannot be the same, and must be 1 letter only']);
    end
    
    % Store text information for use in function calls
    textinfo={name_clim1,code_clim1,units_clim1,meth_clim1,name_clim2,code_clim2,units_clim2,meth_clim2};
    
    
    %--- PROMPT FOR SEASON SETTINGS AND NUMBER OF SIMULATIONS
    
    kwh=1;
    while kwh;
        prompt={'Enter ending month of growth season (1 = jan, 12 = dec):',...
            'Enter the number of months in each of the 4 seasonal groupings:',...
            'Number of simulations for estimation of confidence levels (at least 1000)'};
        name='Season and simulation settings';
        numlines=1;
        defaultanswer={'9','[1 3 6 12]',num2str(nsim_default)};
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        endmo = str2num(answer{1});
        gtemp = str2num(answer{2});
        nsim = str2num(answer{3});
        if nsim<nsim_default ||  ~ismember(endmo,[1:12]) 
            uiwait(msgbox(['Ending months must be integer in range 1:12; number of simulations must be at least ' num2str(nsim_default)],'Message','modal'));
        elseif  ~all(ismember(gtemp,[1:12]))
            uiwait(msgbox('Season-lengths must be at least 1 month, no more than 12 months','Message','modal'));
        elseif length(gtemp)~=4;
            uiwait(msgbox('Must specify exactly 4 different season-lengths','Message','modal'));
        elseif  ~all(diff(gtemp)>0)
            uiwait(msgbox('Specify season-lengths in order of increasing length','Message','modal'));
        else
            kwh=0;
        end
        end; % while
    g = cell(1,4);
    for n = 1:length(g);
        g{n}=gtemp(n);
    end
    
    
   %--- PROMPT FOR COLOR OPTION AND FOR SWITCH OF ROLES OF PRIMARY AND 
   %    SECONDARY CLIMATE VARIABLES
   
   kopt=nan(1,2);
   kopt(1) = menu('Choose color option for plot','Color','B/W');
   kopt(2) = menu('Optional switch of primary and secondary climate variables',...
       [code_clim1 ' as primary and ' code_clim2 ' as secondary'],...
       [code_clim2 ' as primary and ' code_clim1 ' as secondary']);
else; % "driver-script" mode
    name_clim1=textinfo{1};
    code_clim1=textinfo{2};
    units_clim1=textinfo{3};
    meth_clim1=textinfo{4};
    name_clim2=textinfo{5};
    code_clim2=textinfo{6};
    units_clim2=textinfo{7};
    meth_clim2=textinfo{8};
    
    if strcmp(upper(meth_clim1),'SUM')
        kmeth_clim1=1;
    elseif strcmp(upper(meth_clim1),'MEAN')
        kmeth_clim1=2;
    else
        error('method for seasonaling not ''sum'' or ''mean''');
    end
    if strcmp(upper(meth_clim2),'SUM')
        kmeth_clim2=1;
    elseif strcmp(upper(meth_clim2),'MEAN')
        kmeth_clim2=2;
    else
        error('method for seasonaling not ''sum'' or ''mean''');
    end
    
    if ~iscell(time_specs) || length(time_specs)~=3
        error('time_specs must be cell of length 3');
    end
    
    
    
end; %      if nargin==0;



%--- INPUT CHECK

L = [isvector(x)  size(x,1)>12];
if ~all(L);
    error(' x must be cv of length greater than 12');
end
L = [isvector(yrx)  size(yrx,1)==size(x,1)];
if ~all(L);
    error(' yrx must be cv of same length as x');
end

[mP,nP]=size(P);
[mT,nT]=size(T);
L = [mP>120 nP==3  nT==3  mT>144];
if ~all(L);
    error('P and T must be row size at least 144 (12 yr) , with 3 cols');
end
L= all((P(:,2)>=1 & P(:,2)<=12)) & all((T(:,2)>=1 & T(:,2)<=12));
if ~all(L);
    error('Col 2 of P and T must be between 1 and 12');
end

L =   diff(P,1)==1 | diff(P,1)==0;
if ~all(L);
    error('col 1 of P must inc by 0 or 1');
end
L =   diff(T,1)==1 | diff(T,1)==0;
if ~all(L);
    error('col 1 of T must inc by 0 or 1');
end


L = [isscalar(endmo) & ismember(endmo,[1:12]) ];
if ~all(L);
    error('endmo must be scalar in range of {1 12}');
end

if ~iscell(g);
    error('g must be a cell');
end
[mg,ng] = size(g);
L = [mg==1    ng==4];
if ~all(L);
    error('g must be row-cell with 4 elements');
end
for n = 1:length(g);
    gthis=g{n};
    L = ismember(gthis,[1:12]);
    if ~L
        error('element of g must be between 1 and 12');
    end
end

L = iscell(textinfo) && (length(textinfo)==8);
if ~L
    error('textinfo must be a cell of length 8');
end


% Debug --- next 3 lines
if nsim<nsim_default;
    error(['nsim must be at least ' num2str(nsim_default) ' (you set nsim= ' num2str(nsim) ')']);
end



%---  ORGANIZE MONTHLY TSS INTO ANNUAL TIME SERIES MATRIX OF MONTHLY AND SEASONAL
%     CLIMATE VARIABLES. SEASONALIZED DATA WIL BE STORED IN MATRICES
%     U AND V 
% Say P is the primary climate variable and T the secondary.
% Which climate variable becomes U and which becomes V depends on setting
% for kopt(2).  
% kopt(2)==1:   P becomes U, T becomes V; correlations are between
%   tree-ring index and P; partial correlations are between tree-ring index
%   and T, after removing linear dependence on P from both
% kopt(2)==2:   P becomes V, T becomes U; correlations are between
%   tree-ring index and T; partial correlations are between tree-ring index
%   and P, after removing linear dependence on T from both

if kopt(2)==1;
    [U,yrU]=subfun01(P,endmo,g,kmeth_clim1,nmos); % Primary goes into U
    [V,yrV]=subfun01(T,endmo,g,kmeth_clim2,nmos); % Secondary into V
    var1a=code_clim1; % 1-letter code of primary
    var1b=name_clim1; % name of primary
    var1c=textinfo{3}; % units of primary
    var2a=code_clim2; % 1-letter code of secondary
    var2b=name_clim2; % name of secondary
    var2c=textinfo{7}; % units of secondary
else
    [U,yrU]=subfun01(T,endmo,g,kmeth_clim2,nmos); % Secondary into U
    [V,yrV]=subfun01(P,endmo,g,kmeth_clim1,nmos); %  Primary into V
    var2a=code_clim1; 
    var2b=name_clim1;
    var2c=textinfo{3}; % units of primary
    var1a=code_clim2;
    var1b=name_clim2;
    var1c=textinfo{7}; % units of primary
end


%-- TRIM TREE-RING AND CLIMATE DATA TO COMMON PERIOD
[yr1,x1,U1,V1]=subfun02(x,yrx,U,yrU,V,yrV);
ntrim = length(yr1);
ncol = size(U1,2);


%--- ALLOW USER TO SPECIFY PERIOD FOR ANALYSIS, SUB-PERIODS FOR TEST OF
%  DIFFERENCE IN CORRELATIONS, AND MINIMUM ALLOWABLE LENGTH OF SERIES FOR
%  CORRELATION ANALYSIS

if nargin~=0; % if driver-script mode
    % Some minimal checking of the input analysis periods
    [yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2,Lsub] =subfun20(time_specs,yr1,minlen,minlen_sub);
        
else % call subfun13 for point-and-click input and checking of analysis period and subperiods
    [yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2,Lsub]=subfun14(yr1(1), yr1(end),minlen,minlen_sub);
end; % if not point-and-click mode


%---  IF NEEDED, TRIM THE DATA TO SPECIFIED FULL-ANALYSIS PERIOD

if yrgo~=yr1(1) || yrsp ~=yr1(end);
    L=yr1>=yrgo & yr1<=yrsp;
    yr1=yr1(L);
    x1=x1(L);
    U1=U1(L,:);
    V1=V1(L,:);
else
end




%--- SAY X IS A TREE-RING SERIES, P IS THE PRIMARY CLIMATE VARIABLE AND T IS
% THE SECONDARY CLIMATE VARIABLE. COMPUTE VERSIONS OF X AND T WITH THEIR LINEAR
% DEPENDENCE ON P REMOVED.   
%
% In the call to subfun03 (below), x1 is the
% tree-ring series; U1 is a matrix whose cols are the primary climate
% variable for different season-lengths and ending months; and V1 is the
% secondary climate variable for different season lengths and ending
% months.  Any reversal of roles of input climate variables as primary and
% secondary (as stipulated by kopt(2)) has already been done.
%
% X1 is returned as the matrix of residuals of tree-ring on primary climate
% T1 is returned as the matrix of residuals of secondary climate on primary
%   climate
[X1,T1]=subfun03(x1,U1,V1);



%--- COMPUTE SAMPLE CORRELATIONS
% 
% In the following call to subfun04, input arguments are as follows:
% U1: time series matrix of seasonal series of primary climate variable
% x1: vector of tree-ring series
% X1: time series matrix of tree-ring series adjusted for linear dependence
%       on primary climate variable in each season
% T1: time series matrix of seasonal series of secondary climate variable
%       adjusted for linear dependence on primary climate variable
%
% Output r1 is a vector of simple correlations of x1 with cols of U1.
% Output r2 is a vector of partial correlations, which are identically the
%   simple correlations of cols of X1 with corresponding cols of T1
% Output Highr is structure storing series and metadata needed later for
%   scatterplots and time series for the highest-correlated seasons of
%   primary climate variable and tree-ring index
[r1,r2,Highr]=subfun04(x1,X1,U1,T1);
Highr.id = var1a; % 1-letter code of primary climate variable
Highr.nm = var1b; % full name ...
Highr.units = var1c; % units;
Highr.yrx = yr1; % year vector for correlation analysis
Highr.g = g; % specifies the four season-lengths


%--- SIMULATE THE TREE-RING SERIES BY EXACT SIMULATION; COMPUTE CORRELATIONS
% OF SIMULATED SERIES WITH SEASONALIZED PRIMARY CLIMATE VARIABLE.  ALSO SIMULATE
% EACH OF THE "ADJUSTED" TREE-RING SERIES AND SECONDARY CLIMATE SERIES (ADJUSTED
% FOR REMOVAL OF LINEAR DEPENDENCE ON PRIMARY CLIMATE VARIABLE), AND COMPUTE CORRELATIONS
% OF ADJUSTED TREE-RING INDEX WITH ADJUSTED SECONDARY CLIMATE VARIABLE.
% THEN USE THE EMPIRICAL DISTRIBTIONS OF THE CORRELATIONS FROM THE
% SIMULATIONS TO COMPUTE PROBAILITY POINTS FOR THE OBSERVED CORRELATIONS r1
% AND r2. nsim IS THE NUMBER OF DESIRED SIMULATIONS

[p1,p2]=subfun05(x1,U1,V1,nsim,r1,r2); % x1 is tree-ring index, 



%--- COMPUTE PEARSON r BETWEEN PRIMARY AND SECONDARY CLIMATE VARIABLES

rtemp = repmat(NaN,ncol,1);
for n = 1:ncol;
    u = U1(:,n);
    v = V1(:,n);
    r = corrcoef([u v]);
    rtemp(n) = r(1,2);
end
% Compute approx 95% CI for correlations between primary and secondary
% climate variables.  No adjustment for any autocorrelation, non-normality,
% etc.
rtemp_95 = 1.96/sqrt(length(u));  


Result.r1=r1;
Result.r2 = r2;
Result.r3 = rtemp;
Result.r3_95 = rtemp_95;
clear rtemp_95
Result.p1=p1;
Result.p2=p2;
Result.yrgo = yrgo;
Result.yrsp = yrsp;
Result.nsim=nsim;
Result.nmos=nmos;
Result.endmo=endmo;
Result.g=g;



%---- AUTOCORRELATION COMPUTATION


Result.r4 = nan(4*nmos,1); % to hold first order autocorrelation of primary climate variable
Result.r5 = nan(4*nmos,1); % to hold first order autocorrelation of residual of secondary climate variable
%   regressed on primary climate variable
Result.r6 = nan(5,1); % lag 1-5 autocorrelation of tree-ring series

for n=1:ncol;
    u = U1(:,n);
    v = T1(:,n);
    [r,SE2,r95]=acf(u,3,[1 1]);
    Result.r4(n)=r(1);
    [r,SE2,r95]=acf(v,3,[1 1]);
    Result.r5(n)=r(1);
end;
for n = 1:5;
    [r,SE2,r95]=acf(x1,5,[1 1]);
    Result.r6(:)=(r(1:5))';
end



% MAIN FIGURE 

title1str=['Correlations and partial correlations; analysis period: ' num2str(yrgo) '-'  num2str(yrsp)];
[Stemp,Htemp,mlab,nms_end]=subfun06(Result,g,kopt,title1str,textinfo,kbar);
Result.S=Stemp;
Highr.mlab=mlab;
Highr.nms=nms_end;



%--- SUPPLEMENTARY FIGURES 2-7
subfun08(Result,x1,yr1,U1,V1,T1,kopt,textinfo);


%--- SCATTERPLOTS: 4-PANEL, OF TREE-RING VS CLIMATE FOR BEST SEASONS
subfun11(Highr);


%--- TIME PLOTS: 4-PANEL, OF TREE-RING VS CLIMATE FOR BEST SEASONS
subfun12(Highr);



%--- SUMMARY TEXT FIGURE WINDOW
Result.H = subfun10(Result,Htemp,var1a,var2a);
figure(10); % Bring summary text figure to front




%--- TEST OF DIFFERENCE OF CORRELATION IN SUB-PERIODS

if Lsub==0;
     %disp(['Sub-period test of correlations will be skipped because ' num2str(yrgo1) '-' num2str(yrsp1) ' or ' num2str(yrgo2) '-' num2str(yrsp2)  ' less than ' num2str(minlen_sub) ' yr']);
    disp(['Sub-period test of correlations will be skipped']);
else
    Result.subtest=subfun17(Highr,yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2);
end

figure(10); % Bring summary text figure to front


%--- STORE DESCRIPTIONS IN STRUCTURE OUTPUT

if nargin~=0;
    filetree='see calling script';
    fileP='see calling script';
    fileT='see calling script';
    str_mode='Called from a driver-script';
else
    str_mode='Run in ''point-and-click'' mode';
end

Result.what =char({['Results of seascorr run on ' datestr(date)],...
    ['    ' str_mode],...
    ['Input files = ' filetree ', ' fileP ', ' fileT],...
    'Correlation of tree-ring series with seasonal climate variables',...
    '(Note: ''P'' and ''T'' are used below to represent primary and secondary',...
    '  climate variables, respectively, and do not necessarily mean',...
    '  ''precipitation'' and ''temperature''. ''x'' is used to represent the',...
    '  tree-ring series',...
    '',...
    'Result has fields:',...
    '',...
    '   .S {1 x4}s Listing of correlations and partial correlations (data for figure 1)',...
    '   .H (?x?}s text summary of highest correlations for each of the four season-lengths',...
    '   .r1 (56 x 1)r correlations of x with P',...
    '   .r2 (56 x 1)r partial correlations of x with T. Some denote as r_T.P',...
    '   .p1 (56 x 1)r  empirical non-exceedance probabilities of r1',...
    '   .p2 (56 x 1)r  empirical non-exceedance probabilities of r2',...
    '   .yrgo (1 x 1)i start year of correlation period',...
    '   .yrsp (1 x 1)i  end year of correlation period',...
    '   .nsim (1 x 1)i number of simulations used in exact simulations',...
    '   .endmo (1 x 1)i  ending month of growth season',...
    '   .g {} 1 x 4 number of months in groupings (see inputs) ',...
    '   .nmos (1 x 1)i number of months in monthly climate window (e.g., 14)',...
    '   .r3 (56 x 1)r  Pearson r between P and T',...
    '   .r3_95 (1x1)r approximate 95% confidence interval for correlations r3',...
    '   .r4 (56 x 1)r  first order autocorrelation of P',...
    '   .r5 (56 x 1)r first order autocorrelaton of T.P',...
    '   .r6 (5 x 1)r lag 1-5 autocorrelations of x',...
    '   .subtest -- structure with detailed results of test for difference of ',...
    '       correlation in early and late sub-periods. Refer to Result.subtest.what',...
    '       for definition of fields'});


%--- WRITE OUTPUT FILES FOR STANDALONE USERS

subfun21(Result,fout1,fout2);
 



%*** SUBFUNCTIONS

function [Y,yrY]=subfun01(X,endmo,g,k,nmos)
% Convert 3-col monthly time series climate series into annual time series
% of monthly and seasonal climate variables
%
% X  is a 3-col series -- year, month, value of P or T or whatever
% endmo  is specified ending month of growth season (e.g., 9 is September)
% g is a row-cell, 4 elements, with the numbers of months in "seasons"
% k is option for P (k==1) or T (k==2);  sum is used for P,
%   and average for T
%
% Y is an annual tsm with 56 columns, one for each
% end-month/number-of-months combination
% yrY is year vector for Y
%   For example, if g ={1,3,6,12} and endmo==9, the first 14 cols of Y are
%   1-month-total P for ending months August of previous year through Sept
%   of current year; the next 14 cols of Y are 3-month total P for the
%   periods with the same ending months, and so on
%
% It is assumed that X is a 3-col time series structure that begins with Jan of the first year 
% and ends with Dec of the last year
%
% NaN in input.  NaNs are allowed in the input.  This function uses
% function nonan1 to find out the longest unbroken stretch of years with no
% missing data in the output matrix Y, and truncates it if necessary to
% that stretch.  An error is returned if the operation results in fewer
% than 10 years of observations.


j=X(:,2); % month
L= j==endmo;
i2 = find(L);
X = X(1:i2(end),:); % truncate X to end with the specified ending month of "growth year"
[mX,nX]=size(X);
t = (1:mX)'; % fake "year"
x = X(:,3); % cv of the data
j = X(:,2);
yrX = X(:,1); % actual calendar year of data in X
ngrp = length(g); % number of seasonal groupings; I'm using 4 as reasonable for plotting purposes

if ngrp~=4;
    error('Please use exactly 4 seasons (length of g should be 4');
end
if g{1} ~= 1;
    error('Number of months in first monthly grouping (g{1}) must be 1');
end

G = cell(ngrp,1); % to eventually hold the annual time series matrices for each seasonal grouping

% Compute and store the seasonalized time series
for n = 1:ngrp;
    m=g{n}; % number of months in grouping
    [s,ts]=mafilt1(x,t,m,2); % moving average, collated to ending month
    mdrop = length(x) -length(s); % lose this many leading values in taking the m-month average
    yr = yrX;
    month = j;
    if mdrop>0;
        month(1:mdrop)=[];
        yr(1:mdrop)=[];
    end

    % Because we assume a 14-month window, make s,yr, month evenly
    % divisible by 14
    itemp = mod(length(s),nmos);
    if itemp>0;
        s(1:itemp)=[];
        yr(1:itemp)=[];
        month(1:itemp)=[];
        ts(1:itemp)=[];
    end


    [ms,ns]=size(s);
    i4 = (1:ms)'; % row index to s
    % compute ending row index
    i2 = flipud((ms:-12:14)');  % cv of ending rows
    I2 = repmat(i2,1,14);
    i3 = (13:-1:0);
    I3 = repmat(i3,length(i2),1);
    I4 = I2 -I3;
    Z = s(I4);
    if k==1; % precip
        Z = Z*m; % sum
    else
    end
    yrZ = (yr(end:-12:14));
    yrZ = flipud(yrZ);
    [mZ,nZ]=size(Z);
    if mZ~=length(yrZ);
        error(['Z row-size = ' num2str(mZ) ', but yrZ is length ' num2str(length(yrZ))]);
    end
    G{n}=[yrZ Z];
end
yron = repmat(NaN,ngrp,1);
yroff = yron;
for n = 1:ngrp;
    Z = G{n};
    yron(n) = Z(1,1);
    yroff(n) = Z(end,1);
end
yron = max(yron);
yroff = min(yroff);

% Put all seasonally grouped series into a single matrix, Y
ncols = 14*ngrp;
yr = (yron:yroff)';
nyears = length(yr);
Y  = repmat(NaN,nyears,ncols);
for n =1:ngrp;
    Z=G{n};
    yrZ = Z(:,1);
    Z = Z(:,2:end);
    L = yrZ>=yron & yrZ<=yroff;
    jgo = 1 + (n-1)*14;
    jsp = jgo+13;
    Y(:,jgo:jsp) = Z(L,:);
end %end; % for n = 1:ngrp;
yrY = yr;


%--- TRUNCATE TO UNBROKEN (NO MISSING DATA) SECTION

[yrgo2,yrsp2]=nonan1(Y,yrY);
L = (yrY>=yrgo2 & yrY<=yrsp2);
if sum(L)<10;
    error('Fewer than 10 years of unbroken climate data');
end
Y = Y(L,:);
yrY = yrY(L);


function [yr,x,P,T]=subfun02(x,yrx,P,yrP,T,yrT)
% Trim time series P,T,x to a common period

yrgo = max([yrx(1) yrP(1) yrT(1)]);
yrsp = min([yrx(end) yrP(end) yrT(end)]);

L = yrx>=yrgo & yrx<=yrsp;
x=x(L);
yr=(yrgo:yrsp)';

L = yrP>=yrgo & yrP<=yrsp;
P=P(L,:);

L = yrT>=yrgo & yrT<=yrsp;
T=T(L,:);
if yrsp-yrgo+1<10;
    error([num2str(yrgo) '-' num2str(yrsp) ': overlap of tree rings and climate less than 10 years']);
end



function [X1,T1]=subfun03(x,P,T)
% Computes "adjusted" T and x.  Ajusted means having had removed the linear
% dependence on P.  X1 are the residuals of x on P.  T1 are the residuals
% on T on P.  X1 and P1 have 56 columns because assume 4 "seasonal"
% groupings and a 14-month window
%
% "P" and "T" are nominal terms, used for convenience.  They may represent
% "Precipitation" and "Temperature", but that depends on whether those are
% the two climate variables read in by the calling function seascorr, and 
% also on the setting of kopt(2) in seascorr.  The actual definitions of
% P and T are unimportant to subfun03.
%
% Assumed that calling function checks for proper time coverage
%
% X1 is (? x 56) time series matrix of residuals from regression of
% tree-ring index on P for each of the 56 grouping.  Why 56?  Because
% assume 4 goupings (e.g., 1 month, 3 month, 6 month, 12 month) and a
% 14-month window
%
% T1 is similar matrix of residuals from regression of T on P
%
% Purpose: produce same-size matricex X1 and T1 whose paired columns can be
% correlated to get "partial correlations"

[mP,nP]=size(P);
X1=repmat(NaN,mP,nP);
T1 = repmat(NaN,mP,nP);


for n= 1:nP;
    
    % Regress x on P and put residuals in a col of X1
    z=x;
    u=P(:,n);
    v=T(:,n);
    X=[ones(mP,1) u];
    b = X\z;
    zhat = X*b;
    X1(:,n)=z-zhat;

    % Regress T on P and put residuals in a col of T1
    b=X\v;
    vhat = X*b;
    T1(:,n)=v-vhat;
end




function [r1,r2,Highr]=subfun04(x,X1,P,T1)
% Compute sample correlations; get index to ending month for season of
% highest correlation for each season-length; store the index and
% corresponding time series in a structure that seascorr can later used to
% make scatters and time plots
%
% x is the col vector of tree-ring index
% X1 is matrix of resids from regession of index on P
% T1 is matrix of resids from regression of T on P
% P is a matrix of precip
%
% The above matrics have 56 cols
% It us assumed that calling function has checked that all variables have
% same time coverage
%
% r1 is simple corr between index and monthly or seasonal P
% r2 is partial r between index and T (dependence of both x and T on P
% removed beforehand
% Highr: structure with data and information that will be used by seascorr
% to make scatters of tree-ring on primary climate variable for the
% strongest relationship fro each of 4 season-lengths

r1 = (corrone(x,P))'; % correl of index with each monthly and seasonal P series
[mP,nP]=size(P);
r2 = repmat(NaN,nP,1); % to hold partial r of index with T after both adjusted for P

% Compute correlations  r_x,T.P, meaning partial corr of index with T after
% index and T have first been adjusted to remove linear dependence on P
for n = 1:nP;
    u=X1(:,n);
    v=T1(:,n);
    r = corrcoef([u v]);
    r2(n) = r(1,2);
end

% Get the highest absolute correlations for each season length;
Pfour = repmat(NaN,mP,4); % to store the seasonal climate series, primary variable
iend = repmat(NaN,4,1); % index to the 14 ending months, to the ending month with
% highest r for each of 4 season-lengths
for k =1:4; % loop over season-lengths
    kgo = (k-1)*14+1; % start index for the first of 14 series or correlations
    ksp = kgo+13; % end index...
    rtemp = r1(kgo:ksp); % pull the 14 correlations
    [rmax,imax]=max(abs(rtemp)); % imax marks whic of the 14 correls is highest
    jmax = imax + (k-1)*14; % index to the 56 series
    Pfour(:,k)=P(:,jmax);
    iend(k)=imax;
end; % loop over season-lengths
Highr.P = Pfour; % primary climate series
Highr.x = x; %  tree-ring series
Highr.i14 = iend; % index to ending month (f 14) 




function [p1,p2]=subfun05(x,U,V,nsim,r1,r2)
% Simulate time series of x and compute correlations of 1) simulated tree-ring
% index with series in U, 2) simulated time series of cols of X1 wit cols
% of V
% x is the tree-ring series
% U is the primary climate variable
% V is the secondary climate variable
% nsim is number of desired simulations
% r1 is observed sample correlation of x with primary clim variable for
%   each season
% r2 is observed partial correlation of x with secondary clim variable for
%   each season (controlling for primary climate variable)

%--- EXACT SIMULATIONS OF THE TREE-RING SERIES

mtaper=0.1;
kopt = 1; % will force means and std devs of simulated series to be same and equal to those of observed
Result=pdgmsim(x,nsim,mtaper,kopt); % Result .Y has simulated series
Y = Result.Y;


%---- SIZE VECTORS TO STORE CORRELATIONS

[mU,nU]=size(U);
p1 = repmat(NaN,nU,1); % correlations, for nU seasons
p2 = repmat(NaN,nU,1); % partial correlations


%---   PRIMARY CLIMATE VARIABLE CORRELATION WITH SIMULATED TREE RINGS

for n = 1:nU; % loop over the climate seasons
    rthis1 = r1(n); % precip sample correlation
       
    %-- correlation -- precipitation
    r = (corrone(U(:,n),Y))'; % correlations with simulated series
    rabs=abs(r); % absolute correlations
%     if abs(rthis1)>max(rabs);
%         nbigger=0.5;
%     elseif abs(rthis1)<min(rabs);
%         nbigger=nsim+0.5;
%     else
%         nbigger = sum(rabs>abs(rthis1));
%     end
%     pval = nbigger/(nsim+1);
%     p1(n)=pval;
    p1(n)=subfun13(rthis1,r);
end; % for n = 1:nU; % loop over the climate seasons


% %---   SECONDARY CLIMATE VARIABLE PARTIAL CORRELATION WITH SIMULATED SERIES
%  Method
% 1) Pull a simulated tree-ring series y, 56 series U and 56 series V
% 2) Compute the 56 series of residuals of y on U
% 3) Compute the 56 series of residuals of cols of V  on corresp cols of U
% 4) compute simple correlations between pairs of those series (56 corrs)
% 5) repeat 1-3 for all 1000 simulations
% 6) compared the observed partial correlaton for each seasonal grouping with
%    the 1000 correlations for the simulations; compute probability point

%--- partial correlations, x.U with V.U
R = repmat(NaN,nsim,nU); % to hold the correlations with simulated series
for j = 1:nsim; % repeat for each simulation
    y = Y(:,j); % a simulated tree-ring series
    [X1,T1]=subfun03(y,U,V); % X1, T1 are tree-rings and secondary climate
    %      variable with dependence on primary climate variable removed  removed
    for k = 1:nU; % for each of nU seasons, compute correlation of residual from regression
        %  of the simulated tree-ring index on the primary climate variabl
        %  with the residuals of the secondary climate variable on the
        %  primary climate variable
        rtemp = corrcoef([X1(:,k)  T1(:,k)]);
        R(j,k) = rtemp(1,2);
    end
end;

% Compute empirical probability points of observed partial correlation for
% each of the nU season based on the cdfs of partial correlations for the
% simulations
for n = 1:nU; % loop over the climate seasons
    rthis2 = r2(n); % temperature sample partial correlation
    
    %-- correlation -- precipitation
    r = R(:,n); % correlations with simulated series
    rabs=abs(r);
%     if abs(rthis2)>max(rabs);
%         nbigger=0.5;
%     elseif abs(rthis2)<min(rabs);
%         nbigger=nsim+0.5;
%     else
%         nbigger = sum(rabs>abs(rthis2));
%     end
%     pval = nbigger/(nsim+1);
%     p2(n)=pval;
    p2(n)=subfun13(rthis2,r);
end; % for n = 1:nU; % loop over the climate seasons

function [S,H,mlab,nms_end]=subfun06(Result,g,kopt,tit1,text1,kbar)
%
% Draw plots with correlations and partial correlations
%
% kopt is (1 x 2)i
%  kopt (1) is color control
%   ==1 color
%   ==2 B/W
% tit (1 x ?)s label
% text1 is cell of length 8 with elements 1-4 the name, code, units and
%   seasonalizing method for first climate variable read in and elements 5-8
%   the same for the second climate variable read in.  
% kbar (1 x1)i option to handle Matlab change in bar function
%   ==1 version before R2014B
%   ==2 R2014B or later
% g{1 x 4}i  number of months in each of the 4 seasonal groupings
% S {1x4}s  text summaries for figure 1
% mlab = month labels for 14 ending months of seasons
% nms_end = readable labels corresponding to mlab

close all

if kopt(2)==1;
    var1a=text1{2};  % 1-letter code of primary climate variable
    var2a=text1{6}; % 1-letter code of secondary ...
else
    var1a=text1{6}; % 1-letter code of primary climate variable
    var2a=text1{2}; % 1-letter code of secondary ...
end



nmos = Result.nmos;
endmo = Result.endmo;
ylab1 =['r_{x,' var1a '}'];
ylab2=['r_{x,' var2a '.' var1a '}'];

r1 = Result.r1;
r2=Result.r2;
p1 = Result.p1;
p2 = Result.p2;


%*****************  SET UP THE COLOR TRIPLETS FOR COLOR AND B/W PLOTS
%
% This section hard-coded.  Normally no need to change it.  But one
% may want to play with changes. The triplets control the density of shading
% for confidence bands.  Rows 1-3 give colors for 95% 90% and other for
% primary limate variable;  rows 4-6 for secondary climate variable; 
% Rows 7-9 give B/W colors that apply to both if B/W option used
% 
% Note that the correlations of tree-ring index with primary climate
% variable are to be in the top plot of figure 1, and that the
% partial correlations of index with the secondary climate variable are to
% be in the bottom plot.  Color coding generally is blue for the primary
% climate variable and red for the secondary.  But.... this is overruled
% whenever temperature (uniquely identified by code "T") happens to be one
% of the climate variables.  Then bar charts for T use red and
% charts for the other climate variable use blue regardless of assignment
% of the two variables as primary and secondary


% Top plot in blue, bottom in red, unless kopt(2) says switch the first and
% second read-in climate variables such that second read in is primary and
% first read in is secondary
if kopt(2)==1;
    C = [0 0 1; .7 .7 1; 1 1 1; 1 0 0; 1 .7 .7; 1 1 1; .2 .2 .2; .6 .6 .6; 1 1 1];
else; % this code 
    C = [1 0 0; 1 .7 .7; 1 1 1; 0 0 1; .7 .7 1; 1 1 1; .2 .2 .2; .6 .6 .6; 1 1 1];
end

% Override to make sure T variable always has the red
if strcmp(upper(var1a),'T')
    C = [1 0 0; 1 .7 .7; 1 1 1; 0 0 1; .7 .7 1; 1 1 1; .2 .2 .2; .6 .6 .6; 1 1 1];
end


%--- LOGICAL SIGNIFICANCE (a two-sided significance)

% L (3 x nmos)L  indicates whether weights significant at .05, .10
%     row 1 applies to .01 level.  A "1" means signif, a "0" not
%     row 2 applies to .05 level. ....
%     row 3 applies to "insignificant" correls
LP = logical(zeros(3,4*nmos));
LP(1,:)= (p1'<0.005 | p1'>0.995);
LP(2,:)= (~LP(1,:)) & (p1'<0.025 | p1'> 0.975);
LP(3,:)=  ~(LP(1,:) | LP(2,:))  ;
LT = logical(zeros(3,4*nmos));
LT(1,:)= (p2'<0.005 | p2'>0.995);
LT(2,:)= (~LT(1,:)) & (p2'<0.025 | p2'> 0.975);
LT(3,:)=  ~(LT(1,:) | LT(2,:))  ;



%----- Set colors for patches

%Color patches; c1 for 99% sig, c2 for 95%, c3 for other
if kopt(1)==1; % color
   c1 =C(1,:); c2 = C(2,:); c3=C(3,:);
else
   c1 =C(7,:); c2=C(8,:); c3=C(9,:);
end


CastP = repmat(' ',nmos*4,1); % initialize asterisk labeling for P
CP = zeros(1,nmos*4,3);
n99 = sum(LP(1,:));
if n99>0;
    if kopt(1)==1;
        CP(1,LP(1,:),:) = repmat(c1,n99,1);
    else
        CP(1,LP(1,:),:) = repmat(c3,n99,1);
        CastP(LP(1,:))=repmat('$',n99,1);
    end
end
n95 = sum(LP(2,:));
if n95>0;
    if kopt(1)==1;
        CP(1,LP(2,:),:) = repmat(c2,n95,1);
    else
        CastP(LP(2,:))=repmat('#',n95,1);
        CP(1,LP(2,:),:) = repmat(c3,n95,1);
    end
end
nother = sum(LP(3,:));
if nother>0;
   CP(1,LP(3,:),:) = repmat(c3,nother,1);
end


% Color patches
if kopt(1)==1; % color
   c1 =C(4,:); c2 = C(5,:); c3=C(6,:);
else
   c1 =C(7,:); c2=C(8,:); c3=C(9,:);
end

CastT = repmat(' ',nmos*4,1); % initialize asterisk labeling for T
CT = zeros(1,nmos*4,3);
n99 = sum(LT(1,:));
if n99>0;
    if kopt(1)==1;
        CT(1,LT(1,:),:) = repmat(c1,n99,1);
    else
        CastT(LT(1,:))=repmat('$',n99,1);
        CT(1,LT(1,:),:) = repmat(c3,n99,1);
    end
end
n95 = sum(LT(2,:));
if n95>0;
    if kopt(1)==1;
        CT(1,LT(2,:),:) = repmat(c2,n95,1);
    else
        CT(1,LT(2,:),:) = repmat(c3,n95,1);
        CastT(LT(2,:))=repmat('#',n95,1);
    end
end
nother = sum(LT(3,:));
if nother>0;
   CT(1,LT(3,:),:) = repmat(c3,nother,1);
end



%--- MAKE X-AXIS LABEL OF MONTHS

s1={'N*','D*','J*','F*','M*','A*','M*','J*','J*','A*','S*','O*','N*','D*'};
s2 = {'J','F','M','A','M','J','J','A','S','O','N','D'};

s3 = s2(1:endmo);
s4 = [s1 s3];
n1 = length(s4);
ncut = n1-nmos;
if ncut>0;
    s4(1:ncut)=[];
end
s = [s4 s4 s4 s4];


figure(1);

set(gcf,'RendererMode','manual');
set(gcf,'Renderer','zbuffer');

fwidth = 0.7;
fheight = 0.5;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH])

ax1 = axes('Position',[0.06 0.54 0.91 0.38]);
ax2 = axes('Position',[0.06 0.112 0.91 0.38]);



%--- PRIMARY CLIMATE-VARIABLE CORRELATION BAR CHART

j = (1:length(r1))';

rmax=max(r1);
rmin= min(r1);
yhi =  min([1.0 rmax+0.2]);
ylo =  max([-1.0  rmin-0.2]);
if yhi<0.25;
    yhi=0.25;
end
ylo =  max([-1.0  rmin-0.2]);
if ylo>-0.25;
    ylo=-0.25;
end

linesx=[14.5  28.5  42.5];


% BAR CHART, PRIMARY CLIMATE VARIABLE

axes(ax1)


if kbar==1; % before R2014
    h1 = bar(j,r1);
    x1 = get(h1,'Xdata');
    y1 = get(h1,'Ydata');
    set(h1,'FaceColor',c3);  %--- First mark all bars as not significant
    hh1=get(h1,'Children'); % get the indivual patches handle, before R2014B
    
    % Draw colored patches to replace the bars
    hpatch1=patch(get(hh1,'XData'),get(hh1,'YData'),CP);
    set(hpatch1,'LineWidth',2);
        
    % Adjust parent of patch
    h1 = get(hpatch1,'parent');
    set(h1,'XLim',[0 4*nmos+2],...
        'Xgrid','off');
    jtick = j(2:2:end);
    set(h1,'XTick',jtick,'XTickLabel',s(2:2:end));

else  % R2014B and later
    B=squeeze(CP); % 3-d array of bar colors to 2-d; B is 56x3
    npatches=size(B,1);
    for n =1:npatches;
        bthis = B(n,:);
        h1=bar(j(n),r1(n));
        h1.FaceColor=bthis;
        if n==1;
            hold on;
        else
        end
       
    end
    hold off
    
    % Add tick marks and month labels
    hp = get(h1,'Parent');
    xticky = [j(2):2:j(n)]; % ticks every othermonth
    set(hp,'XTick',xticky)
    set(hp,'XTickLabel',s(2:2:end))
    
end
set(gca,'YLim',[ylo yhi]); % Restrict y-axis range
ylabel(ylab1);

% Shorten tick marks
tlens = get(gca,'TickLength'); % length of tick mark on [x y]
tlens = tlens/2;
set(gca,'TickLength',tlens);



if kopt(1)==2; % B/W
    for k=1:(nmos*4);
        if r1(k)>=0;
            astpos ='Bottom';
        else
            astpos='Top';
        end
        textast=text(k,r1(k),CastP(k));
        set(textast,'HorizontalAlignment','Center','VerticalAlignment',astpos)
    end
end

% vertical dividing lines
for n=1:length(linesx);
    hline = line([linesx(n) linesx(n)],[ylo yhi]);
    set(hline,'Color',[0 0 0],'Linestyle','--');
end


% text for number of months in season (4 seasons)
for k = 1:4;
    xpos = 10+(k-1)*14;
    ypos = ylo+ 0.96*(yhi-ylo);
    if k==1 && g{1}==1;
        txt1 = [num2str(g{k}) ' month'];
    else
        txt1 = [num2str(g{k}) ' months'];
    end
    htext = text(xpos,ypos,txt1,'Horizontalalignment','Center','VerticalAlignment','top');
end

% Label the variable at upper right
xxlim = get(gca,'XLim');
xwide=diff(xxlim);
xgo = xxlim(2)-0.01*diff(xxlim);
yylim = get(gca,'YLim');
ygo = yylim(2)-0.01*diff(yylim);
text(xgo,ygo,var1a,'FontSize',18,'HorizontalAlignment','Right','VerticalAlignment','top');

% Horizontal line at zero
line([0 4*nmos+1],[0 0],'Color',[0 0 0]);



% KEY FOR SIGNIFICANCE OF COLORS

%Color patches; c1 for 99% sig, c2 for 95%, c3 for other
if kopt(1)==1; % color
   c1 =C(1,:); c2 = C(2,:); c3=C(3,:);
else
   c1 =C(7,:); c2=C(8,:); c3=C(9,:);
end

xgo = xwide/100;
xdel = xwide/40;
ydel = 0.07*diff(yylim); % height of slabs
yhi1 = yylim(2)-0.03*diff(yylim);
ylow1 = yhi1 - ydel;
yhi2 = ylow1-0.02*diff(yylim);
ylow2 = yhi2-ydel;

xleg =[xgo xgo  xgo+xdel xgo+xdel];
yleg = [ylow1 yhi1 yhi1 ylow1];
if kopt(1)==1; % color
    hlegp1 = patch(xleg,yleg,c1);
    text(xgo+xdel+xwide/100,(ylow1+0.5*ydel),'\alpha=0.01');
else
    text(xgo+xwide/100,(ylow1+0.5*ydel),'\alpha=0.01 ($)');
end

xleg =[xgo xgo xgo+xdel xgo+xdel];
yleg = [ylow2 yhi2 yhi2 ylow2];
if kopt(1)==1; % color
    hlegp2 = patch(xleg,yleg,c2);
    text(xgo+xdel+xwide/100,(ylow2+0.5*ydel),'\alpha=0.05');
else
     text(xgo+xwide/100,(ylow2+0.5*ydel),'\alpha=0.05 (#)');
end
title(tit1);


%---  BAR CHART, SECONDARY CLIMATE VARIABLE

j = (1:length(r2))';

rmax=max(r2);
rmin= min(r2);
yhi =  min([1.0 rmax+0.2]);
if yhi<0.25;
    yhi=0.25;
end
ylo =  max([-1.0  rmin-0.2]);
if ylo>-0.25;
    ylo=-0.25;
end

linesx=[14.5  28.5  42.5];


% Draw bar chart

axes(ax2)


if kbar==1;
    h1 = bar(j,r2);
    x1 = get(h1,'Xdata');
    y1 = get(h1,'Ydata');
    %--- First mark all bars as not significant
    set(h1,'FaceColor',c3);
    hh1=get(h1,'Children'); % get the indivual patches handle
    
    % Make the patchs
    hpatch1=patch(get(hh1,'XData'),get(hh1,'YData'),CT);
    set(hpatch1,'LineWidth',2);
    
    % Adjust parent of patch
    h1 = get(hpatch1,'parent');
    set(h1,'XLim',[0 4*nmos+2],...
        'Xgrid','off');
    jtick = j(2:2:end);
    set(h1,'XTick',jtick,'XTickLabel',s(2:2:end));
else
    B=squeeze(CT); % 3-d array of bar colors to 2-d; B is 56x3
    npatches=size(B,1);
    for n =1:npatches;
        bthis = B(n,:);
        h1=bar(j(n),r2(n));
        h1.FaceColor=bthis;
        if n==1;
            hold on;
        else
        end
        
    end
    hold off
    
     
    % Add tick marks and month labels
    hp = get(h1,'Parent');
    xticky = [j(2):2:j(n)]; % ticks every othermonth
    set(hp,'XTick',xticky)
    set(hp,'XTickLabel',s(2:2:end))
end

if kopt(1)==2; % B/W
    for k=1:(nmos*4);
        if r2(k)>=0;
            astpos ='Bottom';
        else
            astpos='Top';
        end
        textast=text(k,r2(k),CastT(k));
        set(textast,'HorizontalAlignment','Center','VerticalAlignment',astpos)
    end
end

set(gca,'YLim',[ylo yhi]);
xlabel('Ending Month (*=previous year)');
ylabel(ylab2);

% Shorten tick marks
tlens = get(gca,'TickLength'); % length of tick mark on [x y]
tlens = tlens/2;
set(gca,'TickLength',tlens);


% vertical dividing lines
for n=1:length(linesx);
    hline = line([linesx(n) linesx(n)],[ylo yhi]);
    set(hline,'Color',[0 0 0],'Linestyle','--');
end

% text for number of months
for k = 1:4;
    xpos = 10+(k-1)*14;
    ypos = ylo+ 0.96*(yhi-ylo);
    if k==1 && g{1}==1;
        txt1 = [num2str(g{k}) ' month'];
    else
        txt1 = [num2str(g{k}) ' months'];
    end
    htext = text(xpos,ypos,txt1,'Horizontalalignment','Center','VerticalAlignment','top');
end

% Label the variable at upper right

xxlim = get(gca,'XLim');
xwide=diff(xxlim);
xgo = xxlim(2)-0.01*diff(xxlim);
yylim = get(gca,'YLim');
ygo = yylim(2)-0.01*diff(yylim);

text(xgo,ygo,var2a,'FontSize',18,'HorizontalAlignment','Right','VerticalAlignment','top');


% Horizontal line at zero

hold on;
line([0 4*nmos+1],[0 0],'Color',[0 0 0]);
hold off;


% Color significance key


%Color patches
if kopt(1)==1; % color
   c1 =C(4,:); c2 = C(5,:); c3=C(6,:);
else
   c1 =C(7,:); c2=C(8,:); c3=C(9,:);
end

xgo = xwide/100;
xdel = xwide/40;
ydel = 0.07*diff(yylim); % height of slabs
yhi1 = yylim(2)-0.03*diff(yylim);
ylow1 = yhi1 - ydel;
yhi2 = ylow1-0.02*diff(yylim);
ylow2 = yhi2-ydel;

xleg =[xgo xgo  xgo+xdel xgo+xdel];
yleg = [ylow1 yhi1 yhi1 ylow1];
if kopt(1)==1; % color
    hlegp1 = patch(xleg,yleg,c1);
    text(xgo+xdel+xwide/100,(ylow1+0.5*ydel),'\alpha=0.01');
else % B/W
     text(xgo+xwide/100,(ylow1+0.5*ydel),'\alpha=0.01 ($)');
end

xleg =[xgo xgo xgo+xdel xgo+xdel];
yleg = [ylow2 yhi2 yhi2 ylow2];
if kopt(1)==1; % color
    hlegp2 = patch(xleg,yleg,c2);
    text(xgo+xdel+xwide/100,(ylow2+0.5*ydel),'\alpha=0.05');
else % B/W
    text(xgo+xwide/100,(ylow2+0.5*ydel),'\alpha=0.05 (#)');
end
    
%--- Build text summaries for each of four monthly groupings

S=cell(1,4); % to hold the text summaries
H=cell(1,4); % to hold info on highest correl with prim climate variable
r = repmat(NaN,nmos,2); % to hold correlations in col1, partrials in 2
p = repmat(nmos,2); % to hold nonexceedance probabilities
Lsig = cell(1,2); % to hold significance flags
mlab=s4; % labels for the 14 months
varnms={var1a,var2a}; % labels for primary and secondary climate variable
yrs =[Result.yrgo Result.yrsp];
for n = 1:4;
    igo = 14*(n-1)+1; % start index for correlations to pull
    isp = igo +13; % end index
    mlength=g{n} ; % length of season
    r =[r1(igo:isp) r2(igo:isp)];
    p =[p1(igo:isp) p2(igo:isp)];
    Lsig{1}=(LP(:,igo:isp))';
    Lsig{2}=(LT(:,igo:isp))';
    [S{n},H{n},nms_end]=subfun09(mlength,r,p,Lsig,mlab,varnms,yrs);
end



function P = subfun07(pfP)
%
% Organizes a 13-col climate matrix into a 3-col monthly matrix,
% with columns the year, month and value

A = importdata(pfP);

% convert 13-col matrix to 3-col: year, month, value
yr = A(:,1);
nyr = length(yr);
if ~all(diff(yr)==1);
    error(['year column in ' pfP ' does not increment by 1']);
end
yr = yr'; % to rv
YR = repmat(yr,12,1); % row-dupe
yr = YR(:);   % the year col for 3-col matrix

j = (1:12)';
j = repmat(j,nyr,1); % the month column

A(:,1)=[]; % strip year
if any(any(isnan(A)));
    error(['data in ' pfP ' has NaN ']);
end
A=A'; % transpose so that col 1 is jan-dec of year 1; col 2 is jan-dec of year 2, etc
a= A(:);
P = [yr j a];
clear A yr nyr j a




function subfun08(D,x,yrx,P,Torig,T,kopt,textinfo)
% Build supplementary figures: 
% 1) bar chart of correlations of primary with secondary climate variables,
%   56 seasons
% 2) time series plot of tree-ring series
% 3) climograph
% 4) autocorrelation function of tree-ring series, lags 0-20, with 95% CI
%   based on large-lag standard error
% 5) spectrum (Blackman-Tukey)
% 6) bar chart of lag-1 autocorrelations of primary climate variable, along
%    with 95% CI for test of null hypothesis of zero autocorrelation;  also
%    on plot is horizontal line marking first-order autocorrelation of the
%    tree-ring series
%
% D is structure. D is same as structure Result in calling function.  See comments on
%   Result there for list of fields
% x is tree-ring index, yrx is year for it
% P is the primary climate variable (e.g. precipitation for each "season"
%   (col))
% Torig is the seondary climate variable (e.g. temperature for each "season"
%   (col))
% T is "adjusted" secondary variable for each "season" (dependence on primary  removed)
% kopt is (1x2)i
%   kopt(1) is for color (==1) or B/W (==2)
%   kopt(2) is for reversal of normal interest in P as primary variable
%       ==1 P primary, T secondary
%       ==2 T primary, P secondary
% textinfo : a cell with labels and other information on the climate
%   variables

mP = size(P,1); % number of of years of climate data

colsBW={[0 0 0],[0 0 0],[0.6 0.6 0.6],[0 0 0]}; 
colsColor={[0 0 1],[0 0.5 0],[1 0 0],[0 0 0]}; 
LwBW =[ 1 1 2 1];
LwColor=[1 1 1 1];
if kopt(1)==1;
    cols =colsColor;
    Lw=LwColor;
else
    cols=colsBW;
    Lw = LwBW;
end

% Settings for some selected CI lines on plots
if kopt(1)==1;
    CIcolor=[1 0 0]; % red CI if color plot
else
    CIcolor=[0 0 0]; % black CI if B/W plot
end

stryr = [num2str(D.yrgo) '-' num2str(D.yrsp)]; % start and end year of analysis period
nmos = D.nmos;
endmo = D.endmo;
g=D.g;
ylab1 ='r_{x,P}';
ylab2='r_{x,T.P}';


r3 = D.r3;
r4  =D.r4;
r5 = D.r5;
r6 = D.r6;


%--- MAKE X-AXIS LABEL OF MONTHS

s1={'N*','D*','J*','F*','M*','A*','M*','J*','J*','A*','S*','O*','N*','D*'};
s2 = {'J','F','M','A','M','J','J','A','S','O','N','D'};

s3 = s2(1:endmo);
s4 = [s1 s3];
n1 = length(s4);
ncut = n1-nmos;
if ncut>0;
    s4(1:ncut)=[];
end
s = [s4 s4 s4 s4];



%--- CORRELATION OF P and T

figure(2);
fwidth = 0.85;
fheight = 0.4;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH])

j = (1:length(r3))';

rmax=max(r3);
rmin= min(r3);
yhi =  min([1.0 1.0]);
ylo =  max([-1.0  -1.0]);
linesx=[14.5  28.5  42.5];

h1=bar(j,r3);
set(h1,'FaceColor',colsBW{3}); % this  bar chart with gray shading regardess of setting for BW or Color
xlabel('Ending Month');
ylabel('Correlation')
set(gca,'XLim',[0 4*nmos+2])

set(gca,'Xtick',j,'XTickLabel',s,'YLim',[-1.01 1.01],'XLim',[0 57])


% vertical dividing lines
for n=1:length(linesx);
    hline = line([linesx(n) linesx(n)],[ylo yhi]);
    set(hline,'Color',[0 0 0],'Linestyle','--');
end

% text for number of months
for k = 1:4;
    xpos = 10+(k-1)*14;
    ypos = 0.90;
    if k==1 && g{1}==1;
        txt1 = [num2str(g{k}) ' month'];
    else
        txt1 = [num2str(g{k}) ' months'];
    end
    htext = text(xpos,ypos,txt1,'Horizontalalignment','Center','VerticalAlignment','top');
end

% Approx 95% CI

c = D.r3_95; % approx CI, equal to 1.96 times sqrt of sample size (no adjustments)
hline = line([0 57],[c c]);
set(hline,'LineStyle','--','Color',CIcolor);
hline = line([0 57],[-c -c]);
set(hline,'LineStyle','--','Color',CIcolor);

% Title 
str_CI = ', with 95% confidence interval';
if kopt(2)==1;
    title(['Intercorrelation of climate variables (' textinfo{2} ' with ' textinfo{6} ')' str_CI]);
else
    title(['Intercorrelation of climate variables (' textinfo{6} ' with ' textinfo{2} ')' str_CI]);
end



%--- TIME SERIES PLOT OF TREE-RING INDEX

figure(3);
fwidth = 0.5;
fheight = 0.7;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH])

subplot(2,1,1);
h = plot(yrx,x,'-o',[yrx(1) yrx(end)],[mean(x) mean(x)]);
set(h(1),'Color',cols{1})
set(h(2),'Color',cols{2})
if kopt(1)==2;
    set(h(2),'LineStyle','--');
end
xlabel('Year');
ylabel('Index');
legend('Index','Mean');
textcorn('A','UL',0.02,0.02,20);
set(gca,'Xlim',[yrx(1)-1  yrx(end)+1]);
set(gca,'Xgrid','on');
title(['Time Plot of Tree-Ring Series, ' stryr]);


%--- LILLIEFORS TEST AND HISTOGRAM

h=lillietest(x,0.05);
if h==1;
    Ltxt='Reject H0';
else
    Ltxt='Accept H0';
end
Ltxt1={'H0: index normal','\alpha=0.05',Ltxt};
clear Ltxt;


subplot(2,1,2);
histfit(x);
h =get(gca,'Children');
if kopt(1)==2; % B/W
    set(h(2),'FaceColor',[0.8 0.8 0.8]);
    set(h(1),'Color',[0 0 0]);
else
    set(h(2),'FaceColor',[0.8 0.8 1]);
end
xlabel('Index');
ylabel('No. Observations');
textcorn('B','UL',0.02,0.02,20);
textcorn(Ltxt1,'UL',0.02,0.20,12);
title('Histogram of Tree-Ring Index & Fitted Normal PDF')



%--- SPECTRUM OF TREE RING 


figure(4);
fwidth = 0.4;
fheight = 0.5;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH]);



%--- Call to pdgmraw for raw periodogram; will get
% I = cv of raw periodogram
% f = cv of frequencies
% v = diagnostic row vector with (1) original variance of x, (2) variance
%    of tapered x, (3) variance of tapered, padded x, (4) computation of
%    variance from periodogram ordinates (a check vs v(1))
mtaper=0.10; % apply split cosine bell taper to 5% of series on front and back 
npad = 2^(nextpow2(length(x))); % desired padded length
kopt_pdgmraw = 1; % scale variance of tapered padded series in pdgmraw before FFT and periodogram computation
[I,f,v]=pdgmraw(x,mtaper,npad,kopt_pdgmraw);


%--- Smooth the raw periodogram with a 5-weight binomial filter
w= wtsbinom(5,2); % 5 is number of desired weights; 2 is an option specifying that
% that the first input argument is the number of desired weights.  w is a
% row vectore of weights
%c=conv(I,w,'valid'); 
c=conv(I,w); 
c = c(5:(end-4)); % lops off the smoothed values based on zero-padded original I
% c is I filtered by w.  Length of c is 4 less than length of x because
% lose 4 data points in filtering
fc = f(3:(end-2)); % frequency vector for c

%--- Plot raw and smoothed periodogram
xlab='Frequency (yr^{-1})';
ylab='Relative Variance';

Imean = mean(I); % mean periodogram ordinate;
hp = plot(f,I,fc,c,[fc(1) fc(end)],[Imean Imean]);
set(hp(1),'Marker','o','Color',cols{1});
set(hp(2),'Color',cols{3},'LineWidth',Lw(3));
set(hp(3),'Color',[0 0 0]);
legend('Raw periodogram','Smoothed','Mean')
xlabel(xlab);
ylabel(ylab);
set(gca,'Position',[0.1300    0.1100    0.7750    0.7450])
title({['Spectrum of Tree-Ring Series, ' stryr],'(smoothing by 5-wt binomial filter)'})





%--- AUTOCORRELATION FUNCTION OF TREE RING SERIES

[rr,SE2,r95]=acf(x,20,[1 1]);

figure(5)
fwidth = 0.7;
fheight = 0.5;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH])

r=rr;
klag =[0 (1:length(r))];
j=klag(2:end);
rtemp = [1 r];
hstem=stem(klag,rtemp);
set(hstem,'Color',cols{1});
xlabel('Lag');
ylabel('r')
lowerlim = -1.0*(max(SE2)+0.05);
set(gca,'XLim',[-0.5 klag(end)+0.5],'YLim',[lowerlim 1.0]);
hline1 = line(j,SE2);
hline2= line(j,-SE2);
set (hline1,'LineStyle','--','Color',CIcolor);
set (hline2,'LineStyle','--','Color',CIcolor);
txt1='Confidence band is \pm2 large-lag standard errors';
text(max(klag),max(SE2),txt1,'HorizontalAlignment','Right','Verticalalignment','Bottom')
title(['ACF and 95% Confidence Band, Tree Ring Series ' stryr])


Lred=logical(0);  % initialize as want white-noise null
Lred = rr(1)>0 & rr(1)>r95; % use red noise null line
if Lred;
    kopt_spectrum=[2 2];
else
    kopt_spectrum=[2 1];
end




%--- FIRST-ORDER AUTOCORRELATION OF PRIMARY CLIMATE VARIABLE IN THE 56
%   SEASONS
%
% Recall: r6 holds the autocorrelations of tree ring variable at lags 1-5
% r4 holds the lag-1 autocorrelations of primary climate variable

figure(6);
fwidth = 0.85;
fheight = 0.4;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH])

%--- Compute 95% 2-sided CI for first-order autocorrelation
% Haan (2002), p 288
lowerci = (-1-1.96*sqrt(mP-2))/(mP-1);
upperci= (-1+1.96*sqrt(mP-2))/(mP-1);

j = (1:length(r4))';
rmax=1.0;
rmin= -1.0;
yhi =  min([1.0 rmax+0.2]);
ylo =  max([-1.0  rmin-0.2]);
linesx=[14.5  28.5  42.5];

h1=bar(j,r4);
set(h1,'FaceColor',colsBW{3}); % this  bar chart with gray shading regardess of setting for BW or Color
xlabel('Ending Month');
ylabel('Lag-1 Autocorrelation')
set(gca,'XLim',[0 4*nmos+2])
set(gca,'Xtick',j,'XTickLabel',s)

% vertical dividing lines
for n=1:length(linesx);
    hline = line([linesx(n) linesx(n)],[ylo yhi]);
    set(hline,'Color',[0 0 0],'Linestyle','--');
end

% text for number of months
for k = 1:4;
    xpos = 10+(k-1)*14;
    ypos = ylo+ 0.90*(yhi-ylo);
    if k==1 & g{1}==1;
        txt1 = [num2str(g{k}) ' month'];
    else
        txt1 = [num2str(g{k}) ' months'];
    end
    htext = text(xpos,ypos,txt1,'Horizontalalignment','Center','VerticalAlignment','top');
end

xlims = get(gca,'XLim');
hline = line(xlims,[r6(1) r6(1)]);
set(hline,'LineStyle',':','LineWidth',2,'Color',CIcolor);
hlineci=line(xlims,[lowerci lowerci]);
set(hlineci,'Color',[0 0 0],'LineStyle','-.');
hlineci=line(xlims,[upperci upperci]);
set(hlineci,'Color',[0 0 0],'LineStyle','-.');
if kopt(2)==1;
    title({['Lag-1 autocorrelation of ' textinfo{2} ' (bars) and tree rings (dotted line)'],...
        'dash-dot line = 95% CI'});
else
     title({['Lag-1 autocorrelation of ' textinfo{6} ' (bars) and tree rings (dotted line)'],...
        'dash-dot line = 95% CI'});
end


%----- CLIMOGRAPH

figure(7);
fwidth = 0.4;
fheight = 0.5;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH])
windno=7; % call to climgram uses to set window
% The first 12 cols of the matrices P and Torig are what you want (these
% have 1-month values.  But the first 12 cols are not generally J-D.
% They may begin with any month.  Approach here:
% 1 Look at first 12 cols
% 2 Find december
% 3 If dec is the 12 th col, order OK
% 4 If dec is the ith col, 
%   -put cols i+1 to 12 at left
%   -put cols 1: at right
%
% P and Torig do not necessarily correspond to precipitation and
% temperature.  The calling function has assigned P as the nominal primary
% climate variable and Torig as the nominal secondary climate variable.
% But the labels and units information in textinfo will not match if
% kopt(2)==2

%--- Set labels and units
% Torig
if kopt(2)==1;
    ylabtop = [textinfo{2} '(' textinfo{3} ')'];
    ylabbot = [textinfo{6} '(' textinfo{7} ')'];
else
    ylabtop = [textinfo{6} '(' textinfo{7} ')'];
    ylabbot = [textinfo{2} '(' textinfo{3} ')'];
end


stemp=s(1:12); % monthl labels, first 12 cols
i1=find(ismember(stemp,'D*') | ismember(stemp,'D'));
if isempty(i1) ;
    error('No D or D* ');
else
end
if i1(1)==1;
    igo=1;
    isp=12;
    Ptemp = P(:,igo:isp);
    Ttemp = Torig(:,igo:isp);
else
    igoa=1;
    ispa=i1(1);
    igob = i1(1)+1;
    ispb = 12;
    Ptemp = [P(:,igob:ispb) P(:,igoa:ispa)];
    Ttemp = [Torig(:,igob:ispb) Torig(:,igoa:ispa)];
    
end
txtin={'Climograph',ylabtop,ylabbot};
Ptemp=[yrx Ptemp];
Ttemp =[yrx Ttemp];

koptcolor=kopt(1);
[mpcp,npcp,mtmp,ntmp]=climgram(Ptemp,Ttemp,txtin,windno,koptcolor);






function [S,H,nms] = subfun09(m,r,p,Lsig,mlab,varnms,yrs)
% Makes text table summary of correlations and partial correlations
%
% m = number months in grouping
% r (14x2)r = corr (col 1) and partial (col 2)
% p (14x2)r =  nonexceedance probability, p*,  of observed correlation or partial
%   correlation. p* is related to p-value for significance.  p-value<0.05,
%   for example, would require p*< 0.025 or p*>0.995
% Lsig {1x2}L  logical matrices marking significance at 0.01, 0.05 and none
%  each matrix 14x3 logical
% mlab {1x14}s    month labels
% varnms {1x2}s  labels for primary (1) and secondary (2) climate variables
% yrs (1x2)i   start and end year of period for correlations
%
% S= summary table of correlations and partial correlations for the m-month
%   seasons
% H = string vector listing season with highest correlation for the m-month
%   season
% nms = cell string of 14 ending months, in readable format

% Make month names
nm1={'J*','F*','M*','A*','M*','J*','J*','A*','S*','O*','N*','D*',...
    'J','F','M','A','M','J','J','A','S','O','N','D'};
nm2={'Jan_prev','Feb_prev','Mar_prev','Apr_prev','May_prev','Jun_prev',...
    'Jul_prev','Aug_prev','Sep_prev','Oct_prev','Nov_prev','Dec_prev',...
    'Jan','Feb','Mar','Apr','May','Jun',...
    'Jul','Aug','Sep','Oct','Nov','Dec'};
d1=mlab{1};
d2=mlab{2};
if strcmp(d1,'J*');
    if strcmp(d2,'F*')
        igo=1;
    elseif strcmp(d2,'J*')
        igo=6;
    else
        igo=7;
    end
elseif strcmp(d1,'F*');
    igo=2;
elseif strcmp(d1,'M*');
    if strcmp(d2,'A*')
        igo=3;
    else
        igo=5;
    end
elseif strcmp(d1,'A*');
    if strcmp(d2,'M*')
        igo=4;
    else
        igo=8;
    end
elseif strcmp(d1,'S*');
    igo=9;
elseif strcmp(d1,'O*');
    igo=10;
elseif strcmp(d1,'N*');
    igo=11;
elseif strcmp(d1,'D*');
end
isp = igo+13;
nms=nm2(igo:isp);
    
    
%--- Pointer to largest absolute correlation with primary
[pkey,ipkey]=max(abs(r(:,1)));



%--- Make header

s2=[num2str(m) '- Month Grouping'];
nyr = yrs(2)-yrs(1)+1;
s3 =['Analysis period: ' num2str(yrs(1)) '-' num2str(yrs(2)) ' (' num2str(nyr)  ' years)'];
s4 = ['Primary climate variable = ' varnms{1} ';  Secondary climate variable = ' varnms{2}];


%--- Build asterisk mtx on signif
%  asterisk in col 2 if p<0.05, in cols 2 and 3 if p<.01

for n=1:2;
    W=repmat('   ',size(r,1),1);
    L1 = Lsig{n};
    Lsub = L1(:,1:2); % pull off cols for .01 and .05 sig
    Lthis=Lsub(:,2); % .05
    Lsingle = Lthis;
    if any(Lsingle);
        w = repmat('*',sum(Lsingle),1);
        W(Lsingle,2)=w;
    end
     Lthis=Lsub(:,1); % .01
     Ldouble=Lthis;
    if any(Ldouble);
        w = repmat('*',sum(Ldouble),1);
        W(Ldouble,3)=w;
        W(Ldouble,2)=w;
    end
    eval(['W' num2str(n) '=W;']);
end

head1=char({'',...
    '-------------------------------------------------------------------',...
    ['Correlation (with ' varnms{1} ')               Partial Correlation (with ' varnms{2} ')'],...
    '-----------------------------         -----------------------------',...
    'Ending           Nonexceedance        Ending           Nonexceedance',...
    'Month          r   Probability        Month          r   Probability',...
    '-------------------------------------------------------------------'});

tail1= char({' ','** = significant (p<0.01)',...
    '*  = significant (p<0.05)'});
    

%--- Make body

b1=repmat(' ',14,1);
b3=repmat('   ',14,1);
b11=repmat('          ',14,1);

c1=char(nms'); % ending month
c2=num2str(r(:,1),'%5.2f'); % correlation
c3=num2str(p(:,1),'%5.4f'); % nonexceedance prob of r
c5=num2str(r(:,2),'%5.2f'); % correlation
c6=num2str(p(:,2),'%5.4f'); % nonexceedance prob of r

clc;
torso1=[c1 b3 c2 b3 b1 c3 W1 b11 c1 b3 c5 b3 b1 c6 W2];
torso2=[c1 b3 c2 b3 b1 c3 W1];


S = char(s2,s3,s4, head1,torso1,tail1);
H=[num2str(m) '     ' torso2(ipkey,:)];

function H = subfun10(R,A,var1,var2)
% Build text table summary of highest correlations with primary clim variable
%
% H = char matrix result, which seascorr prints in a figure window
% R : structure of data; R is the same as Result in the calling function,
%   seascorr;  see opening comments of seascorr for list of fiels
% A : 1x4 cell with summary info for individual season groupings; each
%   element of A is a character string identifying the season, correlation
%   of primary climate variable with tree ring, and non-exceedance
%   probability of that correlation
% var1: 1-character label for primary clim variable
% var2: ... for secondary ...


m = length(A);


%--- ALIGNMENT OF COLUMNS

D=char(A{1},A{2},A{3},A{4});
Dcell=cellstr(D);
Dcell=strrep(Dcell,'_prev','#');
D=char(Dcell);
D1=D;
H=[];

G=cell(m,4);
for n =1:m; % Loop over rows of char matrix D1
    d1=deblank(D1(n,:));
    d1=fliplr(deblank(fliplr(d1))); % remove any leading and trailing blanks from this string
    d1=[' ' d1];
    i1 = ~isspace(d1);
    i2 = diff(i1); % will be 1 if first non-space of a word
    igo=find(i2==1); % index to first char of words
    isp = find(i2==-1); % index to last char of words
     isp(4) = length(d1);
    igo=igo(1:4);
    isp = isp(1:4);
   
    for k =1:4
        dthis = d1(igo(k):isp(k));
        G{n,k} = dthis;
    end
end

for n=1:4;
    eval(['s' num2str(n) '=char(G(:,'  num2str(n) '));']);

end

b2 = repmat('  ',4,1);
b4 = repmat('    ',4,1);

torso1 = [s1 b4 s2 b2 s3 b4 s4];

%--- head

head1 =char({'HIGHEST-CORRELATED SEASONS',...
    [' (Tree rings with ' var1 ')'],...
    '',...
    ['Analysis period: ' num2str(R.yrgo) '-' num2str(R.yrsp)],...
    [num2str(R.nsim) ' simulations'],...
    '',...
    '--------------------------------',...
    '       Ending      Nonexceedance',...
    ' m     Month    r    probability',...
    '--------------------------------'});

tail1=char({'---------------------------------',...
    '# after month means "previous year"',...
    'm-month seasons with given ending month',...
    'r is highest correlation for each m',...
    ' ',...
    'For complete list of correlations and',...
    'partial correlations that are plotted',...
    'in Figure 1, type ''Result.S\{i\}'' at',...
    '  command prompt, where i is 1, 2, 3 or 4.  ',...
    '',...
    'LIST OF FIGURE WINDOWS',...
    '  1) bar charts -- tree ring vs climate',...
    ['  2) bar chart -- ' var1 ' vs ' var2],...
    '  3) time plot and histogram, tree ring',...
    '  4) spectrum of tree-ring series',...
    '  5) acf of tree-ring series',...
    '  6) lag-1 autocorrelation comparison',...
    '  7) climogram',...
    ['  8) scatter plots, tree-ring vs ' var1],...
    ['  9) time plots of tree rings and ' var1],...
    ' 10) this summary text window',...
    ' 11) difference-of-correlation test ',...
    '     (early vs late sub-periods)',...
    ''...
    ''});
H=char(head1,torso1,tail1);

%--- MAKE FIGURE

figure(10);
[cL,cB,cW,cH]=figsize(0.5,0.80);
set(gcf,'Position',[cL cB cW cH]);
hax = axes;
set(gca,'XLim',[0 1],'YLim',[0 1]);
set(gca,'Position',[0.0700    0.2100    0.7750    0.8150])
htext = text(0.1,0.95,cellstr(H),'HorizontalAlignment','Left','VerticalAlignment','Top','FontSize',10,'FontName','Courier');
 set(gca,'Visible','off')

 
 function subfun11(D)
% Draw scatterplots of tree-ring series against primary climate variable
% for the four key seasons.  The key seasons are the season-groupings with highest
% tree-ring correlation each season-length
% D is a structure with input fields

% Unload structure
y = D.x; % tree-ring time series
yr = D.yrx; % year vector for y as well as climate series
X1 = D.P;  % 1-col time series matrix of seasonalized climate variable
s1 = D.nms; % row-cell of strings; 14 possible ending months for seasons
k14= D.i14; % pointer to s1 tell which are the ending month for series in X
unitsx = D.units; % units of data in X
typex  = D.id ; % 1-letter code of climate variable type in X
g=D.g; % row-cell with season-lengths

s1=strrep(s1,'_prev','#'); % more conventient code for plotting season names
[mX1,nX1]=size(X1);

figure(8) 
fwidth =1.3*0.42;
fheight =1.3*0.60;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH])

for n =1:4; % loop over seasons
    hh=subplot(2,2,n);
    ithis = k14(n); % pointer to season name
    nmos=g{n} ; % number of months in season
    idseas = s1{ithis}; % name of season
    if nmos>1;
        str_seas = ['Season: ' num2str(nmos) ' mos ending in ' idseas];
    else
        str_seas = ['Season: ' num2str(nmos) ' mo ending in ' idseas];
    end
    
    % Correlation
    x =X1(:,n);
    r = corrcoef([x y]);
    r=r(1,2);
    str_r = ['r = ' num2str(r,'%5.2f')];
    
    % Regression;
    X=[ones(mX1,1) x];
    b=X\y;
    yhat = X*b;
    xhats =[min(x) max(x)];
    yhats =[min(yhat) max(yhat)];
    if sign(r)==-1
        yhats =[max(yhat) min(yhat)];
    end
    
    
    subplot(2,2,n);
    h = plot(x,y,'o',xhats, yhats);
    xlabel([typex '(' unitsx ')'])
    ylabel('Tree Ring Index')
    set(h(1),'Color',[0 0 0]);
    set(h(2),'Color',[0 0 0]);
    
    str1 ={str_seas,str_r};
    textcorn(str1,'UL',0.02,0.02,11)
end
[axtemp,htemp]=suplabel('Tree rings vs climate for highest-correlated groupings','t');
set(htemp,'fontsize',14);
clear axtemp htemp


function subfun12(D)
% Draw time plots of tree-ring series and primary climate variable for the
% four key seasons.  The key seasons are the season-groupings with highest
% tree-ring correlation each season-length.  Series plotted as z-scores to
% avoid scaling problems
% D is a structure with input fields

% Unload structure
y = D.x; % tree-ring time series
yr = D.yrx; % year vector for y as well as climate series
X1 = D.P;  % 1-col time series matrix of seasonalized climate variable
s1 = D.nms; % row-cell of strings; 14 possible ending months for seasons
k14= D.i14; % pointer to s1 tell which are the ending month for series in X
unitsx = D.units; % units of data in X
typex  = D.id ; % 1-letter code of climate variable type in X
g=D.g; % row-cell with season-lengths

s1=strrep(s1,'_prev','#'); % more conventient code for plotting season names
[mX1,nX1]=size(X1);

figure(9) 
fwidth =1.0*0.85;
fheight =1.0*0.85;
[cL,cB,cW,cH]=figsize(fwidth,fheight);
set(gcf,'Position',[cL cB cW cH])
xlims =[yr(1)-1 yr(end)+1];
y = zscore(y); % tree ring to z-score
str_yr = [num2str(yr(1)) '-' num2str(yr(end))];

% Tree-ring test for sig of linear trend
U = [ones(mX1,1) yr];
[b,bint,r,rint,stats] = regress(y,U,0.01);
if b(2)==0 || sign(b(2))==1;
    diry ='pos';
else 
    diry='neg';
end
if stats(3)<0.01;
    pvaly = '(\itp \rm<0.01)';
    str_trend=['Tree-ring: trend ' diry ' ' pvaly];
elseif stats(3)<0.05;
    pvaly = '(\itp \rm<0.05)';
    str_trend=['Tree-ring trend ' diry ' ' pvaly];
else
    str_trend=['No tree-ring trend'];
end


str_seas=cell(4,1);
str_ctrend=cell(4,1);
for n =1:4; % loop over seasons
    hh=subplot(4,1,n);
    pos=get(hh(1),'Position');
    pos(1)=0.05;
    pos(2)=pos(2)-0.02;
    pos(3)=0.90;
    pos(4)=0.2; % stretch y axis
    set(hh(1),'Position',pos)
    
    ithis = k14(n); % pointer to season name
    nmos=g{n} ; % number of months in season
    idseas = s1{ithis}; % name of season
    if nmos~=1;
        str_seas{n} = ['Season: ' num2str(nmos) ' mos ending in ' idseas];
    else
        str_seas{n} = ['Season: ' num2str(nmos) ' month (' idseas ')'];
    end
        
    x =X1(:,n); % climate series
    x=zscore(x);  % Z-score converson
    
    % Climate, test for sig of linear trend
    U = [ones(mX1,1) yr];
    [b,bint,r,rint,stats] = regress(x,U,0.01);
    if b(2)==0 || sign(b(2))==1;
        diry ='pos';
    else
        diry='neg';
    end
    if stats(3)<0.01;
        pvaly = '(\itp \rm<0.01)';
        str_ctrend{n}=[typex ' trend: ' diry ' ' pvaly];
    elseif stats(3)<0/05;
        pvaly = '(\itp \rm<0.01)';
        str_ctrend{n}=[typex ' trend: ' diry ' ' pvaly];
    else
        str_ctrend{n}=['No ' typex ' trend'];
    end   
    
          
    
    h = plot(yr,x,'-o',yr,y,'-^',[yr(1) yr(end)],[0 0 ]);
    
    set(gca,'Xgrid','on','XLim',xlims)
    if n ~=4;
        xlabel('')
        set(gca,'XTickLabel',[]);
    else
        xlabel('Year')
    end
    ylabel('z-score')
    set(h(1),'Color',[0 0 0]);
    set(h(2),'Color',[0 0 0],'LineStyle','--');
    set(h(3),'Color',[0 0 0]);

end
str9=['Z-score time plots for highest-correlated climate groupings, ' str_yr ';  o  = ' typex ',  \Delta = Tree-ring'];
%suptitle({['Z-score time plots for highest-correlated climate groupings, ' str_yr],...
   % ['o  = ' typex '; ,\Delta = Tree-ring']})
[axtemp,htemp]=suplabel(str9,'t');
set(htemp,'FontSize',14);
postemp=get(axtemp,'Position');
postemp(2)=0.02;
set(axtemp,'Position',postemp);
clear axtemp htemp


% Add text info; do here because subplot may have adjusted axes of panels
h = get(gcf,'Children');
str_seas=flipud(str_seas);
j=0;
for n =1:5;
    hthis = h(n);
    if ~strcmp('off',get(hthis,'Visible')); % the 4 subplots have their "visible" property "on"
        j=j+1;
        axes(hthis);
        textcorn(str_seas{j},'UL',0.01,0.01,11)
        textcorn({str_trend,str_ctrend{j}},'UR',0.01,0.01,11)
    else
    end
end


function p = subfun13(x,y)
% Uses Weibull formula, 1-(m/(n+1)), as algorithm for nonexceedance proability 
%   where n is the length of y and m is the rank  (1 smallest, n largest) y
% If x as large or larger than largest y, x is assigned same nep as largest
% y.  If x is as small or smaller than smallest y, x is assigned same nep
% as smallest y.
%
% In Monte Carlo terms:
% y is the pseudo-population of a statistic
% x is the sample statistic
% p is  prob  y>x

s=sort(y);  % y sorted smallest to largest
n=length(s);
j=(1:n)'; % ranks of sorted y

%YI = INTERP1(X,Y,XI)
if x<=min(y);
    j1 =1;
elseif x>=max(y);
    j1=n;
else
    j1=interp1(s,j,x);   % interpolated rank
end

% Nonexceedance probability for x
p =(j1/(n+1));




function [yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2,Lsub]=subfun14(a,b,c,d)
% Prompt for period for full analysis, sub-period analysis, and minimum
% allowable series length for correlation
%
% a= first year of full available overlap period of climate and tree rings
% b = last year ...
% c = hard coded (in main function) default minimum allowable length (yr)
%     of period for full-calibration analysis
% d=   hard coded (in main function) minimum allowable length of period for sub-period correlation 
% Output are desired settings:
%
% yrgo, yrsp = start and end year of period for full analysis
% yrgo1, yrsp1 = ... for early sub-period
% yrgo2, yrsp2 = ... for late sub-period
% Lsub: whether specified full analysis period long enough to allow
%   sub-period test of difference of correlations ==1 yes, ==0 no


yr1=(a:b)';

%-- PERIOD FOR FULL ANALYSIS

kwh=1;
while kwh;
    
    prompt={'Enter start and end years for full analysis:'};
    name='Time Settings full';
    numlines=1;
    defaultanswer={num2str([a b]), num2str(c)};
    answer=inputdlg(prompt,name,numlines,defaultanswer);
    yrs1 = str2num(answer{1});
    yrgo = yrs1(1);
    yrsp = yrs1(2);
    [L,msg]=subfun15(yrgo,yrsp,yr1,c);
    if L;
        kwh=0;
        disp(msg);
    else
        uiwait(msgbox(msg,'Re-enter','modal'));
    end
end; % while


%---- SPLIT PERIOD IN HALF FOR DEFAULT EARLY AND LATE SUB-PERIODS

a=yrgo;
b=yrsp;
% Split full period in half, favoring length of first half if n odd
n = b-a+1; % number of years in default full period
if mod(n,2)==0; % even number of years
    a1=a;
    b1 = a + n/2 -1;
else
    a1=a;
    b1 = a +ceil(n/2)-1;
end
a2=b1+1;
b2=b;

if (b1-a1+1)<d  || (b2-a2+1)<d
    Lsub=0;
    yrgo1=a1;
    yrsp1=b1;
    yrgo2=a2;
    yrsp2=b2;
     disp(['Sub-period test of correlations will be skipped because ' num2str(yrgo1) '-' num2str(yrsp1) ' or ' num2str(yrgo2) '-' num2str(yrsp2)  ' less than ' nym2str(d) ' yr']);
    return
else
    Lsub=1;
end

kwh=1;
while kwh
    prompt={'Enter start and end years for early sub-period',...
        'Enter start and end years for late sub-period'};
    name='Time Settings 2';
    numlines=1;
    defaultanswer={num2str([a1 b1]),num2str([a2 b2])};
    answer=inputdlg(prompt,name,numlines,defaultanswer);
    yrs2 = str2num(answer{1});
    yrs3 = str2num(answer{2});
    yrgo1 = yrs2(1);
    yrsp1 = yrs2(2);
    yrgo2=yrs3(1);
    yrsp2=yrs3(2);
    
    [L,msg]=subfun16(yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2,d);
    if L;
        kwh=0;
        disp(msg);
    else
        uiwait(msgbox(msg,'Re-enter','modal'));
       
    end
    
end; % while


function [L,msg]=subfun15(yrgo,yrsp,yr1,minlen)
% Check for validity of full-analysis period
%
% yrgo = specified first year
% yrsp = specified last year
% yr1 = cv of years of full overlap of climate and tree rings
% minlen = minimum allowable length of series for correlation
%
% L = logical telling if period OK (1) or not (0);
% msg =  error message

str1 = [num2str(yrgo) '-' num2str(yrsp)];
str2 = [num2str(yr1(1)) '-' num2str(yr1(end))];
msgs ={['Specified analysis period ' str1 ' outside available climate-tree ring overlap ' str2],...
    ['Specified analysis period ' str1 ' shorter than ' num2str(minlen) ' years'],...
    ['Specified analysis period ' str1 ' illogical because first year not earlier than last']};

if yrgo>=yrsp;
    L=0;
    msg = msgs{3};
elseif yrgo<yr1(1) || yrsp>yr1(end);
    L=0;
    msg= msgs{1};
elseif (yrsp-yrgo+1)<minlen;
    msg = msgs{2};
    L=0;
    
else
    msg=['Specified analysis period ' str1 ' OK'];
    L=1;
end




function [L,msg]=subfun16(yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2,minlen)
% Check for validity of sub-periods for early-vs-late test
%
% yrgo, yrsp = start and end years of full analysis period
% yrgo1,yrsp1 = start and end years of early period
% yrgo2, yrsp2 = start and end years of late period
% minlen = minimum allowable length of series for correlation
%
% L = logical telling if period OK (1) or not (0);
% msg =  error message

str1 = [num2str(yrgo1) '-' num2str(yrsp1)];
str2 = [num2str(yrgo2) '-' num2str(yrsp2)];
str3 = [num2str(yrgo) '-' num2str(yrsp)];

msgs ={['Specified early sub-period ' str1 ' outside specified full-analysis period ' str3],...
    ['Specified late sub-period ' str2 ' outside specified full-analysis period ' str3],...
    ['Specified early sub-period ' str1 ' shorter than ' num2str(minlen) ' years'],...
     ['Specified late sub-period ' str2 ' shorter than ' num2str(minlen) ' years'],...
     ['Early sub-period ' str1 ' overlaps late sub-period ' str2],...
     ['Specified late sub-period ' str2 ' precedes early sub-period ' str1]};
 
 if yrgo2<=yrgo1;
     msg=msgs{6};
     L=0;
 elseif (yrsp1>=yrgo2);
     msg = msgs{5};
     L=0;
     
 elseif yrgo1<yrgo || yrsp1> yrsp;
     L=0;
     msg = msgs{1};
     
 elseif yrgo2<yrgo || yrsp2>yrsp;
     L=0;
     msg= msgs{2};
     
 elseif (yrsp1-yrgo1+1)<minlen;
     msg = msgs{3};
     L=0;
 elseif (yrsp2-yrgo2+1)<minlen;
     msg = msgs{4};
     L=0;
 else
     msg=['Specified sub-periods ' str1 ' and ' str2 ' OK'];
     L=1;
 end
 
 function ResultSub=subfun17(H,yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2)
% 
% Test for difference of correlation of climate with tree rings  in early and
%   late sub-periods. Test done for primary climate variable vs tree-ring
%   index, and for the best-correlated season for each of the four
%   season-lengths
%
% yrgo, yrsp = start and end years of full analysis period
% yrgo1,yrsp1 = start and end years of early period
% yrgo2, yrsp2 = start and end years of late period
% H structure with
%   .P (m x4)r time series of primary climate variable for the 4 key
%   seasons
%   .x (m x1)r time series of the tree-ring index
%   .yrx (mx1)r year vector for P and x
%   .nms {1x14}s  ending-month names
%   .g{1x4}r number of months in each of the four seasons
%   .i14(4x1)r index to label of ending month (into nms) of 4 key seasons

%close(2);
mons ={'Jan**','Feb**','Mar**','Apr**','May**','Jun**','Jul**',...
    'Aug**','Sep**','Oct**','Nov**','Dec**',...
    'Jan*','Feb*','Mar*','Apr*','May*','Jun*','Jul*',...
    'Aug*','Sep*','Oct*','Nov*','Dec*',...
    'Jan','Feb','Mar','Apr','May','Jun','Jul',...
    'Aug','Sep','Oct','Nov','Dec'};

%--- Unload a few things

P=H.P;
x=H.x;
yrx=H.yrx;
g=H.g;
i1 = H.i14;
nms = H.nms;

%---- CHECKS

% Analysis period
if yrgo~=yrx(1) || yrsp~=yrx(end);
    error('Miss-match in start and end year of full-analysis period');
end
strfull=[num2str(yrgo) '-' num2str(yrsp)];
stre = [num2str(yrgo1) '-' num2str(yrsp1)];
strl = [num2str(yrgo2) '-' num2str(yrsp2)];

%--- LAG-1 AUTOCORRELATIONS

r1_P=nan(4,1);
r1_x = subfun18(x);
for n = 1:4;
    y = P(:,n);
    r1_P(n) = subfun18(y);
end
clear y n


%---  ADJUSTMENT FACTOR FOR COMPUTING EFFECTIVE SAMPLE SIZE (ADJUSTED FOR
% LAG-1 AUTOCORRELATION); COMPUTE ADJUSTMENT FACTOR USING THE DATA FOR THE
% FULL-PERIOD ANALYSIS

u = repmat(r1_x,4,1);
v = r1_P;

% In computing the adjustment factor for a pair of series, flag any
% pair for which either of the series has a non-positive lag-1 autocorrelation.
% These flagged pairs will NOT have the sample size adjusted, and their
% effective sample size will be identical to the original sample size.
Lnull = u<=0 | v<=0;
f = (1-u.*v) ./ (1+u.*v); % adjustment factor for each pair of series
f(Lnull)=1.0;


%--- CLIMATE-TREE RING CORRELATIONS

R=nan(4,3); % to hold correlations for full-period, early sub-period and late sub-period
N1 = nan(4,3); % to hold original sample size corresponding to R
N2 = nan(4,3); % to hold effective sample size (for evaluation of significance of correl)

[R(:,1) N1(:,1)] = subfun19(x,P); % full-period correlations

% Early sub-period
L= yrx>=yrgo1 & yrx<=yrsp1;
x1=x(L);
P1 = P(L,:);
[R(:,2) N1(:,2)] = subfun19(x1,P1); 

% Late sub-period
L= yrx>=yrgo2 & yrx<=yrsp2;
x1=x(L);
P1 = P(L,:);
[R(:,3) N1(:,3)] = subfun19(x1,P1); 


%---- EFFECTIVE SAMPLE SIZE

F= repmat(f,1,3); % will apply adjustment factor based on full-period lag-1 autocorrelation to sub-periods 
%  as well as full period
N2 = N1 .* F;


%--- TEST FOR DIFFERENCE OF CORRELATION

D=nan(4,12); % storage matrix to hold
% col 1-3 Pearson r for full, early, late sub-periods
% col 4-5 effective sample size for assessment of
%   significance 
% col 6-7 Fisher transformed correlations for early, late periods
% col 8  difference in transfomed correlation, late-early
% cols 9-11  variance of z1, z2, d
% col 12 p-value for significance of differenc in correlation

for n =1:4; % loop over season-lengths
    r1 = R(n,2); % early-period correlation
    n1 = N2(n,2); % early period effective sample size for correlation
    r2 = R(n,3); % late-period correlation
    n2 = N2(n,3); % late period effective sample size for correlation
        
    G = corrdiff(r1,r2,n1,n2);
    D(n,2:12)=[r1 r2 n1 n2 G.z1 G.z2 G.diff G.variance G.pvalue];
end
D(:,1)=R(:,1); % full-period corelation

% p-value truncation.  Check p-values for significance of difference in
% correlation. If pvalue<0.001, set to 0.001
pv = D(:,12);
L = pv<0.001;
pv(L)=0.001;



%--- BUILD TABLE

c1 = num2str(D(:,1),'%5.2f'); % correlation, early
c2 = num2str(D(:,2),'%5.2f'); % correlation, early
c3 =  num2str(D(:,3),'%5.2f'); % correlation, late
c4 = num2str(D(:,4),'%5.0f'); % adjusted sample size for correlation assessment,early
c5 = num2str(D(:,5),'%5.0f'); % adjusted sample size for correlation assessment,lated
c6 = num2str(D(:,8),'%6.4f'); % difference in Fisher-transformed correlations
c7 = num2str(pv,'%6.3f'); % p-value for difference in transformed coeff 


% Season label
nms = strrep(nms,'_prev','*');
seaslabs = cell(4,1);
gg=nan(4,1);
for n =1:4;
slast =nms{i1(n)};
i3=strmatch(slast,mons,'exact');
    nmos = g{n}; % number of months
    gg(n)=nmos;
    if nmos~=1;
        sfirst = mons{i3-nmos+1};
        seasname =[sfirst '-' slast];
    else
        seasname=slast;
    end
    seaslabs{n}=seasname;
end
a1=strjust(char(seaslabs),'right');
a2 = num2str(gg,'%3.0f');



b1 = repmat(' ',4,1);
b2 = [b1 b1];
b3=[b1 b2];

torso1= [a1 b3 b2 a2 b3 c1 b2 c2 b2 c3 b3 b2 c4 b1 c5 b2 c6 b3 b1 c7];

tit1 = char({'TEMPORAL STABILITY OF CORRELATION FROM EARLY TO LATE SUB-PERIOD',...
    ' ',...
    [' Full =  ' strfull ',  Early = ' stre ',  Late  = ' strl],...
    ' '});
 
head1=char({'--------------------------------------------------------------',...
    '                                      Sample',...
    '    Season^{a}          Correlation^{b}       Size^{c}    Test Results^{d}',...
    '---------------   ----------------    ------  ---------------- ',...
    '  Months length   Full Early  Late     \it{N}\rm_{1} \it{N}\rm_{2}     \Delta\it{Z}       \it{p}\rm',...
    '--------------------------------------------------------------'});


tail1=char({'--------------------------------------------------------------',...
    '',...
    '^{a}Season: start & end months and number of months in season;',...
    ' asterisk denotes year preceding tree-ring year.',...
    '^{b}Correlation: Pearson correlation of tree-ring index with primary',...
    ' climate variable for full-period, early-period, and late-period.',...
    '^{c}Sample Size: \itN\rm_{1} and \itN\rm_{2} are the effective sample sizes for the',...
    ' correlations computed on early and late sub-periods, respectively.',...
    ' Effective sample size is fewer than the number of observations if ',...
    ' both time series have positive lag-1 autocorrelation. ',...
    ' Autocorrelations for the assessment computed on the full analysis',...
    ' period. Sample-size adjustment after Dawdy and Matalas (1964).',...
    '^{d}Test Results: The test statistic (\Delta\itZ\rm) is the difference between',...
    ' transformed correlations for the early and late periods, following',...
    ' Panofsky and Brier (1968) and Snedecor and Cochran (1989).  The',...
    ' last column is the \itp\rm-value for a test of the null hypothesis that',...
    ' the population sample correlations for the early and late period',...
    ' are the same. A significant difference in sub-period correlations',...
    ' is indicated by a small \itp\rm (e.g., \itp\rm<0.05).',...
    '',...
    ''});


body1 = char(tit1,head1,torso1,tail1);

figure(11);
[cL,cB,cW,cH]=figsize(0.65,0.78);
set(gcf,'Position',[cL cB cW cH]);
hax = axes;
set(gca,'XLim',[0 1],'YLim',[0 1]);
htext = text(0.02,0.95,cellstr(body1),'HorizontalAlignment','Left','VerticalAlignment','Top','FontSize',10,'FontName','Courier');
set(gca,'Visible','off')
set(gca,'Position',[0.1300    0.0500    0.73   0.91])


ResultSub.what = char({['Output stored by seascorr/subfun17 on ' datestr(date)]...
   'Test for difference of correlations between two sub-periods',...
   'Correlations tested are tree-ring index with primary climate variable',...
   'for periods:',...
   ['  Full = ' strfull],...
   ['  Early = ' stre],...
   ['  Late = ' strl],...
   'Refer to ResultSub.table for definitions of the four seasons tested. ',...
   'ResultSub is stucture with fields:',...
   '   .table (char mtx) = summary table',...
   '   .treer1 (1x1)r  lag-1 autocorrelation of tree ring index on full period',...
   '   .climr1 (4 x 1)r lag-1 autocorrelations of the 4 key regional climate series',...
   '   .D (4x11)r  summary data matrix (1 row per season), with columns:',...
   '       1-3 Pearson correlations for full, early and late periods',...
   '       4-5 Effective sample sizes for early and late periods.  These are',...
   '           sample sizes adjusted for lag-1 autocorrelation',...
   '       6-7 Fisher-transformed versions of correlations in cols 2 and 3',...
   '         8 Difference of Fisher-transformed correlation in early and late period',...
   '      9-11 Variance of z1,z2, and deltaz, which are, respectively, the transformed',...
   '           early correlation , late correlation and difference early-late',...
   '        12 p-value for test of null hypothesis that population correlations the',...
   '           same in early and late sub-periods'});
ResultSub.table = body1;
ResultSub.treer1=r1_x;
ResultSub.climr1=r1_P;
ResultSub.D = D;


function r=subfun18(x)

%------ LAG-1 AUTOCORRELATIONS

x1=x(1:(end-1));
x2=x(2:end);
r = corrcoef([x1 x2]);
r=r(1,2);


function [r,n]=subfun19(x,Y)
% Compute Pearson correlations, climate vs tree ring
X= repmat(x,1,4); % col-dupe the tree-ring series
[r,n]=corrpair(X,Y);
r=r'; % to cv
n=n'; % to cv



function [yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2,Lsub] =subfun20(time_specs,yr,c,d)
% Checks "driver-script" analysis periods 
%
% time_specs{3x1} cells with start and end year of full-period,
% early-period and late-period
% yr (?x1)r   year vector corresponding to default full-period based on
%   available overlap of climate and tree rings
% c  minimum allowable length of full-analysis period
% d mimumum allowable length of a sub-period
% Lsub (1x1)L  ==1: do sub-period test; ==0 skip

ts1 = time_specs{1};
ts2 = time_specs{2};
ts3 = time_specs{3};


%---Store specified full-analyis period
if isempty(ts1)
    yrgo = yr(1);
    yrsp = yr(end);
    Lempty=true;
elseif length(ts1)==2
    yrgo=ts1(1);
    yrsp = ts1(2);
    Lempty=false;
else
    error('time_specs{1} must be empty or vector of length 2')
end


%---Check full-period against yr and truncate if necessary
if Lempty
     str_full = [num2str(yrgo) '-' num2str(yrsp)];
     mess1 = {['Full-period analysis set to ' str_full ',the overlap of climate and tree-rings'],...
         'with start year adjusted to accomodate need for two leading years of climate data for lagged correlations'};
        uiwait(msgbox(mess1,'Message','modal'));
else
   yrgo_spec=yrgo;
   yrsp_spec=yrsp;
   str_spec = [num2str(yrgo_spec) '-' num2str(yrsp_spec)];
   Ltrunc=false;
    if yrgo <yr(1)
        yrgo = yr(1);
        Ltrunc=true;
    end
    if yrsp >yr(end);
        yrsp = yr(end);
        Ltrunc=true;
    end
    str_full = [num2str(yrgo) '-' num2str(yrsp)];
    if Ltrunc
        mess1 = {['Full-period analysis truncated from ' str_spec ' to ' str_full],...
            'for consistency with overlap of climate and tree-ring data. Because lags are needed for the correlation',...
            'analysis, the full-analysis period cannot start until two years after the start of monthly climate. For these data, ',...
            ['the widest possible full-analysis period is consequently ' num2str(yr(1)) '-' num2str(yr(end)) ]};
        uiwait(msgbox(mess1,'Message','modal'));
    else
    end
end
[L,msg]=subfun15(yrgo,yrsp,yr,c); % QC check of full-analysis period
if ~L;
    error(msg);
end

 

%--- CHECK SUB-PERIODS

% Empty?
L2 = isempty(ts2);
L3 = isempty(ts3);
if (L2 && ~L3) || (L3 && ~L2);
    error('Cannot specify one of time_specs{2} and time_specs{3} empty and not the other')
end

if L2; % if empty specifed sub-periods
    % Set default if empty
    a=yrgo;
    b=yrsp;
    % Split full period in half, favoring length of first half if n odd
    n = b-a+1; % number of years in default full period
    if mod(n,2)==0; % even number of years
        a1=a;
        b1 = a + n/2 -1;
    else
        a1=a;
        b1 = a +ceil(n/2)-1;
    end
    a2=b1+1;
    b2=b;
    yrgo1=a1;
    yrsp1=b1;
    yrgo2=a2;
    yrsp2=b2;
    if (b1-a1+1)<d  || (b2-a2+1)<d
        Lsub=0;
        
        
        str_skip=['Sub-period test of correlations will be skipped because ' num2str(yrgo1) '-' num2str(yrsp1) ' or ' num2str(yrgo2) '-' num2str(yrsp2)  ' less than ' nym2str(d) ' yr'];
        uiwait(msgbox(str_skip,'Message','modal'));
        return
    else
        Lsub=1;
    end
else
    % sub-periods not empty
    if length(ts2)~=2 || length(ts3)~=2;
        error('time_specs{2} and time_specs{3} must be empty or vectors of length 2');
    end
    yrgo1 = ts2(1); % start of early period
    yrsp1 = ts2(2); % end of ...
    yrgo2 = ts3(1); % start of late period
    yrsp2 = ts3(2); % end o ...
    
    [L,msg]=subfun16(yrgo,yrsp,yrgo1,yrsp1,yrgo2,yrsp2,d);
    if L==0;
        uiwait(msgbox(msg,'Message','modal'));
        uiwait(msgbox('Sub-period test of correlations will be skipped','Message','modal'));
        Lsub=0;
    else
        Lsub=1; % do the sub-period test
    end
    
end
function subfun21(R,f1,f2)
% Writes output files for standalone users
% R is structure Result in Seascorr
% f1 is name of output file for formated table output
% f2 is name of output file for all-numeric, 56x9 matrix of correlatoins,
% etc
%
% Applies fprintf to write 2 output files of statistics

%------ Table summaries (4 tables)


sdivide=char(' ','$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',' ');

head1=char('Below are four tables.  Each table lists the correlations and',...
'partial correlations and their significance for one of the four',... 
'seasonal groupings in Figure 1 of Seascorr output.',' ');

for n =1:4;
    if n==1;
        D=char(head1,R.S{n});
    else
        D=char(D,sdivide,R.S{n})
    end
end
[mD,nD]=size(D);
fid = fopen(f1,'w');
fmt = ['%' num2str(nD) 's\n'];
for n = 1: mD;
    d=D(n,:);
    fprintf(fid,fmt,d)   
end
fclose(fid);    
 

%------ Numerical statistics summary

head1=char('Below is a 56x9 numeric matrix with correlations, partial correlations, etc. The 56 columns',...
    'correspond to the 56 ''seasons'' in Seascorr (14 ending months x 4 seas6on length).  The order of the rows',...
    'is the same as the order of ''seasons'' in Seascorr Figure 1.  The columns of the 56x8 mattrix are as follows:',...
    ' ',...
    '1 sequential ''season'' number, from 1 to 56',...
    '2 correlation of tree-ring variable with the primary climate variable',...
    '3 Monte Carlo nonexceedance probability of the the above correlation',...
    '4 partial correlation of tree-ring ring index for secondary climate variable (controlling for primary)',...
    '5 Monte Carlo nonexceedance probability of the the above partial correlation',...
    '6 correlation of primary climate variable with secondary climate variable',...
    '7 lag-1 autocorrelation of P',...
    '8 lag-1 autocorrelation of T.P (secondary climate variable after removal of linear dependence on primary climate variable');



j = (1:length(R.r1))';
X=[j R.r1 R.p1 R.r2 R.p2 R.r3 R.r4 R.r5];
[mX,nX]=size(X);
fmt2='%3d %6.3f    %7.4f    %6.3f    %7.4f    %6.3f    %6.3f    %6.3f\n';

fid = fopen(f2,'w');

[mh,nh]=size(head1);
fmt4 = ['%' num2str(nh) 's\n'];
for n = 1:mh;
    h = head1(n,:);
    fprintf(fid,fmt4,h);   
end

head2=char('',['Lags 1-6 autocorrelation of x : ' num2str(R.r6')],' ');
[mh,nh]=size(head2);
fmt5 = ['%' num2str(nh) 's\n'];
for n = 1:mh;
    h = head2(n,:);
    fprintf(fid,fmt5,h);   
end

head3=char('','  1    2          3         4          5        6          7         8','');
[mh,nh]=size(head3);
fmt6 = ['%' num2str(nh) 's\n'];
for n = 1:mh;
    h = head3(n,:);
    fprintf(fid,fmt6,h);   
end

fprintf(fid,fmt2,X')   ;
fclose(fid)


