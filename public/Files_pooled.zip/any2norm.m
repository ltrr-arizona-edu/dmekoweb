function Result=any2norm(x,kopt)
% any2norm: data of any distribution to normal by cdf mapping
% function Result=any2norm(x,kopt);
% Last Revised 2017-11-12
%
% Data of any distribution to normal by cdf mapping. Data is sorted increasing.  Values are
% mapped to standard normal with same non-exceedance probability.  Finally, original mean and
% standard deviation are restored.  Lookup table is created to allow back-and-forth conversion
% between the empiricl distribution of x and the normal distribution with the same mean and 
% variance. See notes for caveats on use
%
%****   INPUT 
%
% x (mx x 1)r   time series; no NaN allowed; must be row vector of length
%   at least 20
% kopt -- options
%   kopt(1) graphics
%       ==true:  figure windows with histograms & time plots
%       ==false: skip graphics
%
%*** OUTPUT
%
% Result -- structure of results
%   .y (my x 1)r  the normal-converted version of x; has same mean  and std
%         dev as x
%   .nties (? x 1)i number of ties in sorted x;  [] if no ties;  otherwise, nties(j) holds
%         number of ties of length j.  Because ties of length 1 are moot
%   .V (my x 2); lookup table whose columns are (1) sorted normalized
%      series and (2) sorted original series;
%
%*** REFERENCES --- none
%
%*** TOOLBOXES NEEDED -- none
%
%*** UW FUNCTIONS CALLED -- none
%
%*** NOTES
%
% If x has repeated values, the conversion will fail to some extent.  The
% problem is more extreme the more repeated valued there are.  For example,
% if 1/4 of x are the same, the converted series will also have 1/4 of its
% values the same, and this cannot be normally distributed
%
% x must be cv of length at least 20
%
% Empirical non-exceedance prob is computed by sorting values and giving
% probability (j-0.5)/n to each, where j is the rank and n is the length of
% x
%
% To recover the original series from the transformed series, use
% v1 = interp1(Result.V(:,1),Result.V(:,2),Result.y),
% assuming have transfomed with Result = any2norm(v).
%
% Revised 2017-11-12 optional skipping of graphics; to avoid messing up
% existing graphic in calling script or function when want to retain those
% figure windows

L= isvector(x) && size(x,1)>20 && ~any(isnan(x));
if ~L;
    error('x must be cv of length at least 20, and have no NaN');
end
mx=length(x);
xmn=mean(x);
xstd = std(x);


%--- PERCENTILES THAT CORRESPOND TO THE RANKED x

j = (1:mx)';
p = (j-0.5)/mx;



%--- GET RANKS OF x

[r,nties]=ranktie1(x);


%--- COMPUTE CORRESPONDING NON-EXCEEDANCE PROBS

p = (r-0.5)/mx;


%---- GET STD NORMAL VALUES EITH THOSE NON-EXCEEDANCE PROBS, THEN CONVERT BACK TO
% ORIGINAL MEAN AND STD OF x

y=norminv(p,0,1); % standard norm deviates corresponding to the non-exceedance probs of the sorted x
z = zscore(y); % force to exactly [0,1]
y = xmn + (z * xstd); % convert to desired mean, std dev

ymn = mean(y);
ystd = std(y);


if kopt(1)==true
        
    %---    HISTOGRAMS
    
    ylims = [min([min(x)  min(y)])   max([max(x)  max(y)])];
    figure(1);
    subplot(2,1,1)
    hist(x);
    set(gca,'XLim',ylims);
    title(['Histogram of x; mean = ' num2str(xmn) ', std dev = ' num2str(xstd)]);
    
    
    subplot(2,1,2);
    hist(y);
    set(gca,'XLim',ylims);
    title(['Histogram of y; mean = ' num2str(ymn) ', std dev = ' num2str(ystd)]);
    
    
    %-- TIME SERIES
    
    figure(2);
    hp1 = plot(j,x,j,y,[j(1) j(end)],[xmn xmn]);
    if mx<=100;
        set(hp1(1),'Marker','o');
        set(hp1(2),'Marker','^');
    end
    xlabel('Time');
    ylabel('Data');
    legend('x','y','Mean of x')
    
else
end

Result.y=y;
Result.nties=nties;
Result.V = [sort(y) sort(x)];





