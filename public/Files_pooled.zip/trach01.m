function Result=trach01
% trach01: Sensitivity of cell-anatomy climate signal on width of climate day-window
% Result=trach01(datin,specs)
% Last revised 2019-09-30
%
% Sensitivity of cell-anatomy climate signal on width of climate
% day-window. First of three functions (trach01,02,03) aimed at color
% mapping the strength of correlation of quantile (ring-portion)
% cell-anatomy tree-ring time series with day-windowed climate.
%
%*** INPUT
%
% No input arguments. User prompted to click on specifically formatted
% input files of tree-ring data and daily climate data. These may
% optionally be xlsx spreadsheet files or mat (Matlab) files.  User also
% prompter for various settings of specifications. Defaults are hard coded
% at start of this function. 
%
%*** OUTPUT
%
% Figures with color-mapped correlation. X-axis is starting day of first
% climate window. In Northern Hemisphere this axis goes from Jan 1 to Jan
% 30.  Y-axis is width of window, which is hard coded to vary from 5 days
% to 30 days. Color-mapped is maximum Spearman or Pearson (optional)
% correlation reached. Figure window #1 maps the highest positive
% correlation. Figure window #2 maps the highest negative correlation. Note
% that have a sample correlation for each combination of 
%
%*** NOTES
%
% One figure window will be produced for each tree-ring series. Each
% tree-ring series represents some cell-anatomy variable (e.g., lumen area
% (LA)) for some portion (nominally called a "quantile") of the ring width
% or ring number. 
%
% The figure window is color-mapped Spearman or Pearson (optional)
% correlation between the tree-ring series and day-windowed climate for a
% window width (y-axis) and given day-of-year (x-axis) of the end of the
% window. For example, a row of the correlation matrix might apply to the
% correlation of LA with 10-day average soil water content (SWC) for 10-day
% periods with ending days ranging from #32 (Feb 1) to #365.
%
% x-axis is labeled "Day of year," and covers days 32-360. This is ending
% day of given window. y-axis is window size, in days, ranging from 5 to
% 30.
%
% Outline...
%   Read tree-ring file and daily climate file
%       Store name of tree-ring variable, and store the variable, y, for each
%       quantile in a different col of Y. 
%   Allocate R for correlations for different window sizes (j) and
%       different ending days (i), where i and j are indices to x and y
%       axis
%   Loop over window sizes m=5:30 days
%       m-day run moving average or sum, storing year, day number and
%           value-->u, yr, day#
%       Loop over ending days 32-365
%           Pull annual time series for given combination of m and ending day-->v, yrv
%           Store as a column of V; each column for a different end day
%       Have tsm V, with yrV
%       Using corr, get vector r of correlation of z with cols of V
%       Store that vector of correlations in row j of R
%   Store R in cell of a col-cell variables, G
%   Loop over the cells of G, each time making a figure window with
%       color-mapped correlation
%


%--- PRELIMINARIES

%--- Block climate daily matrix so starts with a Jan 1 and ends with a
% last day of December----->X

%--- Count number of years in X, and build year vector yrX

%--- Read tree-ring series;  store as Y , yrY; each col a different
% quantile tree-ring series

%--- Compute maximum possible analysis period for correlations with
% day-windowed climate; allow choice of shorter period

%---Trim x and Y to analysis period (X1,y1)

% Hard Code
close all
defname1='TSME_LA.mat';
defname2='simulationsCPRdaily_B.xlsx';

xgo=32; xsp =365; % x-axis, day of year; ending day of windowed climate
ygo =5; ysp =32; %  y-axis;  windows size in days
jx =(xgo:xsp)';
jy =(ygo:ysp)';
mR = length(jy);
nR = length(jx);

treevars={'Mean lumen area','Mean cell-wall thickness'};
treevs ={'LA','CWT'};
ktree = menu('What kind of cell-anatomy time series?',treevars);
if ktree~=1
    error('Coded so far only for mean lumen area')
end
treevar =treevars{ktree};
treev =treevs{ktree};

prompt = {'Enter tree-ring data files suffix:','Enter climate data file suffix:'};
title = 'Enter suffixes for input data ffiles';
dims = [1];
definput = {'mat','xlsx'};
answer = inputdlg(prompt,title,dims,definput);
ftype_tree=answer{1};
ftype_clim=answer{2};

% Get tree-ring file path, filename, and file type
tit1='Input file with cell-anatomy time series';
if strcmp(ftype_tree,'mat')
    ffilter={'*.mat'};
elseif strcmp(ftype_tree,'xlsx')
     ffilter={'*.xlsx';'*.xls'};
end
[file,path,indx]=uigetfile(ffilter,tit1,defname1)
pftree=fullfile(path,file);
filetree=file;

% Get climate-data file path, filename, and file type
tit1='Input file with day-windowed climate time series';
if strcmp(ftype_clim,'mat')
    ffilter={'*.mat'};
elseif strcmp(ftype_clim,'xlsx')
     ffilter={'*.xlsx','*.xls'};
end
[file,path,indx]=uigetfile(ffilter,tit1,defname2)
pfclim=fullfile(path,file);


%--- READ CLIMATE DATA FILE

if strcmp(ftype_clim,'xlsx') || strcmp(ftype_clim,'xls')
[A,B]=xlsread(pfclim);
elseif  strcmp(ftype_clim,'mat') 
    eval(['load ' pfclim ';']) % year vector, data matrix and cell of series labels, such as "SWC"
else
end

%---- SELECT CLIMATE VARIABLE

bheads =B(1,:);
bnms=bheads;
bnms(1:4)=[];
kpick1= menu('Choose climate variable',bnms);
xwant = bnms{kpick1}; % say, "SWC"

specs.datatype=[xwant];
% xwant='SWE';
% specs.datatype=[xwant ' (mm)'];


%-----STORE DAILY CLIMATE TIME SERIES IN X

iwant = find(ismember(bheads,xwant));
X=A(:,[1 2 3 4 iwant]); % yr, month, day of month, day of yr, data value


%----- COMPUTE THE DAY-WINDOWED CLIMATE AND ASSOCIATED PLOTTING POINTS
%       FOR FIRST OF EACH MONTH ON EVENTUAL TIME PLOT THAT STARTS JAN 1 IN
%       NORTHERN HEMISPHERE AND JULY 1 IN SOUTHERN HEMISPHERE. THE FIRST
%       DAY WINDOW NEED NOT START IN JAN 1 OR JULY 1, BUT MUST START IN
%       SOME DAY OF JAN (NH) OR JULY (SH).


% Set up input for call to daygrp01

prompt = {'Enter seasonalizing method (''mean'' or ''sum'')',...
    'Enter hemisphere ("N" or "S")',...
    'Enter caxis lower correlation for caxis',...
    'Enter caxis lower correlation for caxis',...
    'Enter figure width and height as screen fraction'};
title = 'Specification for windows and mapping';
dims = [1 ];
definput = {'mean','N','-1.0','1.0','[0.8 0.5]'};
a = inputdlg(prompt,title,dims,definput);

datin.X=X;
specs.howseas=a{1};
specs.hemisphere=a{2};
specs.caxisLo=str2num(a{3});
specs.caxisHi=str2num(a{4});
cLo=specs.caxisLo;
cHi=specs.caxisHi;
fdims=str2num(a{5});


%--- Block climate daily matrix so starts with a Jan 1 and ends with a
% last day of December----->X

yr = X(:,1); mo = X(:,2); daymo=X(:,3);
L = mo==1 & daymo==1;
i1 = find(L);
i1=i1(1); 
L = mo==12 & daymo==31;
i2 = find(L);
i2=i2(end); 
X = X(i1:i2,:);

%--- Count number of years in X, and build year vector yrX
yr = X(:,1); mo = X(:,2); daymo=X(:,3);
yrX = unique(yr);
d = diff(yrX);
if ~all(d==1)
    errror('yr1 does not increment by 1')
end


%----MENU TO CHOOSE COLOR MAP

colmaps={'parula','jet','hsv','hot','cool','gray','copper'};
kcolmap=menu('Choose color map',colmaps);
colmap=colmaps{kcolmap};


%---- Load tree-ring time series into Y, yrY
if strcmp(ftype_tree,'xlsx') || strcmp(ftype_tree,'xls')
    error('Tree-ring data input so far coded for mat only')
elseif  strcmp(ftype_tree,'mat')
    eval(['load ' pftree  ';']);  % structure D.Chron
    Y=D.Chron.X; yrY = D.Chron.yrX;
else
end


%--- Compute maximum possible analysis period for correlations with
% day-windowed climate; allow choice of shorter period

yrgo = max([yrX(1) yrY(1)]);
yrsp = min([yrX(end) yrY(end)]);
str_yrs1 =[num2str(yrgo) '-' num2str(yrsp)];

qanal = questdlg(['Accept default maximum possible analysis period of ' str_yrs1 '?']);
if strcmp(qanal,'Yes')
    ichange=false;
else
    yrgo1=yrgo; yrsp1=yrsp;
    kwh1=0;
    while kwh1==0
        prompt = {'First year','Last year'};
        title =['Specify analysis period (' str_yrs1 ')'];
        dims = [1 ];
        definput = {num2str(yrgo1),num2str(yrsp1)};
        a = inputdlg(prompt,title,dims,definput);
        options.Resize='on';
        yrgo2 = str2num(a{1});
        yrsp2 = str2num(a{2});
        if yrgo2<yrgo || yrsp2>yrsp
            h=warndlg('Specified years outside data coverage');
        else
            kwh1=1;
            yrgo=yrgo2;
            yrsp = yrsp2;
            ichange=true;
        end
    end
end



%---- TRIM X AND Y TO COVER SAME YEARS

L=X(:,1)>=yrgo & X(:,1)<=yrsp;
X=X(L,:);
yrX=(yrgo:yrsp)';
L=yrY>=yrgo & yrY<=yrsp;
Y=Y(L,:); yrY=yrY(L);
[mY,nY]=size(Y);
[mX,nX]=size(X);


%==== CORRELATION ANALYSIS AND MAPPING
%
%   Allocate R for correlations for different window sizes (j) and
%       different ending days (i), where i and j are indices to x and y
%       axis
%
% Recall already have the needed information
% xgo, xsp, ygo, ysp as the start and end points of x and y axes
% jx and jy as vectors of those axes points
% mR and nR as row-size and col size of matrices to hold correlations. 


%--- MOVING AVERAGE OR OR MOVING SUM MATRICES OF WINDOWED CLIMATE

W =cell(length(jy),1); % each cell to hold a tsm of day-windowed climate for a different window width m days. 
% the cols fo the tsm will be time series for the m-day period with ending
% day  xgo to xsp
[mW,nW]=size(W);

x=X(:,5); % the daily climate time series
d =X(:,4); % day of year
yrd =X(:,1);
tx= (1:mX)'; % sequential time vector
for n =1:length(jy); % loop over window size, short to long
    B = nan(mY,nR); % mY years by nR ending days
    m=jy(n); % the window size
    
    % moving average of length m days
    [x1,tx1]=mafilt1(x,tx,m,2);
    d1=d(tx1);
    yrd1 = yrd(tx1);
    
    for k =1: length(jx);
        dkey = jx(k);
        L = d1==dkey; % windows endng on desired day
        x2=x1(L);
        yrx2= yrd1(L);
        if length(x2) ~= mY
            error(['For window-width ' num2str(m) ' and ending day ' num2str(dkey) ',  annual series not length ' num2str(mY) ' years'])
        end
        B(:,k)=x2;
    end
    W{n}=B; % B in W{1} is for the shortest desired window, or shortest moving average
end

G = cell(nY,1); % each to hold a correaltion matrix for a different tree-ring quantile

for n = 1:nY
    R = nan(mR,nR);
    y = Y(:,n); % tree-ring time series
    for kk =1:mW
        B=W{kk};
        r = corr(y,B,'type','Spearman');
        R(kk,:)=r; % note that the top row of R applies to the shortest window, the bottom row to the longest
    end
    G{n}=R;
    
end


%----- COLOR MAPPING

str_tita=[treev '(' filetree ') vs ' xwant ', ' num2str(yrgo) '-' num2str(yrsp)];

for n =1:nY
    
    str_titb =['Quantile ' num2str(n) '/' num2str(nY) ' of ' str_tita];
    R=G{n};
    
    % find largest + and - correlation in R, and their position
    [xtemp,itemp] = max(R); % rv of max for each window end-day
    [xtemp,itemp] = max(xtemp); %  window end-day with max positive r
    xkey =jx(itemp);
    xa = R(:,itemp); % cv of R for that window end-day
    [xtemp,jtemp]=max(xa); % the highest positive value in R is xtemp
    ykey=jy(jtemp); % the window size for that R
    rbiggie=R(jtemp,itemp);
    rstr_p =['Max positive, r=' num2str(rbiggie,'%5.2f') ' for ' num2str(ykey) '-day window ending on day ' num2str(xkey)];
    xkeyp=xkey; ykeyp=ykey;
    
    % find largest  - correlation in R, and position
    [xtemp,itemp] = min(R); % rv of max for each window end-day
    [xtemp,itemp] = min(xtemp); %  window end-day with min positive r
    xkey =jx(itemp);
    xa = R(:,itemp); % cv of R for that window end-day
    [xtemp,jtemp]=min(xa); % the highest negative value in R is xtemp
    ykey=jy(jtemp); % the window size for that R
    rneggie=R(jtemp,itemp);
    rstr_n =['Max negative, r=' num2str(rneggie,'%5.2f') ' for ' num2str(ykey) '-day window ending on day ' num2str(xkey)];
    xkeyn=xkey; ykeyn=ykey;
    
    figure(n);
    [cL,cB,cW,cH]=figsize(fdims(1),fdims(2));
    set(gcf,'Position',[cL cB cW cH]);
    
    h=imagesc(jx,jy,R);
    caxis([cLo cHi]);
    xlabel('Ending day of window')
    ylabel('Window size (days)');
    hold on
    h1=plot(xkeyp,ykeyp,'o','MarkerSize',12,'Color',[0 0 0],'MarkerFaceColor',[ 0 0 0]);
    h2=plot(xkeyn,ykeyn,'o','MarkerSize',12,'Color',[0 0 0]);
    hb=colorbar;
    hb.Label.String='Correlation (Spearman)';
    hb.Label.FontSize=12;
    hold off
    hax =gca;
    hax.Title.String=str_titb;
    str_msg1={rstr_p,rstr_n};
    uiwait(msgbox(str_msg1,'Message str_msg1','modal'));
    
end

% STOPPED HERE
end