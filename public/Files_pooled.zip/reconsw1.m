function Result=reconsw1(X,yrX,y,yry,specs,specsSim)
% reconsw1: stepwise reconstruction using leave-m-out cross-validation to choose final step
% Result=reconsw1(X,yrX,y,yry,specs,specsSim);
% Last revised 2019-08-27
%
% Stepwise reconstruction using leave-m-out cross-validation to choose final step.
% Model optionally handles lags on predictors. With no lags,
% cross-validation is leave-1-out. With lags, more than one observation is
% left out in cross-validation (see below). Cross-validation is used to
% select the appropriate step that a final regression model should be
% stopped at, with criterion of minimum root-mean-square error of
% validation. The method used here avoids the common mistake of using an
% initial regression on all observations to select the final predictors
% BEFORE cross-validating the model. Doing so is equivalent to "peeking" at
% the validation data beforehand, which guarantees that cross-validation
% will favor the model you have already selected.
%
%*** INPUT
%
% X (mX x nX)r  predictors-- matrix or vector time series of predictors
% yrX (mX x 1)i year vector for X
% y (my x 1)r  predictand; or for site-centered recons, a matrix (my x ny)
% yry (my x 1)i year vector for y
% specs = structure of specifications
%   .pin for entry in stepwise (see notes for special case)
%   .pout for removal in stepwise (see notes for special case)
%   .nlag: maximum negative lag on predictors (
%   .plag: maximum positive lag allowed on predictors
%   .CalYrs (1x2)i or []:   a specified first and last year (on y) of
%      calibration period; if [], function will use longest possible calib  period
%   .LRA : analysis of residual (1x2)L
%       (1) true==do it;   false=skip it
%       (2) true==do graphics (slower); false=skip graphics [this option
%       meaningless if LRA(1) true
%   .pthresh (1x1)r threshold decimal proportion (e.g., 0.95) of
%       cross-validationa model that must reach whatever step is selected for
%        final model
% SpecsSim: specifications for call to pdgmsim
%  .nsim (1x1)i number of simulations (e.g., 1000)
%  .mtaper (1x1)r  decimal fractional total of series to be tapered (e.g.,
%        0.10, which means 5% on front and 5% on back
%  .kopt(1x2)i options
%       (1) force sims to have same mean and standard deviation as the
%               observed series
%           ==1 yes;  ==2 no
%       (2)  turn off the msgbox warning about failing Lilliefors
%           ==1 yes;  ==2 no (default if length(kopt)==1)
%  .len (1x1)i  or []. desired length of simulations; or, if [], same
%           length as the observed series
%
%*** OUTPUT --- structure Result, with fields
%
% .yh, yryh: reconstruction of y
% .RMSEstep: (? x 3)r    step, RMSEcv1, and decimal fraction of obs yielding a left-out estimate
% .StepSelected (1x1)i  step selected for final model
% .mout (1x1)i  cross-validation is leave-mout-out
% .inmodel: logical indicator to cols of the lagged predictor mtx included
% .Loser: logical indicator that had to override stepwise and assign single
%   highest correlated predictor as the the single predictor in final
%   because at step 1 no variables enterd stepwise in a least one of the
%   leave-m-out cross-validation fits
% .statsc: structure of calibration stats, with fields:
%    yrgo: start year of calib (keyed to y)
%    yrsp: end year of calib
%    R2: R-squared
%    R2a: adjusted R-squared
%    pF: p-value of overall F of regression
%    RMSE
%    MAE median absolute error of calibration
%    pDW: p-value of Durbin Watson statistic
% .statsv: structure of validation stats, with fields
%    RMSEcv
%    RE: Reduction of error (RE)
%    r: Pearson correlation of recon with observed
%    p: Monte-carlo one-tailed significance of recon with observed
%    MAE median absolute error of cross-validation
% .resids (?x3)r
%   1 year
%   2 calib -- observed minus predicted y
%   3 leave-m-out cross-validation -- observed minus cv-predicted y
%
%
%*** REFERENCES
%
% Percival, D.B., and Constantine, W.L.B., 2006. Exact simulation of 
% Gaussian time series from nonparametric spectral estimates with 
% application to bootstrapping. Statistics and Computing, 16: 25-35.
%
%*** UW FUNCTIONS CALLED
%
% corrone --correlation by theoretical method
% corrts2 --- correlation testing by Monte Carlo exact simulation
% lagyr3 -- build lagged predictor matrix
% recv -- reduction of error statistic
% residck2  --- analysis of regression residuals
%
%*** TOOLBOXES NEEDED
%
% statistics
%
%*** NOTES
%
% X, yrX, y, yry: these input series must overlap by at least 30 observation, which
%   is way too lenient. There can be leading or trailing NaNs. Whether or
%   not you use lagged predictors, do NOT put the lagged predictors in X.
%   Function reconsw1 builds the lagged predictor matrix.
%
% nlag, plag: these should both be input as positive integers, and will determine "mout" for
% leave-mout-crossvalidation: mout = 1+2m,  where m is the sum of nlag and
% plag.  Thus, if specify lags -2 through +2:  nlag=2, plag=2 and mout=9.
% nlag us the number of negative lags on the predictors; plag is the number
% of positive lags.  For example, if nlag==0 and plag==0, no lags are used.
% If nlag==1 and plag==1, y(t) is regressed on x(t), x(t-1) and x(t+1)
%
% Specs.Sim.  These inputs are for the Monte Carlo test of significance of
% the correlation of observed predictand with the cross-validation
% predictsions. The simulations are done by "exact" simulation (Percival
% and Constantine (2006).  This method is used mainly to handle possibly
% autocorrelated predictand. 
%
% Choice of final step for model.  Cross-validation here serves the purpose
% of selecting how many steps the final regression model should be run to
% in stepwise regression. With each cross-validation model, based on a different N-1 years of 
% calibration, the actual selected predictors may be different. Each of
% the cv models will have a step at which the root-mean-squared error of
% cross-validation (RMSEcv) is minimum. The lowest such step for all N-1 cv
% models is the selected stopping step for the final reconstruction model,
% which is then calibrated using all N years. 
%
% specs.pthresh: The final step in stepwise regression of the cv models
% will generally differ. For example, maybe there are 100 models, and only
% 99 of these run out to step 2. If also the minimum RMSEcv for all of
% these models is step 2, there is a dilemma. You could select the final
% step for the reconstruction model as 2, but one of the cv models did not
% even reach step 2. specs.pthresh lets you get around the problem by
% requiring that only  a decimal fraction pthresh cv models actually run to
% step 2. Settting pthresh to 0.90 means that you will accept some step j
% as long as 90% of the cv models ran to step 2 and for all of those the
% RMSEcv reached its lowest value at no step lower than 2. This is
% complicated. A simple strategy is to set specs.pthresh==1.


% UNLOAD INPUT SPECS

nlag=specs.nlag; plag=specs.plag;
pin = specs.pin; pout=specs.pout;
LRA = specs.LRA; % (1x2)L   see input
pthresh=specs.pthresh;
CalYrs=specs.CalYrs;
[mX,nX]=size(X);
maxsteps=(1+plag+nlag)*nX; % maximum possible number of predictors in final model

% INITIAL STEPWISE TO CHOOSE CUTOFF STEP

% Build lagged predictor mtx, including lags -nlag to +plag on predictors
% 
% If there are m predictors (before lagging), the first m columns of U1
% will hold the unlagged predictors. Remaining cols will hold the negative
% lags, and then the positive lags. For both negative and positive lags the
% order of columns is increasing lat.
yrs=[yrX(1) yrX(end)];
[U1,yrsU1]=lagyr3(X,yrs,[0 nlag plag]);
yrU1 = (yrsU1(1,1):yrsU1(1,2))';

% Pull the part of U1 with no anyNaN rows
igo = yrsU1(3,1);
isp = yrsU1(3,2);
U = U1(igo:isp,:);
yrU = yrU1(igo:isp);

% check time step of predictor matrix
i1 = diff(yrU);
if ~all(i1==1)
    error('yrU not inc by 1')
end
clear igo isp

% Get calibration period data for the lagged predictior matrix and the
% predidictand
%
% Have long mtx, with no anynan rows, as U, yru;
v=y; yrv=yry;
yrgoc = max([yrv(1) yrU(1)]);
yrspc = min([yrv(end) yrU(end)]);


% Optionally shorten the full calibration period
if isempty(CalYrs)
else
    if CalYrs(1)<yrgoc
        error(['Cannot set CalYrs(1) earlier than ' num2str(yrgoc)])
    end
    if CalYrs(2)>yrspc
        error(['Cannot set CalYrs(2) later than ' num2str(yrspc)])
    end
    yrgoc = CalYrs(1);
    yrspc = CalYrs(2);
end
Result.statsc.yrgo=yrgoc;
Result.statsc.yrsp=yrspc;

L = yrv>=yrgoc & yrv<=yrspc;
vc= v(L);
yrvc=yrv(L);
L = yrU>=yrgoc & yrU<=yrspc;
Uc= U(L,:);
yrUc=yrU(L);
nyrc = length(vc);

%-- find highest correlated predictor, in case stepwise picks none
r = corrone(vc,Uc);
[a,ia]=max(abs(r));
Lnull= false(1,size(Uc,2));
Lnull(ia)=true;
clear r a ia;


% Do the stepwise regression with cross-validation; select step; fit
% final model
%
IX=crospull(nyrc,nlag,plag);% pointer mtx for leave-n-out cv
% cols of IX have 1s for obs to be included in the cv model fiitting
mout=1 +2*(nlag+plag);
Result.mout=mout;

E1 = nan(nyrc,maxsteps); % to hold cross-validation errors; cols are steps in model
m1 = nan(nyrc,1); % to hold cv calib means
E2 = nan(nyrc,maxsteps); % to hold errors, null models
Yh=nan(nyrc,maxsteps); % to cv estimates
Loser=false(1,nyrc);
RMSEstep=nan(maxsteps,3);

npool = size(Uc,2); % size of predictor pool 
for m = 1:npool
    % loop over leave-m-out models
    for k = 1:nyrc
        ix = IX(:,k);
        z=vc(ix);
        W = Uc(ix,:);
                
        [b,se,pval,inmod1,stats,nextstep,history]=stepwisefit(W,z,'penter',pin,...
            'premove',pout,'display','off','maxiter',m,...
            'scale','off');
        % stepwise(W,z,[],0.25,0.50);
        %disp('here')
        
        if m==1 && sum(inmod1)==0
             [b,se,pval,inmod1,stats,nextstep,history]=stepwisefit(W,z,'inmodel',Lnull,'penter',pin,...
            'premove',pout,'display','off','maxiter',m,...
            'scale','off');
            ypred=subfun02(Uc,k,stats,b,inmod1);
            Yh(k,m)=ypred;Yh(k,m)=ypred;
            Loser(k)=true;
        elseif sum(inmod1)~=m
           Yh(:,m)=NaN;
        else
            % left-out predictions
            ypred=subfun02(Uc,k,stats,b,inmod1);
            Yh(k,m)=ypred;
        end
        if m==1
            m1(k)=mean(z);
        end
    end
end

% Compute tsm  of "deleted" residuals for regression run to steps 1, 2, ...
[mYh,nYh]=size(Yh);
Vc = repmat(vc,1,nYh); % duped-col observed predictand
E1 = Vc-Yh;

if pthresh==1
    ncrit=length(vc);
else
    ncrit=floor(pthresh*length(vc)); % require that decimal proportion pthresh (e.g., 0.95) of
    % the cross-validation models reach this step with the specified pin and
    % pout
end

% sum of squares, mean square, root-mean-square,  of deleted residuals
D1=subfun01(E1);

% Select step for final calibration
Result.RMSEstep=[(1:npool)'  D1.rms' D1.f1'];
L=~isnan(D1.rms);
if sum(L)==1 && find(L)==1
    Result.StepSelected=1;
else
    % Pick step with minimum cv RMSE, with restriction that at least ncrit of
    % the cv models must have run to that step
    L1=D1.n1>=ncrit;
    if ~any(L1)
        error(['Fewer than ' num2str(pthresh) ' fraction of cv models ran to step 1!'])
    end
    D1a.rms=D1.rms(L1);
    [a,ia]=nanmin(D1a.rms);
    Result.StepSelected=ia;
end
clear ia a

% Compute tsm "null-model" residuals for regression run to steps 1, 2, ...
M1 = repmat(m1,1,nYh);
E2 = Vc-M1;
D2=subfun01(E2);

if any(Loser)
    Result.Loser=true;
    inmod1=false(1,length(inmod1));
    inmod1(1)=true; % will calibrate using lag-0 index
else
    Result.Loser=false;
end



% STEPWISE TO GET PREDICTORS FOR FINAL MODEL
%
%
if Result.Loser
else
 [b,se,pval,inmod1,stats,nextstep,history]=stepwisefit(Uc,vc,'penter',pin,...
            'premove',pout,'display','off','maxiter',Result.StepSelected,...
            'scale','off');
end
Result.inmodel=inmod1;


%----- Recalibrate model using function regstats

% store the long predictor subset to be used for recon
Xlong=[ones(length(yrU),1) U(:,inmod1)];
yrXlong = yrU;

% Regression

Xc =  Uc(:,inmod1);
yrXc=yrvc;
skey = regstats(vc,Xc) ;
Result.statsc.R2 = skey.rsquare;
Result.statsc.R2a = skey.adjrsquare;
Result.statsc.pF =skey.fstat.pval;
Result.statsc.RMSE =sqrt(skey.mse);
Result.statsc.MAE = median(abs(skey.r));
Result.statsc.pDW = skey.dwstat.pval;

Result.resids =nan(length(vc),3);
Result.resids(:,1)=yrvc;
Result.resids(:,2)=skey.r;

beta1=skey.beta;


%--- ANALYSIS OF RESIDUALS

if LRA(1)
    if LRA(2)
        kra=2;
        fclose all
    else
        kra=1;
    end
    isum = sum(inmod1);
    this_label='serles';
    yhat_temp=skey.yhat;
    ResultAR = residck2 (vc,yhat_temp,yrvc,isum,this_label,kra);
else
    ResultAR=[];
end




% figure(1)
% h = plot(yrvc,vc,'-o',yrvc,skey.yhat,'-^');
% legend('Observed','Reconstructed')


%--- CROSS-VALIDATION OF SELECTED MODEL

Result_recv=recv(vc,Xc,IX);
% Following comparisons for series 1 when modifying recv to use
% time-varying means as calib mean cross-validation
% RE: 0.6198 --- using overall cal mean
% RE: 0.6304 --- using cv-model-variable calibration mean

Result.resids(:,3)=Result_recv.ecv;
Result.statsv.RMSE = Result_recv.RMSEcv;
Result.statsv.RE = Result_recv.RE;
Result.statsv.MAE=  median(abs(Result_recv.ecv));

% Monte-Carlo based one-tailed significance of correlation of predicted
% with observed predictand 
kdir=1; % one tailed test
kopt_corr=1; % interested in positive correlaton
[r,pvalue]=corrts2(vc,Result_recv.yhat,kopt_corr,kdir,specsSim);
Result.statsv.r=r;
Result.statsv.p=pvalue;
clear pvalue r 


%--- RECONSTRUCTION

Result.yh = Xlong*beta1;
Result.yryh= yrXlong;

% figure(1)
% h = plot(Result.yryh,Result.yh, yrvc,skey.yhat,'-^');
% legend('Observed','Reconstructed')

end


%---- SUBFUNCTIONS


function D=subfun01(X)
% mean square and RMS for cols of a tsm
% cols may contain some NaN
% Also returns the number and fraction of observations non-NaN

[mX,nX]=size(X);
A = X .*X; % each element square

L = ~isnan(A);
n1 = sum(L); % number of non-NaN values in each column of X
f1 = n1 / mX; % decimal proportion of obs with a value, f

a=nansum(A); % sum of all non-nan in cols of A
ms = (a ./ n1); % cv of mean square
rms = sqrt(ms);  % cv of root mean square

D.rms = rms;
D.ms = ms;
D.f1 = f1;
D.n1 =n1;
end


function ypred=subfun02(Uc,k,stats,b,inmod1)
% left-out predictions
H = [1 Uc(k,inmod1)];
bthis =[stats.intercept;  b(inmod1)];
ypred = H*bthis;
end