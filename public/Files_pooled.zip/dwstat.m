function [d,choice]=dwstat(e,durbin,k)
% dwstat:  Durbin-Watson statistic on residuals of a MLR model
% [d,choice]=dwstat(e,durbin,k);
% Last revised 2011-7-28
%
%*** IN 
%
% e (nobs x 1)r  regression residuals
% durbin (38 x 11)r  table of .01 (one sided) values for D-W stat
% k (1 x 1)i  number of predictors in the regression model
%
%*** OUT 
%
% d (1 x 1)r  computed D-W statistic
% choice (1 x 1)s   decision on the null hypothesis that rho==0
%   'R' reject
%   'U' uncertain
%   'A' accept
%
%
%*** REFERENCES
%
% Harvey A. C. (1990) The econometric analysis of time series, second edition. MIT Press. For large sample
% size, says the DW statistic is approximately normally distributed with mean 2 and variance 4/N, where N is
% the sample size. 
%
% Savin, N.E. and White, K.J., "The Durbin-Watson Test for Serial Correlation with Extreme Sample Sizes or Many
% Regressors", Econometrica, Vol. 45, 1977, pp. 1989-1996. I have not yet read this.  May deal with k>5

%*** NOTES *******
%
% The alpha level is interpreted as 0.01 for a one-sided test and 0.02 for a two-sided test
%
% dwstat.m handles only up to 5 predictors.  This is because that's the limit of the
% table I keyed in from Draper and Smith
%
% The table for interpreting the D-W statistic is assumed to be loaded by the
% calling function.  For reference, this table is durbin.dat in the structure 
% durbin, stored in \mlb\tables
%
% Revised 2005-8-19  to handle sample sizes larger than 100 
% Revised 2011-7-28 to handle sample sizes up to 200 and number of
% predictors up to 20


[nobs,ntemp]=size(e);
if ntemp~=1;
   error('e must be col vector');
end

if nobs<6;
    error('Number of observations must be at least 6')
elseif nobs<=200;
    if nobs <(k+5);
        error('Lookup table required at least 5 more observations than predictors');
        
    else
    end
else
    % Use the normal approximation. See References above.
end
if k>20;
    error('My Durbin-Watson table only covers up to 20 predictors in model');
end



%************** Compute D-W stat (see Ostrom 1978, p 27, eq 2.24)

dtop = diff(e);  % first difference of residuals
num =    sum(dtop .* dtop); % sum of squares of them
denom = sum(e .* e); % sum of squares of resids
d = num/denom; % D-W stat


%************* GET APPROPRIATE COLUMNS OF TABLE

if nobs<=200;
    klow = k*2;
    khi = klow+1;

    ylow = durbin(:,klow);
    yhi = durbin(:,khi);
    
    % Truncate DW table so no NaN rows
    Lkill = isnan(ylow) | isnan(yhi);
    ylow(Lkill)=[];
    yhi(Lkill)=[];
    durbin(Lkill,:)=[];
    
    % Interpolate
    dlow = interp1(durbin(:,1),ylow,nobs);
    dhi = interp1(durbin(:,1),yhi,nobs);

    if d<dlow ;
        choice='R';
    elseif d>= dlow && d<dhi;
        choice='U';
    elseif d>=dhi && d<= (4-dhi);
        choice = 'A';
    elseif d>(4-dhi) && d<(4-dlow);
        choice='U';
    elseif d>(4-dlow);
        choice='R';
    end
else % this section follows Harvey (1990)
    meanDW = 2.0;
    varDW = 4/nobs;
    pcrit = 0.01; % approp for one-sided test
    dlow = norminv(pcrit,2,sqrt(varDW));
    dhi  = norminv((1-pcrit),2,sqrt(varDW));
    if d<dlow;
        choice = 'R';
    elseif d>dhi;
        choice = 'R';
    else
        choice = 'A';
    end;
end;
