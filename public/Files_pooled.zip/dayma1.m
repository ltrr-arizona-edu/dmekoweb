function D=dayma1(W,dayend,m,hemisphere, yrswant)
% dayma1: moving average of a daily climate time series
% D=dayma1(W,dayend,m,daykey,hemisphere);
% Last Revised 2019-10-06
%
% Moving average of a daily climate time series.
% Utility function called by trach02 in summarizing daily clmate
% signal in annual cell-anatomy time series. Computes a tsm of 
% non-overlappingmoving averages of size m. The smoothed series are
% organized so that the last ends in day-of-year dayend, and the first must
% not include any days before day 1 (Jan 1).
%
%*** INPUT
% 
% W (mW x 5)r   year, month, da--of-month, day of year, data value
%     dayend (1x1)i   ending day of last window. In Northern Hemisphere, this
%     ending day can range from 32 (Feb 1) to 365, which is Dec 31 or 30,
%     depending on leap years. It is assumed that years of W have either 365 or
%     366 data values. In other words, convention here is NOT to have NaN for
%     Feb 29 of non-leap years.
% dayend (1x1)i ending day of last window (e.g., 289 for Oct 15) of
%   non-leap year
% m (1x1)i  length of moving average, in days
%   hemisphere: "N" or "S"
%  yrswant(1x2)i first and last year of desired annual tsm 
%
%*** OUTPUT
%
% D--- structure 
%   .Y (mY x nY)r   moving average time series for m-day moving average 
%       arranged in columns from window with earliest ending date to window
%       with latest ending date. These window are non-overlapping
%   .yrY (1x1)i  year vector for Y.  Year is last year of the windowed
%       value in Y.
%   .dend (?x1)i ending day of each window for columns of Y
%
%*** REFERENCES -- NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED -- NONE
%
%*** NOTES
%


yr=W(:,1); mo=W(:,2); dmo=W(:,3); dyr=W(:,4); x = W(:,5);


%--- ENDING DAYS OF NON-OVERLAPPING WINDOWS

jend=flipud((dayend:-m:m)');
D.dend=jend;


%--- RUNNING MEAN OF DAILY CLIMATE, FROM START TO FINISH

ma=length(yr);
tx=(1:ma)';
kopt=2;
[s,ts]=mafilt1(x,tx,m,kopt);
% s is the running mean; ts is the time vector for s, aligned at ending day
% of the window;


%--- DAY VECTORS TRIMMED TO MATCH TIMING OF RUNNING MEANS

yr1 = yr(ts); mo1=mo(ts); dmo1=dmo(ts); dyr1 = dyr(ts); x1=x(ts);
% These are same length as s, ts, the smoothed time series and its time
% vector. 


%---- ANNUAL TIME SERIES (TSM) OF DAY-WINDOWED CLIMATE

yrY=(yrswant(1): yrswant(2))';
mY= length(yrY);
nwind = length(jend); % number of windows
nY = nwind;
Y = nan(mY,nY);

for n =1:nwind
    jthis =jend(n);
    
    L1 = yr1>=yrswant(1)  & yr1<=yrswant(2);
    L2= dyr1==jthis;
    L3=L1 & L2;
    yrcheck =yr1(L3);
    Lyr = yrcheck==yrY;
    if ~all(Lyr)
        error('Year problem')
    end
    Y(:,n)=s(L3);
end
D.Y=Y;
D.yrY=yrY;

end