function [nmlist]=rwlids1(pfin,cols)
% rwlids:  Check core ids in an rwl file and build a renaming template
% [nmlist]=rwlids1(pfin,cols);
% Last revised 2016-05-19
%
% Check core ids in an rwl file and build a renaming template. Builds a
% list of core ids in the rwl file, writes those to a .txt file that can be
% edited for assigning new ids.
%
%
%*** INPUT
%
% pfid (1 x ?)s  path and filename of input rwlfile; just need filename if
%   if run from folder with the file
% cols (1x2)i  first and last column of id in input file.  
%   For example, [1 8]
%
%*** OUTPUT
%
% nmlist (ncores x ?)s   character matrix, one row per core, with core id
%   in cols 1-8 and cols 11-18.  Idea is that can use 
% iflags (1x?)i flags of problems with the input file
%   empty -- no problems
%   1 = unique ids not all contiguous
%
%*** REFERENCES -- NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED -- NONE
%
%*** NOTES
%--- NO HEADER LINES (USUALLY THESE GO OUT TO COL 80)
%--- NO TRAILING BLANK LINE
%--- 72 COLS
%--- ANY ID AT LEAST TWO ROWS
%--- ROWS CONTIGUOUS FOR  IDS
%--- MORE THAN ONE LETTER AFTER FIRST 3 CHARS OF ID

D = textread(pfin,'%s','delimiter','\n','whitespace','');


% ---- NO TRAILING BLANK LINE
if length(D{end,:})==1
    nmlist=[];
    smess =[pfin ' has trailing blank line'];
    uiwait(msgbox(smess,'Warning','modal'));
    return;
end

%--- 72 COLS
S=char(D);
[mS,nS]=size(S);
if nS ~=72;
    smess ={[pfin ' col size is ' num2str(nS) ' should be 72'],...
        'Guessing that problem is have 3-line header before data',...
        'xxx1.rwl will be written. xxx1.rwl will not have the header',...
        'and will also be truncated to the first 72 cols.',...
        '',...
        'Check xxx1.rwl with text editor to see that data block looks OK,',...
        'then can run rwlids1 again on xxx.rwl to get id translation table and',...
        'error messages about core ids',...
        ''....
        'Can copy/paste from command window to record this operation'};
    uiwait(msgbox(smess,'Warning','modal'));
    S(1:3,:)=[];
    S=S(:,1:72);
    s=[pfin '-->xxx1.rwl: 3-line header stripped off and file truncated to 72 cols by rwlids1.m']
    nmlist=[];
    

    [mS,nS]=size(S);
    fid = fopen('xxx1.rwl','w');
    fmt = '%72s\n';
    for n =1:mS;
        sline = S(n,:);
        fprintf(fid,fmt,sline);
    end
    fclose (fid);
    
    return;
end

%--- ANY ID AT LEAST TWO ROWS
%--- ROWS CONTIGUOUS FOR UNIQUE IDS
i1=cols(1); i2=cols(2);
A = S(:,i1:i2);
C = unique(A,'rows');
[mC,nC]=size(C); % mC different ids
for n = 1: mC;
    c=cellstr(C(n,:));
    LIA = ismember(cellstr(A),c);
    nhit = sum(LIA);
    if nhit<2;
        smess =[pfin ' id = ' char(c) ' fewer than two rows'];
        uiwait(msgbox(smess,'Warning','modal'));
        return;
    end
    ifind = find(LIA);
    idiff = diff(ifind);
    if ~all(idiff==1);
        smess =[pfin ' id = ' char(c) ' not contiguous rows'];
        uiwait(msgbox(smess,'Warning','modal'));
        return;
    end
end


%--- MORE THAN ONE LETTER AFTER FIRST 3 CHARS OF ID
U=C(:,4:end);
L=isletter(U);
sum1 = (sum(L'))'; % total number of letters after first 3 chars
if max(sum1)>1;
    LL = sum1>1;
    badguys = cellstr(C(LL,:));
    disp(badguys);
    smess =['More than one letter after firest 3 characters of id: see command window'];
    uiwait(msgbox(smess,'Warning','modal'));
    return;
end
clear U 


%---- BUILD CHAR MATRIX OF SUBSTITUTE IDS
y ={'A','B','C','D','E','F','G','H'}; 
F=C; % matrix of current ids
U=C(:,4:end);
L=isletter(U);
L=(~any(L'))';   % T if no letter after first 3 chars of id
[mF,nF]=size(F);
for n = 1:mF;
    Lthis = L(n);
    if Lthis
        f = F(n,:);
        g = f;
        L1 = ~isspace(f);
        i1=find(L1);
        i1=max(i1);
        i2 = str2num(f(i1));
        if i2==0; %  id like KAX560 assume tha "0" refers to section, and treated as "A" core of tree 56
            i2=1;
        end
        g(i1)=y{i2};
        F(n,:)=g;
        
        
    end
end



%------ BUILD ASCII FILE OF IDS, REPEATED AS 2 COLS, WITH SPACE IN BETWEEN

B = [C repmat(' ',mC,1) F];
[mB,nB]=size(B);

fid = fopen('idlistxxx1.txt','w');

for n = 1:mB;
    bthis = B(n,:);
    fprintf(fid,'%s\n',bthis);
end
fclose(fid)


nmlist=B;

smess1 ={['idlistxxx1.txt, a table for id-translation for file ' pfin ' has been written.'],...
    ['Next step would be to edit this txt file and run rwlids2.m on ' pfin ' to get an rwl with revised ids'],...
    'For record-keeping, later rename idlistxxx1.txt with a unique name so can associate ids in file with ids on core mounts'};
uiwait(msgbox(smess1,'Notice','modal'));





