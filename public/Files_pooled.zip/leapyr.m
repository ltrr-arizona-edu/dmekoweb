function L=leapyr(yr)
% leapyr:  find out whether a year is a leap year (has a Feb 29)
% L=leapyr(yr);
% Last revised 2010-3-9
%
% Operates on scalar or column vector of years.  Returns whether each year is a leap year.
%
%*** INPUT
%
% yr (? x 1)i  year or years to be tested; e.g., [1800; 1900 ; 2000];
%
%
%*** OUTPUT
%
% L (? x 1)L  1 if year in yr is a leap year, 0 otherwise
%
%
%*** REFERENCES -- NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED -- NONE
%
%*** NOTES
%
% Feb of a leap year has 29 days.  Feb of a non-leap year has 28 days.  Leap year is every 
% year evenly divisible by 4, with special condition on century years (e.g., 1900, 2000).
% If century year not evenly divisible by 400, NOT a leap year.
%
% Uses Gregorian calendar, with Sept 14, 1752 as date of calendar reform.
% Accordingly, 11 days are skipped: In England, the 2nd of September as
% followed by the 14th of September in 1752.  Any date in the gap is
% invalid.  Functions that call leapyr in converting some calendar year to
% time since some start point need to adjust if the start point precedes
% the date of calendar reform. For example, yr2hrz.m must subtract 11 days
% to get the correct "number of days" since 1-1-1 for any year after 1752.  


L4= mod(yr,4)==0;
L100 = mod(yr,100)==0;
L400= mod(yr,400)==0;


Learly=yr<1752 & L4 ;   % leap year before start of Gregorian (actually Sept 14, 1752)
Llate = yr>=1752 & ((L400) | (L4 & ~L100));
L=Learly | Llate;
