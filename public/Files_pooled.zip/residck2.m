function Result = residck2 (yo,yh,yr,npred,name,kopts)
% residck2: analysis of regression residuals
% Result = residck (yo,yh,npred,name,kopts);
% Last revised 2019-08-29
%
% Analysis of regression residuals.  Addresses assumptions of normality, non-autocorrelation,
% independence from predicted values.
%
%
%*** IN
%
% yo (m x 1)r time series of observed predictand
% yh (m x 1)r time series of reconstructed or predicted predictand (y "hat")
% yr (m x 1)i year vector for yo, yh
% npred (1 x 1)i  number of predictors in the regression model generating yh
% name (1 x ?)s  name of series, or other string used to label plots
% kopts (1 x 1)i  options
%   kopts(1): concise vs verbose
%       ==1 concise; no graphics;  decisions usually made with graphics coded 'X'
%       ==2 verbose -- full graphics, pausing at each series
%
%*** OUT
%
% Result -- structure with fields
%   .trend (1 x 4)r   estimated slope (regression coef vs time) , 95% CI, and tend key:
%       1 = Positive trend (signif slope at 95%)
%       -1= Negative trend
%       0 = Slope not significant
%   .r1 (3 x 2)r  Col 1: first order autocorrelaton of yo, yh, and residials e = yo-yh
%                 Col 2: 1 if value in row 1 significant at 0.05 level in one-tailed test,
%                        0 otherwise
%   .DW (1 x 1)s 'A','R', or 'U' for test at one sided 0.01 level
%   .means (1 x 3)r   mean of obs, mean of recon, length of overlap
%   .rsq (1 x 1)r  squared correl between yo and yh
%   .normality (1 x 2)s :  1 = Lilliefores test at .01 alpha;  2 = visual assessment of histogram. A= accept,
%       R=reject
%   .e_vs_fit (1 x 1)s  residuals vs fitted predictand: 'A' = accept that no dependence, 'R' = reject that idea
%       (subjective);
%
%
%*** REFERENCES
%
%
%*** UW FUNCTIONS CALLED -- none
%
%
%*** TOOLBOXES NEEDED 
%
% Statistics
%
%
%*** NOTES  
%


%--- COMPUTE THE RESIDUALS

if ~all([isvector(yo)  isvector(yh) isvector(yr)])
    error('yo, yh, yr must be col vectors');
end
if length(yo) ~= length(yh)
    error('yo and yh must be same length');
end
if length(yr) ~= length(yo)
    error('yr wrong length');
end
e = yo-yh;
t = yr;

%---- CORRELATION AND MEAN

meano = mean(yo);
meanh = mean(yh);
dflag =abs(meano-meanh)/std(yo);
if dflag>1E-6
    error([name ': diff in means of yo and yh greater than one millionth stdev of yo']);
end
r = corrcoef([yo yh]);
r = r(1,2);
rsq = r .* r;
Result.rsq = rsq;
Result.means = [meano meanh length(t)];
strr = ['r^{2} = ' num2str(rsq,'%5.3f')];
strmn =['mean_{yo} = ' num2str(meano,'%5.1f') '; mean_{yh} = ' num2str(meanh,'%5.1f') ';   '  ];
   


%--- REGRESSSION ON TIME
[B,BINT,R,RINT,STATS] = regress(e,[ones(length(e),1), t],.05);
ehat = [ones(length(e),1)  t] *B;
bint=B(1);
bslope=B(2);
strslope=['slope = ' num2str(bslope)];
str2 = ['95% CI for slope: ' num2str(BINT(2,1)) ' to '  num2str(BINT(2,2))];
if BINT(2,1)>0
    trdir = 1;
elseif BINT(2,2)<0
    trdir = -1;
else
    trdir = 0;
end
Result.trend = [bslope BINT(2,1) BINT(2,2) trdir];



%--- TIME SERIES PLOTS
xlims=[t(1) t(end)];
if kopts(1)==2;
    figure (1);
    [cL,cB,cW,cH]=figsize(.7,.6);
    set(gcf,'Position',[cL cB cW cH]);
    subplot(2,1,1);
    hp1 = plot(t,yo,t,yh,[t(1) t(end)],[mean(yo) mean(yo)]);
    set(gca,'XLim',xlims);
    set(hp1(1),'Color',[0 0 1],'LineWidth',1);
     
    set(hp1(2),'Color',[1 0 0],'LineWidth',1);
    if length(t)<150
        set(hp1(1),'Marker','o');
        set(hp1(2),'Marker','^');
    end
    set(hp1(3),'Color',[0 0 0],'LineWidth',0.5);
    title(['Observed (yo) and predicted (yh) predictand, ' strr]);
    legend('yo','yh','mean yo');
    grid on;

    subplot(2,1,2);
    hp1 = plot(t,e,t,ehat,[t(1) t(end)],[mean(e) mean(e)]);
     set(gca,'XLim',xlims);
    set(hp1(1),'Color',[0 0 1],'LineWidth',1);
    set(hp1(2),'Color',[1 0 0],'LineWidth',1);
    if length(t)<150
        set(hp1(1),'Marker','o');
    end
    set(hp1(3),'Color',[0 0 0],'LineWidth',0.5);
    textcorn('Test for linear trend','UL',.01,.01,12)
    title(['Residuals; ' strslope ';  ' str2]);
    legend('e','ehat','mean(e)');
    grid on;
else
end

%--- NORMALITY

%[h,p,LSTAT,CV] = lillietest(e,.01);
% Debugging:  lillietest as of 10-08-12 bombs with p as output arg in some
% cases
h = lillietest(e,.01);

if h==1 
    str1 = 'Reject Normality at .01';
else
    str1='Do Not Reject Normality at .01';
end


%--- HISTOGRAM

tn = 'AA';
if h==1 ;
    tn(1)='R'
end;

if kopts(1)==1
    tn(2)='X';
else
    figure(2);
    [cL,cB,cW,cH]=figsize(.5,.5);
    set(gcf,'Position',[cL cB cW cH]);
    hp2=histfit(e);
    xlabel('residuals')
    grid on;
    %title([name ';  Lilliefors p = ' num2str(p) ';  ' str1]);
    textcorn('Normality tested with Lilliefors test','UR',.01,.01,12)
    title([name '; ' str1]);
    knorm = menu('Choose','Looks normal','Defininely does not look normal');
    if knorm ==1
        tn(2)= 'A';
    else
        tn(2)='R';
    end
end

Result.normality=tn;
if kopts(1)==1;
else;
    uiwait(msgbox('Press a key to continue','Message','modal'));
end;


%--- AUTOCORRELATION

r1=repmat(NaN,3,2);
% acf and test for + first-order autocorrelation
[r,SE2,r95]=acf(yo,10); % Observed


figure(3)
[cL,cB,cW,cH]=figsize(.7,.6);
set(gcf,'Position',[cL cB cW cH]);

rone=r(1);
r1(1,1)=rone;
if abs(rone)>r95;
    r1(1,2)=1;
else;
    r1(1,2)=0;
end
kacf=[1 1];
[r,SE2,r95]=acf(yh,10); % Predicted

rone=r(1);
r1(2,1)=rone;
if abs(rone)>r95
    r1(2,2)=1;
else
    r1(2,2)=0;
end
kacf=[2 1];
[r,SE2,r95]=acf(e,10); % Residuals
rone=r(1);
r1(3,1)=rone;
if abs(rone)>r95
    r1(3,2)=1;
    strr1 =['r(1) = ' num2str(rone,'%5.2f') ' significant by 1-sided t test'];
else
    r1(3,2)=0;
    strr1 =['r(1) = ' num2str(rone,'%5.2f') ' not significant by 1-sided t test'];
end
Result.r1= r1;



% DW test on e
%load c:\mlb\tables\durbinwt;
load durbinwt
durbin=durbin.dat;
[d,choice]=dwstat(e,durbin,npred);
strd=['Durbin-Watson = ' num2str(d,'%6.3f')];
if strcmp(choice,'A');
    dwchoice='Durbin-Watson: cannot Reject H0 at 0.01 level (one sided)';
    Result.DW = 'A';
elseif strcmp(choice,'R');
    dwchoice='Durbin-Watson: reject H0 at 0.01 level (one sided)';  
    Result.DW = 'R';
elseif strcmp(choice,'U');
    dwchoice='Durbin-Watson: uncertain region for one-sided test at 0.01 level';   
    Result.DW = 'U';
else;
    error('Invalid result');
end;


if kopts(1)==1
else
    % acf plot of residuals
    figure(3);
    i1 = 1:length(r);
    hp3 = stem(i1,r);
    hold on;
    hps=plot(i1,SE2,i1,-SE2);
    xlabel('lag, k');
    ylabel('r(k)');

    set(hps(1),'Color',[1 0 0],'LineStyle','--')
    set(hps(2),'Color',[1 0 0],'LineStyle','--')
    set(gca,'YLim',[-1 1]);
    xlims=get(gca,'XLim');
    set(gca,'XLim',[xlims(1)-0.5  xlims(2)+0.5]);
    xlims = get(gca,'XLim');
    ylims = get(gca,'YLim');
    xpt1 = xlims(1) + 0.2*diff(xlims);
    ypt2 = ylims(1) + 0.2*diff(ylims);
    ypt1 = ylims(1) + 0.1*diff(ylims);
    text(xpt1,ypt1,dwchoice);
    text(xpt1,ypt2,strr1);
    legend('r(k)','95% CI (large-lag)');
    title([name ';  ACF of residuals']);
    hold off;


    figure(4); % lagged scatter of residuals
    
    e2=e(2:end);
    e1 =e(1:(end-1));
    
    r = corrcoef([e1 e2]);
    r= r(1,2);
    str_r = ['r = ' num2str(r,'%5.2f')];
    xlims=[min(e1) max(e1)];
    hp4 = plot(e1,e2,'*');
    set(gca,'XLim',xlims);
    xlabel('e(t-1)');
    ylabel('e(t)');
    xlims=get(gca,'XLim');
    ylims=get(gca,'YLim');
    line(xlims,[0 0 ],'Color',[0 0 0]);
    line([0 0 ],ylims,'Color',[0 0 0]);
    hline=lsline;
    set(hline,'Color',[1 0 0]);
      textcorn(str_r,'UL',.01,.01,12)
    title(['Residuals: lagged Scattterplot']);
end;


%--- RESIDS VS PREDICTED

if kopts(1)==1
    tp='X';
else
    figure(5);
    xlims=[min(yh) max(yh)];
    hp5 = plot(yh,e,'+',xlims,[0 0]);
    xlabel('Fits')
    ylabel('Residuals')
    grid on;
    title([name ';  Residuals vs fitted values']);
    kp = menu('Choose','No clear pattern --OK','Looks like strong dependence');
    if kp ==1
        tp='A';
    else
        tp='R';
    end
end


Result.e_vs_fit=tp;
if kopts(1)==1;
else;
    uiwait(msgbox('Press a key to continue','Message','modal'));
end;
