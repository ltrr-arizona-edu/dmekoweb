function n2=sseff(n1,r1)
% sseff: effective sample size, or sample size adjusted for first-order autocorrelation
% n2=sseff(n1,r1);
% Last revised  2004-10-14
%
% Computes effective sample size, or sample size adjusted for first-order autocorrelation. Handles
% two optional situations: 1) univariate time series, 2) bivariate time series (relevant to correlation coefficient)
%
%*** INPUT ARGUMENTS
%
% n1 (1 X 1)i  sample size of time series; or of bivariate time series
% r1 (1 x 1)r or (1 x 2)r first-order autocorrelation coefficient of time series; see notes
%
%*** OUTPUT ARGUMENTS
%
% n2 (1 x 1)i  effective sample size, which is the sample size adjusted for autocorrelation in the time series
%
%*** REFERENCES
%
% Dawdy, D.R., and Matalas, N.C., 1964, Statistical and probability analysis of hydrologic data, 
% part III: Analysis of variance, covariance and time series, in Ven Te Chow, ed., Handbook of 
% applied hydrology, a compendium of water-resources technology: New York, McGraw-Hill 
% Book Company, p. 8.68-8.90. (sample size adjustment for first-order autocorrelation)
%
%*** UW FUNCTIONS CALLED -- none
%
%
%*** TOOLBOXES NEEDED : none
%
%
%*** NOTES  ****************************************
%
% r1:  (1 x 1) indicates univariate mode;  (1 x 2) indicates bivariate mode (as in adjusting sample size for significance of a correl coef)
%
% Revised 2004-10-14 so that negative first order autocorrelation does not give an INCREASE in effective sample
% size 

if (~all([size(n1,1)==1 size(n1,2)==1]))  | n1<=3;
    error('n1 not a scalar greater than 3');
end;

if size(r1,1)~=1;
    error('r1 not a scalar or row vector');
end;

if size(r1,2)==1; % if univariate mode
    if r1<-1 | r1>1;
        error('r1 outside range [-1 1]');
    end;
    f = (1-r1)/(1+r1);
elseif size(r1,2)==2; % bivariate mode
     if r1(1)<-1 | r1(1)>1;
        error('r1(1) outside range [-1 1]');
    end;
    if r1(2)<-1 | r1(2)>1;
        error('r1(2) outside range [-1 1]');
    end;
    f =(1-r1(1)*r1(2))/(1+r1(1)*r1(2));
else; 
    error('col size of r1 cannot be greater than 2');
end;
n2=round(n1*f);

if n2>n1;
    n2=n1;
end;
    