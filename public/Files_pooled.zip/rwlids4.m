function rwlids4(pfrwl,pftxt,crwl,ctxt,clog)
% rwlids4: Trim an rwl file by deleting indicated series.
% rwlids4(pfrwl,pftxt,crwl,ctxt,clog);
% Last revised 2013-6-9
%
% Trim an rwl file by deleting indicated series.
% take an input rwl file, such as ca614.rwl, and an rwlHG1-made output file,
% such as ca614_rwlHG1_out.txt, and make a trimmed rwl file, with default 
% temporary name with "c" ("culled") at end (e.g., ca514c.rwl.  
%
%*** INPUT
%
% pfrwl (1x?)s  the input rwl filename  (e.g., ca614.rwl)
% pftxt (1x?)s  the input txt filename (e.g., ca614_rwlHG1_out.txt
% crwl (1x2)i  first and last col of id in pfrwl (e.g., [1 8])
% ctxt (1x2)i  first and last col of id in pftxt  (e.g., [7 14])
% clog (1x1)L  col of logical indicator in pftxt:  1=keep, 2= not (e.g.%% 47)
%
%
%*** OUTPUT
%
% An rwl file is created with the culled set of ring widths.  The filename is the
% same as that of the input rwl file, except with "c" added at the end of
% the name.
%
%
%*** REFERENCES -- NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED -- NONE
%
%
%*** NOTES
%
%



%--- READ THE TXT FILE, AND STORE THE IDS AND THE LOGICAL "KEEP" FIELD

% Deal with problem that textread function cannot handle paths
[a,b,c]=fileparts(pftxt);
pfnew = [b c];
clear a b c;
B = textread(pfnew,'%s','delimiter','\n','whitespace','');

B1=char(B);
id2a = B1(:,ctxt(1):ctxt(2));
ncores1 = size(id2a,1);
id2b = cellstr(id2a);
Lkeep = logical(str2num(B1(:,clog)));
id2c = id2b(Lkeep);  % col-cell of the ids of cores to be kept



%--- READ THE RWL FILE, AND PULL THE COL-RANGE THAT HOLDS THE IDS 

A = textread(pfrwl,'%s','delimiter','\n','whitespace','');
A1=char(A);

% check conditions that might mean first 3 lines are headers
B=A1(1:3,10:72);  % expect this to leave just numeric data
L=isletter(B);
L1 = any((any(L'))); % any of first rows with chars in cols 10:72

L2=A1(1,8)=='1' && A1(2,8)=='2' && A1(3,8)=='3'; % rows 1-3 have 1, 2, 3 in col 8


if L1 || L2 
    A1(1:3,:)=[];
else
end

[mA1,nA1]=size(A1);

id1a = A1(:,crwl(1):crwl(2));
id1b =cellstr(id1a);
id1c=unique(id1b);  % col-cell of unique combinations of patterns in the id field of input rwl7:14


%----- CHECK THAT ALL IDS IN THE TXT FILE ARE FOUND IN THE ID FIELD OF THE
% RWL FILE

L=ismember(id2c,id1c);
if ~all(L);
    error(['Not all ids in ' pftxt ' found in ' pfrwl]);
end


%--- Loop over all unique id-field combinations in the rwl file, and build
% a char matrix including only those lines from the rwl matching the ids
% found in the txt file

d=blanks(nA1);
D = repmat(d,mA1,1);
[mD,nD]=size(D);


[msize1,nsize1]=size(id1c); 
irow2=0; % initialize pointer to D
for n = 1:msize1
    a1=id1c(n);
    if ~any(ismember(id2c,a1))
    else
        L=ismember(id1b,a1); % lines with this id in the original rwl
        nlines=sum(L);
        irow1 = irow2+1;
        irow2 = irow1+nlines-1;
        D1 = A1(L,:);
        D(irow1:irow2,:)=D1;
        %disp('bingo')
    end
end
D= D(1:irow2,:);
[mD,nD]=size(D);



%--- WRITE OUTPUT RWL FILE

pfout = [strtok(pfrwl,'.') 'c.rwl'];
fid=fopen (pfout,'w');
for n =1:mD
    d = D(n,:);
    fprintf(fid,'%s\n',d);
end
fclose(fid)

