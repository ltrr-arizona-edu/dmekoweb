function [C,Lx,Lflag]=rwlids3(pfin,Lskip)
% rwlids3:  high-grade an overloaded mat file of ring widths
% [C,Lx,Lflag]=rwlids3(pfin);
% Last revised 2017-01-16
%
% High-grade an overloaded mat file of ring widths.
% First of two function (second is rwlids4) used to high-grade a collection
% of measured ring widths to emphasize long, highly intercorrelated series
% and evenness of sample coverage. First written to deal with Stahle's blue
% oak, which have huge sample size. 
%
%*** INPUT
%
% pfin (1 x ?)s  path and filename of input mat file; just need filename if
%   if run from folder with the file.  Note the input is a mat file, NOT an
%   rwl file, but is automatically produced in working folder when lockdown
%   is run on an rwl.
% Lskip (1x1)L logical for skipping all saves and prints
%   ==1 skip em
%   ==0 execute prints and saves
%
%*** OUTPUT
%
% Two output files are produced. Names begin with name of the input rwl
% file, without suffix.  For example, ca412.rwl would contribute "ca412".
%
% Output ascii file "xxx_rwlids3_out.txt" is the
% file with list of ids, and other information, ordered from longest to
% shortest segment length.
% 
% The txt file has these space-separated items:
% 1) sequential number (in the .mat file produced by rwlinp or lockdown),
% 2) core id,
% 3) segment length,
% 4) start year,
% 5) end year,
% 6) column of% logical 0's.
% 'xxx' in the name will actually be the first part of the input rwl
% filename.
%
% Mat file with name  xxx_rwlids3_specs, with the final specs used in
% running  rwlids3 on the data in the rwl file with name pfin.  "xxx" will
% actually be that rwl file name w/o suffix.
%
%
%*** REFERENCES -- NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED -- NONE
%
%*** NOTES
%
% 16 Jan 2016 templated off earlier version.  this revision more explicitly
% first culls by combination of segment length and correlation, then move
% on to handle "late" cores (cover some specific recent year) and "early"
% cores (subset with earliest start years. 
%
% Need to do the preliminary step (see below) first
%
% Idea is to use the output txt file, along with the original rwl file, as
% input to rwlids4.m, which will pull only the series with "1" in the last
% column to build the output rwl file aaa_rwlids3.rwl, which user should
% rename before subsequent use.
%
% This revised rwl file can then be run through function lockdown to check
% that any series might need to be dropped.  If lockdown says drop a
% series, you can edit the output txt file, run rwlids4 again, run lockdown
% again, etc, till happy. The txt file serves as permanent record of how
% the rwl you finally used is related to the original rwl, from the ITRDB,
% say.
%
% Preliminary step:
% 
% - run lockdown or rwlinp to create a mat-file version of the original rwl
%
% Main steps in this function are:
% - Read the input mat file of measured ring widths
% - Using start and end years, compute and store a version of series ids
%   for series sorted longest to shortest (by segment length), with earlier
%   start year favored if same segment length
% - Convert ring-width series to indices using default of 100-yr spline
%       * index as ration of width to spline, s
%       * Divide by mean width instead of s if s ever goes non-positie or if
%         computed index exceeds 5; save flag, f, identifying such problem
%         series 
% - Correlation of each core index with all others, and median of whose r
%       * if flag, f, was set for the core, set the median r to NaN
%       * if flag, f, was set for one of the other cores, ignore than r
%        (set it to NaN) in computing the median correlation
% - Answer prompts on program setting
% - While loop
%     * pull all series that satisfy segment length and correlation
%       thresholds
%     * If necessary add series that cover the specified last year. Series
%       selected by combined criteria of segment length and correlation. 
%     * Plot of sample size as function of time for the high-graded set of
%       core
%     * Optionally revise the specifications for minimum acceptable segment
%       length, etc.
% - Write out the txt file that rwlids4 will use in combination with the
%      original rwl file to produce a high-graded rwl file
%
%--- Suggested folder use
%
% 1) make a blank folder, and copy the initial rwl there
% 2) run lockdown on the rwl and look over 
%
%
% Graphics windows output include diagnostics to help in interactive choice of
% settings,and summary plots of sample size variation before and after
% high-grading (Fig 3) and site chronology before and after high-grading
% (Fig 4). The site chromologies are computed with a 100-yr spline. Any
% cores for which the spline gave problems are omitted from the "before
% high-grading" chronology. Problems are defined as spline fit going
% non-positive or the computed index for any year exceeding 5.0 (which
% could be an artifact of spline approaching zero).



close all

%---- HARD CODE

nmin=30; % require at least 30 yrs of overlap for a correlation


%---- LOAD INPUT RING-WIDTHS (UNCULLED)

D=load(pfin); % structure with fields including nms, yrs
nms=D.nms;
nser = length(nms);
yrs = D.yrs;



%--- COMPUTE AND STORE VERSIONS OF IDS AND AND SEQUENCE FOR SERIES SORTED
% FROM LONGEST TO SHORTEST

m = yrs(:,2)-yrs(:,1)+1; % segment length
yrgo = yrs(:,1);
yrsp = yrs(:,2);

X =[m yrgo yrsp]; % segment length, start year, end year; in original order
[Y,iy]=sortrows(X,[-1 2]); % segment leng, start year, end year; ordered
%  first from longest to shortest segment, then from earliest to latest
%  start year (favors earlier start year if segment lengths the same)

ids = nms(iy); % ids of segment-length ordered nms

iseq = (1:nser)';
zcol = zeros(nser,1);

blanks3 = repmat('   ',nser,1);


%--- DETREND EACH RING WIDTH WITH 100%N SPLINE
%
%  Also store a  flag if growth curve goes non-positive or index in any
%  year exceeds 5.0. Divide by mean instead of spline fit if either condition

[U,yrU]=sov2tsm(D.X,D.yrs,[],[]); % put series in a tsm, with series 
%    ordered as before sorting for segment length
nms1=D.nms;
p1 = nan(nser,1); % to hold spline parameter
[mU,nU]=size(U);
V=nan(mU,nU); % to hold core indices
yrV=yrU;
F = nan(nU,2) ; % flags iflag1 and iflag2
Lflag = false(nU,4); % col 1 = ratio standardization used mean width because fitted',...
% growth curve goes non-positive; col 2 = ratio standardization used mean width',...
% because some computed index exceeds 5.0; col 3 = selected by over-ride despite
% segment legth below threshold; col 4 = selected despite correlation below threshold


for n = 1:nser; % loop to compute and store "100%N spline core indices"
    u = U(:,n);
    [u,yru]=trimnan(u,yrU);
    mu = length(u);
    per = mu;
    amp =0.5;
    p = splinep(per,amp); % spline parameter
    
    s= csaps(yru,u,p,yru);
    yra=yru;
    irow = yra-yrU(1)+1;
    a = u ./ s; % core index
    
    if any(s<=0)
        iflag1=1;
        V(irow,n)=u/mean(u);
        iflag2=0;
    else
        iflag1=0;
        a = u ./ s; % core index
        if any (a>5)
            iflag2=1;
            V(irow,n)=u/mean(u);
        else
            iflag2=0;
            V(irow,n)=a;
        end
    end
    F(n,:)=[iflag1 iflag2];
    %      plot(yru,u,yru,s);
    %      figure(1)
end

L=F==1;
L=(any(F'))';
f =false(nser,1);
f(L)=1; % logical flag for any of the original cores having one of the 
%   conditins of 1) index ever going negative or 2) some index value >5



%--MEDIAN CORRELATION OF EACH CORE INDEX SERIES WITH ALL OTHERS OVERLAPPING
%  BY AT LEAST nmin YR. 

% R :   to hold median correlation of
R = nan(nU,2);
n1=nser-1;
for n = 1:nU % loop over cores, with n the key series
    if f(n) % if key series had a flag, do not try computing correlations
        R(n,:)=[NaN NaN];
    else
        vthis = V(:,n);
        nms1this = nms1{n};
        r = nan(nser-1,1); % to hold corr of this series with all other
        H=V;
        H(:,n)=[];
        [mH,nH]=size(H);
        f1=f;
        f1(n)=[];
        for nn = 1:nH;  % loop over the other series
            hthis = H(:,nn);
            fthis = f1(nn);
            if fthis
                r(nn)=NaN;
            else
                L = (~isnan(vthis)) & (~isnan(hthis));
                nsize = sum(L);
                if nsize<nmin
                    r(nn)=NaN;
                else
                    Z=[vthis(L)   hthis(L)];
                    r1 = corrcoef(Z);
                    r(nn) = r1(1,2);
                end
            end
        end
        ncorrs = sum(~isnan(r));
        R(n,1)=nanmedian(r);
        R(n,2)=ncorrs;
    end
    
end

figure(1);
[cL,cB,cW,cH]=figsize(.6,.7);
set(gcf,'Position',[cL cB cW cH]);

subplot(2,2,1);
hist(Y(:,1));
ylabel('Number of Cores');
xlabel('Years')
title('Segment length');

subplot(2,2,2);
hist(Y(:,2));
ylabel('Number of Cores');
xlabel('Year')

title(['Start Year; earliest= ' num2str(min(Y(:,2)))]);

subplot(2,2,3);
hist(Y(:,3));
ylabel('Number of Cores');
xlabel('Year')
title(['End Year; latest= ' num2str(max(Y(:,3)))]);

subplot(2,2,4);
hist(R(:,1));
xlabel('correlation');
ylabel('Number of Cores');
title('Median correl of each core index with all others');

uiwait(msgbox({pfin,[num2str(nU) ' cores']},'Stats','modal'));



%------------- END OF CORRELATION ANSLYS
% 
% Recall, now have
% R (2 cols), with median correlation and number of correlations for the median
% F (2 cols), the flag for negative growth curve and for index>5



%--- REORDER R AND F FROM LONGEST TO SHORTEST SAMPLE LENGTH, AS 

%--- Reorder R and F from longest to shortest segment
% recall iy is index to order cores from original order to order longest to
% shortest sgment length
% 
R = R(iy,:); % col1= median corr of core with all others; col2= sample size for corr
F= F(iy,:);  % col1=flag for index goes negative; col2=flag for index exceeds 5 in at least one year



%-----     DEFAULT PROMPTS

yrlast =nanmax(Y(:,3)); % last year
str1=num2str(yrlast);
lenseg=130;
str2=num2str(lenseg);
% default min acceptable median corr as 10th percentile
defpctile=25;
str3=num2str(defpctile);
%  nwant2 with earliest start
nwant2=min([10 nser]);
str5=num2str(nwant2);
%  nwant3 series covering year yrlast
nwant3=min([10 nser]);
str6=num2str(nwant3);

prompt={['Enter the ''last'' year for update'],...
    ['Enter min allowable seg length  '],...
    ['Enter the min acceptable percentile of median correlation'],...
    ['Enter nwant2, number of ''ealiest'' starting segments '],...
    ['Enter nwant3, number of series that include ''last'' update year ']};
name='Settings';
numlines=1;
defaultanswer={num2str(yrlast),...
    num2str(lenseg),...
    num2str(defpctile),...
    num2str(nwant2),...
    num2str(nwant3)};

answer=inputdlg(prompt,name,numlines,defaultanswer);
yrlast=str2num(answer{1});
lenseg=str2num(answer{2});
defpctile=str2num(answer{3});
nwant2=str2num(answer{4});
nwant3=str2num(answer{5});


kwh1 = 1; % control for while loop

% Recall R(:,1) is median correlation of each core index with all others,
% and that rows of R are sorted in decreasing order of segment length  of
% core index

while kwh1==1
    
    rcrit1 = R(:,1);  % cv of median corr of core index with all others
    L = ~isnan(rcrit1);
    rtemp = rcrit1(L); % subset of cores that has a median correlation, not NaN
    rthresh = prctile(rtemp,defpctile); % threshold acceptable median correlation 
        
    %----- Find the
    %  nwant1 with longest segments
    %  nwant2 with earliest start
    %  nwant3 series with longest segments that go up to as least as recent as yrlast
    
    Lx =logical(zcol); % cv logical false same length as full number of cores, segment length ordered
    
    
    %--- Minimum acceptable segment length (pending needs on ends of record
    leny = Y(:,1);
    L1 = leny>=lenseg;
    if sum(L1)==0
        error(['No series with segment length at least ' num2str(lenseg)]);
    end
    
    %--- Minimum acceptable median correlation of core index with all
    %    others
    L2 = rcrit1>=rthresh;
    if sum(L2)==0
        error(['No series with median correlation at least ' num2str(rthresh)]);
    end
    
    %--- Satisfies both criteria --- segment length and median correlation
    L3=L1 & L2;
    if sum(L3)==0
        error('No series satisfies both criteria of segment length and correlation');
    end
    
    
    %--- COVERAGE OF SPECIFIED RECENT YEAR
    
    L4a = Y(:,3)>=yrlast;
    L4b = L3 & L4a;
    L9 = L3; % updated pointer to rows wanted
    if sum(L4b)>=nwant3 % already have enought series covering last year without 
        % relaxing segment length or correlation criterion
        
    else
        need1 = nwant3-sum(L4b); % need this many more series covering yrlast
        L4c= (Y(:,3)>=yrlast) & ~L3; % series not yet selected that cover yrlast
        i1=find(L4c);
        b1 = leny(L4c); % segment length for subset
        b2 = rcrit1(L4c); % correlations for subset
        
        % Compute weight for segment length and correlaton 
        
        % rank for segment length, correlation
        [rb1,ntie]=ranktie1(b1); % higher rank is longer segment
        [rb2,ntie]=ranktie1(b2); % higher rank is higher correlation
        rcombo = (rb1+rb2)/2; % average rank; higher is better
        
        [rb, ntie]=ranktie1(rcombo); % higher rb is better
        
        % Find rows of rb with the need1 highest values
        [rbx,irbx]=sort(rb,'descend');
        iwin = irbx(1:need1); % keep these rows, indexed to b1, b2
        iw = i1(iwin); % keep thes row, relative to Y
        
        L9(iw)=1; % update the pointer to selected series in Y
        
    end
    clear iwin iw rb ntie rb1 rb2 b1 b2 i1 L4a L4b L4c
 
       
   
    %--- COVERAGE BY SPECIFIED NUMBER OF EARLIEST SERIES
    %
    % nwant2 is the desired number of earliest-year series
    % Identify the rows of Y that are the nwant2 earlist series
    yron = Y(:,2);
    [a,ia]=sort(yron,'ascend');
    irow = ia(1:nwant2);
    L=ismember(irow,find(L9)); % which elements of irow are already in L9
    nL = sum(L);
    if all(L) % all in already
    else
        iadd = irow(~L);
        L9(iadd)=1;
    end
    
    Lx=L9; % rename for convenience
   

    
    %---BUILD FLAG TO SERIES THAT ARE SELECTED BUT EITHER DO NOT MEET THE
    % SEGMENT LENGTH THRESHOLD OR DO NOT MEET THE CORRELATION THRESHOLD
    
    Lflag(:,1:2)=F; % special standardization using mean
    Lflag(:,3) = L9 & leny<lenseg;
    Lflag(:,4)= L9 & rcrit1<rthresh;
    
   
    %--- Re-order columns of Time series matrix of original widths, pull the
    % selected series, and plot a time series of number of cores.
    U1=U(:,iy); % L to R from longest to shortest segment length
    yrU1=yrU;
    U2=U1(:,Lx);
    yrU2=yrU1;
    LU2 = ~isnan(U2);
    ncores = (sum(LU2'))'; % time series cv of number of cores in culled chron
    
    strx ={'Settings for rwlids3.m',...
        ['Total cores before/after screening = ' num2str(nser) '/ ' num2str(sum(Lx))],...
        ['Update year = ' num2str(yrlast)],...
        ['Min allowable seg-length = ' num2str(lenseg)],...
        ['Min allowable pctile of med r =' num2str(defpctile) '; r=' num2str(rthresh,'%5.2f')],...
        [num2str(nwant2) ' series with earliest start years are retained'],...
        [num2str(nwant3) ' series covering year ' num2str(yrlast) ' are retained']};
    
    
    figure(2);
    [cL,cB,cW,cH]=figsize(.6,.7);
    set(gcf,'Position',[cL cB cW cH]);
    
    h = plot(yrU2,ncores);
    xlabel('Year');
    ylabel('Number of cores');
    textcorn(strx,'UL',0.02,0.02,12);
    
    qagain=questdlg('Change settings?')
    if strcmp(qagain,'Yes')
        
        
        prompt={['Enter the ''last'' year for update (' str1 ')'],...
            ['Enter min allowable seg length  (' str2 ')'],...
            ['Enter the min acceptable percentile of median correlation (' str3 ')'],...
            ['Enter nwant2, number of ''ealiest'' starting segments (' str5 ')'],...
            ['Enter nwant3, number of series that include ''last'' update year (' str2 ')']};
        name='Settings';
        numlines=1;
        defaultanswer={num2str(yrlast),...
            num2str(lenseg),...
            num2str(defpctile),...
            num2str(nwant2),...
            num2str(nwant3)};
        
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        yrlast=str2num(answer{1});
        lenseg=str2num(answer{2});
        defpctile=str2num(answer{3});
        nwant2=str2num(answer{4});
        nwant3=str2num(answer{5});
        
        
    else
        kwh1=0;
    end
    
    
end; %while


%--- Build and save .mat output file with record of specs

clear D;

part1 = strtok(pfin,'.');
part2 = '_rwlids3_specs.mat';
fileout = [part1 part2];
D.what = char({['Output of function rwlids3 run on ' pfin ' on ' datestr(date)],...
    'D is a structure with fields:',...
    ['   yrlast - specified ''last year'' that updates should cover'],...
    'lenseg = minimum allowable segment length',...
    'yrlast = function tries to retain at least ''nwant3'' series covering this year',...
    '   Of course, if this might not be possible if fewer than nwant3 series series',...
    '   extend to that year',...
    'defpctile = minimum acceptable percentile of median correlation of a series with all other series',...
    'rthresh = the correlation corresponding to that percentile',...
    ['nwant2 = specify that prefer to keep the nwant2 ''earliest'' (start year) series'],...
    ['nwant3 = specify that prefer to keep the nwant3 series with longest seg length that extend up through year yrlast'],...
    ['ids_culled = col-cell of ids of selected cores'],...
    ''....
    'Over-riding criteria are lenseg and defpctile. That is the first screening. Then',...
    'time coverage in the specified ''last'' year is checked. If not enough',...
    'additional series are added based on even weighting of ranked segment length',...
    'and correlation. ',...
    '',...
    'Lflag is a flag collated to the series names in ''ids_culled''. Columns are 0 or 1, with 1 being:',...
    '   col 1: spline detrending bombed because spline went to 0 or negative; had to use mean width instead',...
    '   col 2: computed ratio index using spline exceeded 5.0 in some year; reverted to using mean width',...
    '          instead of spline fit',...
    '   col 3: series accepted even though ''lenseg'' not satisfied; could be because needed more series',...
    '          covering ''yrlast'', or because needed more of the early series',...
    '   col 4: series accepted even though ''defpctile'' correlation not high enough; likewise for possible',...
    '          reasons'});
D.yrlast=yrlast;
D.lenseg=lenseg;
D.yrlast=yrlast;
D.defpctile=defpctile;
D.rthresh=rthresh;
D.nwant2=nwant2;
D.nwant3=nwant3;
D.ids_culled = nms1(Lx);
D.Lflag=Lflag;

if ~Lskip
    eval(['save ' fileout ' D;']);
else
end


%---- BUILD OUTPUT MATRIX

c1 = num2str(iseq);
c2 = char(ids);
c3 = num2str(Y);
c3a = num2str(R(:,1),'%5.2f');
c3b = num2str(R(:,2),'%3.0f');
c4 = num2str(Lx);


C =[c1 blanks3 c2 blanks3 c3 blanks3 c3a blanks3 c3b blanks3 c4];

if ~Lskip
    fout = [strtok(pfin,'.')  '_rwlids3_out.txt'];
    [mC,nC]=size(C);
    fid = fopen(fout,'w');
    for n = 1:mC
        c=C(n,:);
        fprintf(fid,'%s\n',c);
    end
    fclose(fid)
else
end


%---- SAMPLE SIZE PLOT BEFORE AND AFTER

[a,b]=fileparts(pfin);
bb=strrep(b,'_','-');


s={['Sample Size Before and After High-Grading ' bb],...
    'Before','After','Year','Number of Cores'};
tsplot1ss(U,yrU,U2,yrU2,s)



%--- TIME PLOTS OF SITE CHRONOLOGIES BEFORE AND AFTER HIGH-GRADING

V1= V(:,iy); % core indices, ordered from longest to shortest segment length
V2= V1(:,Lx); % subset of core indices after high-grading
yrV1=yrV;
yrV2=yrV;
V1(:,Lflag(:,1))=[]; % drop cores for which spline dropped to non-positive
V1(:,Lflag(:,2))=[]; % drop cores for which computed index exceeded 5.0 in any year

s={['100-Spline Site Chronology Before and After High-Grading ' bb],...
    'Before','After','Year','Index'};
tsplot2ss(V1,yrV1,V2,yrV2,s)




