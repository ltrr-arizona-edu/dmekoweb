function lockdown(jpick)
% lockdown: graphical quality control of dating/measurement by correlation analysis
% lockdown(jpick);
% Last revised 2019-12-30
%
% Graphical quality control of dating/measurement by correlation analysis. 
% Main purpose is to check tentatively dated ring-width series against a "master" -- a correctly
% dated series.  This master may either be read in, or built iteratively from the tentatively dated
% series. User should refer to the file lockdown.doc for detailed running
% instructions.  
%
%
%*** INPUT
%
% jpick (1 x ?)i , [], or missing:  pointer to series in the rwl file to be tested in this run;  allow for the analysis to
%     be restricted to a few test cores, which might be necessary with some huge datasets (e.g., hundreds of cores).
%     Example 1:  jpick=[1 3 5] use only the first, third and fifth core in the rwl file
%     Example 2:  jpick=[34:end]   use only the 34th through last cores
%     Example 3:  jpick =[] use all cores.  Missing argument jpick also means this
%.
% User prompted for the name of the .rwl file with the ring widths to be tested, and optionally prompted for
% names of a .crn file with a master chronology or a .mat file with core ids of series for the tentative
% master.
%
%*** OUTPUT
%
% Screen plots summarizing results:
% 1) line plot with minimum, maximum and median r of each ring-width series and the master
% 2) Grayscale map flagging for each ring-width series and m1-year period offset by m2 years whether
%   1) the highest r is at the dated position and r>rc, where rc is a specified critical threshold correlation
%   2) the highest r is at the dated position, but r<=rc
%   3) the highest r is not at the dated position, but r>rc at the dated position
%   4) the highest r is not at the dated position, and r<=rc at the dated position
% 3) Colormap similar to map in (2), but going from red (highest r) to blue (lowest r)
% 4) Time series plot windowed r on time (top), standard devs (middle), and with the corresponding
%   high-pass z-score series in zoomable window (bottom)
%
%*** REFERENCES -- none
%*** UW FUNCTIONS CALLED
%
%*** TOOLBOXES NEEDED
%
%*** NOTES
%
%
% Correlations are computed with a window width m1 years and offset of m2 years.  The series are organized
% so that the first correlatons is for times 1:m1, second is for (1+m2):(m1+m2), etc.  If the length of the
% series is not be divisible by m, a final m-year period is aligned to end with last year of the common period.
% Default changeable m1 and m2 are hardcoded. Reasonable choices are m1=50 and m2=5;
%
% Series whose dating is in question are called "test" series.  The series used to check the dating of the test
% series is called the "reference" series
%
% To emphasize high-frequency ring-width variation, which must be relied on for accurate annual dating, series are
% high-pass filtered with a cubic smoothing spline g and then converted to zscores.  The high-pass version of a series
% is computed by the ratio method ( v = w/g) if dealing with core ring-widths from the rwl file, and by the
% difference method (v = w-g) if w is a site chronology from a crn file.  The master is computed by arithmetic
% averaging over series after they have been individually converted to zscores.  The average series itself is then
% converted to a zscore.  Thus the master, by whatever method, has mean 0 and std 1.
%
%
% If the master series is built from ring widths of a subset of cores, the following operations are taken:
% 1) each ring-width series is high-pass-filtered and then converted to unit variance, as described above
% 2) the transformed ring-width series are averaged together to form a mean time series
% 3) that mean series is again converted to unit variance
%
% The cubic smoothing spline is specified in an input dialog by the wavelength at which the frequency response
% is 0.5.  A reasonable choice for this wavelength is 20 years
%
% Test and master subsets of ringwidths from the same rwl file are kept mutually exclusive.  In other words, the master for
% testing a particular sample never includes that sample.  If the master is a crn file, this independence could be violated--
% for example if the crn was built from trees that happened to include a
% core from the same tree as the test series.  
%
% Depending on menu choices, the master is read in from a .crn file, built from specified cores, or built from all 
% cores except the core being tested.  If the master comes from a .crn file or an id-list of master cores, the same
% master applies to all series tested in a rung of lockdown.  If the master is built from "all other cores", a different
% master applies in the test for each test core.  The master in this case
% is an average over all other cores.
%
% The number of cores in the master is annotated above the x axis at years evenly divisible by
% 20 so that the user has some idea of the robustness of the master at a
% particular time.
%
% The optional argument "jpick" is included to allow for the possibility that only some subset of cores in a .rwl file
% should be tested.  This restriction might be necessary if the .rwl file includes many (say, several hundred ) cores, which
% would make the screen menues too cumbersome.  If master is built using
% option for "all other series", the cores available for the master are
% also restricted by jpick.  If jpick =[] or the jpick argument is not included, no such restriction is made, and "all other" means all
% other cores in the rwl file containing the test cores.  But, say jpick==1:10.  Then core series 1,2,...10 are
% the only cores tested, and the only cores considered for the master.  When testing series 1, the master is
% made up of series 2 -10.  When testing series 2, the master is made from the set {1 3-10}, etc.
%
% Notation
% variable 1: test series
% variable 2: reference series
% u full length original series
% v windowed original series
% w windowed scaled high-pass series
% s standard-deviation of rw change, test series
%
% Revised 20100821 to insert two pause statements to work around matlab bug
% that causes uigetfile to occasionally fail inexplicably, as if the
% computer's mind is racing too fast to incorporate the code
%
% Revised 20100321 to fix bug in labeling of the time series of standard
% deviations. 
%
% Revised 20100329 to identify missing ring years in the test series and
% include vertial line on the zoomed z-score time series plots where those
% are.  
%
% Revised 20100409 to allow plotting a pair of ring-width series
%
% Revised 20100503  to use square-root transform followed by difference
% detrending to compute core indices from ring widths and the flexible
% spline (e.g., 20-yr spline).  Previously used difference detrending for
% conversion of master when it is crn file, but used ratio detrending for
% ring-widths to be tested. When spline goes near zero this can give
% exploding core index.  Now use difference detrending of the widths after
% widths are square-root transformed to emphasize variations at the narrow
% end of distribution more than those at the wide end.  Also revised such
% the zoomed plot (bottom of 3) that shows z-score plots in zoomed segment
% are plotted as z-scores based on the means and standard deviations for
% the zoomed window.  This seems reasonable because correlations in a
% window are relative to the mean of the window.
%
% Revised 20191230 to 1) allow filling in of internal missing values of
% measurments using mean-ratio method, and 2) to replace any negative
% measurements with zero.  Width and density measurment should not be
% negative. Negative values are sometimes (e.g., ITRDB) used to flag
% missing data. The check for negative values is done AFTER the optional
% call to meanrat1 to fill in missing values. 

close all;
clc;

if nargin==0
    jpick=[];
end


%--- HARD CODE

wind_width=50; % default window width
wind_shift=5; % initialize window width
spline_period=20; % wavelength spline has frequency response 0.
mr=50; % minimum number of years for median-ration computation; important only if internal
%   missing data in measurement series
xmiss=-9990; % default missing value
maxser=10;
p_spline = splinep(spline_period,0.50); % spline parameter
str_spline1 = [num2str(spline_period) ' spline'];
str_spline2 = ['High Pass (' num2str(spline_period) ' spline)'];



%---- FIND OUT IF USER ON LINUX.  IF SO, SOME PROBLEMS WITH LATEX
% WILL DEMAND SETTING INTERPRETER TO TEX IN SOME PLACES
 a=OStell;
 if strcmp(a.OS,'Linux');
     MeLinux='Yes';
 else
     MeLinux='No';
 end
 

%--- CHOOSE TO DEAL WITH EITHER TENTATIVELY DATED SERIES OR 'UNDATED' SERIES DEFINED TO HAVE STARTING YEAR 1
kmode = menu('Choose mode','Test tentatively dated series','Blind shifting of a test series against master',...
    'Plots only: any series, any length with pre-defined master')';
if kmode~=1;
      uiwait(msgbox('Lockdown only handles the first mode so far','Fatal Error','modal'));
    error('Lockdown only handles the first mode so far')
end


if kmode==1


    %--- CHOOSE FORM OF REFERENCE SERIES: CRN FILE, ALL OTHER CORE RING WIDTHS, SPECIFED SUBSET OF CORE RING WIDTHS

    kref = menu('Choose form of master','A crn-file site chronology',...
        'Scaled high-pass average of all other core indices',...
        'Scaled high-pass average of core indices whose ids will be read in');
    
    
    %---- OPTION FOR PRELIMINARY FILLING IN OF INTERNAL MISSING VALUES IN
    % TIME SERIES
    
    qmiss = questdlg('Do time series have internal missing values  that need to be filled in?');
    
    
    %--- OPTIONALLY READ A MASTER CRN FILE
    
    if kref==1
        [y1,yry1,s1,yrs1]=subfun02;
    else
        % No action; will be building master from the rwl file
    end


    %--- INPUT DIALOG TO SPECIFY SPINE WAVELENGTH, WINDOW WIDTH

    prompt={'Enter the spline wavelength:','Enter the sliding window width:',...
        'Enter the offset:'};
    name='Program settings';
    numlines=1;
    defaultanswer={num2str(spline_period),num2str(wind_width),...
        num2str(wind_shift)};
    answer=inputdlg(prompt,name,numlines,defaultanswer);
    spline_period=str2num(answer{1});
    wind_width=str2num(answer{2});
    wind_shift = str2num(answer{3});
    p_spline = splinep(spline_period,0.50); % spline parameter
   

    %--- INPUT DIALOG TO SPECIFY OPTIONAL FILLING IN OF MISSING DATA 
    
    if strcmp(qmiss,'Yes')
        prompt={ 'Enter missing-value code:',...
            'Enter minimum number of years for a ''mean-ratio'' computation:',...
            'Enter maximum number of predictor series for missing data:'};
        name='Missing data estimaton';
        numlines=1;
        defaultanswer={num2str(xmiss),num2str(mr),num2str(maxser)};
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        xmiss= str2num(answer{1});
        mr= str2num(answer{2});
        maxser= str2num(answer{3});
    else
        xmiss=[]; mr=[]; maxser=[];
    end
    
    
    %--- INPUT THE RWL FILE (HAS THE TEST SERIES, AND MAYBE THE SERIES FOR THE MASTER)
    
    [file1,path1,jpick,X,nms,yrs]=subfun04(jpick);
    Xall=X;
    nmsall=nms;
    yrsall=yrs;
    jall = (1:size(nmsall,1))';


    %--- OPTIONALLY READ A .MAT FILE OF CORE IDS OF MASTER SERIES

    if kref ==3;
        [file_ids,path_ids,ids_master]=subfun03; % ids_master is cell of ids for master
        nref = length(ids_master); % number of cores in specified master
       
        file2=file1;
        
        % Update jpick by omitting any master cores -- do not want to test any of the master cores
        dtemp=cellstr(nmsall);
        jmaster = find(ismember(nmsall,ids_master));
        jpick = setxor(jpick,jmaster);
        if isempty(jpick);
            error('set of test cores is empty after masking those in master');
        end

        % Build a string menu of ids of cores, with those in master marked M
        nmsall_cell=cellstr(nmsall);
        nmstest_cell=nmsall_cell(jpick);
        nmsmaster_cell =nmsall_cell(jmaster);
        L=ismember(nmsall_cell,nmsmaster_cell) | ismember(nmsall_cell,nmstest_cell);
        pf_ids = [path1 'ids_master.mat'];
    elseif kref==1; % using crn file as reference
        nmsall_cell=cellstr(nmsall);
        nmstest_cell=nmsall_cell(jpick);
        nmsmaster_cell=[];
        pf_ids = [path1 'ids_master.mat'];
        file2=file1;
    elseif kref==2; % using all other cores as master
        nmsall_cell=cellstr(nmsall);
        nmstest_cell=nmsall_cell(jpick);
        file2=file1;
        pf_ids = [path1 'ids_master_initial.mat'];
    end

    kmaster=0; % master has not been changed yet


    %--- STORE TEST SERIES IN TIME SERIES MATRIX

    [X,yrX,nms]=sov2tsm3(X,yrs,nms,jpick,[]); % x is tsm of rw series, yrx is year vector; nms is col-cell of strings
    [mX,nX]=size(X);
    
    % Check that the years of selected test series are consistent with the dated-series  mode
    T = firstlst(X,yrX);
    if any(T(:,1)==1);
        error(['You said dated-series mode, but one or more series starts with year 1']);
    end
    
    
    %---- Optionally change any internal missing to NaN & replace by mean-ratio method
    
    if strcmp(qmiss,'Yes')
        Lneed = any(any(X==xmiss));
        if ~Lneed
        else
            L1=X==xmiss;
            X(L1)=NaN;
            kopt_mr=2;
            D=meanratio1(X,yrX,mr,kopt_mr,maxser); % D.Y, D.yrY is totally filled in X
            Y=D.Y; yrY=D.yrY;
            [mY,nY]=size(Y);
            for n =1:nY
                y=Y(:,n);
                Tgo =T(n,1); Tsp=T(n,2);
                L =yrY>=Tgo & yrY<=Tsp;
                y(~L)=NaN;
                X(:,n)=y;
            end
        end
    else
    end
    
    
    %----- ALL RING WIDTH (OR OTHER DATA THIS PROGRAM MIGHT BE APPLIED TO)
    % MUST BE NON-NEGATIVE.  THE OPTIONAL DATA-FILLING JUST COMPLETED WOULD
    % FILLED IN NEGATIVE-VALUE MISSING VALUE CODED DATA. BUT WHAT IF SOME
    % NEGATIVE VALUES STILL PERSIST. MUST DELETE THOSE. APPROACH TAKEN IS
    % TO TELL USER HOW MANY NEGATIVE VALUES WERE CHANGED,AND TO CONVERT
    % THEM TO ZERO
    
    
    L1=X<0;
    n_neg1=sum(L1);
    L2 = n_neg1>0;
    n_neg2 = sum(n_neg1);
    if n_neg2>0
        b={['Total of ' num2str(n_neg2) ' negative measurements detected and changed to zero'],...
            'At least one negative found in each of the following series','  '}';
        nms_neg=nms(L2);
        str_neg = [b; nms_neg];
        uiwait(msgbox(str_neg,'Message: str_neg','modal'));
        X(L1)=0;
    else
    end
    clear L1 n_neg1 L2 n_neg2 b nms_neg 
    
    
    
    ntest = nX; % this many ring width series to be tested
  
    
    %--- BUILD LOGICAL TSM OF MISSING RINGS IN X
    Lmiss = X==0;

    %--- COMPUTE ZSCORE HIGH PASS MASTER
    %  If just one master for the analysis (kref==1 or kref==3), will have it in
    % x_master, yrx_master,n_master, where n_master is the time-varying sample size for master
    % If more than one master (kref==2), have X_master, yrX_master, SS,yrSS, where these are time series
    % matrices the same col-size as the number of test series, and each column is the master to be used for
    % that test series.

    % Store all ring widths in time series matrix
    [Xall,yrXall,nmsall]=sov2tsm3(Xall,yrsall,nmsall,((1:size(nmsall,1))'),[]);
    
    % If had replaced negative values by mean value method, need to do same
    % for Xall
    if Lneed
        Xall=X;
    end
    
    
    
    [mXall,nXall]=size(Xall); % the "all" variables may be later needed if updating the master

    if kref==1; % using crn file for master
        % Recall have crn master in y1, yry1, with sample size in s1
        n_master = s1;
        kdir = 2; % use difference to compute high pass
        [x_master,yrx_master]=subfun01(y1,yry1,p_spline,kdir);
        
        % Build time series of master sample size (number of cores or trees, depending on source crn)
        yrss =yry1;
        ss = s1; 
             
    elseif kref==2; % using all non-test cores for master -- will have a different master for each test core

        %--- Build master
        %
        % The master, for this option, is the average s-score high-pass index for "all other" cores -- the set
        % not included the core tested.  It is assumed that all cores no        t in jpick are NOT to be considered to
        % be tested or to be used in building a master
        
        M = NaN(mX,nX); % to hold the master series (zscore high-pass) applicable to each core
        yrM=yrX;
        A = NaN(mX,nX); % to hold zscore high-pass series (for each core)
        yrA=yrX;
        G = NaN(mX,nX); % to hold spline curve used to high pass each series
        yrG=yrX;

        % Check that the years of selected test series are consistent with the dated-series  mode
        T = firstlst(X,yrX);
        if any(T(:,1)==1);
            error(['You said dated-series mode, but one or more series starts with year 1']);
        end
        YRS1 = T; % store first and last valid year of each test series
        
        % Generate zscore high-pass versions of all jpick series
        for n =1:nX; % loop over all series in jpick
            x = X(:,n);
            yrx = yrX;
            kdir=2; % use ratio(1) or difference(2) in computing high-pass
            [y,yry,gv]=subfun01(x,yrx,p_spline,kdir);
            
            Lreal =isreal(y);
            if ~Lreal
                disp('here')
            end
            
%             figure(1)
%             plot(yrx,x,yry,gv);
%             title(nms{n});
%             figure(1)
%             pause
            
            igo = yry(1)-yrM(1)+1;
            isp =igo + length(y) -1;
            A(igo:isp,n)=y; % store z-score high pass test series
            G(igo:isp,n)=gv; % store spline curves used in computing A
        end  %  for n =1:nX; % loop over all seris in jpick

        
        
        %----  Compute the nX master series
        
        nmaster=nX-1; % number of series available (not necessarily all in same year ) for each master
        M = NaN(mX,nX);  % to hold each test-specific master sieres
        LLmaster = false(nXall,ntest);  % to hold pointer to cores in each master in Xall, nmsALL
        Nms_master = cell(nmaster,ntest); % each col of this cell-mtx has the ids of cores in the  a master
        SS = zeros(mX,nX); % to hold time-varying sample depths of masters
        yrSS=yrX;
        
        
      
        Lshort = false(nX,1); % to flag test series with insufficient overlap with reference series
        L = true(nX,1);
        for n =1:nX; % loop over columns of A
            nmsthis = nms;
            nmsthis(n)=[];
            Nms_master(:,n) = nmsthis;
            L1 = L;
            L1(n)=0;
            A1 = A(:,L1);
            yrA1=yrA;
            
            T = firstlst(A1,yrA1); % 2-col mtx of first and last years of series
            ton = min(T(:,1));
            toff = max(T(:,2));
            L4= yrA>=ton & yrA<=toff;
            igo = ton - yrA(1)+1;
            isp = toff-yrA(1)+1;
            A1 = A1(L4,:);
            yrA1=yrA1(L4);
            [bogus,ntemp]=size(A1);
            if ntemp==1
                ymaster=A1;
            else
                ymaster = (nanmean(A1'))'; % average over cores to be used as master
            end
            M(igo:isp,n)= ymaster; % Store masters

            % Convert master to zscores
            mn_temp=nanmean(ymaster);
            sd_temp=nanstd(ymaster);
            ymaster = (y - mn_temp) / sd_temp;
            clear mn_temp sd_temp;
            
            % Compute time-varying sample size (number of cores) in masters
            Z = (A1)';
            L5 = ~isnan(Z);
            n_master = (sum(L5))';
            SS(igo:isp,n)=n_master;
            clear n_master L5 Z A1 yrA1 toff ton igo isp T
        end; % for n =1:nX; % loop over columns of A
        YRS2 = firstlst(M,yrM); % first and last year of each master series
        
        
        % Flag series with insufficient overlap with master for even 1 windowed  correlation
        for n = 1:ntest; % loop over test series
            yruz = (YRS1(n,1):YRS1(n,2))'; % year cv for test series
            yrvz = (YRS2(n,1):YRS2(n,2))'; % year cv for master
            nlap = length(intersect(yruz,yrvz));
            if nlap<(wind_width+2); % need the extra 2 yrs for lagged at -1 and +1
                Lshort(n)=1;
            end
        end

              
        clear L yruz yrvz n nlap
        % Now have this:
        %
        % M, yrM;  master series, a time series matrix, same size as X
        % YRS1: 2-col matrix of first and last valid year of each series
        % YRS2: 2-col matrix of first and last year of the available
        %   masters for those
        % SS, yrSS:   sample size for M
        %  Nms_master: a cell-string matrix, each col with the ids of cores in the master for that col of X
        % Lshort: cv with zeros, except 1 if less than (wind_width+2) overlap between master and test

    elseif kref==3; % building master from selected cores
        Lmaster = ismember(nmsall,ids_master);
        nmaster = length(ids_master);
        if sum(Lmaster) ~= nmaster
            error(['You specified ' num2str(nmaster) ' cores as masters, but only ' sum(Lmaster) ' name matches of ids']);
        end
        X_master = Xall(:,Lmaster);
        yrX_master = yrXall;
        nms_master=ids_master;
        Y_master = NaN(size(X_master,1),nmaster); % to hold zscore high-pass version of X_master
        Gv = Y_master; % for spline curves used in coverting X_master to Y_master
        yrY_master = yrX_master;
        for n = 1:nmaster; % loop over master series, computing zscore of high-pass
            x = X_master(:,n);
            yrx = yrX_master;
            kdir=1; % use ratio in computing high-pass
            [y,yry,gv]=subfun01(x,yrx,p_spline,kdir);
            igo = yry(1)-yrY_master(1)+1;
            isp =igo + length(y) -1;
            Y_master(igo:isp,n)=y;
            Gv(igo:isp,n)=gv;
        end;

        % Average over master cores
        [bogus,ntemp]=size(Y_master);
        if ntemp>1;
            T = firstlst(Y_master,yrY_master); % 2-col mtx of first and last years of series
            ton = min(T(:,1));
            toff = max(T(:,2));
            L= yrY_master>=ton & yrY_master<=toff;
            Y_master = Y_master(L,:);
            yrY_master=yrY_master(L);
            Z = (Y_master)';
            L = ~isnan(Z);
            n_master = (sum(L))';
            
            % Make time series of sample size (number of cores) in master
            yrss = yrY_master; 
            ss = n_master;
            
            z = (nanmean(Z))'; % column vector of mean of the zscores of individual high-pass master cores
            yrx_master = yrY_master;
            x_master = (z - nanmean(z)) / nanstd(z); % re-scale average series as zscore
        else
            x_master=y;
            yrx_master = yry;
            n_master = ones(length(y),1); % number of cores in master
            
            % Make time series of sample size (number of cores) in master
            yrss = yrx_master; 
            ss = n_master;
        end
    else % all-other cores master
        error('Must code for sample size time series of master for all-other-series option');
    end
    
    
    %--- HONE THE PLOTTING TIME SERIES OF SAMPLE SIZE FOR MASTER
    %
    % On plot, will want to annotate sample size at first year and at every year evenly divisible
    %  by m_window
    
    m=20;
    if kref~=2; % using a single master
        kopt_fun5=1;
        [ss1,yrss1]=subfun05(ss,yrss,m,kopt_fun5);
    else 
        kopt_fun5=2; % all-other option; each test series has different master
         [ss1,yrss1]=subfun05(SS,yrSS,m,kopt_fun5);
         sscell=ss1;
         yrss1=[];
    end
    
    %--- SPLINE-FIT, HIGH-PASS FILTER AND SCALE ALL TEST  SERIES; ALSO CHECK OVERLAP WITH MASTER
    %
    % Recall tha X, yrX, nms has the time series, year and names, and that this set has already been culled
    % according to jpick.
    
    
    if kref~=2; % Recall that if kref==2, have already done the high-pass filtering and computed the master
        %   series (multiple in that case), as well as other matrices, such as A, YRS1, G, Lshort, etc

        A = NaN(mX,nX); % to store the scaled high-pass test series
        YRS1 = NaN(nX,2); % to store first and last year of each test series
        G = A; % to store growth curves
        yrA= yrX;
        Lshort = false(nX,1); % to flag test series with insufficient overlap with reference series
        for n = 1:nX; % loop over test series
            if kref ==1 || kref==3; % have a single relevant master
                vz =x_master;
                yrvz =yrx_master;
            else
                vz = X_master(:,n);
                yrvz = yrX_master;
                [vz,yrvz]=trimnan(vz,yrvz);
            end
            x = X(:,n);
            yrx = yrX;
            kdir=1; % use ratio in computing high-pass
            [uz,yruz,gu]=subfun01(x,yrx,p_spline,kdir);
            YRS1(n,:)=[yruz(1) yruz(end)];
            igo = yruz(1)-yrA(1)+1;
            isp =igo + length(uz) -1;
            A(igo:isp,n)=uz;
            G(igo:isp,n)=gu;
            % Check for overlap with vz, yrvz
            nlap = length(intersect(yruz,yrvz));
            if nlap<(wind_width+2); % extra 2 yrs overlap to allow for computing lagged r
                Lshort(n)=1;
            end
        end; % for n = 1:nX; % loop over test series
        clear n vz yrvz x yrx uz yruz gu igo isp nlap;
    else
    end
    
    % Dead in water if no series have enough overlap with master
    if sum(~Lshort)==0;
        error(['No test series marked by jpick have at least ' num2str(wind_width) ' yr overlap with reference']);
    end
    
    
    %---- Warn if some test series too short for testing with master
    nshort = sum(Lshort); % number of test series with insufficient overlap with master
    if nshort>0;
        nmsout =nmstest_cell(Lshort);
        mess1 = ['These ' num2str(nshort) ' series have < ' num2str(wind_width+2) ' years overlap with master--will not be tested'];
        mess1=[mess1; nmsout];
        uiwait(msgbox(mess1,'Message','modal'));
    end
   
    
    %--- BUILD CHAR MATRIX WITH FIRST AND LAST YEAR OF ALL CORE SERIES FROM THE RWL (TEST, MASTER, AND ANY NOT
    % IN JPICK

    str_men2=[repmat('(',nXall,1) num2str(yrsall(:,1)) repmat('-',nXall,1)  num2str(yrsall(:,2)) repmat(')',nXall,1)];
    menu_test2 = [num2str(jall) repmat(' ',nXall,1) char(nmsall) repmat(' ',nXall,1) str_men2];
    menu2 = cellstr(menu_test2);
    H = menu_test2;
    clear str_men2 menu_test2;
    
    
    %-- Ascii txt file output  LockdownMenu2.txt  of all cores except those
    % masked out by JPICK
    
    fid = fopen('LockdownMenu1.txt','w');
    sthis=char({[file1  ' =  input rwl file'],...
        ' ',...
        'LockdownMenu1.txt',...
        'List of all series in the rwl',...
        'Any series specified to be masked out by jpick not included'});
    
    % header info
    [mH,nH]=size(sthis);
    eval(['fmth = ''%' num2str(nH) 's\n''']);
    for n =1:mH;
        hthis = sthis(n,:);
        fprintf(fid,fmth,hthis);
    end
    
    % list
    [mH,nH]=size(H);
    eval(['fmth = ''%' num2str(nH) 's\n''']);
    for n =1:mH;
        hthis = H(n,:);
        fprintf(fid,fmth,hthis);
        
    end
    fclose(fid);
    
    
    %--- ELIMINATE THE TEST SERIES WITH TOO-SHORT OVERLAP WITH MASTER
    
    jpick(Lshort)=[];
    X = X(:,~Lshort);
    Lmiss=Lmiss(:,~Lshort); % missing ring matrix
    nX = size(X,2);
    G(:,Lshort)=[];
    A(:,Lshort)=[];
    YRS1 = YRS1(~Lshort,:);
    nms = nms(~Lshort);
    ntest=length(nms);
    
    
    % Depending, also eliminate the masters
    if kref==2 && any(Lshort);
        YRS2 = YRS2(~Lshort,:);
        M(:,Lshort)=[];
        [bogus,nM]=size(M);
        Nms_master(:,Lshort)=[];
        ss1(Lshort)=[];
        sscell(Lshort)=[];
        
    end;
    

    %--- BUILD MENU CHOICES TO REMAINING TEST SERIES
     
    str_men1=[repmat('(',nX,1) num2str(YRS1(:,1)) repmat('-',nX,1)  num2str(YRS1(:,2)) repmat(')',nX,1)];
    menu_test = [num2str(jpick) repmat(' ',nX,1) char(nms) repmat(' ',nX,1) str_men1];
    menu1 = cellstr(menu_test);
    clear str_men1 menu_test;


    %---- COMPUTE AND STORE THE CORRELATIONS AND INDIVIDUAL-PLOT INFORMATION

    % The three subplots with time series plots of windowed r, standard deviations, and z-score series
    F1_titles = cell(ntest,1); % title
    F1_legends = cell(ntest,1); % legends
    F1_r = cell(ntest,1); % 4-col tsm of end year , correlations of test_t vs master_t, test_t vs master_t+1,
    %      test_t vs master_t-1
    F1_s = cell(ntest,1); % 3-col tsm of year, windowed std of test, of master


    % The summary correlation figure
    F2_legends = {'Median','Minimum','Maximum'};
    F2_xlabel='Series Number';
    F2_ylabel='Correlation';
    F2_xticklabel=cellstr(num2str(jpick));
    F2_data = NaN(ntest,3);  % to hold median, minimum and maximum correlation

    str_lag = {'x_{t} vs y_{t}','x_{t} vs y_{t+1}','x_{t} vs y_{t-1}'}; % this will be a legend on top plot
    
    D.la=cell(ntest,1); % to hold logical data on missing rings

    for n = 1:ntest; % loop over test series
        nm_ref = strtok(file2,'.'); % name of master, or reference, series
        nm_test = [strtok(file1,'.') '-' nms{n}]; % name of test series
        if kref==1;
            nm_ref = strtok(file2,'.'); % name of ref series
        elseif kref==2;
            nm_ref = [strtok(file1,'.') '- all others'];
        else
            nm_ref = [strtok(file1,'.') '- specified'];
        end
        F1_legends{n}={nm_ref,nms{n}};

        % Get pair of series
        x = A(:,n); % test series, z score high pass
        yrx=yrA;
        x_la =Lmiss(:,n); % handle missing data
        yrx_la=yrx;
        if kref==1 || kref==3;
            y = x_master;
            yry = yrx_master;
        else % master is made from all other series in jpick 
            y=M(:,n);
            yry = yrM;
        end

        % Trim
        [x,yrx]=trimnan(x,yrx);
        Lkeep =yrx_la>=yrx(1) & yrx_la<=yrx(end);
        x_la = x_la(Lkeep); % trim missing data logical vector
        yrx_la = yrx_la(Lkeep);
        [y,yry]=trimnan(y,yry);
        str_full=[num2str(yrx(1)) '-' num2str(yrx(end))]; % full coverage of test series


        % FIND OVERLAP OF HIGH-PASS AND CULL

        yrgo = max([yrx(1) yry(1)]);
        yrsp = min([yrx(end) yry(end)]);
        str_checkable=[num2str(yrgo) '-' num2str(yrsp)]; % full coverage of test series
        L=yrx>=yrgo & yrx<=yrsp;
        x=x(L);
        yrx = yrx(L);
        x_la = x_la(L);
        yrx_la=yrx_la(L);
        L=yry>=yrgo & yry<=yrsp;
        y=y(L);
        yry = yry(L);

        if sum(L)<(wind_width+2);
            str_hey1 = [nms{n} ' (Series # ' num2str(jpick(n)) ' in ' file1 ') short; maximum allowable window width is ' num2str(sum(L)-1) ' yr'];
            error(str_hey1);
        end

        str_1=['All: ' str_full '; Checkable: ' str_checkable];
        F1_titles{n}=['Test series, x_{t} = ' nms{n} ' (' str_1 ');   Master series, y_{t} = ' nm_ref];

        
        
        % STORE CULLED HIGH-PASS DATA FOR LATER INTERACTIVE PLOTS
           
        D.data{n}=[yrx x y];
        D.nmtest{n}  = nms{n};
        D.nmref{n} = nm_ref;
        
        % Missing ring
        D.la{n}=[yrx_la x_la];

        % COMPUTE DIFFERENCE OF HIGH-PASS TEST AND HIGH-PASS REF
        % Want to compute absolute departures and get their 0.95 prob point.  Then build a logical pointer to years
        % in which absolute departure is unusually large.  Later, will compute sums of those large-values in the
        % moving window, and plot at end of window year.
        d = x-y;
        dabs=abs(d);
        Lbig=dabs>prctile(dabs,95);


        % MAKE MATRICES OF INDEX POINTERS TO STARTING AND ENDING YEARS OF WINDOW SEGMENTS--I3

        nsize = length(x);
        yrend = ((yrx(1)+wind_width-1):wind_shift:yrx(end))';
        if yrend(end) < yrx(end);
            yrend=[yrend; yrx(end)];
            yrstart = yrend-wind_width+1;
        end;
        D.yrend{n}=yrend;
        isp = (yrend-yrx(1)+1)'; % rv of ending rows of x and y for each segment
        I1 = repmat(isp,wind_width,1);
        i2 = flipud((0:(wind_width-1))');
        I2 = repmat(i2,1,size(I1,2));
        I3 = I1-I2;
        clear isp I1 I2 i2;

        % Shifted pointers; X(I3fa) vs Y(I3ra) is test in year t with ref in t+1
        %  X(I3fb) vs Y(I3rb) is test in year t with ref in t-1
        I3fa = I3(1:(end-1),:);
        I3ra = I3((2:end),:);
        I3fb = I3((2:end),:);
        I3rb = I3((1:end-1),:);

        
        % MAKE TSMs OF SHIFTED TIME SERIES OF  SERIES -- F and R for test and reference

        F = x(I3);
        R = y(I3);
        B = Lbig(I3);


        %-- STANDARD DEVIATIONS, WINDOWED

        s_f = nanstd(F);
        s_r= nanstd(R);
        F1_s{n}=[yrend s_f' s_r'];


        %--- CALL CORRPAIR TO GET THE CORRELATIONS FOR EACH SUBPERIOD

        [r,nr]=corrpair(F,R);
        D.r{n}=r;
        D.summary(n,:)=[length(r) median(r) min(r) max(r)];
        nbig = nansum(B); % number of unusually large departures in zscore high-pass series in the window
        [ra,nra]=corrpair(x(I3fa),y(I3ra));
        [rb,nrb]=corrpair(x(I3fb),y(I3rb));

        %-- STORE
        F1_r{n} = [yrend r' ra' rb']; % year, correlation simultaneous, lagged -1, +1


    end; % for n = 1:ntest; % loop over test series



    %---- PLOTTING
    
    kvirgin = 1; % logical tells whether initial master has been modified yet. When kvirgin==0, it has.

    kwh1 = 1;
    while kwh1==1;

        kmen1 = menu('Choose','Check a ''test'' series','View summary stats',...
            'Modify makeup of master','Quit');
        if kmen1==1;
            kmen2 = menu('Choose test series',menu1);
            knew=1;  % you have selected another test series
            
            % May need to re-set the time-varying sample size for master
            if kref==2;
                ss1=sscell{kmen2}(:,2); 
                yrss1=sscell{kmen2}(:,1); 
                sss1 =SS(:,kmen2);
                yrsss1 = yrSS;
                
            else
            end
                       
            kwh4=1;
            while kwh4==1
                figure(2);
                [cL,cB,cW,cH]=figsize(0.8,0.6);
                set(gcf,'Position',[cL cB cW cH]);
                if knew==1;
                    yrx = D.data{kmen2}(:,1); % the zscore high pass data, year
                    yry=yrx;
                    x=D.data{kmen2}(:,2); % test series
                    x_la=D.la{kmen2}(:,2); % missing ring
                    y=D.data{kmen2}(:,3); % master series

                    xlims= [yrx(1)-3 yrx(end)+3];
                    Fthis=F1_r{kmen2};
                    yrend = Fthis(:,1);
                    r = Fthis(:,2);
                    ra = Fthis(:,3);
                    rb = Fthis(:,4);
                    Fs = F1_s{kmen2};
                    leg_s = F1_legends{kmen2}; % 1 is master, 2 is test

                    subplot(3,1,1);
                    hp1=plot(yrend,r,yrend,ra,yrend,rb);
                    set(hp1(1),'LineWidth',2,'Color',[0 0 1],'Marker','o');
                    set(hp1(2),'LineWidth',1,'Color',[1 0 1]);
                     set(hp1(3),'LineWidth',1,'Color',[0 1 0]);
                    xlabel(['End Year of ' num2str(wind_width) '-yr window']);
                    ylabel('r');
                    hleg1 = legend(str_lag);
                    if strcmp(MeLinux,'Yes');
                        set(hleg1,'Interpreter','Tex')
                    end
                    set(hleg1,'Position',[0.151    0.7850    0.0845    0.1280])
                    grid on;
                    title(F1_titles{kmen2});
                    xlims_a = get(gca,'XLim');  % save XLim so that same can be used in subplot(3,1,2)
                    htext1=text(yrend(1),r(1),'o','FontSize',14,'Visible','Off'); % Invisible circle to be moved later
                    
                    
                    % Subplot with standard deviations of test and master in sliding window; also the sample
                    % size (number of cores) annotated above x axis.  The sample size may be number of trees if
                    % the master is a crn file and the sample size is defined as number of trees in that file
                    subplot(3,1,2);
                    hp2=plot(Fs(:,1),Fs(:,3),Fs(:,1),Fs(:,2)); %col 2 is test, col 3 is master
                    hleggy=legend(leg_s);
                    if strcmp(MeLinux,'Yes');
                        set(hleggy,'Interpreter','Tex');
                    end
                    set(hp2(1),'Color',[0 0 0]);
                    set(hp2(2),'Color',[1 0 0]);
                    set(gca,'XLim',xlims_a);
                    ylims_ss = get(gca,'YLim');
                    ypt_ss = ylims_ss(1) + 0.02*diff(ylims_ss);
                    Ltemp = yrss1>=yrx(1) & yrss1<=yrx(end);
                    ss2 = ss1(Ltemp);
                    yrss2 = yrss1(Ltemp);
                    if yrss2(1)-yrx(1)<10;
                        yrss2(1)=[];
                        ss2(1)=[];
                    else
                    end
                    yrss2 = [yrx(1); yrss2];
                    if kref==2;
                        ss2 = [ sss1(yrsss1==yrx(1)); ss2];
                    else
                        ss2 = [ ss(yrss==yrx(1)); ss2];
                    end
                    txt_ss = cellstr(num2str(ss2));
                    ypt_ss = repmat(ypt_ss,length(yrss2),1);
                    
                    % Truncate text on sample size so that labeling does
                    % not extend left of xlims_a
                    Lkeep = yrss2>=xlims_a(1);
                    yrss3=yrss2(Lkeep);
                    ypt_ss3=ypt_ss(Lkeep);
                    txt_ss3=txt_ss(Lkeep);
                    
                    text_ss=text(yrss3,ypt_ss3,txt_ss3,'Horizontalalignment','Center','VerticalAlignment','Bottom');
                    %text_ss=text(yrss2,ypt_ss,txt_ss,'Horizontalalignment','Center','VerticalAlignment','Bottom');
                    xlabel(['End Year of ' num2str(wind_width) '-yr window']);
                    ylabel('Standard Dev');
                    grid on;
                    
                    subplot(3,1,3);
                    hp3=plot(yry,y,yrx,x);
                    set(hp3(1),'Color',[0 0 0]);
                    set(hp3(2),'Color',[1 0 0]);
                    set(gca,'XLim',xlims);
                    D.xlims{n}=xlims;
                    D.ylims{n} = get(gca,'YLim');
                    ylabel('z-score');
                    xlabel('Year');
                    hleggy=legend(leg_s);
                    if strcmp(MeLinux,'Yes')
                        set(hleggy,'Interpreter','Tex');
                    end
                    grid on;
                    knew=0;
                else
                end
                
                kmen5 = menu('Choose','Click on a point in top plot for zoomed time series in bottom','No zoom, move on','Plot ring widths for a pair of series');
                kfirst = 1; % first time through, no need to replot time series yet
                
                if kmen5==1;
                    
                    if kfirst==1;
                    else
                        figure(2)
                        subplot(3,1,3);
                        hp3=plot(yry,y,yrx,x); % z score recomputed within the zoom window (both series have mean 0 and variance 1 in the plot window)
                        set(hp3(1),'Color',[0 0 0]);
                        set(hp3(2),'Color',[1 0 0]);
                        set(gca,'XLim',xlims);
                        D.xlims{n}=xlims;
                        D.ylims{n} = get(gca,'YLim');
                        ylabel('z-score');
                        xlabel('Year');
                        hleggy=legend(leg_s);
                        if strcmp(MeLinux,'Yes')
                            set(hleggy,'Interpreter','Tex');
                        end
                        grid on;
                        
                    end
                    
                    
                    % Get end point for zoom from top series
                    figure(2);
                    subplot(3,1,1);
                    hkids=get(gca,'Children');
                    set(hkids(1),'Visible','off');
                    [xpt,ypt]=ginput(1);
                    diffx = abs(xpt-yrend);
                    [bogus,iw]=min(diffx);
                    yrlast = yrend(iw);
                    %htext_circ= text(yrlast,rthis(iw),'o','HorizontalAlignment','Center','VerticalAlignment','Middle');
                    set(hkids(1),'Visible','On','Position',[yrlast r(iw) 0],'HorizontalAlignment','Center','VerticalAlignment','Middle');
                    yrfirst = yrlast-wind_width+1;
                    yrslab=(yrfirst:yrlast)';
                    Lslab = yrx>=yrfirst & yrx<=yrlast;
                    
                    
                    % missing
                    if length(x) ~=length(x_la);
                        disp('here')
                    end
                    
                    subplot(3,1,3);
                    hpnew=plot(yrslab,zscore(y(Lslab)),'-o',yrslab,zscore(x(Lslab)),'-^');
                    set(hpnew(1),'Color',[0 0 0]);
                    set(hpnew(2),'Color',[1 0 0]);
                    ylabel('z-score');
                    xlabel('Year');
                    hleggy=legend(leg_s);
                    if strcmp(MeLinux,'Yes')
                        set(hleggy,'Interpreter','Tex');
                    end
                    grid on;
                    kfirst =0;
                    
                    % missing ring
                    xx_la = x_la(Lslab);
                    if any(xx_la);
                        ylims=get(gca,'YLim');
                        nla = sum(xx_la); % number of missing rings in slab
                        ila = find(xx_la);
                        for nn =1:nla;
                            t=yrslab(ila(nn));
                            hline = line([t t],[ylims],'Color',[1 1/3 0]);
                        end
                        
                    else
                    end
                    
                    
                    
                elseif kmen5==2;
                    kwh4=0;
                elseif kmen5==3; % plot ring widths for two series
                    h = nmsall_cell;
                    nh = length(h);
                    h{nh+1}='No more rw plots; move on!';
                    kwh5 = 1;
                    while kwh5==1;
                        kpairplot = menu('Choose first of two rw series',h);
                        if kpairplot==nh+1;
                            kwh5=0;
                        else
                            hh = nmsall_cell;
                            hh{kpairplot}=['*' hh{kpairplot}];
                            ksegundo = menu('Choose second of two two rw series',hh);
                            
                            Xtwo = Xall(:,[kpairplot ksegundo]);
                            yrXtwo = yrXall;
                            
                            % Trim the two series to be plotted to their
                            % common period of coverage
                            x1 = Xtwo(:,1);
                            x2 = Xtwo(:,2);
                            [x1,yrx1 ]=trimnan(x1,yrXtwo);
                            [x2,yrx2 ]=trimnan(x2,yrXtwo);
                            yron = max([yrx1(1) yrx2(1)]);
                            yroff = min([yrx1(end) yrx2(end)]);
                            if yroff<yron;
                                error('No overlap in the two series');
                            end
                            L = yrx1>=yron  & yrx1<=yroff;
                            x1=x1(L)
                            yrx1=yrx1(L);
                            L = yrx2>=yron  & yrx2<=yroff;
                            x2=x2(L);
                            yrx2=yrx2(L);
                            figure(3);
                            [cL,cB,cW,cH]=figsize(.7,.5);
                            set(gcf,'Position',[cL cB cW cH]);
                            h1 = plot(yrx1,x1,'-o',yrx2,x2,'-^');
                            set(gca,'Xgrid','on')
                            hleggy=legend(nmsall_cell{kpairplot},nmsall_cell{ksegundo});
                            if strcmp(MeLinux,'Yes')
                                set(hleggy,'Interpreter','Tex');
                            end
                            xlabel('Year');
                            ylabel('Ring Width (100ths or 1000ths of mm');
                        end
                    end
                    
                else
                    error('kmen5 must be 1, 2 or 3');
                end

            end; % while kwh4==1
        elseif kmen1==2;
            figure(1);
            ylims_temp = [min(D.summary(:,3))-0.1  1];
            if ylims_temp(1)>0;
                ylims_temp(1)=0;
            end
            jseq = (1:nX)';
            hp1 = plot(jseq,D.summary(:,2),'o','Linewidth',2,'MarkerSize',12);
            hold on;
            hp2=plot(jseq,D.summary(:,3),'x','Color',[1 0 0]);
            hp3=plot(jseq,D.summary(:,4),'x','Color',[0 0.6 0]);
            set(hp2,'MarkerSize',10,'LineWidth',2);
            set(hp3,'MarkerSize',10,'LineWidth',2);

            xlabel('Series Number');

            ylabel('Correlation');
            legend('Median','Minimum','Maximum');
            set(gca,'XTick',jseq,'XLim',[0 nX+1],'YLim',ylims_temp,'Xticklabel',num2str(jpick));
            grid on;
            hold off;
            fheight=0.3;
            fwidth=0.1 + 0.7*(nX/50);
            fwidth=min([fwidth 0.8]);
            [cL,cB,cW,cH]=figsize(fwidth,fheight);
            set(gcf,'Position',[cL cB cW cH]);
        elseif kmen1==3 ;  % Modify makeup of master
            if kref==1 || kref==3;
                if isempty(nmsmaster_cell) &&   kref==1;
                    Lin = false(length(nmsall),1); % none yet in master
                else
                    Lin = ismember(nmsall,nmsmaster_cell);
                end
                nallow =[0 length(Lin)];
                strmenu='Toggle Y for a core to be in master, N for a core to not be in master';
                C1=menu2;
                
                C2=cellstr(repmat('-N',length(C1),1));
                C2(Lin)=cellstr('-Y');
                [bogus,Lout] = menucell (C1,C2,Lin,nallow,strmenu);
                nmsmaster_cell=nmsall(Lout);
                %nmsmaster_cell=C3';
                kmaster=1;
            else % assumes "all other cores"  in master;  here you can build a "separate" master one by
                % one by adding cores 
                C1=menu2;
                if kvirgin==1;
                    C2=cellstr(repmat('-N',length(C1),1));
                    Lin = false(length(nmsall),1); % none yet in master
                    kvirgin=0; % no longer virgin
                else
                    Lin = ismember(nmsall,nmsmaster_cell);
                    C2(Lin)=cellstr('-Y'); % toggle 
                end;
%                 nmsmaster_cell=Nms_master(:,kmen2);
%                 if isempty(nmsmaster_cell);
%                     Lin = logical(zeros(length(nmsall),1)); % none yet in master
%                 else
%                     Lin = ismember(nmsall,nmsmaster_cell);
%                 end
               
                strmenu='Toggle Y for a core to be in master, N for a core to not be in master';
                
                nallow =[0 length(Lin)];
                [bogus,Lout] = menucell (C1,C2,Lin,nallow,strmenu);
                nmsmaster_cell=nmsall(Lout);
                %nmsmaster_cell=C3';
                kmaster=1;
                
            end

        else % kmen1 == 4
            kwh1=0;
            

            % Optionally update the master
            if kmaster==1;
                ktemp = questdlg(['Update ' pf_ids ' with revised list of master cores?']);
                if strcmp(ktemp,'Yes');
                    ids_master = nmsmaster_cell;
                    eval(['save ' pf_ids ' ids_master;']);
                end
            else
            end

            kclose = questdlg('Close all windows?');
            if strcmp(kclose,'Yes');
                close all hidden;
            else
            end
        end;

    end; % while kwh1==1;
elseif kmode==2; %  kmode==2
    
    shiftcor(jpick); % function that deals with possible dating position of undated
    
else  % kmode ==3; % plot only, any core, any length, against predefined master 
    
    % Specify the master
    kmaster = menu('Choose form of master','A crn-file site chronology',...
        'Scaled high-pass average of core indices whose ids will be read in');
    if kmaster==1;
        [y1,yry1,s1,yrs1]=subfun02; % Get standard chron and sample size from crn file. 
        
    else % get ids for master from a stored file
        [file_ids,path_ids,ids_master]=subfun03;
    end;
    
    % Get the spline parameter for high-pass filtering
    prompt={'Enter the spline wavelength:'};
    name='High-pass filter setting';
    numlines=1;
    defaultanswer={num2str(spline_period)};
    answer=inputdlg(prompt,name,numlines,defaultanswer);
    spline_period=str2num(answer{1});
    p_spline = splinep(spline_period,0.50); % spline parameter
    
    % Get the ring width data from rwl file
    [file1,path1,jpick,X,nms,yrs]=subfun04(jpick);
    Xall=X;
    nmsall=nms;
    yrsall=yrs;
    jall = (1:size(nmsall,1))';
    
    
    % Store all ring widths in time series matrix
    [Xall,yrXall,nmsall]=sov2tsm3(Xall,yrsall,nmsall,((1:size(nmsall,1))'),[]);
    [bogus,nXall]=size(Xall); % the "all" variables may be later needed if updating the master
    
    
    %--- Store test series in time series matrix
    [X,bogus,nms]=sov2tsm3(X,yrs,nms,jpick,[]); % x is tsm of rw series, yrx is year vector; nms is col-cell of strings
    [bogus,nX]=size(X);
    ntest = nX; % this many ring width series to be tested
    
          
    %--- Form the master
    
    if kmaster ==1; % using crn chronology for th emaster
        % Recall have crn master in y1, yry1, with sample size in s1
        n_master = s1;
        kdir = 2; % use difference to compute high pass
        [bogus,yrx_master]=subfun01(y1,yry1,p_spline,kdir);
        
        % Build time series of master sample size (number of cores or trees, depending on source crn)
        yrss =yry1;
        ss = s;
    else; % building master cores in a name list
        
        % Update jpick by omitting any master cores -- do not want to test any of the master cores
        dtemp=cellstr(nmsall);
        jmaster = find(ismember(nmsall,ids_master));
        jpick = setxor(jpick,jmaster);
        if isempty(jpick);
            error('set of test cores is empty after masking those in master');
        end
        
        % Build a string menu of ids of cores, with those in master marked M
        nmsall_cell=cellstr(nmsall);
        nmstest_cell=nmsall_cell(jpick);
        nmsmaster_cell =nmsall_cell(jmaster);
        L=ismember(nmsall_cell,nmsmaster_cell) | ismember(nmsall_cell,nmstest_cell);
        
        
        Lmaster = ismember(nmsall,ids_master);
        nmaster = length(ids_master);
        if sum(Lmaster) ~= nmaster;
            error(['You specified ' num2str(nmaster) ' cores as masters, but only ' sum(Lmaster) ' name matches of ids']);
        end
        X_master = Xall(:,Lmaster);
        yrX_master = yrXall;
        nms_master=ids_master;
        Y_master = NaN(size(X_master,1),nmaster); % to hold zscore high-pass version of X_master
        Gv = Y_master; % for spline curves used in coverting X_master to Y_master
        yrY_master = yrX_master;
        for n = 1:nmaster; % loop over master series, computing zscore of high-pass
            x = X_master(:,n);
            yrx = yrX_master;
            kdir=2; % use ratio (1) or difference (2) in computing high-pass
            [y,yry,gv]=subfun01(x,yrx,p_spline,kdir);
            igo = yry(1)-yrY_master(1)+1;
            isp =igo + length(y) -1;
            Y_master(igo:isp,n)=y;
            Gv(igo:isp,n)=gv;
        end;
        
        % Average over master cores
        [bogus,ntemp]=size(Y_master);
        if ntemp>1;
            T = firstlst(Y_master,yrY_master); % 2-col mtx of first and last years of series
            ton = min(T(:,1));
            toff = max(T(:,2));
            L= yrY_master>=ton & yrY_master<=toff;
            Y_master = Y_master(L,:);
            yrY_master=yrY_master(L);
            Z = (Y_master)';
            L = ~isnan(Z);
            n_master = (sum(L))';
            
            % Make time series of sample size (number of cores) in master
            yrss = yrY_master;
            ss = n_master;
            
            z = (nanmean(Z))'; % column vector of mean of the zscores of individual high-pass master cores
            yrx_master = yrY_master;
            x_master = (z - nanmean(z)) / nanstd(z); % re-scale average series as zscore
        else
            x_master=y;
            yrx_master = yry;
            n_master = ones(length(y),1); % number of cores in master
            
            % Make time series of sample size (number of cores) in master
            yrss = yrx_master;
            ss = n_master;
        end
        
        % Build time series of master sample-size labels
        kopt_fun5=3;
        m=10;
        [ss1,yrss1]=subfun05(ss,yrss,m,kopt_fun5);
        
    end
    
        
    
    %--- Reduce the set of test series those satisfying the following
    %conditions  
    % 1 Not in master
    % 2 Having at least 3 years overlap with master
    % 3 Shorter than some number of years, with the number to be prompted
    % for
    
    %--- Store test series in time series matrix
    [X,yrX,nms]=sov2tsm3(X,yrs,nms,jpick,[]); % x is tsm of rw series, yrx is year vector; nms is col-cell of strings
    [bogus,nX]=size(X);
    ntest = nX; % this many ring width series to be tested
    
    
    
end; % if kmode==1;


% return  here if change the composition of master
%--- GENERATE THE HIGH-PASS MASTER

%--- COMPUTE THE INDIVIDUAL WINDOWED CORRELATIONS AND THEIR TIME SERIES PLOTS (length(jpick) windows)

%--- COMPUTER THE MATRIX OF CORRELATIONS FOR THE GRAY-SCALE AND COLOR MAPS

%--- MAKE THE GRAYSCALE AND COLORMAP FIGURES

%---- MAKE THE SUMMARY CORRELATION FIGURE

%---- MAKE THE MENU FOR
%   Check a test series
%   View summary correlation plot
%   View grayscale map of segment correlations
%   View color map of segment correlations
%   (optional--if master not crn) Change composition of master


%---- SUBFUCTIONS

function [y,yry,g]=subfun01(x,yrx,p_spline,kdir)
%
% Compute z-score high-pass of a time series
% x, yrx is original time series, possibly with NaNs in part
% p_spline is spline parametere
% kdir == method for removing fitted spline: 1== ratio, 2==difference
%
% y, yry == z-score high pass version of x
% g = smooth curve returned by call to spline function csaps
%
xtemp=x;
[xtemp,yrxtemp]=trimnan(x,yrx); % trim leading and trailing NaNs
L=isnan(xtemp); % mark any internal NaN
xxtemp=xtemp(~L); % pull non-NaNs of trimmed
if kdir==2;
    xxtemp = sqrt(xxtemp); % transform to emphasize low values over high
    % Revision 2013Nov16a
    xtemp =sqrt(xtemp); 
    %--------------
end
yrxxtemp=yrxtemp(~L);
[g,p] = csaps(yrxxtemp,xxtemp,p_spline,yrxtemp); % compute smoothing spline

% Revision 2011Aug31a
if any(g<=0);
    Lzero=g<=0;
    g(Lzero)=eps;
end
if kdir==1; % if high pass if ratio of time series to smooth curve
    if any(g<=0);
      error('ratio high pass blows up because g goes to zero or negative');
        
    end
    u = xtemp ./ g; % high pass series, as ratio
else
    u = xtemp - g; % high pass series, as difference

end
umean = nanmean(u);
ustd = nanstd(u);
y = (u-umean) / ustd; % zscore of high-pass
yry= yrxtemp;
%plot(yrxtemp,(xtemp-nanmean(xtemp))/nanstd(xtemp),yry,y)
%plot(yrxtemp,xtemp,yry,g)

function [y1,yry1,s1,yrs1]=subfun02
%
% Get site chron from a crn file
% y1,yry1 is the site chron
% s1,yrs1 is the sample size
pause(1)
[file2,path2]=uigetfile('*.crn','crn Infile with master series');
%pf2=[path2 file2]; % merge path and filename
pf2=fullfile(path2,file2); % merge path and filename
[y,s,yry]=crn2vec2(pf2); % y is a site chronology, s is sample size, yry is year
y1 =y;
yry1=yry;
s1=s;
[y1,yry1]=trimnan(y1,yry1);
[s1,yrs1]=trimnan(s1,yry);


function [file_ids,path_ids,ids_master]=subfun03
%
% Prompt for name of a file with ids of series to be used in master
% and load that file
%
% file_ids is the filename
% path_ids is the path to the file
% ids_master is cell of ids
%
pause(1)
[file_ids,path_ids]=uigetfile('ids_*.mat','Infile with ids of cores for building master');
pf_ids =[path_ids file_ids];
eval(['load ' pf_ids ';']);
if ~exist('ids_master','var');
    error([pf_ids ' does not have variable ids_master']);
else
    if ~isa(ids_master,'cell');
        error('ids_master not a cell');
    end
end


function [file1,path1,jpick,X,nms,yrs]=subfun04(jpick)
% 
% Read in the rwl file, which has X, nms, yrs
[file1,path1]=uigetfile({'*.rwl;*.RWL'},'rwl files (*.rwl, *.RWL) with ''test'' series');

pf1=[path1 file1]; % merge path and filename
pf1a=rwlinp(pf1);
eval(['load ' pf1a ';']); % X, nms, yrs are key
if size(jpick,1)==1;
    jpick=jpick';
end;
if isempty(jpick);
    jpick=(1:size(nms,1))';
end


function [ss1,yrss1]=subfun05(ss,yrss,m,kopt)
%
% Develop text time series for annotating number of samples in master
% On plot, will want to annotate sample size at first year and at every year evenly divisible
%  by m
%
% ss: either a cv or a time series matrix of sample size of of master; a
%   matrix if the "all others" option
% yrss year vector for ss
% m: want to annotate at first year and then all years evenly divisible by
%   m
% kopt==1:   cross-dating mode (kmode==1) and master by either crn or
%       id-list file
% kopt==2:  cross-dating mode (kmode==1) and master by "all others" 
% kopt==3:  plot-check mode (kmode==3) [in this mode cannot have "all
%   others" mster


if kopt==1 || kopt==3;
    L1 = mod(yrss,m)==0;
    L1(1)=1;
    yrss1=yrss(L1);
    ss1=ss(L1);
else  % "all others" are masters;
    
    % Make cells with time series of sample size for masters
    ntest =size(ss,2); 
    sscell = cell(ntest,1);
    for n=1:ntest;
        ss_this = ss(:,n);
        yrss_this=yrss;
        L2 = ss_this>0;
        ss_this=ss_this(L2);
        yrss_this=yrss_this(L2);
        if ~all(diff(yrss_this)==1);
            error('yrss_this not inc by 1');
        end
        L1 = mod(yrss_this,m)==0;
        yrss1_this=yrss_this(L1);
        ss1_this=ss_this(L1);
        sscell{n}=[yrss1_this ss1_this];
    end
    ss1 = sscell;
    yrss1=[];
end

