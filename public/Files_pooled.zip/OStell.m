function Result=OStell
% OStell: find out the operating system of the computer
% Result=OStell;
% Last Revised 2009-08-23
%
% Find out the operating system of the computer.
% Makes call to matlab 'computer' function ans returns structure identifying
% whether MS Windows, Linux, or Mac (or Solaris, if 64-bit), and whether
% platform 32-bit or 64-bit
%
%**** INPUT 
%
% No input arguments
%
%
%*** OUTPUT
%
% Result -- structure of results
%   .OS (1 x ?)s  -- operating system
%       Windows
%       Linux
%       Mac
%       Sun Solaris    
%   .nbits (1 x 1)r
%       32
%       64
%
%*** REFERENCES --- none
%
%*** TOOLBOXES NEEDED -- none
%
%*** UW FUNCTIONS CALLED -- none
%
%*** NOTES

 
OSids={'PCWIN','GLNX86','MACI','PCWIN64','GLNXA64','SOL64','MACI64'};
platforms={'Windows','Linux','Mac','Windows','Linux','Sun Solaris','Mac'};
nbits =[32 32 32 64 64 64 64];
d=computer;
L1=ismember(OSids,d);
if sum(L1)==0;
    error([d ' not match any operating system']);
elseif sum(L1)>1;
    error(['More than one match for OS ' d]);
end
i1 = find(L1);
Result.OS=platforms{i1};
Result.nbits=nbits(i1);
    