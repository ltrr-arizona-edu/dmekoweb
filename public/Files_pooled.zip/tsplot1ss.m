function tsplot1ss(X,yrX,Y,yrY,s)
% tsplot1ss: time series plot of sample size for two sets of ring widths
% tsplot1ss(X,yrx,Y,yrY,s)
% Last revised 2017-01-16
%
% Time series plot of sample size for two sets of ring widths
%
%*** INPUT
%
% X (mX x nX)r  % first time series matrix of ring widths
% yrX (mX x 1)i % year vector...
% Y (mX x nX)r  % second time series matrix of ring widths
% yrY (mX x 1)i % year vector...
% s{}1=title
%    2=legend for nx
%    3=legend for ny
%    4=x axis label
%    5=y axis label


[mX,nX]=size(X);
[mY,nY]=size(Y);


%---- NUMBER OF SERIES PER YEAR 

L = ~isnan(X);
nx =    (sum(L'))';
L = ~isnan(Y);
ny =    (sum(L'))';


yrnx = yrX;
yrny = yrY;

[nx, yrnx]=trimnan(nx,yrnx);
[ny, yrny]=trimnan(ny, yrny);


yrgo = min([yrnx(1) yrny(1)]);
yrsp = max([yrnx(end) yrny(end)]);
xlims = [yrgo-3 yrsp+3];

yhi = max([max(nx) max(ny)]);
ylo=0;
ylims = [0  yhi+0.1*yhi];

str1 ={['Before, N=' num2str(nX) ' cores'],...
    ['After , N=' num2str(nY) ' cores']};
    



figure
[cL,cB,cW,cH]=figsize(.75,.6);
set(gcf,'Position',[cL cB cW cH]);

h = stairs(yrnx,nx);
set(gca,'XLim',xlims,'YLim',ylims);
hold on;
h=stairs(yrny,ny);
legend(s{2},s{3})
xlabel(s{4});
ylabel(s{5});
title(s{1});

textcorn(str1,'UL',0.02,0.02,14)
hold off;
