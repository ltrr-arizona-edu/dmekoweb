function Result=trach02
% trach02: Sensitivity of cell-anatomy climate signal on width of climate day-window
% Result=trach02(datin,specs)
% Last revised 2019-10-06
%
% Sensitivity of cell-anatomy climate signal on choice of starting day
% of first non-overlapping climate day-window of specified size. The second
% of trinity (trach02,02,03) of functions for color-mapped summary of
% hydroclimatic signal. After trach01, you will have some idea of a window
% size capturing signal. Now want to check whether the alignment of the
% non-overlapping windows of that size relative to day-of-year makes an
% appreciable difference in signal.
%
% 
%*** INPUT
%
% No input arguments. User prompted to click on specifically formatted
% input files of tree-ring data and daily climate data. These may
% optionally be xlsx spreadsheet files or mat (Matlab) files.  User also
% prompter for various settings of specifications. Defaults are hard coded
% at start of this function. 
%
%*** OUTPUT
%
% Result.summary: a character matrix with some information about the run
%
% Figure window j=1:M, where M is the number of tree-ring subdivsions or
% quantiles. Figure jA is a plot of maxium positive correlation and maximum
% absolute negative correlation in any day window as a function of the last
% day of year of the latest window. Figure jB gives similar summaries of
% the maximum number of significant correlations in any window.
%
% Optionally, depending on response to a prompt, a summary text file and
% png files of the figure windows. These files are date-codes and are of
% the form:
% Summary_trach02_07-Oct-2019.txt
% Fig1_trach02_07-Oct-2019.png 
%
%*** NOTES
%
% One 2x1 figure window will be produced for each tree-ring series. Top is
% plot of maximum and minimum r against ending day-of-year of last window.
% Bottom is plot of number of significant correlations, at the specific
% critical alpha. No adjustement for autoncorrelation.
%
% Northern vs Southern Hemisphere. For NH specify window size, m, and last
% day/month of last window. Non-overlapping windows than formed backwards from that
% day-of-year, such that first window does not cross into previous calendar
% years. Also compute windowed series for same, but with last window ending
% in days j2:(j2+m).
%
% Southern Hemisphere not yet coded. Thinking will translate to a new
% x-coordinate system with t==1 at July 1 of year before growth year. Each
% t in that system will map to a specific "day-of-year" and month/day. Idea
% is that early windows should be in mid-winter, before start of cambial
% growth. 
%
% Figures. Each figure window will have and A and a B. A will have line
% plots of maximum absolute r (positive and negative) as function of ending
% day of last window. B will have corresponding plots of number of
% significant windows. Significance will be  guided by input critical
% alpha, and will not be adjusted for autocorrelation or multiple
% comparisons. 
%
% Legends wil define the two curves. Text within figure will list important
% findings. Super-title will define analysis, such as:
% "Quantile 1/1 of lumen area (filename) vs SWC [11-day non-overlapping windows 1965-2014]"
% x-axis is last day of last window, and is set to have m points, where m
% is the window size in days. 
%
%
% Outline...
%   Read data files and set up specifications 
%   Store tree-ring series in columns of matrix Y
%   Compute and store windowed annual climate time series in cells of a col-cell
%   Set the analyisis period and end days of windows to be used
%   Loop over tree-ring quantiles and climate windows
%       Compute and store correlations and associated data
%   Organize input args for call to subfunction that produces plots

% Hard Code
close all
defname1='TSME_LA.mat';
defname2='simulationsCPRdaily_B.xlsx';

% Output filename date stamp
dstamp=['trach02_' datestr(date,1)];

qskip = questdlg('Skip all ''print'' and ''save'' statements?');

pathcurr=cd;

treevars={'Mean lumen area','Mean cell-wall thickness'};
treevs ={'LA','CWT'};
ktree = menu('What kind of cell-anatomy time series?',treevars);
if ktree~=1
    error('Coded so far only for mean lumen area')
end
treevar =treevars{ktree};
treev =treevs{ktree};

prompt = {'Enter tree-ring data files suffix:','Enter climate data file suffix:'};
title = 'Enter suffixes for input data ffiles';
dims = [1];
definput = {'mat','xlsx'};
answer = inputdlg(prompt,title,dims,definput);
ftype_tree=answer{1};
ftype_clim=answer{2};

% Get tree-ring file path, filename, and file type
tit1='Input file with cell-anatomy time series';
if strcmp(ftype_tree,'mat')
    ffilter={'*.mat'};
elseif strcmp(ftype_tree,'xlsx')
     ffilter={'*.xlsx';'*.xls'};
end
[file,path,indx]=uigetfile(ffilter,tit1,defname1);
pftree=fullfile(path,file);
filetree=file;



%---- Load tree-ring time series into T, yrT
if strcmp(ftype_tree,'xlsx') || strcmp(ftype_tree,'xls')
    error('Tree-ring data input so far coded for mat only')
elseif  strcmp(ftype_tree,'mat')
    eval(['load ' pftree  ';']);  % structure D.Chron
    T=D.Chron.X; yrT = D.Chron.yrX;
else
end


% Get climate-data file path, filename, and file type
tit1='Input file with day-windowed climate time series';
if strcmp(ftype_clim,'mat')
    ffilter={'*.mat'};
elseif strcmp(ftype_clim,'xlsx')
     ffilter={'*.xlsx','*.xls'};
end
[file,path,indx]=uigetfile(ffilter,tit1,defname2);
pfclim=fullfile(path,file);
fileclim=file;

%--- READ CLIMATE DATA FILE

if strcmp(ftype_clim,'xlsx') || strcmp(ftype_clim,'xls')
[A,B]=xlsread(pfclim);
elseif  strcmp(ftype_clim,'mat') 
    eval(['load ' pfclim ';']) % year vector, data matrix and cell of series labels, such as "SWC"
else
end

%---- SELECT CLIMATE VARIABLE

bheads =B(1,:);
bnms=bheads;
bnms(1:4)=[];
kpick1= menu('Choose climate variable',bnms);
xwant = bnms{kpick1}; % say, "SWC"

specs.datatype=[xwant];



%-----STORE DAILY CLIMATE TIME SERIES IN X

iwant = find(ismember(bheads,xwant));
X=A(:,[1 2 3 4 iwant]); % yr, month, day of month, day of yr, data value


%----- COMPUTE THE DAY-WINDOWED CLIMATE AND ASSOCIATED PLOTTING POINTS
%       FOR FIRST OF EACH MONTH ON EVENTUAL TIME PLOT THAT STARTS JAN 1 IN
%       NORTHERN HEMISPHERE AND JULY 1 IN SOUTHERN HEMISPHERE. THE FIRST
%       DAY WINDOW NEED NOT START IN JAN 1 OR JULY 1, BUT MUST START IN
%       SOME DAY OF JAN (NH) OR JULY (SH).


% Set up input for call to daygrp01

prompt = {'Enter seasonalizing method (''mean'' or ''sum''):',...
    'Enter hemisphere ("N" or "S"):',...
    'Enter number of days in window:',...
    'Specify ending month of last window:',...
    'Specify ending day of month of last window:',...
    'Specify correlation method:',...
    'Specify p-value for summary of number of significant correlations',...
    'Enter figure width and height as screen fraction:',...
    'Enter name of color map'};

title = 'Specification for windows and mapping';
dims = [1 ];
definput = {'mean','N','15','10','15','Spearman','0.05','[0.6 0.7]','parula'};
a = inputdlg(prompt,title,dims,definput);
datin.X=X;
specs.howseas=a{1};
specs.hemisphere=a{2};
specs.nday=str2num(a{3});
specs.endmo=str2num(a{4});
specs.endday=str2num(a{5});
specs.corrmeth=a{6};
specs.alphar=str2num(a{7});
fdims=str2num(a{8});
colmap=a{9};


%----- COMPUTE WINDOWED CLIMATE SERIES AND STORE SERIES FOR GIVEN ENDING
% DAY OF LAST WINDOW IN COL-CELL

%--- Input daily climate should start Jan 1 and end Dec 30 or 31
yr = X(:,1); mo = X(:,2); daymo=X(:,3); dyr=X(:,4);
L1=mo(1)==1 & dyr(1)==1 ;
L2=mo(end)==12 & (dyr(end)==365 || dyr(end)==366);
L3=L1 & L2;
if ~L3
    error('Input daily climate file must begin with Jan 1 of a year and end with Dec 31 of a year');
end

%--- Year coverage of daily climate data
yrgoC =min(yr); yrspC=max(yr);

%--- Get unique years in climate matrix and make sure increments by 1
yrX = unique(yr);
d = diff(yrX);
if ~all(d==1)
    errror('yrX of daily climate  does not increment by 1')
end


%--- Compute maximum possible analysis period for correlations with
% day-windowed climate; allow choice of shorter period

yrgo = max([yrX(1) yrT(1)]);
yrsp = min([yrX(end) yrT(end)]);
str_yrs1 =[num2str(yrgo) '-' num2str(yrsp)];

qanal = questdlg(['Accept default maximum possible analysis period of ' str_yrs1 '?']);
if strcmp(qanal,'Yes')
    ichange=false;
else
    yrgo1=yrgo; yrsp1=yrsp;
    kwh1=0;
    while kwh1==0
        prompt = {'First year','Last year'};
        title =['Specify analysis period (' str_yrs1 ')'];
        dims = [1 ];
        definput = {num2str(yrgo1),num2str(yrsp1)};
        a = inputdlg(prompt,title,dims,definput);
        options.Resize='on';
        yrgo2 = str2num(a{1});
        yrsp2 = str2num(a{2});
        if yrgo2<yrgo || yrsp2>yrsp
            h=warndlg('Specified years outside data coverage');
        else
            kwh1=1;
            yrgo=yrgo2;
            yrsp = yrsp2;
            ichange=true;
        end
    end
end


%---- ANNUAL TIME SERIES OF DAY-WINDOWED CLIMATE

dayend1=mdy2jdy(specs.endmo,specs.endday);
daycrit=dayend1+specs.nday;
if daycrit>365
    error([num2str(dayend1) ' too late in year to allow ' num2str(specs.nday) ' more days before Dec 31']);
end
dends =((dayend1:(dayend1+(specs.nday)-1)))';  % cv of ending days
nends = length(dends); % number of ending days of last window

G=cell(nends,1);
yrswant=[yrgo yrsp];
for n =1:nends
    dthis =dends(n);
    D=dayma1(X,dthis,specs.nday,specs.hemisphere, yrswant);
    G{n}=D;
end


%==== CORRELATION ANALYSIS 

[mT,nT]=size(T); % size annual tree-ring matrix
R1= nan(nends,nT); % highest positive correlation
R2=R1; % highest absolute negative correlation
R3=R1; % maximum number of  significant positive correlations
R4=R1; % maximum number of significant negative correlations

% specs.alphar

for n =1:nends % loop over the various ending days of last window(want sensitivity to this)
    dendthis =dends(n);
    Y = G{n}.Y;
    [R,P]=corr(T,Y,'type',specs.corrmeth);
    
    % max positive correlation
    a= max(R');
    R1(n,:)=a;
    
    % max absolute negative correlation
    Rtemp=R;
    L=Rtemp>0;
    Rtemp(L)=0;
    Rtemp=abs(Rtemp);
    a=max(Rtemp');
    R2(n,:)=a;
    
    % maximum number of significant positive correlations
    Lp = R>0;
    Ls = P<specs.alphar;
    L3=Lp & Ls;
    ksum = sum(L3');
    R3(n,:)=ksum;
    
    % maximum number of significant negative correlations
    Ln = R<0;
    Ls = P<specs.alphar;
    L4=Ln & Ls;
    ksum = sum(L4');
    R4(n,:)=ksum;
    
end


%----- FIGURE WINDOWS

nwindow=length(D.dend);
nday=specs.nday;
% Super titles
strinf1={'Sensitivity of tree-ring vs daily-climate correlation ',...
    'to shift in alignment of non-overlapped climate windows',...
    ' ',...
    ['Run of function trach02 on ' datestr(date)],...
    [treevar ' vs ' xwant ' in non-overlapping ' num2str(nday) '-day windows'],...
    ['Analysis period: ' num2str(yrgo) '-' num2str(yrsp)],...
    ['Tree rings from ' filetree],...
    ['Climate from ' fileclim],...
    ['Total of ' num2str(nwindow) ' windows'],...
    ['   earliest ending in day-of-year ' num2str(D.dend(1))],...
    ['   latest ending in day-of-year ' num2str(D.dend(end))]};


x=dends; % cv
xlims=[min(x)-1   max(x)+1];
ylims1=[0 1];
m=specs.nday;

ylims1=[0 1];

ylims2=max([1+max(max(R4)) 1+max(max(R3))]);
ylims2=max([ylims2 5]);
ylims2=[0 ylims2];

for k=1:nT
    
    strQ=[treev 'quantile ' num2str(k) '/' num2str(nT)];
    
    r1 =R1(:,k);
    [q1,iq1]=max(r1);
    r2 =R2(:,k);
    [q2,iq2]=max(r2);
    r3 =R3(:,k);
    [q3,iq3]=max(r3);
    r4 =R4(:,k);
    [q4,iq4]=max(r4);
    
    rng1=['  Range +r: ' num2str(min(r1),'%5.2f') ' to ' num2str(max(r1),'%5.2f')];
    rng2=['  Range 1r: ' num2str(min(r2),'%5.2f') ' to ' num2str(max(r2),'%5.2f')];
    strQ={strQ,rng1,rng2};
    
    
    figure(k)
    [cL,cB,cW,cH]=figsize(fdims(1),fdims(2));
    set(gcf,'Position',[cL cB cW cH]);
    
    subplot(2,1,1)
    h=plot(x,r1,'-o',x,r2,'-^');
    set(gca,'YLim',ylims1)
    set(gca,'XLim',xlims)
    xlabel(['Ending day-of-year of last ' num2str(nday) '-day window']);
    ylabel([specs.corrmeth ' r'])
    hleg=legend('+r','-r');
    hax =gca;
    hax.Title.String=['Maximum correlation in any of the ' num2str(nwindow) ' total windows'];
    textcorn(strQ,'UL',0.02,0.02,10)
    
    hline1=line([x(iq1) x(iq1)],ylims1);
    hline1.Color=h(1).Color;
    hline2=line([x(iq2) x(iq2)],ylims1);
    hline2.Color=h(2).Color;
    hleg.String(3:4)=[];    
    
    
    subplot(2,1,2)
    h=plot(x,r3,'-o',x,r4,'-^');
    set(gca,'YLim',ylims2)
    set(gca,'XLim',xlims)
    xlabel(['Ending day-of-year of last ' num2str(nday) '-dat window']);
    ylabel('N')
    hleg=legend('+r','-r');
     strb=['Maximum number of significant (p<' num2str(specs.alphar,'%5.2f') ') correlations in any window'];
    hax =gca;
    hax.Title.String=strb;
    
    hline3=line([x(iq3) x(iq3)],ylims2);
    hline3.Color=h(1).Color;
    hline4=line([x(iq4) x(iq4)],ylims2);
    hline4.Color=h(2).Color;
    hleg.String(3:4)=[];    
    
    if strcmp(qskip,'Yes')
    else
        fout=['Fig' num2str(k) '_' dstamp];
        pf=fullfile(pathcurr,fout);
        print(pf,'-dpng')
    end
end

Result.summary=char(strinf1);
if strcmp(qskip,'Yes')
else
    fout=['Summary_' dstamp '.txt'];
    pf=fullfile(pathcurr,fout);
    fid = fopen(pf,'w');
    S=Result.summary;
    [mS,nS]=size(S);
    fmt1 =['%' num2str(nS) 's\n'];
    for n =1:mS
        s =S(n,:);
        fprintf(fid,fmt1,s);
    end
    fclose (fid)
end


end
