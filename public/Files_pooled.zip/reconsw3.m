function Result=reconsw3(X,yrX,y,yry,specs,specsSim)
% reconsw3: stepwise reconstruction using split-sample validation to choose final step
% Result=reconsw1(X,yrX,y,yry,specs,specsSim);
% Last revised 2019-08-26
%
% Stepwise reconstruction using split-sample validation to choose final step.
% The specified full calibration period 
%
% Model optionally handles lags on predictors. This is a sister function to
% reconsw1, which used cross-validation instead of split-sample validation
% to choose the appropriate number of steps for the final model. A model is
% fit stepwise to the first half of data and at each step is validated on
% the second half of the data. Then the process is reversed. Root mean
% square erro of validation (RMSEv) will reach a minimum a step j1 for
% validation on the second half, and at step j2 for validation on the first
% half. The final selected step is the minimum of j1 and j2. After the
% validation exercise, a final model is fit stepwise to the full period
% (first and second halves) and the model is stopped at the selected step. 
%
%*** INPUT
%
% X (mX x nX)r  predictors-- matrix or vector time series of predictors
% yrX (mX x 1)i year vector for X
% y (my x 1)r  predictand; or for site-centered recons, a matrix (my x ny)
% yry (my x 1)i year vector for y
% specs = structure of specifications
%   .pin for entry in stepwise (see notes for special case)
%   .pout for removal in stepwise (see notes for special case)
%   .nlag: maximum negative lag on predictors 
%   .plag: maximum positive lag allowed on predictors
%   .CalYrs (1x2)i or []:   a specified first and last year (on y) of full 
%      calibration period; if [], function will use longest possible calib  period
%   .klong (1x1)i if full calibration period is odd number of
%       observations, tells which should be the longer "half"
%           klong==1: larger number of observations (by 1) is first half
%           klong==2: larger number of observations (by 1) is second half
%   .LRA (1x2)L : analysis of residuals on final model
%       (1) true==do it;   false=skip it
%       (2) true==do graphics (slower); false=skip graphics [this option
%       meaningless if LRA(1) true
% SpecsSim: specifications for call to pdgmsim
%  .nsim (1x1)i number of simulations (e.g., 1000)
%  .mtaper (1x1)r  decimal fractional total of series to be tapered (e.g.,
%        0.10, which means 5% on front and 5% on back
%  .kopt(1x2)i options
%       (1) force sims to have same mean and standard deviation as the
%               observed series
%           ==1 yes;  ==2 no
%       (2)  turn off the msgbox warning about failing Lilliefors
%           ==1 yes;  ==2 no (default if length(kopt)==1)
%  .len (1x1)i  or []. desired length of simulations; or, if [], same
%           length as the observed series
%
%*** OUTPUT --- structure Result, with fields
%
% .yh, yryh: reconstruction of y
% .RMSEstep1: (? x 3)r    step, RMSEv, and RE for calibration on early and
%       validation on late
% .RMSEstep2: (? x 3)r    step, RMSEv, and RE for calibration on late and
%       validation on early
% .StepSelected (1x1)i  step selected for final model
% .inmodel: logical indicator to cols of the lagged predictor mtx included
%       in final model
% .Loser: logical indicator that had to override stepwise and assign single
%   highest correlated predictor as the the single predictor 
% .LoserWhy (1x1)i why a loser?
%       ==1 no predictor entered in at least one of the split sample
%           calibrations
%       ==2 some predictor(s) entered, but in validation none of the possible
%           models had RE>0 for both validation halves
% .statsc: structure of calibration stats, with fields:
%    yrgo: start year of calib (keyed to y)
%    yrsp: end year of calib
%    R2: R-squared
%    R2a: adjusted R-squared
%    pF: p-value of overall F of regression
%    RMSE
%    MAE median absolute error of calibration
%    pDW: p-value of Durbin Watson statistic
% .statsv: structure of validation statistics, with following fields:
%     yhv, yryh:  calibration period predictions from split-sample validation
%     D -- time series of predictand; columns are :
%       1 observed 
%       2 predictions from model calibrated on full period
%       3 predictions for period A from model calibrated on A
%       4 predictions for period B from model calibrated on A
%       5 predictions for period B from model calibrated on B
%       6 predictions for period A from model calibrated on B
%     yrD - year vector for D
%     rmse -- root mean square error. Col 1 is for calibration columnn 2 for validation
%       row 1: for full-period model (col 2 is NaN because full model not validated
%       row 2: for calibration on period A and validation on period B
%       row 3: for calibration on period B and validation on period A
%     R2RE -- R-squared of calibration (col 1) and RE of validation (col 2)
%       row 1: for full-period model (col 2 is NaN because full model not validated
%       row 2: for calibration on period A and validation on period B
%       row 3: for calibration on period B and validation on period A
%     splits: 3 x 2 matrix giving start and end years of :
%       row 1: full period
%       row 2: split-period A
%       row 3: split-period A
% .resids (?x3)r
%   1 year
%   2 calib -- observed minus predicted y, for full model 
%   3 validation (split sample). For each year in the first half of data,
%      the residual is from prediction by model fit to the second half of
%      data, and vice versa. These residuals from split samples predictions
%      based on the same predictors, but calibrated on different halves of
%      the full calibation record
%
%
%*** REFERENCES
%
% Percival, D.B., and Constantine, W.L.B., 2006. Exact simulation of 
% Gaussian time series from nonparametric spectral estimates with 
% application to bootstrapping. Statistics and Computing, 16: 25-35.
%
%*** UW FUNCTIONS CALLED
%
% corrone --correlation by theoretical method
% corrts2 --- correlation testing by Monte Carlo exact simulation
% lagyr3 -- build lagged predictor matrix
% recv -- reduction of error statistic
% residck2  --- analysis of regression residuals
%
%*** TOOLBOXES NEEDED
%
% statistics
%
%*** NOTES
%
% X, yrX, y, yry: these input series must overlap by at least 30 observation, which
%   is way too lenient. There can be leading or trailing NaNs. Whether or
%   not you use lagged predictors, do NOT put the lagged predictors in X.
%   Function reconsw1 builds the lagged predictor matrix.
%
% nlag, plag: these should both be input as positive integers, and will determine "mout" for
% leave-mout-crossvalidation: mout = 1+2m,  where m is the sum of nlag and
% plag.  Thus, if specify lags -2 through +2:  nlag=2, plag=2 and mout=9.
% nlag us the number of negative lags on the predictors; plag is the number
% of positive lags.  For example, if nlag==0 and plag==0, no lags are used.
% If nlag==1 and plag==1, y(t) is regressed on x(t), x(t-1) and x(t+1)
%
% Specs.Sim.  These inputs are for the Monte Carlo test of significance of
% the correlation of observed predictand with the validation
% predictsions. The simulations are done by "exact" simulation (Percival
% and Constantine (2006).  This method is used mainly to handle possibly
% autocorrelated predictand. 
%
% Choice of final step for model.  Split-sample validation here serves the purpose
% of selecting how many steps the final regression model should be run to
% in stepwise regression. Validation root mean square error (RMSEv) will
% vary with regression step, such that a minimum is reached at some step
% when model is fit to first half and validated on second half, and another
% minimum is reached at some step when model is fit to the second half and
% validated on the first half. The earliest step the minimum RMSEv is
% reached in either half is the final selected step for the reconstruction
% model. 


% UNLOAD INPUT SPECS

nlag=specs.nlag; plag=specs.plag;
pin = specs.pin; pout=specs.pout;
LRA = specs.LRA; % (1x2)L   see input
CalYrs=specs.CalYrs;
klong=specs.klong;
[mX,nX]=size(X);
maxsteps=(1+plag+nlag)*nX; % maximum possible number of predictors in final model

% INITIAL STEPWISE TO CHOOSE CUTOFF STEP

% Build lagged predictor mtx, including lags -nlag to +plag on predictors
% 
% If there are m predictors (before lagging), the first m columns of U1
% will hold the unlagged predictors. Remaining cols will hold the negative
% lags, and then the positive lags. For both negative and positive lags the
% order of columns is increasing lat.
yrs=[yrX(1) yrX(end)];
[U1,yrsU1]=lagyr3(X,yrs,[0 nlag plag]);
yrU1 = (yrsU1(1,1):yrsU1(1,2))';

% Pull the part of U1 with no anyNaN rows
igo = yrsU1(3,1);
isp = yrsU1(3,2);
U = U1(igo:isp,:);
yrU = yrU1(igo:isp);

% check time step of predictor matrix
i1 = diff(yrU);
if ~all(i1==1)
    error('yrU not inc by 1')
end
clear igo isp

% Get calibration period data for the lagged predictior matrix and the
% predictand
%
% Have long mtx, with no anynan rows, as U, yru;
v=y; yrv=yry;
yrgoc = max([yrv(1) yrU(1)]);
yrspc = min([yrv(end) yrU(end)]);

% Optionally shorten the full calibration period
if isempty(CalYrs)
else
    if CalYrs(1)<yrgoc
        error(['Cannot set CalYrs(1) earlier than ' num2str(yrgoc)])
    end
    if CalYrs(2)>yrspc
        error(['Cannot set CalYrs(2) later than ' num2str(yrspc)])
    end
    yrgoc = CalYrs(1);
    yrspc = CalYrs(2);
end
Result.statsc.yrgo=yrgoc;
Result.statsc.yrsp=yrspc;

L = yrv>=yrgoc & yrv<=yrspc;
vc= v(L);
yrvc=yrv(L);
L = yrU>=yrgoc & yrU<=yrspc;
Uc= U(L,:);
yrUc=yrU(L);
nyrc = length(vc);

%-- find highest correlated predictor, in case stepwise picks none
r = corrone(vc,Uc);
[a,ia]=max(abs(r));
Lnull= false(1,size(Uc,2));
Lnull(ia)=true;
clear r a ia;


%---- SET PERIOD FOR SPLIT-SAMPLE VALIDATION

if rem(nyrc,2)==1
    if klong==1
        n1=ceil(nyrc/2);
        n2=nyrc-n1;
    elseif klong==2
        n2=ceil(nyrc/2);
        n1=nyrc-n1;
    end
else
    n1 =nyrc/2;
    n2=n1;
end
if nyrc~=(n1+n2)
    error('nyrc must equal sum of n1 and n2')
end
% start and end years of the split sample periods
yrgo1 = yrgoc;
yrsp2= yrspc;
yrsp1 = yrgo1+n1-1;
yrgo2=yrsp1+1;


%---- allocate cells to hold split-sample validation errors and errors for
% corresponding null models 

% Storage for split-sample validation residuals. E1 will hold these. The
% first n1 members of E1 will be residual for early years based on
% prediction from model fit to late years. The last n2 members of E1 will
% be residuals for late years based on prediction from model fit to early
% years.
E1 = nan(nyrc,maxsteps); % to hold cross-validation errors; cols are steps in model
m1 = nan(1,2); % to hold calibration-period means of predictand for early (1) and late (2 halves
E2 = nan(nyrc,maxsteps); % to hold errors, null models. These are validation residuals when
% the calibration-period mean is used as a predictor  
Yh=nan(nyrc,maxsteps); % to cv estimates
yrYh = (yrgoc:yrspc)';
Result.Loser=false; % will turn on if any of these conditions: 1) no predictors enter in at least one of the 
% split-sample calibrations; 2) a variable entered, but RE not positive for at least one of the
% split-sample validations
Result.LoserWhy = 0; % if non-zero, why a loser (1==no predictor entered in calib, 2==at least one of 
% the REs for selected model is non-positive
 
RMSEstep1=nan(maxsteps,3); %step, RMSEv, and RE for calibration on early and
%       validation on late
RMSEstep2=nan(maxsteps,3); %step, RMSEv, and RE for calibration on late and
%       validation on early


%--- CALL subfun03 FOR INITIAL SPLIT-SAMPLE CALIBRATION-VALIDATION

T=[yrgo1 yrsp1; yrgo2 yrsp2]; %  start and end years of the split sample

%  First for calib on early and validation on late
jsplit=1; % calib on early, validate on late
Rss = subfun03(Uc, yrUc,vc,yrvc,T,jsplit,pin,pout,Lnull,Yh);
Yh=Rss.Yh;
if Rss.Loser
    Result.Loser =true;
    Result.Loserwhy =1;
end

%  Second for calib on late and validation on early
jsplit=2; % calib on early, validate on late
Rss = subfun03(Uc, yrUc,vc,yrvc,T,jsplit,pin,pout,Lnull,Yh);
Yh=Rss.Yh;
if Rss.Loser
    if ~Result.Loser
        Result.Loser =true;
        Result.Loserwhy =1;
    else
    end
end


%---- SELECT THE FINAL STEP FOR STEPWISE
%
% Know that Yh has validation predictions in columns. Col 1 is for stepwise
% with one step, col 2 for stepwise with 2 steps, etc. If only the first
% col is without NaNs, then one step is the final step. Otherwise, check
% that succeeding steps yield positive RE on both halves, and a decrease in
% RMSEv on both halves.

L= ~any(isnan(Yh));
if ~any(L)
    ihigh=1;
    Yh = nan(nyrc,1);
else
    ihigh = max(find(L));
end

%Trim some matrices
Yh = Yh(:,1:ihigh);

if ~Result.Loser
    Rv=subfun05(Yh,yrYh,y,yry,T); % Compute split-period RMSEv and RE for each step
    Result.RMSEstep1 = Rv.RMSEstep1;
    Result.RMSEstep2 = Rv.RMSEstep2;
    
    % Select final step as step preceding the first increase in RMSEv on either half, or non-positive
    % RE on either half of the split-sample validation.
    % On other hand, if only one step, no need to look at RMSEv
    if ihigh==1
        Result.StepSelected=1;
        RE1 = Result.RMSEstep1(1,3);
        RE2 = Result.RMSEstep1(1,3);
        if ~(RE1>0 && RE2>0)
            Result.Loser=true;
            Result.LoserWhy=2;
        end
       
    else
        RMSE1 = Result.RMSEstep1(:,2);
        RMSE2 = Result.RMSEstep2(:,2);
        
        RE1 = Result.RMSEstep1(:,3);
        RE2 = Result.RMSEstep2(:,3);
        d1=diff(RMSE1);
        d2=diff(RMSE2);
        Ld = d1>=0 | d2>=0; % if RMSEv increased in either half
        Lp = RE1(2:end)<=0 |  RE2(2:end)<=0; % if RE in either half is not positive
        L3 = Ld  | Lp;
        if ~any(L3)
            Result.StepSelected=ihigh;
        else
            i1 = find(L3);
            Result.StepSelected=i1;
        end
        
    end
else
    Result.StepSelected=1;
end


% STEPWISE TO GET PREDICTORS FOR FINAL MODEL
%
% Recall: Result.Loser and Result.LoserWhy mark special treatment series. 
% Up till now you have used split-sample validation to find the step to
% stop stepwise at. If a Loser, regardless of why, you will not run
% stepwise to select the predictors, but will set the single predictor as
% that highest correlated with the predictand over the full calibraiton
% period. Also, if not a loser but with Result.StepSelected==1, can also
% use that approach, as would identify the same predictor as stepwise.
% 
% For Result.StepSelected>1, must run stepwise to see which predictors
% enter in calibration on full period
%
if Result.Loser || Result.StepSelected==1
    L = false(1,4);
    r=corrone(vc,Uc);
    rabs=abs(r)
    [s,ia]=sort(rabs,'descend')
    icol1 = ia(1); % will use Uc(:,icol1) as the single predictor for regstats; will skip stepwise
    L(icol1)=true;
    inmod1=L;
    Result.inmod1=inmod1;
    clear L r rabs s ia icol1
else
    [b,se,pval,inmod1,stats,nextstep,history]=stepwisefit(Uc,vc,'penter',pin,...
        'premove',pout,'display','off','maxiter',Result.StepSelected,...
        'scale','off');
    Result.inmodel=inmod1;
end


%----- CALIBRATE OR RE-CALIBRATE SELECTED MODEL ON FULL CALIBRATION PERIOD 

% store the long predictor subset to be used for recon
Xlong=[ones(length(yrU),1) U(:,inmod1)];
yrXlong = yrU;

% Regression

Xc =  Uc(:,inmod1);
yrXc=yrvc;
skey = regstats(vc,Xc) ;
Result.statsc.R2 = skey.rsquare;
Result.statsc.R2a = skey.adjrsquare;
Result.statsc.pF =skey.fstat.pval;
Result.statsc.RMSE =sqrt(skey.mse);
Result.statsc.MAE = median(abs(skey.r));
Result.statsc.pDW = skey.dwstat.pval;

Result.resids =nan(length(vc),3);
Result.resids(:,1)=yrvc;
Result.resids(:,2)=skey.r;

beta1=skey.beta;


%--- ANALYSIS OF RESIDUALS

if LRA(1)
    if LRA(2)
        kra=2;
        fclose all
    else
        kra=1;
    end
    ResultAR = residck2 (vc,skey.yhat,yrvc,sum(inmod1),'series',kra);
else
    ResultAR=[];
end

% figure(1)
% h = plot(yrvc,vc,'-o',yrvc,skey.yhat,'-^');
% legend('Observed','Reconstructed')



%--- TEMPORAL STABILITY OF SELECTED MODEL (FIRST HALF VS SECOND HALF)
%
% Split-sample calibration-validation is done using the selected model
% (identified predictors from earlier steps). Positive RE on both halves of
% calibration is some evidence for stability. Note that this exercise is
% NOT necessarily the same as the earlier split-sample calibration
% validation used to select the final number of steps for the stepwise
% reconstruction model. In that earlier split-sample analyis, the
% calibraiton on separate halves could conceivably pointed to different
% sets of predictors, and those different sets would be used for the
% validation. 

% Set up input arguments for recsplit1
datin.X = Uc; % tsm of calib predictor pool
datin.yrX=yrUc; %   .yrX (mX x 1)i year vector for X
datin.y = vc; % cv of calib period predictand
datin.yry = yrvc;
datin.yrsplit= [T(1,1)  T(2,2); T];
datin.inmodel = inmod1;
datin.jFig1=6;

[mUc,nUc]=size(Uc);
j = (1:nUc)';
sj = num2str(j);
datin.Xlab=cellstr(sj)';
datin.kopt=2;
Result.statsv=recsplit1(datin); % structure: see recsplit1 comments for definition of fields

%---- GENERATE THE VALIDATION RESIDUALS FROM FITS AND OBSERVED
%
% The residuals are in cols 4 and 6 of Result.statsv.D
a = Result.statsv.D(:,4);
L1 = isnan(a);
L2 = ~isnan(Result.statsv.D(:,6));
if sum(L1)~=sum(L2)
    error('miss-match in residuals')
end
a(L1)=Result.statsv.D(L2,6);
Result.statsv.yhv= a; % validation predictions
Result.statsv.yryhv= yrvc;
Result.resids(:,3)=Result.statsv.D(:,1)-a;
clear a L1 L2 

%--- CORRELATION OF OBSERVED Y WITH VALIDATION RESIDUALS
% Monte-Carlo based one-tailed significance of correlation of predicted
% with observed predictand 
kdir=1; % one tailed test
kopt_corr=1; % interested in positive correlaton
[r,pvalue]=corrts2(vc,Result.statsv.yhv,kopt_corr,kdir,specsSim);
Result.statsv.r=r;
Result.statsv.p=pvalue;
clear pvalue r 


%--- RECONSTRUCTION

Result.yh = Xlong*beta1;
Result.yryh= yrXlong;

% figure(1)
% h = plot(Result.yryh,Result.yh, yrvc,skey.yhat,'-^');
% legend('Observed','Reconstructed')

end


%---- SUBFUNCTIONS


function D=subfun01(X)
% mean square and RMS for cols of a tsm
% cols may contain some NaN
% Also returns the number and fraction of observations non-NaN

[mX,nX]=size(X);
A = X .*X; % each element square

L = ~isnan(A);
n1 = sum(L); % number of non-NaN values in each column of X
f1 = n1 / mX; % decimal proportion of obs with a value, f

a=nansum(A); % sum of all non-nan in cols of A
ms = (a ./ n1); % cv of mean square
rms = sqrt(ms);  % cv of root mean square

D.sos=a;
D.rms = rms;
D.ms = ms;
D.f1 = f1;
D.n1 =n1;
end


function ypred=subfun02(Uc,k,stats,b,inmod1)
% left-out predictions
H = [1 Uc(k,inmod1)];
bthis =[stats.intercept;  b(inmod1)];
ypred = H*bthis;
end


function Rss = subfun03(X, yrX,y,yry,T,jsplit,pin,pout,Lnull,Yh)
% Split-sample validation to select final step (m) for stepwise on full sample.
% Require 1) both calibration splits to allow at m predictors in final
% model, 2) validation RMSEv has not increased yet (up through step m) for
% either model. If either split has no predictors enter for the given pin
% and pout, indicate that just use the predictor with highest correlation
% with predictand for full period, and flag this problem. Likewise if
% neither split gives as positive RE for any step. 
%
% X: tsm of pool of predictors; yrX: year vector
% y: cv of predictand; yry: year vector
% T (2x2): row 1: start and end years of early "half"
%                 row 2: start and end years of late "half"
% jsplit: ==1 calib on early validate on late;==2 reverse
% pin, pout: p-value for entry and removal in stepwise
% Lnull: (1x?)L   which predictor should be used if none enter in stepwise
% Yh: tsm to hold validation predictions

Loser=false;
if jsplit==1
    yrgoc =T(1,1); yrspc=T(1,2);
    yrgov=T(2,1); yrspv=T(2,2);
else
    yrgov =T(1,1); yrspv=T(1,2);
    yrgoc=T(2,1); yrspc=T(2,2);
end
Lv = yrX>=yrgov & yrX<=yrspv;

L = yry>=yrgoc & yry<=yrspc;
z = y(L);
L = yrX>=yrgoc & yrX<=yrspc;
W = X(L,:);
npool = size(W,2); % size of predictor pool 

for m =1:npool
    [b,se,pval,inmod1,stats,nextstep,history]=stepwisefit(W,z,'penter',pin,...
        'premove',pout,'display','off','maxiter',m,'scale','off');
    
    if m==1 && sum(inmod1)==0
        Yh(Lv,m)=NaN;
        Loser=true;
        break
    elseif m>1 && (all(inmod1==inmod1_prev))
        Yh(:,m)=NaN;
    else
        % left-out predictions for model at this step
        ypred=subfun04(X,yrX,T,jsplit,stats,b,inmod1);
        Yh(Lv,m)=ypred;
        inmod1_prev=inmod1;
    end
end
Rss.Yh=Yh;
Rss.Loser=Loser;
end

function ypred=subfun04(X,yrX,T,jsplit,stats,b,inmod1)
% split-sample validation predictions
if jsplit==1
    yrgo =T(2,1); yrsp = T(2,2);
else
    yrgo =T(1,1); yrsp = T(1,2);
end
L = yrX>=yrgo & yrX<=yrsp;
mH = (yrsp-yrgo+1); % length of validation segment
H = [ones(mH,1)  X(L,inmod1)];
bthis =[stats.intercept;  b(inmod1)];
ypred = H*bthis;
end

function Rv=subfun05(Yh,yrYh,y,yry,T)
% Compute RE and  RMSEv with each step of stepwise.

[mYh,nYh]=size(Yh);
Rv.E1= nan(mYh,nYh); % for cv residuals
Rv.E2 = Rv.E1; % residuals by prediction with mean of calib period

%------   Calibration on early, valid on late

yrgoc =T(1,1); yrspc = T(1,2);
yrgov =T(2,1); yrspv = T(2,2);
L= yry>=yrgoc & yry<=yrspc;
meanc = mean(y(L)); % calibration mean of predictand

L = yrYh>=yrgov & yrYh<=yrspv;
n = sum(L);
mean_null = repmat(meanc,n,nYh); % null predictions for late half
L1=yry>=yrgov & yry<=yrspv;
ysub = y(L1); % observed predictand, last half
Ysub = repmat(ysub,1,nYh);
E1s = Ysub-Yh(L,:); % validation residuals -- 
E2s = Ysub-mean_null; % null-model residuals
Rv.E1(L,:)=E1s;
Rv.E2(L,:)=E2s;

nsteps =nYh;
R = nan(nsteps,3) ; % for step, RMSEv, RE
j = (1:nsteps)';
R(:,1)=j; clear j;
D=subfun01(E1s); % structure with fields, including RMS
R(:,2)=(D.rms)';
sos1 = (D.sos)'; % cv

% RE
Dnull = subfun01(E2s);
sos2 =(Dnull.sos)'; % cv
RE= 1 - (sos1 ./ sos2);
R(:,3)=RE;

Rv.RMSEstep1=R;
clear R RE sos1 sos2 Dnull D j 


%------   Calibration on late, validation on early

yrgoc =T(2,1); yrspc = T(2,2);
yrgov =T(1,1); yrspv = T(1,2);
L= yry>=yrgoc & yry<=yrspc;
meanc = mean(y(L)); % calibration mean of predictand

L = yrYh>=yrgov & yrYh<=yrspv;
n = sum(L);
mean_null = repmat(meanc,n,nYh); % null predictions for early half
L1=yry>=yrgov & yry<=yrspv;
ysub = y(L1); % observed predictand, early half
Ysub = repmat(ysub,1,nYh);
E1s = Ysub-Yh(L,:); % validation residuals -- 
E2s = Ysub-mean_null; % null-model residuals
Rv.E1(L,:)=E1s;
Rv.E2(L,:)=E2s;

nsteps =nYh;
R = nan(nsteps,3) ; % for step, RMSEv, RE
j = (1:nsteps)';
R(:,1)=j; clear j;
D=subfun01(E1s); % structure with fields, including RMS
R(:,2)=(D.rms)';
sos1 = (D.sos)'; % cv

% RE
Dnull = subfun01(E2s);
sos2 =(Dnull.sos)'; % cv
RE= 1 - (sos1 ./ sos2);
R(:,3)=RE;

Rv.RMSEstep2=R;
end