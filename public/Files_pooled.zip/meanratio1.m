function D=meanratio1(X,yrX,m,kopt,maxser)
% meanratio1(X,yrX,m,kopt)
% meanratio1:  fill internal missing values in seasonal or annual multi-station tsm of climate data by mean ratio
% Last revised: 2019-12-29
%
% Fill internal missing values  an seasonal or annual multi-station tsm of climate data by mean ratio.
% Starts with tsm of say, precipitation (P) for a given season (say,
% summer) at several stations.  Fills in missing values at key station
% using mean-ratio estimation from other stations that do have data in that
% year.
%
%
%*** IN
%
% X (mX x nX)r  annual or seasonal climate variable for mX years at nX stations
% yrX (mX x 1)i   year vector for X
% m (1 x 1)i  mimimum acceptable number of years for comptation of mean ratios
% kopt (1x1)i options 
%   kopt(1): fill in whole series or just internal missing values
%       ==1 whole series
%       ==2 internal missing values only
%
%*** OUT
%
% D  structure of results, with fields:
%    X, yrX: original climate data, inches
%    Y, yrY:  filled-in version of X, yrX
%    N:   (same size as Y) model number (see row of Lmodel,Imodel) used for estimation
%    N1:   number of stations for each estimation
%    N2:  number of years for mean ratios for the estimation
%    Lmodel{? x 1}L row of Lmodel{i} is pointer to other cols of X used for model for
%       estimation of value in ith col
%    Imodel{? x 1)i  ith row of Imodel{k} holds col number in X of
%       predictors for ith model use in prediction for station in col k of X
%   maxser: average the mean ratio over up to this many predictor series.
%
%
%*******************  NOTES ****************************
%
% Estimates missing value at station from the mean-ratio of
% common-period means at all other stations with data for the missing-value
% year. Uses one or more stations for the estimates. Averages the mean
% ratio over predictor stations and applies that to estimate. 
%
% Priority given to series with longest overlap of data present at target
% station. Average mean ratio (over subset of stations) is used for
% estimate. Different subsets of predictor stations may be used for
% different years requiring estimates.
%
% Predictor stations must have data in the key year (when missing at target
% series. Predictor station must have minimum specfied number of years with
% overlap of target station to be accepted for mean-ratio computation
%
% Assume data is in matrix X, each column a variable, each row a year.
% Assume y is the target station needing estimates. 
% Loop over the target cols, left to right, filling in missing values
% - identify missing-data observations
% - identify unique patterns of missing/present data at other stns in that
%   year subset; these define the initial "models" for estimation. Know
%   that subset of stations will also suffice
% - Loop over the model subsets
%       -Find station in X with longest overlap with y
%       -Check that overlap sufficient, and define new overlap period as
%       that overlap
%       -Check which remaining station has greatest overlap with the new
%       overlap
%       -Keep doing the above, until overlap falls below specified
%       threshold, all series are used, or number of stations used exceeds
%       specified threshold.
%       -Compute mean ratios as the ratio of means of y and the selected
%       members of X for their individual common periods
%       -Estimate missing values using the average mean ratio of the
%       predictors for the year needed
%   end loop
% end loop
%
% Priority for estimation in any given year given to the predictor subset
% with longest overlap with target station
%
% Program bombs with error message if any model does not have at least m
% years of overlap for computing the normals.
%   
% FUTURE POSSIBLE EXTENSIONS
%
% Use Spearman correlation instead of length of overlap as criterion for
% selection of predictor series
%
% 



[mX,nX]=size(X);

% Allocate
yrY = yrX;
Y = X;
N = nan(mX,nX); % model number
N1=nan(mX,nX);
M=nan(mX,nX);
N2=nan(mX,nX);
N3=nan(mX,nX);

Lmodel = cell(nX,1); % to store col numbers of models used for estimation for each station
Imodel = Lmodel;
jall = (1:nX);

for j = 1:nX % loop over stations
    jthis = jall;
    jthis(j)=[];
    z = X(:,j); % cv of target stn
    Z=X;
    Z(:,j)=[];   % submatrix of other stns
    [mZ,nZ]=size(Z);
    if kopt(1)==1
        L1 = isnan(z); % mark missing values in z
    else
        L1 = intnan2(z); % mark internal missing values in z
    end
    nmiss = sum(L1);
    if nmiss==0
        Y(:,j)=z;
        Lmodel{j}=[];
    else
        zzhat = nan(nmiss,1); % will hold the estimated values for this station  (could restore as z(L1)=zzhat)
        nn = zzhat;
        nn1=zzhat;
        nn2=zzhat;
        
        W = Z(L1,:); % submatrix of predictors Z for years needing estimation
        [mW,nW]=size(W);
        L2 = ~isnan(W); % true if a non-key series has data in year  of  missing-data block at key
        
        % Function call to trim models to include only those subsets of
        % predictor series with sufficient specified coverage for
        % mean-ratio computation. Also to re-order models so that priority
        % (first) has the most possible predictors
        [Lmod,Imod]=subfun01(Z,z,m,L1,maxser);
        Lmodel{j}=Lmod;
        Imodel{j}=Imod;
              
        nmods=size(Lmod,1);
        for k = 1:nmods % loop over unique models to fill in
            Lthis=Lmodel{j}(k,:);
            npreds = sum(Lthis);
            %%%Imodel{j}(k,1:npreds)=jthis(Lthis); % which predictors, as cols of X
            
            L4= repmat(Lthis,mW,1); % logical row to predictors duped to row-size of missing year block
            L5=L4 & L2; % for missing-data years , true if series a member of model, and has data
            L6 =  ismember(L5,Lthis,'rows');  % marks rows of W that have predictor data for all predictors in models                      
            % Find years of X that can be used for "normals" (must have data
            % at key station and at the predictors
            Q = Z(:,Lthis);
            L7 = ~isnan(Q);
            if npreds>1
                L8 =     (all(L7'))'; % for master matrix, true if year with data for all predictors
            else
                L8=L7;
            end
            L9 = ~isnan(z) & L8;
            nyears = sum(L9); % number of years available for normals
            if nyears <m
                str_err1 = {['Series #' num2str(j) ': has block of ' num2str(mW) ' years with missing data code.'],...
                    'For computation of mean-ratio, at least one other series must completely cover those years.',...
                    ['Complete coverage is provided for  ' num2str(nyears) ' of that block of years'],...
                    ['Your setting also require that the the target series and set of predictors have'],...
                    ['at least ' num2str(m)  ' years of joint coverage to compute mean ratios']};
                 uiwait(msgbox(str_err1,'Error: str_err1','modal'));
                error(['Only ' num2str(nyears) ' years available for normals for series ' num2str(j)])
            else
            end
            
            % Compute common-period means for target series and predictor series
            a=z(L9);  
            A = Q(L9,:);
            mn_key = mean(a); % scalar
            mn_others=mean(A); % rv or scalar
            
            fact1 = repmat(mn_key,1,npreds) ./ mn_others; % ratios of mean of target to mean(s) of predictors
            P =W(L6,Lthis); % Pull prediction-needed-year submatrix of predictors for this model
            zhat = (P * fact1')/npreds; % estimates for key station for rows L6 of W
            
            % If needed, mask zhat to avoid over-writing already estimated
            % data by a model with more predictors
            znull = nan(nmiss,1);
            znull(L6)=zhat;
            L6a = isnan(zzhat) &  ~isnan(znull);
        
            zzhat(L6a)=znull(L6a); % put in proper rows of cv of target-station years needing predicted
            nn(L6a)=k; % store model number used for prediction
            nn1(L6a)=npreds; % number ofpredictors
            nn2(L6a)=nyears; % number of years used to compute normals
            if sum(isnan(zzhat))==0
                break
            else
            end
        end
        Y(L1,j)=zzhat;
        N(L1,j)=nn;
        N1(L1,j)=nn1;
        N2(L1,j)=nn2;
    end
    disp(['Completed series ' num2str(j)])
end

D.what = char({['Call to meanratio1 on ' datestr(date) ' to get structure D with fields'],...
    '    X, yrX: original climate data',...
    '    Y, yrY:  filled-in version of X, yrX',...
    '    N:   (same size as Y) model number (see row of Lmodel,Imodel) used for estimation',...
    '    N1:   number of stations for each estimation',...
    '    N2:  number of years for mean ratios for the estimation',...
    '    Lmodel{? x 1}L row of Lmodel{i} is pointer to other cols of X used for model for',...
    '       estimation of value in ith col',...
    '    Imodel{? x 1)i  ith row of Imodel{k} holds col number in X of',...
    '       predictors for ith model use in prediction for station in col k of X'});
D.X=X;
D.yrX=yrX;
D.Y=Y;
D.yrY=yrY;
D.N=N;
D.N1=N1;
D.N2=N2;
D.Lmodel=Lmodel;
D.Imodel=Imodel;
end




function  [Lmod,Imod]=subfun01 (Z,z,m,L1,maxser)
% Revise columns for model to ensure that sufficient overlap of
% present years for computation of mean ratios with specified m.
% Select series as predictors in order of overlap of years with target
% series. Output Lmod and Imod have the columse (keyed to Z) of the
% predictors. Row-size of Lmod is number of models. Imod is a col-cell with
% the row-numbers (in Z) of the predictor series.
%
% Z: time series matriz, same row size as the column vector z that has
%   missing data to be filled in.
% z: col vector of the time series needing filling
% m: require at least m observations of overlap of the predictor set (some
%   cols of Z) with z
% L1: logical point to the years of z needing estimates
% maxser (1x1)i  predictor is the mean ratio averaged over predictors.
%
% 

% For the years needing filled in, find the unique combinations of others
% series that cover the years
[~,nZ]=size(Z);
W = Z(L1,:); % submatrix of predictors Z for years needing estimation
[mW,nW]=size(W);
L2 = ~isnan(W); % true if a non-key series has data in year  of  missing-data block at key
[L3,I,J]=unique(L2,'rows'); % rows of L3 indicate unique sets of predictors
nmods = size(L3,1); % number of unique sets

% Allocate for models (combinations) that will eventually be used for
% filling in
Lmod=false(nmods,nZ);
Imod=cell(nmods,1);

%--- Check that all years of W are indeed represented by the set of models
% in rows of L3
L=false(mW,1);
nset=nan(nmods,1); % for number of years represented by each model
for n =1:nmods
    Lthis = L3(n,:);
    W1=W(:,Lthis);
    W1a=W1';
    Lb1=~isnan(W1a);
    Lb2=(all(Lb1))';
    nwin = sum(Lb2);
    L(Lb2)=true;
    nset(n)=nwin;
end
if  ~all(L)
    error('The initial set of unique model does not cover all years needed to be estimated')
end
clear L n Lthis W1 W1a Lb1 Lb2 nwin


%----- For each unique combination, find longest overlap over all Z of any
% series and z. If overlap sufficient (m obs) for mean-ratio, start adding
% other series, until overlap drops below m

npreds=zeros(nmods,1); % to hold number of predictors for each model
Lz = ~isnan(z);
LZ= ~isnan(Z);


for n =1:nmods
    
    Lthis =L3(n,:);
    W1=W(:,Lthis); % Z subset, this model, target period
    nset1 = nset(n); % number of year in target period for which ALL model predictors are present
    
    La =Lz;
    LB=LZ (:,Lthis);
    ithis = find(Lthis); % columns (in Z) of predictors
    
    kwh1=1;
    nser=0;
    i_inmodel=[];
    
    ithis1=ithis;
    while kwh1
        nLB=size(LB,2);
        LA=repmat(La,1,nLB);
        Lx1 =LA & LB;
        
        nsum1=sum(Lx1); % rv, full overlap, number of observations
        [xmax,imax]=max(nsum1); % maximum overla, and member of ithis
        if isempty(LB) | (xmax<m) | (nser==sum(Lthis))  |  (nser>=maxser)
            kwh1=0;
            Imod{n}=i_inmodel;
            Lmod(n,i_inmodel)=true;
        else
            i_inmodel=[i_inmodel; ithis1(imax)];
            nser=nser+1;
            ithis1(imax)=[];
            La=La & LB(:,imax);
            LB(:,imax)=[];
        end
    end

end

%--- Check that final model is subset of unique set of predictors
for n =1:nmods
    Lthis = Lmod(n,:);
    L3check = L3(n,:);
    Lbad = Lthis & ~L3check;
    if any(Lbad)
        error('Final set of predictors not a subset of the full unique set')
    end
end

%----- Reduce to just unique models
Lmod1=Lmod; Imod1=Imod;
[Lmod,I,J]=unique(Lmod,'rows'); % rows of Lmod indicate unique sets of predictors
Imod=Imod(I);
nmods =size(Lmod,1);
npreds=nan(nmods,1);
npreds= (sum(Lmod'))'; % cv, number of predictors in each model

% ---- Re-order models with priorty to larger number of predictors.
[b,ib]=sort(npreds,'descend');
Lmod = Lmod(ib,:);
Imod =Imod(ib);

end
