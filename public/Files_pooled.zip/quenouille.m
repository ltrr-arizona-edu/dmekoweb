function [r,p,rc,N,k]=quenouille(x,y,K)
% quenouille: confidence interval for cross-correlation of autocorrelated series
% [r,p,rc,N,k]=quenouille(x,y,K);
% Last revised 2017-03-17
%
% Confidence interval for cross-correlation of autocorrelated series
%
%*** INPUT ARGUMENTS
%
% x (mx x 1)r first time series
% y (my x 1)r second time series
% K (1x1)i  number of lags to use in the autocorrelation function
%
%
%*** OUTPUT ARGUMENTS
%
% r ((2K+1) x 1)r cross-correlaton function x(t) with y(t+1) for i=-K:K
% p ((2K+1) x 1)r p-value for cross-correlations of x(t) with y(t+i) for
%   i=-K to +K
% rc (3x1)r  critical r ar 0.05, 0.01, 0.001 (two tailed)
% N (1x2)r original and effective sample size
% k (1x1)i number of lags of autocorrelations used for adjustment
%
%*** REFERENCES
%
% J.K. Angell,1980. Comparison of variations in atmospheric quantities with
% sea surface temperature variations in the equatorial eastern Pacific.
% Monthly Weather Review 109,230:243.
%
%
%*** UW FUNCTIONS CALLED 
%
% acf
%
%
%*** TOOLBOXES NEEDED 
%
%
%*** NOTES  
%
% Adjustment to effective sample size uses the autocorrelations of x and y
% out to a the first lag that either autocorrelation becomes non-positive.
% If lag-1 autocorrelation of either x or y is negative, not adjustment is
% made


[mx,nx]=size(x);
[my,ny]=size(y);

L = isvector(x) && isvector(y);
if ~L
    error('x and y must be vectors');
end
if  ~(mx==my && nx==ny)
    error('x and y must be same length');
end
    
if ~isscalar(K)
    error('K must be scalar')
end

mx = length(x);
if K>10
    error('Choose K 10 or lower');
end
if K> floor(mx/4)
    error('Choose K less than 1/4 length of time series');
end



%--- COMPUTE AUTCORRELATION FUNCTIONS OF X AND Y

k=[1 1];
[rx,SE2,r95]=acf(x,K,k);
[ry,SE2,r95]=acf(y,K,k);

% Use the autocorrelation function only out to the lag before either rx or
% ry becomes negative
if rx(1)<=0 || ry(1)<=0
    Ladjust=0;
    k=0;
else
    Lx = rx<=0;
    if sum(Lx)==0
        kkx=K;
    else
        ix = find(rx<=0);
        kkx =ix(1)-1; % highest lag that rx is >0
    end
    
    Ly = ry<=0;
    if sum(Ly)==0
        kky=K;
    else
        iy = find(ry<=0);
        kky =iy(1)-1; % highest lag that ry is >0
    end
    kk = min([kkx kky]);
    Ladjust=1;
    k=kk;
end
      




%--- effective sample size


N1=mx;

if Ladjust==1
    a =  2* (rx(1:k) .* ry(1:k));
    denom = 1+ sum(a);
    N1 = mx/denom;
else
end


%---- compute the xcorrelations from lags -K to K

D=[zscore(x) zscore(y)];
C = xcorr(D,K,'coeff');
r = C(:,3); % xcorrs of x(t) with y(t+i)


%--- fischer transform

z = 0.5*[log(1+r) - log(1-r)];



%--- Standard error of Z 

sez = 1/sqrt(N1-4);


%----- FOR NORMAL DISTRIBUTION WITH STANDARD DEVIATION sez, 

mu = 0;
sigma = sez;
pd = makedist('Normal',mu,sigma);

y = [0.0005 0.005 0.025 0.975 0.995 0.9995];
zcrit = icdf(pd,y);



%---- vector of correlations and correspondind z values

x = (-0.99:0.01:0.99)';
zx = 0.5*[log(1+x) - log(1-x)];


xcrit = interp1(zx,x,zcrit);
rc =(xcrit(4:6))';

y = cdf(pd,z);

my = length(y);
p = nan(my,1);
L = y>0.5;
p(L)=2*(1.0-y(L));
L = y<=0.5;
p(L) = 2*y(L);

if N1>mx
    error('effective sample size cannot be greater than original')
end

N=[mx N1];
