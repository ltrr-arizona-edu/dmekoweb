function Result=trachmap2(dtype,treev,filetree,A,B,fdims,colMap,rLo,rHi)
% trachmap2: color map correlation of tracheid cell-anatomy data with climate
% Result=trachmap2(A,B,rLo,rHi)
% Last revised 2019-10-03
%
% color map correlation of tracheid cell-anatomy data with climate.
% Correlates day-windowed climate data with tracheid tree-ring time series for
% quantiles of the ringwidth or ring number. 
%
%*** INPUT
% treev (1x?)s type of tree-ring variable (e.g., Lumen Area); used for
%   labeling only
% filetree (1x?)s name of tree-ring data file
% A: structure of plot metadata and correlations. Fields:
%   .year (mX x 1)i  year vectors
%   .daygo (? x 1)i starting day of year of each window
%   .daysp (?x1)i ending day of year of each window
%   .C (myr x nwind)r time series matrix of windowed cliamte
%   .mon1ticks (?x1)r plotting points along day-of-year axis for first of
%       month of all months in the analysis period
%   .mon1labels {?x1}c   month letter for thodse months
%
% B: structure with correlations and significance in fields:
%   .R (mR x nR)r correlations for mR ring quatiles and nR day windows
%   .P (mP x nP)r  p-value of significance of correlations
%   .AC structure with autocorrelation information on tree-ring series
%       .a1X (m x 1)r lag-1 (year) autocorrelation of each tree-ring series
%       .sig1X (mx1)i  significance level (0.01 ==2; 0.05==1; p>0.05==0)
%       .a1Y (n x 1)r lag-1 (year) autocorrelation of each day-windowed climate series
%       .sig1Y (nx1)i  significance level (0.01 ==2; 0.05==1; p>0.05==0)
%    .Q (mQ x 1)r  or []:  percentage of tree-ring variance explained by
%       regression on the tree-ring series for the preceding quantile. []
%       if you happened to not call for the adjustment.
% colMap(1x?)s   color map (e.g. "parula")
% rLo (1x1)r  lower correlation at which color map truncated
% rHi (1x1)r  upper correlation at which color map truncated
%
%*** OUTPUT
%
% Result: a structure with matrices of correlations and significance
%
%
%*** NOTES
%

colormap(colMap)

%B.R(1,end)=0.6;
R=B.R;
P=B.P;


%  flip R and add nan row and col, in prep for imagesc because want bottom
%  row to be for earliest  quantile
R1=flipud(R); % corrs for earliest tree ring quantile along bottom
%R1=R;
[mR1,nR1]=size(R1);
ix =1:nR1;
iy=1:1:mR1;
yticks=iy';
yticklabs=cellstr(num2str(yticks));


%  PLOTTING POSITION OF FIRST OF EACH MONTH IN UNITS OF THE PCOLOR X
% AXIS
x1=A.daygo;
j1 = A.mon1ticks;
%x2 = subfun01(x1,j1);
x2=A.mon1ticks+0.5;


figure(1)
[cL,cB,cW,cH]=figsize(fdims(1),fdims(2));
set(gcf,'Position',[cL cB cW cH]);

h=imagesc(R1);
set(gca,'Ytick',yticks)
set(gca,'YTickLabel',flipud(yticklabs));
set(gca,'Xtick',j1)
set(gca,'XtickLabel',A.mon1labels)

xlabel('Climate day-window')
ylabel('Tree-ring quantile')

hold on;

% Add significance (closed black circle for 0.01, open for 0.05)


% plotting postions along y axis of center
[s,y2] = subfun02(R1);

P=flipud(P);
[mP,nP]=size(P);
for j = 1:mP
    y3=y2(j); % y positions
    for k =1:nP
        p = P(j,k);
        x3 =k;
        if p<0.01
            h = plot(x3,y3,'o');
            set(h,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0])
        elseif p<0.05
              h = plot(x3,y3,'o');
              set(h,'MarkerEdgeColor',[0 0 0])
        else
        end
    end
end
hold off

% title

[mm1,dd1]=ddd2mmdd(2000,A.daysp(1)); %this will give month/year of that day-number in a leap year
[mm2,dd2]=ddd2mmdd(2000,A.daysp(end)); 
deltat = 1+A.daysp(1) -A.daygo(1);
str_a=['[' num2str(deltat) '-day windows ending ' num2str(mm1) '/' num2str(dd1) ' to ' num2str(mm2) '/' num2str(dd2) ']'];
str_b=[treev '(' filetree ') vs ' dtype ' ' str_a];
    

%  Color bar

c=colorbar;
c.Label.String = 'Correlation';
caxis([rLo rHi])

title(str_b,'Interpreter','None')
Result=[];
end

function x2=subfun01(x1,j1)
% x plotting coordinate for J, F, etc.
mx =length(x1);
m = (1:mx)';
x2 = interp1(x1,m,j1);
end

function [s,y2] = subfun02(R)
[mR,nR]=size(R);
j = (1:mR)';
s=cellstr(num2str(j));
y2=j;
end
