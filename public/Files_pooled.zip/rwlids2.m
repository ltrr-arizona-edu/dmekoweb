function S=rwlids2(pfrwl,pfids,cols)
% rwlids2: Substitue ids in an rwl file
% S=rwlids2(pfrwl,pfids,cols);
% Last revised 2016-05-19
%
% Substitue ids in an rwl file.  Reads list of original and substitute ids
% from pfids and changes the ids in the rwl file pfrwl accordingly
%
%
%*** INPUT
%
% pfrwl (1 x ?)s  path and filename of input rwlfile; just need filename if
%   if run from folder with the file
% pfids (1 x ?)s  path and filename of input file with ids and replacement
%   ids; just need filename if run from folder with the file
% cols (1x2)i  first and last column of id in input rwl file.  
%   For example, [1 8].  If [1 8], assume pfids has the original ids in [1
%   8] and the replacements in [10 17]
%
%*** OUTPUT
%
% S (? x 72)s char matrix of the rwl file
%
% Also generated is file xxxx.rwl, the revised rwl file to be checked and
% renamed manually
%
%*** REFERENCES -- NONE
%*** UW FUNCTIONS CALLED -- NONE
%*** TOOLBOXES NEEDED -- NONE
%
%*** NOTES
%
%----NO HEADER LINES
%--- NO TRAILING BLANK LINE
%--- 72 COLS
%--- ANY ID AT LEAST TWO ROWS
%--- ROWS CONTIGUOUS FOR  IDS
%--- MORE THAN ONE LETTER AFTER FIRST 3 CHARS OF ID

D = textread(pfrwl,'%s','delimiter','\n','whitespace','');

T = textread(pfids,'%s','delimiter','\n','whitespace','');
H=char(T);
nH=size(H,2);

[mT,nT]=size(T);

for n = 1:mT;
    h = T{n};
    if length(h)<nH;
        d = nH-length(h);
        h = [h repmat(' ',1,1)];
    end
    i1 = cols(1);
    i2=cols(2);
    ncol = cols(2)-cols(1)+1;
    i3 = cols(2)+2;
    i4 = i3+ncol-1;
    h1 = h(i1:i2);
    h2 = h(i3:i4);
    D=strrep(D,h1,h2);
    
end

S=char(D);
[mS,nS]=size(S);
if nS~=72;
    error('S not have 72 cols')
end

s1=S(1,:);
fid = fopen('xxx2.rwl','w');
for n =1:mS;
    s1=S(n,:);
    fprintf(fid,'%s\n',s1);
end
fclose(fid);


