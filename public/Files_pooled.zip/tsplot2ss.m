function tsplo2ss(X,yrX,Y,yrY,s)
% tsplot2ss: Time series plot of 2 alternative chronologies from core indices
% tsplot2ss(X,yrx,Y,yrY,s)
% Last revised 2017-01-17
%
% 
%
%*** INPUT
%
% X (mX x nX)r  % first time series matrix of core indices
% yrX (mX x 1)i % year vector...
% Y (mX x nX)r  % second time series matrix of core indices
% yrY (mX x 1)i % year vector...
% s{}1=title
%    2=legend for nx
%    3=legend for ny
%    4=x axis label
%    5=y axis label


[mX,nX]=size(X);
[mY,nY]=size(Y);



%--- COMPUTE SITE CHRONOLOGY AS ARITH MEAN OF CORE INDICES

x=(nanmean(X'))';
yrx = yrX;
[x,yrx]=trimnan(x,yrx);

y=(nanmean(Y'))';
yry = yrY;
[y,yry]=trimnan(y,yry);x


yrgo = min([yrx(1) yry(1)]);
yrsp = max([yrx(end) yry(end)]);
xlims = [yrgo-3 yrsp+3];

yhi = max([max(x) max(y)]);
ylo=0;
ylims = [0  yhi+0.1*yhi];


% String info on year with largest difference
yron= max([yrx(1) yry(1)]);
yroff = min([yrx(end) yry(end)]);
L = yrx>=yron & yrx<=yroff;
u1 = x(L);
yru1 = yrx(L);
L = yry>=yron & yry<=yroff;
u2 = y(L);
yru2 = yry(L);
[d,id]=max(abs(u1-u2));
str1 ={['Largest difference in ' num2str(yru2(id)) ':'],...
    ['   Before = ' num2str(u1(id), '%5.3f')],...
    ['   After  = ' num2str(u2(id), '%5.3f')]};

r = corrcoef([ u1 u2]);
r = r(1,2);
str2 = ['r=' num2str(r,'%7.4f')];

figure
[cL,cB,cW,cH]=figsize(.75,.6);
set(gcf,'Position',[cL cB cW cH]);

h = plot(yrx,x,yry,y);
set(gca,'XLim',xlims,'YLim',ylims);

legend(s{2},s{3})
xlabel(s{4});
ylabel(s{5});
textcorn(str1,'UL',0.02,0.02,14)
title(s{1});
textcorn(str2,'UL',0.50,0.02,14)
title(s{1});
