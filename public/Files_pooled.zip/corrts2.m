function [r,pvalue]=corrts2(x,y,kopt,kdir,specs)
% corrts2:  significance test of correlation between two time series, Monte Carlo
% [r,pvalue]=corrts1(x,y,kopt,kdir,specs);
% Last revised 2019-06-19
%
% Test of null hypothesis that population correlation is zero against either one-sided or
% two sided alternative hypothesis.  Simulations are  done on x.
%
%*** INPUT
%
% x (mx x 1)r one time series
% y (my x 1)r the other time series, same length as x
% kopt(1 x 1)i
%   kopt(1) ?-tailed test
%       ==1 one tailed
%       ==2 two tailed
% kdir (1 x 1)i if one sided, which direction for alter hypoth
%   ==1  population r greater than 0
%   ==2  population r less than 0
%   Note: set kdir==[] for two sided test 
% specs: structure of specification for call to pdgmsim
%  .nsim (1x1)i number of simulations (e.g., 1000)
%  .mtaper (1x1)r  decimal fractional total of series to be tapered (e.g.,
%        0.10, which means 5% on front and 5% on back
%  .kopt(1x2)i options
%       (1) force sims to have same mean and standard deviation as the
%               observed series
%           ==1 yes;  ==2 no
%       (2)  turn off the msgbox warning about failing Lilliefors
%           ==1 yes;  ==2 no (default if length(kopt)==1)
%  .len (1x1)i  or []. desired length of simulations; or, if [], same
%           length as the observed series
%
%*** OUTPUT
%
% r (1 x 1)r correlation coefficient
% pvalue(1 x 1)r  p-value for test 
%
%*** REFERENCES
%
% Bloomfield, P., 2000. Fourier analysis of time series: an introduction, 
% second edition. John Wiley & Sons, Inc., New York. 261 p.
%
% Percival, D.B., and Constantine, W.L.B., 2006. Exact simulation of 
% Gaussian time series from nonparametric spectral estimates with 
% application to bootstrapping. Statistics and Computing, 16: 25-35.
%
%*** UW FUNCTIONS CALLED 
%
% pdgmsim-- exact simulations
%
%*** TOOLBOXES NEEDED
%
% Statistics
%
%
%*** NOTES
% 
% Null hypothesis is that the samples are uncorrelated.  Test valid only for this null hypothesis. 

% CHECK INPUTS



[mx,nx]=size(x);
if nx~=1 | mx<5
    error(' x must be cv of minimum length 5');
end
nsize1 = mx;

len = specs.len;
if isempty(len)
    len = nsize1;
else
end

nsim = specs.nsim;
mtaper = specs.mtaper;
kopt_sim=specs.kopt;
 

% y
[my,ny]=size(y);
if nx~=1 | mx~=my
    error(' y must be cv of same length as x');
end
if any(isnan(x)) | any(isnan(y))
    error('NaNs in x or y');
end


% kopt
if size(kopt,1)~=1 | size(kopt,2)~=1
    error('kopt must be 1 x 1');
end
if ~all(kopt>=1 & kopt<=2)
    error ('kopt entries must be 1 or 2');
end


% Compute Correlation
r =corrcoef([x y]);
r=r(1,2);

%  Exact simulatons of x

Result_sim=pdgmsim(x,nsim,mtaper,kopt_sim,len);
r1 = corrone(y,Result_sim.Y)'; % cv of correlations with the simulations

if r>=max(r1)
    if kdir==1
        pvalue=0;
        return
    else
        pvalue=1;
        return
    end
elseif r<=min(r1)
    if kdir==1
        pvalue=1;
        return
    else
        pvalue=0;
        return
    end
end


s1=sort(r1);
j =(1:nsim)';
p1=j/(nsim+1); % non-exceedance

p=interp1(s1,p1,r);
     
% Tails 
if kopt(1)==1 
    ntail=1; % one tailed
else
    ntail=2; % two tailed
end


if ntail==1
    if kdir==1
        pvalue=1-p;
    else
        pvalue=p;
    end
else
    if p>0.5
        pvalue=2*(1-p);
    else
        pvalue=2*p;
    end
end









