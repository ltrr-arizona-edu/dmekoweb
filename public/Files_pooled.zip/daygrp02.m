function Result=daygrp02(datin,specs)
% daygrp02: organize daily climate series for function trach01
% Result=daygrp02(datin,specs)
% Last revised 2019-10-02
%
% Organize daily climate series for functions on color-mapping cell-anatomy climate signal
% Arranges daily data in averages or sums over non-overlapping n-day blocks
% and stores with metadata. 
%
%*** INPUT
%
% datin: structure of input data and related setting
%   .X (mX x 4)r   year, month, day of month, data value of climate series
% specs: structure of settings
%   .datatype (1x?)s axis-label of data type, possibly including units (e.g., "SWC (mm)")
%   .nday (1x1)i number of days for window
%   .endmo (1x1)i month for last day-window grouping (1=Jan, 12=Dec)
%   .endday (1x1)i day of that month for last grouping
%   .goday (1x1)i day of month of start of earliest window (day in Jan for
%       Northern Hemisphere and day in July for Southern Hemisphere)
%   .howseas (1x1)i jhow to seasonalize
%       ==1 sum
%       ==2 mean
%   .hemisphere (1x1)s  which hemisphere the site is ("N" or "S") --
%        (Notes)
%   .caxisLo (1x1)r  color map reaches most extreme lower color at this
%           correlation
%   .caxisHi (1x1)r  color map reaches most extreme high color at this
%           correlation
%   .QCplot (1 x ?)s whether or not you want a quality control plot
%       with time series of the climate variable for the first, median and
%       last window
%           "Yes" want
%           "No"  skip
%
%*** OUTPUT
%
% Result: a structure with matrices of correlations and significance
%   .datatype (1x?)s name of data and unit (e.g., "SWC (mm)")
%   .seashow(1x1)i how seasonalized (1=sum, 2=mean)
%   .daygo: cv of starting day number for each window 
%   .daysp: cv of ending day number for each window 
%   .nyr (1x1)i  number of calendar years bridged by windowed series;
%       This should be set as 1 for Northern Hemispher, and 2 for Southern
%       Hemispher
%   .nper (1x1)i number of windows
%   .C (nyr x nper): time series matrix of the windowed mean or sum
%   .year (nyear x 1)i year vector for C
%   .mon1ticks (?x1)r first of month x-label tick plotting points, assuming
%       x-axis of color map starts with the day-of-year of first window and
%       ends wth day-of-year of last window
%   .mon1labels {nx1}s  month labels for mon1ticks
%
%
%
%*** REFERENCES
%
%*** UW FUNCTIONS CALLED 
%
% mdy2jdy.m... month/day to day of year
%
%
%*** TOOLBOXES NEEDED -- none
%
%
%*** NOTES
%
% Assumes the calling function (e.g., trach03) intends to do a color map
% of correlation of intra-ring tree-ring variables (e.g., mean lumen area)
% for quantile (e.g., quintiles) of the ring width with climate variables
% in non-overlapping nday-day windows. 
%
% Determines windows by starting with day-of-year of last window and
% working backwards until the first window whose starting day would be in
% the current year (Jan 1 or later). This is the Northern Hemispher
% strategy. Same strategy in Soutern Hemisphere for windows, except keyed on July 1 of
% year before tree growth rather than Jan 1 of tree-ring year. . 



%---- HARD CODE

if strcmp(specs.hemisphere,"N")
    s1 ={'J','F','M','A','M','J','J','A','S','O','N','D'}';
    js1=[1 32  61 92 122 153 183 214 245 275 306 336]'; % day number of first of month
else
    error('Not yet coded for Southern Hemisphere')
end

%--- UNLOAD
m=specs.nday;
X=datin.X;
[mX,nX]=size(X);


%--- DAY OF YEAR OF END OF LAST DESIRED WINDOW

if strcmp(specs.hemisphere,'N')
 day1=mdy2jdy(specs.endmo,specs.endday); % specified month/day of last window
 else
    error('Not yet coded for Southern Hemisphere')
end
 

%---- COMPUTE HOW MANY NDAY-DAY PERIODS ARE IN A YEAR, STARTING WITH 
%  LAST PERIOD AND WORKING BACK

% k1,k2 will be cv's of first and last day of each period, from latest to
% earliest
if strcmp(specs.hemisphere,'N')
    k2=(day1:(-1*specs.nday):(specs.nday))'; % end days of all n-day periods that start not earlier than Jan 1
    k1= (k2-(specs.nday-1)); % start days
else
    error('not coded yet for SH')
end
k1=flipud(k1); k2=flipud(k2); % so that k1, k2 now arranged from earlies to latest window
nper = length(k1);


%----- COMPUT THE MOVING AVERAGE OR SUM  OF DAILY CLIMATE

yr = X(:,1); mo=X(:,2); dmo=X(:,3); dyr =X(:,4); x=X(:,5); % store cols of daily climate separately
mx = length(x);
tx = (1:mx)'; % sequential cv time vector for x

koptma=2; % yry will be end year of moving average or sum
[xs,txs]=mafilt1(x,tx,m,koptma);

if specs.howseas==1
elseif specs.howseas==2
    y=y*m; % moving ave to moving sum
end

% tim the year, month, day of month and day of year files to txs
yr1=yr(txs); mo1=mo(txs); dmo1=dmo(txs); dyr1=dyr(txs);
Result.year =unique(yr1);
d = diff(Result.year);
if ~all(d==1)
    error('Result.year does not inc by 1');
end
C = nan(length(Result.year),nper);


%--- PULL NON-OVERLAPPING WINDOWED CLIMATE ANNUAL SERIES FOR EACH CLIMATE
%WINDOW

for n = 1:nper
    k2this =k2(n);
    L = dyr1==k2this;
    y = xs(L);
    if n==1
        yry =yr1(L);
    else
        yra = yr1(L);
        if ~all(yra==yry)
            error(['Year vector changed from period ' num2str(n) ' - 1']);
        else
            yry=yra;
        end
        if ~all(Result.year ==yry)
            error('Unexpected yry, not identical to Result.year');
        end
    end
    C(:,n)=y;
end
Result.C=C; % tsm of annual time series of non-overlapping windowed climate; each col a time series; 
% earliest 
Result.daygo = k1;
Result.daysp = k2;
 
 
%----- X AXIS PLOTTING POINTS FOR FIRST OF MONTH
%
% On the color map, assume the x-axis starts with day of year k1(1) and
% ends with day of year k2(end)

jmon=(1:12)'; % cv of calendar months
L1 =js1>=k1(1);
i1=find(L1);
i1=i1(1); % first of month for month of first window

L1 = js1<=k2(end);
i2=find(L1);
i2 = max(i2); % first of month for month of last window

mticks=i2-i1+1; % color map with have this many first-of-month ticks
j=i1:i2;
s2=s1(j);
js2=js1(j);
% s2 ad js2 are day-of-year for the ticks

% Translate tick x plotting point units of sequential window
% Have nper windows, with ending day-of-year of k2 (cv).The corresponding
% color-map plotting points will be 1:nper. Into a cv (1:nper)',
% coresponding to cv k2, will want to interpolate points for the
% day-of-year cv js2, which in turn has the tick labels s2 (col-cell)

j1 =(1:nper)';
j2 = interp1(k2,j1,js2) ;

Result.mon1ticks=j2;
Result.mon1labels=s2;


%---- SIMPLE DEBUG TIME PLOTS FOR FIRST, MIDDLE AND LAST WINDOW

if strcmp(specs.QCplot,'Yes')
    xlims=[Result.year(1) Result.year(end)];
    
    figure(1)
    [cL,cB,cW,cH]=figsize(.7,.5);
    set(gcf,'Position',[cL cB cW cH]);
    m = ceil(nper/2);
    m=[1 m nper];
    
    h = plot(Result.year,C(:,m(1)), Result.year,C(:,m(2)), Result.year, C(:,m(3)));
    set(gca,'XLim',xlims)
    set(h(1),'Marker','o');
    set(h(2),'Marker','*');
    set(h(3),'Marker','^');
    xlabel(['Window number (' num2str(specs.nday) '-mean or sum']);
    ylabel(specs.datatype);
    title([specs.datatype ' in jth ' num2str(specs.nday) '-day window']);
    legend(['j=' num2str(m(1))],['j='  num2str(m(2))],['j='  num2str(m(3))]);
    
    % Inform about this plot, and that should save as fig if want to use it
    % for quality control
    a = [Result.daygo(m(1)) Result.daysp(m(1)); Result.daygo(m(2)) Result.daysp(m(2)); Result.daygo(m(3)) Result.daysp(m(3))];
    str1={'This plot can be used to check that the input climate data has',...
        'been properly read in. You can go back to your original daily data and make sure',...
        'that the mean or sum for three plotted windows is correct by ''hand-computing'' the',...
        'windowed mean or sum for a year or so and comparing with the plotted values. The',...
        'figure window with the plots will disappear when you close this message, but you',...
        'will find plot files ''QCtemporary1.fig'' and QCtemporary.png'' in the current working',...
        'directly after running this function',...
        '   ',...
        'The start and end day of year for the three windows is:',...
        num2str(a)};
     uiwait(msgbox(str1,'Message-str1','modal'));
     fnm = 'QCtemporary';
    hgsave(gcf, fnm); 
     print(gcf, '-dpng',fnm); 
     
else
end

disp('here')
end
