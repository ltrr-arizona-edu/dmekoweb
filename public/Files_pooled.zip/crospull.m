function IX=crospull(nyears,nlag,plag)
% crosspull: make logical pointer to estimation and crossvalidation subsets for reconstruction model
% IX=crospull(nyears,nlag,plag);
% Last revised 10-10-03
%
% For a data matrix for climatic reconstruction with a model that possibly includes 
% lags on predictors, makes a logical pointer matrix to subsets of rows (years) of the predictand
% data to be used in estimation and crossvalidation.  Uses "leave-n-out" strategy, where 
% n=1+2*m, and m is the sum of the largest negative lag and largest positive lag on the tree rings
% in the reconstruction model. Leaving out n observations ensures no overlap in the tree-ring 
% data used to calibrate models and the data used to generate cross-validation estimates. 
%
%*** INPUT ARGUMENTS
%
%  nyears (1x1)i  number of years in the calibration/verification period
%  nlag (1x1)i    highest negative lag on the predictors (e.g., 2 means up
%   to lag t-2 used as predictors
%  plag (1x1)i    highest positive lag on the predictors
%
%
%*** OUTPUT ARGUMENTS
%
%  IX (m1 x n1)L   logical array, elements of a col refer to rows of data
%		matrix in the calling program. First column of IX has 1's for rows to 
%     be used 
%
%*** REFERENCES
%
% Crossvalidation is discussed by Michaelsen, J., 1987, Cross-validation in statistical 
% climate forecast models, J. of Climate and Applied Meterorology 26, 1589-1600.
%
% The "leave-n-out" strategy is used in:
% Meko, D.M., 1997, Dendroclimatic reconstruction with time varying subsets of tree 
% indices: Journal of Climate, v. 10, p. 687-696.
%
%*** UW FUNCTIONS CALLED -- none
%*** TOOLBOXES NEEDE -- none
%
%*** NOTES
%
% Makes an intermediate array of indexes to be used in cross
% validation in regression models.  Assume you are doing a regression
% analysis with crossvalidation by a "leave n out" strategy.  There
% are n years of data, and you will repetitively estimate a regression
% equation, leaving out enough years so that the predictand for the
% calibration period is independent of tree-ring data that might
% be related to the key year of the left-out sequence.
%
% Given the number of years of data you have, and the number of positive
% and negative lags on the predictor(s) in the model, this function builds
% a 1/0 logical pointer to your data telling which years to use in the 
% current model, and a subscript array telling which year is to be 
% estimated using the current model.
%
% Calling program would use column one of IX for first model:  rows with 1 would
% be used to fit the model, rows would zero would not be used for the fit, and
% the crossvalidation estimate is for year 1 of the nyears.  Next the calling program  
% would use column 2 of IX:  rows with 1 would be used for the fit, rows 
% with zero would not, and the crossvalidation estimate is for year 2. And so on 
% through all nyears of the data.
%
% In the predictor matrix, say X, rows correspond to years, and columns to
% either current or lagged tree-ring indices, or both.  Thus it is assumed
% that X has already been organized with any possible lagging of predictor variable
% in mind.  Crosspull does not directly deal with X, but only with the row
% indices of X. 
%
% Revision 10-10-03.  Instead of leaving out 1+4*maxlag predictand , 
% observations from calibration (as in a
% previous version), leave out 1+2*m, where m is sum of highest
% positive lag and highest negative lag used as predictors


maxlag=max(nlag,plag); % highest lag used
sumlag = nlag+plag; % sum of number of + and - lags
nzero = 1 + 2*(sumlag);  % Number of predictand observations to "leave out" of calibration in the model 
% to estimate the crossvalidation estiamte for the central year of the
% left-out portion.  Ensures that the tree-ring data for the
% cross-validation estimate and the fitted model do not overlap


nmods=nyears;  % Number of regression models to estimate
n1= nmods;

IX = ones(nyears,nmods);  % Initialize logical array as all ones


%*****  Fill an intermediate subscript array

L1=(1:nzero)';  % cv like [1 2 3 4 5]'
L2=L1(:,ones(nmods-2*sumlag,1));  % dupe that column multiple times
K1= 0:(nmods-2*sumlag-1);  %  rv like [0 1 2 3 ...  45]
K2=  K1(ones(nzero,1),:);  % dupe that row multiple times
LK=L2+K2;  % For each regression model, a col of LK tells which rows are
%	to be left out.


%*******  Loop for "inside" years 

first=1*sumlag+1;
last=nyears-(1*sumlag);
for j=1:(nyears-2*sumlag);
	ithis=LK(:,j);
	IX(ithis,j+1*sumlag)=(zeros(nzero,1));
end



%***********   HANDLE "OUTER" YEARS

ncols=1*sumlag; % this many columns are "outer" on either end
if ncols~=0;  % no outer-year problems if no lags
   xl=ones(nyears,ncols);
   for i=1:ncols;
      for j=1:(1*sumlag+i);
         xl(j,i)=0;
      end
   end
   xr=fliplr(xl);
   xr=flipud(xr);
   IX(:,1:(1*sumlag))=xl;
   IX(:,(nyears-1*sumlag+1):nyears)=xr;
end;

IX=logical(IX);
