function Result=trach03
% trach03: color mapped correlation of tracheid data with day-windowed climate
% Result=trachmap1(datin,specs)
% Last revised 2019-09-30
%
% Color mapped correlation of tracheid data with day-windowed climate
% Correlates cell-anatomy time series (e.g., meaR1=flipud(R);n lumen area) for different quantiles
% of ring width or cell number with daily climate data, and color-maps
% result.
%
%*** INPUT
%
% No input arguments. User prompted to click on specifically formatted
% input files of tree-ring data and daily climate data. These may
% optionally be xlsx spreadsheet files or mat (Matlab) files.  User also
% prompter for various settings of specifications. Defaults are hard coded
% at start of this function. 


%----- obsolete bloc
% datin: structure of input data and related setting
%   .X (mX x 4)r   year, month, day of month, data value of climate series
%   .Y (mY x (1+m))r   year, followed by the tree-ring variable (e.g., mean
%       lumen area) for quantiles of the ring ordered from early to late
%   .Xlab (1x?)s string suitable for labeling data-type portion on a y-axis of time plot of the
%       climate variable (e.g., "Mean Lumen Area (mm2)")
%   .Ylab (1x?)s string suitable for labeling a y-axis of time plot of the
%       tree-ring variable (e.g., "Mean Lumen Area (mm2)"
%   .yearA (1x2)i or []; first and last year of desired analysis period
%       (see Notes)
%
% specs: structure of specifications
%   .nday (1x1)i number of of days in the day window. The tree-ring series
%       is correlated with X in successive, non-overlapping n-day periods
%       <10>
%   .endday (1x1)i day-of-year that you want the the last day window to end
%       in <300>. Should be evenly divisible by nday. Typically, this would
%       be a day you are certain cambial growth has stopped by. <300>
%   .nyears (1x1)i daily climate data for this number of years would be
%       used in the correlations with the tree-ring variable in one year <1>
%   .daygo (1 x 1)i nominal day number of first day of daily climate  data you 
%       consider using in the first year lagged against the tree ring  variable 
%       (see Notes) <61>
%   .nsim (1x1)i  number of exact simulations of Y variable to generate in
%       estimating significance of correlation (see Notes). <10,000>
% Specs.ksim (1x1)i  options for the simulation
%   ksim(1): transformaton of the tree-ring annual series to normality
%       ==1 no transformaton considered
%       ==2 forced transformation with quantile mapping if Lilliefors test
%           fails at p<0.01
%       ==3 automatic transformation with quantile mapping regardless of
%           Lillifors test result
% Specs.color: ... structure, for color mapping of correlations
%       Specs.color.mymap: (1x?)s  color map to use <jet>
%       Specs.color.trunc (1x2)r  max the colors out at these correlations
%           <[-1.0 1.0]>
% Specs.Fig: structure of controls over figure window
%       Specs.Fig.wnumber: plot first color map in this figure window <1>
%       Specs.Fig.dims (1x2)r: width and height these decimal fractions of
%
%
%*** OUTPUT
%
%*** NOTES
%
% Input data files. If xlsx, row-1 should be a simple header line of code
% names with units in parentheses, such as "SWE (mm)".  Header for col-1
% should be "Year."  Under year are the years of end month of tree growth.
% Remaining columns are the various climate series (e.g., SWE (mm), SWC
% (mm)). No underscores in these names. 
%
% Specification (specs). User is prompted for these with edit windows and
% menu windows. 


defname1='TSME_LA.mat';
defname2='simulationsCPRdaily_B.xlsx';

prompt = {'Enter tree-ring data files suffix:','Enter climate data file suffix:'};
title = 'Enter suffixes for input data ffiles';
dims = [1];
definput = {'mat','xlsx'};
answer = inputdlg(prompt,title,dims,definput);
ftype_tree=answer{1};
ftype_clim=answer{2};

treevars={'Mean lumen area','Mean cell-wall thickness'};
treevs ={'LA','CWT'};
ktree = menu('What kind of cell-anatomy time series?',treevars);
if ktree~=1
    error('Coded so far only for mean lumen area')
end
treevar =treevars{ktree};
treev =treevs{ktree};

% Get tree-ring file path, filename, and file type
tit1='Input file with cell-anatomy time series';
if strcmp(ftype_tree,'mat')
    ffilter={'*.mat'};
elseif strcmp(ftype_tree,'xlsx')
     ffilter={'*.xlsx';'*.xls'};
end
[file,path,indx]=uigetfile(ffilter,tit1,defname1)
pftree=fullfile(path,file);
filetree=file;


% Get climate-data file path, filename, and file type
tit1='Input file with day-windowed climate time series';
if strcmp(ftype_clim,'mat')
    ffilter={'*.mat'};
elseif strcmp(ftype_clim,'xlsx')
     ffilter={'*.xlsx','*.xls'};
end
[file,path,indx]=uigetfile(ffilter,tit1,defname2)
pfclim=fullfile(path,file);


%--- READ CLIMATE DATA FILE

if strcmp(ftype_clim,'xlsx') || strcmp(ftype_clim,'xls')
[A,B]=xlsread(pfclim);
elseif  strcmp(ftype_clim,'mat') 
    eval(['load ' pfclim ';']) % year vector, data matrix and cell of series labels, such as "SWC"
else
end

%---- SELECT CLIMATE VARIABLE

bheads =B(1,:);
bnms=bheads;
bnms(1:4)=[];
kpick1= menu('Choose climate variable',bnms);
xwant = bnms{kpick1}; % say, "SWC"

specs.datatype=[xwant];
% xwant='SWE';
% specs.datatype=[xwant ' (mm)'];


%-----STORE DAILY CLIMATE TIME SERIES IN X

iwant = find(ismember(bheads,xwant));
X=A(:,[1 2 3 4 iwant]); % yr, month, day of month, day of yr, data value


%----- COMPUTE THE DAY-WINDOWED CLIMATE AND ASSOCIATED PLOTTING POINTS
%       FOR FIRST OF EACH MONTH ON EVENTUAL TIME PLOT THAT STARTS JAN 1 IN
%       NORTHERN HEMISPHERE AND JULY 1 IN SOUTHERN HEMISPHERE. THE FIRST
%       DAY WINDOW NEED NOT START IN JAN 1 OR JULY 1, BUT MUST START IN
%       SOME DAY OF JAN (NH) OR JULY (SH).


% Set up input for call to daygrp01

prompt = {'Enter number of days in window:',...
    'Specify ending month of last window',...
    'Specify ending day of month of last window',...
    'Specify day-of-month of start of first window',...
    'Enter seasonalizing method (''mean'' or ''sum'')',...
    'Enter hemisphere ("N" or "S")',...
    'Enter caxis lower correlation for caxis',...
     'Enter caxis lower correlation for caxis',...
     'Enter figure width and height as screen fraction',...
    'Quality control debuggin time plots? (''Yes'' or ''No'')'};
title = 'Specification for windows and mapping';
dims = [1 ];
definput = {'20','10','15','1','mean','N','-1.0','1.0','[0.6 0.5]','Yes'};
a = inputdlg(prompt,title,dims,definput);

datin.X=X;
specs.nday=str2num(a{1});
specs.endmo=str2num(a{2});
specs.endday=str2num(a{3});
specs.goday =str2num(a{4});
specs.howseas=a{5};
specs.hemisphere=a{6};
specs.caxisLo=str2num(a{7});
specs.caxisHi=str2num(a{8});
cLo=specs.caxisLo;
cHi=specs.caxisHi;
fdims=str2num(a{9});
specs.QCplot=a{10};

Ra=daygrp02(datin,specs);

yrY = Ra.year; % day-windowed climate year
Y = Ra.C ; % day-windowed climate



%----MENU TO CHOOSE COLOR MAP

colmaps={'parula','jet','hsv','hot','cool','gray','copper'};
kcolmap=menu('Choose color map',colmaps);
colmap=colmaps{kcolmap};


%---- CORRELATION ANALYSIS

%---- Load tree-ring time series
if strcmp(ftype_tree,'xlsx') || strcmp(ftype_tree,'xls')
    error('Tree-ring data input so far code for mat only')
elseif  strcmp(ftype_tree,'mat')
    eval(['load ' pftree  ';']);  % structure D.Chron
    X=D.Chron.X; yrX = D.Chron.yrX;
else
end


%--- Correlation analysis with function corrtrach01

datin1.X=X; datin1.yrX=yrX;
datin1.Y=Y; datin1.yrY = yrY;

prompt = {'Analysis period (maximum or specify)',...
    'Adjustment of tree-ring series (yes or no)',...
    'Correlation method (Pearson or Spearman)',...
    'Autocorrelation handling (Monte Carlo or none)',...
    'Computation of day-windowed climate (mean or sum):'};
title = 'Specifications for correlation analysis';
dims = [1 ];
definput = {'maximum','no','Spearman','none','mean'};
a = inputdlg(prompt,title,dims,definput);
APhow=a{1};
TreeAdjust = a{2};
rMeth = a{3};
acHandle=a{4};
windowHow=a{5};

% analysis period
specs1.kopt=nan(1,3);
if strcmp(APhow,'maximum')
    specs1.kopt(1)=1;
elseif strcmp(APhow,'specify')
    specs1.kopt(1)=2;
else
    error('Analysis period method must be ''maximum'' or ''specify''');
end

if specs1.kopt(1)==1
    specs1.AnalysisPeriod=[];
else
    yrgo1 = max([yrX(1) yrY(1)]);
    yrsp1 = min([yrX(end) yrY(end)]);
    stryrs =['(' num2str(yrgo1) '-' num2str(yrsp1) ')'];
    kwh1=0;
    while kwh1==0
        prompt = {'First year','Last year'};
        title =['Specified analysis period ' stryrs];
        dims = [1 ];
        definput = {num2str(yrgo1),num2str(yrsp1)};
        a = inputdlg(prompt,title,dims,definput);
        options.Resize='on';
        yrgo2 = str2num(a{1});
        yrsp2 = str2num(a{2});
        if yrgo2<yrgo1 || yrsp2>yrsp1
            h=warndlg('Specified years outside data coverage');
        else
            kwh1=1;
        end
    end
    specs1.AnalysisPeriod=[yrgo2 yrsp2];
end

% adjustment for removal of dependence on previous quantile tree-ring 
if strcmp(TreeAdjust,'no')
    specs1.kopt(2)=1;
elseif strcmp(TreeAdjust,'yes')
    specs1.kopt(2)=2;
else
    error('Adjustment of tree-ring series must be ''yes'' or ''no''');
end

% Pearson or Spearman
if strcmp(rMeth,'Pearson')
    specs1.kopt(3)=1;
elseif strcmp(rMeth,'Spearman')
    specs1.kopt(3)=2;
else
    error('Correlation method must be ''Pearson'' or ''Spearman''');
end

% Handling of autocorrelation
if strcmp(acHandle,'Monte Carlo')
    if specs1.kopt(3)==1
        specs1.kopt(3)=3;
    elseif specs1.kopt(3)==2
        specs1.kopt(3)=4;
    else
        error('Cannot get here')
    end
elseif strcmp(acHandle,'none')
    % no change to specs1.kopt(3)
else
    error('Autocorrelation handling must be ''Monte Carlo'' or ''none''');
end


%--- specs for Monte Carlo simulations
if specs1.kopt(3) ~=3 && specs1.kopt(3)~=4
    specs1.SimExact=[];
else
    prompt = {'Number of exact simulations)',...
        'Decimal fraction of series ( both ends) to taper',...
        'Normality before simulation (assume or transform)',...
        'Scale simulations (yes or no)',...
        'Quality control graphics from pdgmsim (yes or no)'};
    title = 'Specifications for Monte Carlo significance';
    dims = [1 ];
    definput = {'10000','0.10','assume','yes','no'};
    a = inputdlg(prompt,title,dims,definput);
    specs1.SimExact.nsims=str2num(a{1});
    specs1.SimExact.mtaper=str2num(a{2});
    
    
    % Normality
    spectemp=a{3};
    if strcmp(spectemp,'assume')
        specs1.SimExact.knorm=1;
    elseif strcmp(spectemp,'transform')
        specs1.SimExact.knorm=2;
    else
        error('Normality before simulation must be ''assume'' or ''transform''')
    end
    
    % scaling
    specs1.SimExact.kopt_pdgmsim=[nan nan];
    spectemp=a{4};
    if strcmp(spectemp,'yes')
        specs1.SimExact.kopt_pdgmsim(1)=1;
    elseif strcmp(spectemp,'no')
        specs1.SimExact.kopt_pdgmsim(1)=2;
    else
        error('Scale simulations must be ''yes'' or ''no''')
    end
    
     % graphics from pdgmsim
    spectemp=a{5};
    if strcmp(spectemp,'yes')
        specs1.SimExact.kopt_pdgmsim(2)=2;
    elseif strcmp(spectemp,'no')
        specs1.SimExact.kopt_pdgmsim(2)=1;
    else
        error('Quality control graphics from pdgmsim must be ''yes'' or ''no''')
    end
end

Rb=corrtrach01(datin1,specs1);



%--- COLOR MAP

dtype=specs.datatype;
Rc=trachmap2(dtype,treev,filetree,Ra,Rb,fdims,colmap,cLo,cHi);

end
