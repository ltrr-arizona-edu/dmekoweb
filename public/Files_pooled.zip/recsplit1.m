function stats=recsplit1(datin)
% recsplit1:  split-sample calibration and validation of an MLR model
% stats=recsplit1(datin);
% Last revised 2019-08-27
%
% Split-sample calibration and validation of an MLR model. 
% Assumes you have specified predictors beforehand. You want to test how well 
% a model calibrated on those predictors on half the record succeeds in predicting for
% the other half. This function fits the regression model to three periods.  
% Typically these are the 1) full period, 2) first half, 3) second half.   The model 
%  fit to the full period can be used to double check the regression you may have done outside
% this function. WARNING. If you have used the full period of data to
% identify the predictors, this is psuedo-validation, because you have
% already screened predictors to favor a significant relationship in both
% sub-periods.
%
%*** INPUT
%
% datin: structure with input data and specifications for modeling
%   .X (mX x nX)r  matrix from which predictors are drawn
%   .yrX (mX x 1)i year vector for X
%   .y (my x 1)r   vector of predictand
%   .yry (my x 1)i   year vector for y
%   .yrsplit(3 x 2)i  first and last years
%       row 1:  full-calibratio period
%       row 2:  first sub-period for calibration
%       row 3:  second sub-period for calibration
%   .inmodel (1 x ?)i  index pointer to cols of X identifying which variables of the nX
%       are to be used as predictors
%   .Xlab {1 x nX}s    labels for the columns of X
%   .kopt(1 x 1)i  option for graphics
%       ==1 no graphics
%       ==2 3 figures summarizing split-sample validation
%    .jFig1(1x1)i  either empty (means "1") or figure number to start with
%
%
%*** OUTPUT
%
% stats: structure with regression results; fields are defined in field
% stats.define.  Search code below for "stats.define" to see the
% definitions.
%
%
%*** REFERENCES -- NONE
%
%*** UW FUNCTIONS CALLED
% [mae,rmse,re]=rederr(ybarc,ybarv,yhat,y)
%*** TOOLBOXES NEEDED
%
%*** NOTES
%
%
%



%--- CHECK INPUT

% X and y
X=datin.X;
yrX=datin.yrX;
y=datin.y;
yry=datin.yry;
[mX,nX]=size(X);
[mtemp,ntemp]=size(yrX);
if ntemp ~= 1 | mtemp ~= mX;
    error('yrX must be year vector same row size as X');
end;
[my,ny]=size(y);
[mtemp,ntemp]=size(yry);
if ntemp ~= 1 | mtemp ~= my;
    error('yry must be year vector same row size as y');
end;

jFig1=datin.jFig1;

% inmodel
inmodel=datin.inmodel;
[mtemp,ntemp]=size(inmodel);
if mtemp ~= 1;
    error('inmodel must be row vector');
end;
if   inmodel<1 | inmodel>nX;
    error('inmodel elements cannot be larger than col size of X, or less than 1');
end;


% yrsplit
yrsplit =datin.yrsplit;
[mtemp,ntemp]=size(yrsplit);
if mtemp ~= 3 | ntemp ~= 2;
    error('yrsplit not 3 x 2');
end;
if any(yrsplit(:,1)<max([yry(1) yrX(1)]));
    error('One of the start years in yrsplit too early for X and y');
end;
if any(yrsplit(:,2)>min([yry(end) yrX(end)]));
    error('One of the end years in yrsplit too late for X and y');
end;
if yrsplit(2,2)>= yrsplit(3,1);
    error('End year of first period must be before start year of second');
end;
if yrsplit(2,2)<= yrsplit(2,1) |  yrsplit(3,2)<= yrsplit(2,1) | yrsplit(1,2)<= yrsplit(1,1);
    error('End year of some period in yrsplit is not later than the start year');
end;
if yrsplit(1,1)> yrsplit(2,1)  |  yrsplit(1,2)<yrsplit(3,2);
    error('Split sample periods must be within full period');
end;


% Xlab
Xlab = datin.Xlab;
if size(Xlab,2) ~= nX;
    error('Xlab length must be same as col size of X');
end;
if ~iscell(Xlab);
    error('Xlab not a cell');
end;
xlab = Xlab(inmodel);


% option
kopt = datin.kopt;


% Assemble series to be used
L = yrX>= yrsplit(1,1) & yrX<= yrsplit(1,2);
xf = X(L,inmodel);
yrxf =yrX(L);
if any(any((isnan(xf))));
    error('Some X in full period NaN');
end;
L = yrX>= yrsplit(2,1) & yrX<= yrsplit(2,2);
xa = X(L,inmodel);
yrxa =yrX(L);
if any(any((isnan(xa))));
    error('Some X in early period NaN');
end;
L = yrX>= yrsplit(3,1) & yrX<= yrsplit(3,2);
xb = X(L,inmodel);
yrxb =yrX(L);
if any(any((isnan(xb))));
    error('Some X in late period NaN');
end;


L = yry>= yrsplit(1,1) & yry<= yrsplit(1,2);
yf = y(L);
yryf =yry(L);
if any(any((isnan(yf))));
    error('Some y in full period NaN');
end;
L = yry>= yrsplit(2,1) & yry<= yrsplit(2,2);
ya = y(L);
yrya =yry(L);
if any(any((isnan(ya))));
    error('Some y in early period NaN');
end;
L = yry>= yrsplit(3,1) & yry<= yrsplit(3,2);
yb = y(L);
yryb =yry(L);
if any(any((isnan(yb))));
    error('Some y in late period NaN');
end;




%-------- ALLOCATE

rmse = repmat(NaN,3,2);
R2RE = repmat(NaN,3,2);
nfull=length(yrxf);
D = repmat(NaN,nfull,6);
D(:,1)=yf;
yrD = (yrsplit(1,1):yrsplit(1,2))'; 



%---------- FULL PERIOD ANALYSIS

v = yf;
U = [ones(nfull,1) xf]; 
[b,bint,r,rint,s] = regress(v,U,.05) 
R2RE(1,1)=s(1);
yfhat = U*b;
D(:,2)=yfhat;

e = yf-yfhat;
ss = sum(e .* e);
mse = ss / (nfull-length(inmodel)-2);
rmse(1,1)=sqrt(mse);

evf = nan(length(yf),1); % to hold combined validation residuals from first and last halves

%--------  CALIBRATE EARLY, VALIDATE LATE

v = ya;
nsize=length(yrya);
U = [ones(nsize,1) xa]; 
[b,bint,r,rint,s] = regress(v,U,.05) 
R2RE(2,1)=s(1);
yahat = U*b;
L=yrxf>=yrsplit(2,1) & yrxf<= yrsplit(2,2);
D(L,3)=yahat;

nsz = length(yryb);
UU = [ones(nsz,1) xb];
yhatver = UU * b; % validation predictions for second alf
L=yrxf>=yrsplit(3,1) & yrxf<= yrsplit(3,2);
D(L,4)=yhatver;
evf(L)=yf(L)-yhatver;

e = ya-yahat;
ss = sum(e .* e);
mse = ss / (nsize-length(inmodel)-2);
rmse(2,1)=sqrt(mse);

ybarc = mean(v); % calib period mean of actual predictand
ybarv = mean(yb); % verif period mean of actual predictant
yhat =  yhatver; % predicted for the verif period
y= yb;  % observed predictand for verif period

[zmae,zrmse,zre]=rederr(ybarc,ybarv,yhat,y);
rmse(2,2)= zrmse(2);
R2RE(2,2)=zre(1);

stats.rmse=rmse;
stats.R2RE = R2RE;
stats.D = D; 


%--------  CALIBRATE  LATE, VALIDATE EARLY

v = yb;
nsize=length(yryb);
U = [ones(nsize,1) xb]; 
[b,bint,r,rint,s] = regress(v,U,.05) 
R2RE(3,1)=s(1);
ybhat = U*b;
L=yrxf>=yrsplit(3,1) & yrxf<= yrsplit(3,2);
D(L,5)=ybhat;

nsz = length(yrya);
UU = [ones(nsz,1) xa];
yhatver = UU * b;
L=yrxf>=yrsplit(2,1) & yrxf<= yrsplit(2,2);
D(L,6)=yhatver;
evf(L)=yf(L)-yhatver;

rmse(1,2)=sqrt((sum(evf .* evf))/length(evf));

e = yb-ybhat;
ss = sum(e .* e);
mse = ss / (nsize-length(inmodel)-2);
rmse(3,1)=sqrt(mse);

ybarc = mean(v); % calib period mean of actual predictand
ybarv = mean(ya); % verif period mean of actual predictant
yhat =  yhatver; % predicted for the verif period
y= ya;  % observed predictand for verif period

[zmae,zrmse,zre]=rederr(ybarc,ybarv,yhat,y);
rmse(3,2)= zrmse(2);
R2RE(3,2)=zre(1);

% Optional graphics
if kopt(1)==2;
    
    % Full period
    str1 = ['R^2=' num2str(R2RE(1,1))];
    figure(jFig1); % Full period observed and reconstructed
     [cL,cB,cW,cH]=figsize(.7,.6);
    set(gcf,'Position',[cL cB cW cH]);
    hp1 = plot(yrD,D(:,1),'-o',yrD,D(:,2),'-^');
    set(hp1(2),'Color',[ 1 0 0]);
    xlims=get(gca,'XLim');
    line(xlims,[ybarc ybarc]);
    xlabel('Year');
    legend('Observed','Predicted');
    grid;
    zoom xon;
    title(['Full-Period Model; '  str1]);
    
    % Calib on A, validation on B
    str1 = ['R^2=' num2str(R2RE(2,1))];
    str2 = ['RE=' num2str(R2RE(2,2)) ];
    
    figure(jFig1+1);
    [cL,cB,cW,cH]=figsize(.7,.6);
    set(gcf,'Position',[cL cB cW cH]);
 
    % Top
    subplot(2,1,1);
    hp2a = plot(yrD,D(:,1),'-o',yrD,D(:,3),'-^');
     set(hp2a(2),'Color',[ 1 0 0]);
    xlims=get(gca,'XLim');
    line(xlims,[mean(ya) mean(ya)]);
    xlabel('Year');
    legend('Observed','Predicted');
    grid;
    zoom xon;
    title(['Calibration on Period A; '  str1]);
    % Bottom
    subplot(2,1,2);
    hp2b = plot(yrD,D(:,1),'-o',yrD,D(:,4),'-^');
    set(hp2b(2),'Color',[ 1 0 0]);
    xlims=get(gca,'XLim');
    line(xlims,[mean(ya) mean(ya)]);
    xlabel('Year');
    legend('Observed','Predicted');
    grid;
    zoom xon;
    title(['Validation on Period B; '  str2]);
    
    % Calib on B, validation on A
    str1 = ['R^2=' num2str(R2RE(3,1))];
    str2 = ['RE=' num2str(R2RE(3,2)) ];
    
    figure(jFig1+2);
    [cL,cB,cW,cH]=figsize(.7,.6);
    set(gcf,'Position',[cL cB cW cH]);
    % Top
    subplot(2,1,1);
    hp3a = plot(yrD,D(:,1),'-o',yrD,D(:,5),'-^');
     set(hp3a(2),'Color',[ 1 0 0]);
    xlims=get(gca,'XLim');
    line(xlims,[mean(yb) mean(yb)]);
    xlabel('Year');
    legend('Observed','Predicted');
    grid;
    zoom xon;
    title(['Calibration on Period B; '  str1]);
    % Bottom
    subplot(2,1,2);
    hp3b = plot(yrD,D(:,1),'-o',yrD,D(:,6),'-^');
     set(hp3b(2),'Color',[ 1 0 0]);
    xlims=get(gca,'XLim');
    line(xlims,[mean(yb) mean(yb)]);
    xlabel('Year');
    legend('Observed','Predicted');
    grid;
    zoom xon;
    title(['Validation on Period A; '  str2]);
    
    
end;
    
%-- Compute a RMSEv from the combined validation residuals of first half
% and second halve


stats.rmse=rmse;
stats.R2RE = R2RE;
stats.D = D; 
stats.yrD = yrD;
stats.splits = yrsplit;

% stats.define
w =['Created by call to recsplit1.m on ' datestr(date)];
w=char(w,'D -- time series of predictand; columns are :');
w=char(w,'  1 observed ');
w=char(w,'  2 predictions from model calibrated on full period');
w=char(w,'  3 predictions for period A from model calibrated on A');
w=char(w,'  4 predictions for period B from model calibrated on A');
w=char(w,'  5 predictions for period B from model calibrated on B');
w=char(w,'  6 predictions for period A from model calibrated on B');
w=char(w,'yrD - year vector for D');
w=char(w,'rmse -- root mean square error. Col 1 is for calibration columnn 2 for validation');
w=char(w,'  row 1: for full-period model (col 2 is NaN because full model not validated');
w=char(w,'  row 2: for calibration on period A and validation on period B');
w=char(w,'  row 3: for calibration on period B and validation on period A');
w=char(w,'R2RE -- R-squared of calibration (col 1) and RE of validation (col 2)');
w=char(w,'  row 1: for full-period model (col 2 is NaN because full model not validated');
w=char(w,'  row 2: for calibration on period A and validation on period B');
w=char(w,'  row 3: for calibration on period B and validation on period A');
w=char(w,'splits: 3 x 2 matrix giving start and end years of :');
w=char(w,'  row 1: full period');
w=char(w,'  row 2: split-period A');
w=char(w,'  row 3: split-period A');
stats.define=w;
