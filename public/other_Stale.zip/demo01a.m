% demo01a -- operate on fig
%
% Illustrate use of Handle Graphics to edit a figure that had previously
% been generated and saved as .fig.
%
% Had saved figure window 11 from script Tsp_examples, as file a.fig
% This is a time series of snow course SWE


clear all;
close all;
clc;


hgload a; % loads the fig file; it appears as Figure window 1

h = gcf; % get current figure; assigns handle h

h1 = get(gcf,'Children'); % handle to any children of Figure 1; happens that the only
% child here is a set of axes


% ---- change axis limits

h1.XLim % gives the x-axis limits 
h1.XLim=[1950 1980] ;%  changes the x-axis


% --- Change color of the line in the plot

h2 = get(h1,'Children'); % get children of the axes

% turns out that h1 has 2 children. h2(1) is text, and h2(2) is the line

h2(2).Color=[1 0 0];  % change line to red


%--- Save the revised figure as file aRevised.png

savefig a1;
print ('a1','-dpng'); % saves the figure in png format. Could alternatively
   % save in other graphics formats (see help print)

