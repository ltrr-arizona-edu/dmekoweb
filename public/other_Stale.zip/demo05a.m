% demo05a -- simulate a time series using and AR model 
%
% Load a time series from V1, V2 or V3 data (hard coded decision)
% Plot the series and its acf
% Fit an AR(1) or AR(2) (hard coded decision) model to the time series
% Simulate the time series with the fitted model
% View plots of simulations and original series
% Simulations remain in workspace in matrix S


%---CLEAN SLATE

clear all;
close all;
clc;


%---- GET THE TIME SERIES


iwant = 4; % want thi column from the tsm of V1, V2 or V3 data

load Spring19;
idy = V1.id{iwant}; % get series id
y = V1.tsm(:,iwant); % get the time series -- col iwant in V2.tsm
yry = V1.time; % year vector


%---- TRIM OFF ANY LEADING AND TRAILING NAN AND USE JUST A SUB-PERIOD OF THE
%DATA FOR MODELING

L=~isnan(y);
y = y(L);
yry = yry(L);


% Optional code for selecting sub-period of full data for analysis
 L=yry>=1900 & yry<=2016 ; 
 y = y(L);
 yry=yry(L);


%-- COMPUTE SAMPLE MEAN AND STANDARD DEVIATION

ymean = mean(y);
ystd = std(y);


%---- BUILD SOME LABELS

strnm = ['Onion Creek Incense Cedar, ' idy(1:4)];
stryrs = [num2str(yry(1))  '-' num2str(yry(end))];
strmean = 'Mean';



%---- TIME PLOT

figure(1)

dely = (max(y)-min(y))/10; % increment that is 1/10 the range of y
ylims =[min(y)-dely  max(y)+dely]; %  want this as range of y axis
xlims =[yry(1)-1 yry(end)+1]; % and this for x axis range

h = plot(yry,y,xlims,[ymean ymean]);
set(h,'Marker','o')
xlabel('Year');
ylabel('Index');
legend('Tree Ring','Mean')
set(gca,'YLim',ylims,'XLim',xlims); % restrict range of axes on plot
title(strnm)


%--- PLOT OF ACF

figure(2)
[r,SE2,r95]=acf(y,20,[2 1]); 
rlag1=r(1); % first-order autocorrelation
nsize=length(y); % length of tree-ring series



%--- FIT AN AR(1) MODEL TO TIME SERIES

y1 = y - ymean; % subtract sample mean
Ts = 1; % time step
data1 = iddata(y1,[],Ts); % create data object (see help iddata in Matlab)
mod1 = ar(y1,1); % fit AR(1) model; saves a "model object" mod1
evar = get(mod1,'NoiseVariance'); % get the variance of the model residuals from the fit



%--- SIMULATE

nsim = 5; % say want 5 simulations
S = nan(nsize,nsim); % allocate matrix to store simulations

for n = 1:nsim; % loop over simulations
    ysim = sim(mod1,data1,'Noise'); % call system identification toolbox function
    % next statement lists the standard deviation of the series and of the
    % simulation in the command window
    [std(y1) std(ysim.OutputData)]
    S(:,n)=get(ysim,'OutputData'); % store current simulation
        
end
S = S+ymean; % restore the mean to simulations


%---- TIME PLOT OF TREE-RING INDEX AND SIMULATIONS

figure(3);
[cL,cB,cW,cH]=figsize(.3,.8);
set(gcf,'Position',[cL cB cW cH]);

% Find some min and max y-axis value that will enclose all simulations and
% and the observed series
xlow = min(min(S)); % lowest value in any simulation
xlow = min([xlow min(y)]); % lowest of that and the minimum observed value
xhi = max(max(S));
xhi = max([ xhi max(y)]);

xlims = [yry(1)-1 yry(end)+1]; % want the x-axis to range from just beyond to just beyond years of data

subplot((nsim+1),1,1); % want a multi-row matrix of plots

% plot the observed series
h = plot(yry, y, xlims,[ymean ymean]);
set(h,'Marker','o','Markersize',3)

xlabel([]);
ylabel('Index')
set(gca,'XLim',xlims,'Ylim',[xlow xhi],'XTickLabel',[]);
textcorn('Observed','UR',0.01, 0.01, 10);

% Plot the simulations

for n = 1:nsim;
    subplot((nsim+1),1,n+1);
    txt1 = ['Sim #' num2str(n)];
    
    hp = plot(yry,S(:,n),xlims,[ymean ymean]);
    set(hp,'Marker','o','Markersize',3)
    set(gca,'Xlim',xlims,'YLim',[xlow xhi])
    if n ~= nsim;
        xlabel([]);
        set(gca,'XTickLabel',[]);
    else
        xlabel('Year');
    end
    textcorn(txt1,'UR',0.01,0.01,10)
end

% Cut and paste next command at commend prompt to see acf of simulation 
% [r,SE2,r95]=acf(y,15,[2 1]); % acf if observed series
% [r,SE2,r95]=acf(S(:,2),15,[2 1]); % acf of second simulations (in tsm S)