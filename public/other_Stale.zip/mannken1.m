function Result=mannken1(x,t,kopt)
% mannken1: Mann-Kendal nonparametric test for trend in time series
% Result=mannken1(x,t,kopt)
% Last revised 2019-01-17
%
% Mann-Kendal nonparametric test for trend in time series. Optional
% plots of original series, trend line, and detrended series.
%
%*** INPUT ARGUMENTS
%
% x (mx x 1) time series, length m
% t  (mx x 1) time vector   (must increment by 1)
% kopt (1x1)i options
%   kopt(1): graphics plots of time series, trend line, and detrended series
%       ==1  skip plotting
%       ==2  plot, followed by pause
%
%*** OUTPUT ARGUMENTS
%
% Result: structure
%    .statistic: Mann-Kendal statistic (see Notes)
%    .pvalue:  p-value for two-tailed null hypothesis of no trend
%    .ngrp: number of groups of ties
%    .nties: total number of ties
%    .Lflag (1x1)L   flag
%        (1) inadequate sample size (need 10 or more obs)
%             ==T:   sample size too small
%             ==F:   sample size not too small
%    .b (1x1)r  slope (nonparametric estimate)
%    .a (1x1)r  intercepts ...
%    .xhat (mx x 1)r   trend line
%    .xdetrended (mx x 1)r   detrended x
%
%*** REFERENCES
%
% Haan, C. T. (2002), Statistical Methods in Hydrology, 
%   second ed., Iowa State University Press, 496 pp.
% Helsel, D. R., and R. M. Hirsch (1992), Statistical Methods 
%   in Water Research, Elsevier, Amsterdan, The Netherlands.
% Salas, J. D. (1992), Analysis and modeling of hydrologic
%   time series, in Handbook of Hydrology, edited by D. R. 
%   Maidment, chap. 19, pp. 1–72, McGraw-Hill, Inc., New York.
%
%
%*** UW FUNCTIONS CALLED 
% ties1
%
%*** TOOLBOXES NEEDED -- none
%
%
%*** NOTES  
% 
% If time series has fewer than 10 observations, Result.Lflag(1)==T, and
% all other fields set to [].
%
% A special case is s=0 (see below). This essentially means no slope. The
% following setting are then specified:
%   Result.statistic =0;
%   Result.pvalue=Nan; Result.a=NaN; Result.b=NaN; Result.xhat=NaN;
%   Result.xdetrended = NaN
%
% This is a two-tailed test. H0 is no trend. A small p-value indicates
% reject H0.  For example, if p-value==0.09, we reject H0 at alpha=0.10
% level. If p-value==0.0499, we reject H0 at alpha=0.05.  
%
% Handling of ties follows Salas(1993)
%
% Nonparametric trend line fit following equations in Haan (2002). The
% detrended series Result.xdetrended is shifted such that has same median
% as input series x. 
%
% Test data from Haan (2002) used to originally check results
% x =[25.56 33.28 34.03 35.72 39.33 32.21 30.76 44.45 45.52 42.69]';
% t = (1978:1987)';
%




% Hard Code
%

if ~all(diff(t)==1)
    error('Time vector does not increment by 1')
end
    


N = length(x);

if N<10
    Result.Lflag(1)=true;
    Result.statistic=[];
    Result.pvalue=[];
    Result.ngrp-[];
    Result.nties=[];
    Result.a=[];
    Result.b=[];
    Result.xhat=[];
    Result.xdetrended=[];
    return
else
    Result.Lflag(1)=false;
end

A = repmat(x,1,N); % col-dupe the time series
B=repmat(x',N,1); % obs 1 in col1, obs 2 in col 2, ets
C=A-B;
D = tril(C,-1); % everything above diag set to 0

D(1,:)=[];
D(:,end)=[];

Lp=D>0;
Ln = D<0;
Lz=D==0;

E=D;
E(Lp)=-1;
E(Ln)=1;
E(Lz)=0;

s1=sum(E);
s = sum(s1);

%  Handle ties
T=ties1(x); % structure
if  isempty(T.ngroups)
    vties=0;
    Result.ngrp=0;
    Result.nties=0;
else
    ng =T.ngroups;  % number of groups of ties
    Result.ngrp=ng;
    Result.nties = sum(T.nties);
    w = 0;
    for n = 1:ng
        e = T.nties(n);
        h = e*(e-1)*(2*e+5);
        w=w+h;
    end
    vties=w;
end

if s>0
    m=-1;
elseif s<0
    m=1;
else
    Result.statistic=0;
    Result.pvalue=NaN;
    Result.a=NaN;
    Result.b=NaN;
    Result.xhat=NaN;
    Result.xdetrended=NaN;
    return
end

v=([N*(N-1)*(2*N+5)]-vties)/18;

u=(s+m)/sqrt(v);

w = normcdf(abs(u),0,1);
Result.pvalue =2*(1-w);


%--- NONPARAMETRIC TREND LINE
% Haan 2002, p. 345

N1=N-1;
k=(1:N1)';
k=(flipud(k))';
K=repmat(k,N1,1);

N2=N-2;
j = (N2:-1:0)';
J=repmat(j,1,N1);

H=K-J;
Q=tril(D,0) ./ tril(H,0);

b =nanmedian(Q(:));
tmed = median(t);
a=median(x)-b*tmed;

if b<0;
    bb =' - ';
else
    bb=' + ';
end
eqn1 = ['Fitted line: ' num2str(a) bb num2str(b) 't'];

Result.a=a;
Result.b=b;

xhat = a+b*t;
xdetrended = x-xhat;

% Shift detrended to have same median as original
xmed1 = median(xdetrended);
xmed2 = median(x);
d1= xmed1-xmed2;
xdetrended=xdetrended-d1;

Result.xhat=xhat;
Result.xdetrended = xdetrended;

if kopt(1)==1
else
    figure(1);
    subplot(2,1,1)
    h = plot(t,x,'-o',t,xhat,'-*');
    xlabel('time');
    ylabel('value')
    legend('Series','Trend line')
    title(eqn1)
    
     subplot(2,1,2)
    h = plot(t,x,'-o',t,xdetrended,'-^');
    xlabel('time');  ylabel('value')
    legend('Series','Detrended')
    title('Detrended shifted to same median as original series')
    pause
end
