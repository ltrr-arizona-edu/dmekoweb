% demo09a    dependence of correlation on level of one time series
%
%
% Show use of functions scatter01.m and corrdiff
%
% Test whether the correlation between red fir standard chronology and mountain
% hemlock standard chronology at Carpenter Ridge, CA, differs between high-growth 
% low-growth years in the hemlock chronology 


% Statify observations into terciles, using sorted x(t)
% Scatterplots of y(t) on x(t) for the three terciles of x data
% Compute correlation coefficients and significance assuming population
%   correlaton of zero
% Use function corrdiff.m to test for significance of the difference of the
%   correlations for the lowest tercile and highest tercile years of x

%--- CLEAN HOUSE

close all;  % close all figure windows
clear; % clear all variables from workspace
clc; % clear the command window


%------  LOAD FILE WITH TIME SERIES

load Spring19; % load storage file
i1=10; % V1 series x variable
i2=11; % V1 series y variable
t=V1.time; % store time vector
x=V1.tsm(:,i1); % store series 2 from the time series matrix-
idx = V1.id{i1}; % store series label
y=V1.tsm(:,i2); % store series 6 from the time series matrix-
idy = V1.id{i2}; % store series label
uy = ['(' V1.units{i2} ')'];
ux = ['(' V1.units{i1} ')'];
Ly = ['(' V1.label{i2} ')'];
Lx = ['(' V1.label{i1} ')'];


%-------  RESTRICT DATA BY CULLING ONLY THE VALID PART (NOT-NAN)

L=~isnan(x);  % logical pointer to valid data
x=x(L);  % desired data
tx=t(L); % desired time vector
Nx=length(x); % store sample length as N

L=~isnan(y);  % logical pointer to valid data
y=y(L);  % desired data
ty=t(L); % desired time vector
Ny=length(y); % store sample length as N


%---- TRIM TIME SERIES TO COMMON PERIOD

tgo = max([min(tx(1)) min(ty(1))]); % start time (year)
tsp = min([max(tx(end)) max(ty(end))]); % end time (year)

L = tx>=tgo & tx<=tsp;
x=x(L);
tx=tx(L);


L = ty>=tgo & ty<=tsp;
y=y(L);
ty=ty(L);
N= length(y); % length of series

yrgo =tx(1);
yrsp = tx(end);

m1=yrsp-yrgo+1;


prompt={'Enter start and end years:'};
name='Analysis period';
numlines=1;
defaultanswer={[num2str(yrgo) ' ' num2str(yrsp)]};

answer=inputdlg(prompt,name,numlines,defaultanswer);
a=str2num(answer{1});


yrgo=a(1);
yrsp=a(2);

L = tx>=yrgo & tx<=yrsp;
x=x(L);
tx=tx(L);


L = ty>=yrgo & ty<=yrsp;
y=y(L);
ty=ty(L);
N= length(y); % length of series

tgo =yrgo; tsp = yrsp;


%--- TIME PLOTS

xlims=[tgo tsp];
figure(1)
subplot(2,1,1);
h = plot(tx,x,'-o',[tx(1) tx(end)],[mean(x) mean(x)]);
xlabel('Year');
ylabel([Lx ux])
set(gca,'Xgrid','on','XLim',xlims)
title(['Time plots of ' idx ' (top) and ' idy ' (bottom) with long-term means'])

subplot(2,1,2);
h = plot(ty,y,'-o',[ty(1) ty(end)],[mean(y) mean(y)]);
xlabel('Year');
ylabel([Ly uy]);
set(gca,'Xgrid','on','XLim',xlims)



%------  SET UP UINF INPUT FOR CALL TO SCATTER01

uinf{1} = {idx,idy}; % series ids
uinf{2}={V1.label{i1},V1.label{i2}};
uinf{3}={V1.units{i1},V1.units{i2}};
uinf{4} = {'Year'};
uinf{5}=[];



%-- FUNCTION CALL FOR SCATTERPLOTS


figure(2)
S=scatter01(x,y,tx,ty,uinf);



%--- MESSAGE BOX TO REMIND FOLLOW-UP TEST
str1 = {'Test the difference of r, high tercile vs low tercile,',...
    'using function corrdiff, which has call ',...
    'Result=corrdiff(r1,r2,n1,n2);'};
 uiwait(msgbox(str1,'Message--str1','modal'));
 
 
 %---- CODE SUGGESTIONS FOR FOLLOW-UP TEST
 %  Already have in workspace x and y for common period tgo to tsp
 %  Identify observations with lowest tercile of x using function prctile
 %  Pull that subset of observations into new variables x1, y1
 %  Compute the correlation between x1 and y1 using function corrcoef-->r1
 %  Repeat previous three steps for highest tercile and store correlation as r2
 %  Use function "length" to get sizes of x1  and x2 and store as n1, n2
 %  Make the call to corrdiff
 
