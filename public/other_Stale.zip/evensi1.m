function [y,t]=evensi1(x,t,tgo,tstep,kmeth)
% [y,t]=evensi1(x,t,tgo,tstep,kmeth);
% evensi1:  evenly sample an unevenly sampled time series
% Last revised 2017-01-26
%
% Evenly sample an unevenly sampled time series.
% 
%
%*** INPUT : Coded so far only for xlsx input. Ignore for now the input
% and output arguments. Function produces and xlsx file with the resampled
% time 
%
% x (mX x 1)r time series matrix, sampled at times t
% t (mt x 1)i  time of samples in x
% tgo (1x1) desired time of sample # 1 in evenly sampled data (will be
%   assigned to t==1 in output
% tstep (1x1) desired interval of output series
% kmeth(1x1)i  method
%   ==1 cubic interpolating spline, using Matlab function csaps
%   ==2 linear interpolation, using Matlab function resample applied to
%       "time series object"
%
%
%*** OUTPUT
%
%  y (mY x 1)r time series matrix at constant sampling interval
%  t1 (mY x 1)i integer numbered samples in Y
%  t2 (mY x 1)r corresponding times in t1 in time units of input t
%  
% xlsx file: resample times in cols 1 and 2; interpolated data in col 3.
% col 1 is resample time in original units
% col 2 is sequentially numbered time starting with 1 and incrementing by 1
%
%
% xlsx file is produced, with time increasing downward, at specified
% sample spacing. Output xlsx filename coded to indicate method:
%   ..._revisedA_    cubic interpolating spline
%   ..._revisedB_    linear interpolation
%
%
%*** UW FUNCTIONS CALLED 
%
% none
%
%*** TOOLBOXES NEEDED 
%
% curve fitting: csaps
%
%
%*** NOTES
%
% Interpolating spline is fit to X, t
% values at t1 (t2) are interpolated from the spline
%
% Beware that interpolation to longer time steps than the originall data
% can result in smoothing, and that interpolation to shorter time steps can
% result in extremes "more extreme" than in the original data
%
% Time series is reversed if needed so that time increases downward (most
% recent time at bottom) in output xlsx file. Depending on whether or not
% original time variable was in the form of "years ago", the new sample
% times in the output xlsx might be reversed in sign. The first column of
% that xlsx has those new sample "times", the second column has the ordinal
% time numbers (1 as earliest, 2 as next earlierst, etc.). Remaining
% columns have the resampled time series.

%--- OPTIONAL INPUT VARIATIONS IF NO INPUT ARGUMENTS

fclose all;

if nargin==0
    ftypes={'.mat','xlsx','.txt'};
    
    [filename, pathname, filterindex] = uigetfile( ...
        {'*.mat','MAT-files (*.mat)'; ...
        '*.xlsx','spreadsheet (*.xlsx)'; ...
        '*.txt',  'Ascii text (*.txt)'}, ...
        'Pick a file');
    
    ftype=ftypes{filterindex};
    
    
    pf = fullfile(pathname,filename);
    if strcmp(ftype,'xlsx')
        [A,B]=xlsread(pf);
    else
        error('File type xlsx only type allowed so far');
    end
else
    error('So far coded for just point and click, without input and output arguments')
end


%--- METHOD ?

methods1={'Cubic interpolating spline','Linear interpolation'};
methcodes={'A','B'};
if nargin==0
    kmeth = menu('Choose method for resampling',methods1);
    method1 = methods1{kmeth};
    methcode= methcodes{kmeth};
    
else
end


%--- TIME SHOULD BE FIRST COLUMN

t=A(:,1);


%--- PROMPT FOR DATA FROM ONE OF THE OTHER COLS

b=B(2:end); % the headings, with time heading deleted
kmen1 = menu('Choose series',b);
jcol = kmen1+1; % column of selected data
x=A(:,jcol);


%--- TRIM OFF ANY LEADING AND TRAILING NANS
[x,t]=trimnan(x,t);


%--- CHECK THAT NO CONSECUTIVE TIMES ARE THE SAME;
d=diff(t);
if any(d==0) 
    error('Some consective input times are the same');
end;


%  CHECK THAT TIME CHANGE IS MONOTONIC
if  ~(all(d>0) || all(d<0))
    error('Time change not monotonic');
end


%--OPTIONAL FLIPPING OF DATA SO THAT LAST VALUE IN MATRIX OR VECTOR IS MOST
% (NECESSARY FOR TIME SERIES ANALYSIS TO MAKE SENSE)

str_recent = num2str(t(end));
quest1 = questdlg(['Is ' str_recent ' the most recent ''time'' in your input data?']);
if strcmp(quest1,'Yes')
    if all(d>0)
    else
        t = -1.0 * t; 
    end
else
    x = flipud(x);
    t = flipud(t);
    if all(diff(t)>0)
    else
        t = -1.0*t; % input times probably in "yrs ago'
    end
end


%--- FIND RANGE OF TIME STEPS

d=diff(t);
maxd = max(d);
mind = min(d);



%--- PLOT TIME SERIES, BEFORE RESAMPLE

% String to tell range in tme step
str1 = ['Original data; time-step ranges from ' num2str(mind) ' to ' num2str(maxd) ' time units; time from ' num2str(t(1)) ' to ' num2str(t(end))];

figure(1);
h = plot(t,x,'-');
if length(t)<100
    set(h,'Marker','o');
end
title(str1);

h1 = num2str(t(1));
h2 = num2str(maxd);
 

%--- PROMPT FOR START AND TIME STEP FOR RESAMPLE

prompt={'Enter start time:','Enter increment:'};
name='Settings for re-sampling';
numlines=1;
defaultanswer={h1,h2};

answer=inputdlg(prompt,name,numlines,defaultanswer);

tgo = str2num(answer{1});
tinc = str2num(answer{2});
t2=[tgo: tinc: t(end)]'; % desired resample times
t1 = [1:length(t2)]';

%--- RESAMPLE

if kmeth==1 % cubic interpolating spline
    y=csaps(t,x,1,t2) ; % resample
elseif kmeth==2 % linear interpolation, after conversion to time series object
    ts = timeseries(x,t); % creates the object; type ts at command prompt
    ts.TimeInfo.Units='Original time units'; % change units from default "seconds"
    ts_res=resample(ts,t2,'linear'); % resample
    y =ts_res.Data;
    
else
end


%---- PLOT THE ORIGINAL AND RESAMPLED DATA

figure(2);
h = plot(t2,y,'-*',t,x,'-o');
set(h(1),'Color',[1 0 0])
set(h(2),'Color',[0 0 1])
title('Original and Resampled Data')
legend('Resampled','Original')


%--- ORGANIZE OUTPUT IN A MATRIX AND WRITE OUTPUT

W=[t2 t1 y];
fname=strtok(filename,'.');
fname1=[fname '_revised' methcode '_' num2str(tgo) '-' num2str(tinc)];

pfout = fullfile(pathname,fname1);

xlswrite(pfout,W);

