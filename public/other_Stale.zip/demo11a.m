% demo11a  demonstrate use interactive stepwise tool and function vif 
%
%
% Specifications and steps for stepwise variable selections
% p-enter and p-remove criteria
% <Added variable plot = Partial regression leverage plot>
% Effect of multicolinearity on parameter estimate
%
%
%
% 1) Specify a predicand series and time series matrix of potential
%     predictors
% 2) Enter the predictors stepwise interactively, viewing effect on 
%    estimated parameters and on predictive power (R-squared and adj
%    R-squared
% 3) View added variables plots to assess possible importance of nonlinearity
%    in multivariate context  
%
%

%---  CLEAR THE TABLE

close all;  % close all figure windows
clear; % clear all variables from workspace
clc; % clear the command window


%------  LOAD FILE WITH TIME SERIES AND ASSIGN PREDICTAND AND POOL OF
%  PREDICTORS

load Spring19; % load storage file




% -- SETUP 1:  y is series #2 from V1: Annual flow of N Fork American
% River


iy=2; % specify that will use a V1 variable for predictand, y
ty=V1.time; % store time vector for y
y = V1.tsm(:,iy); % store predictand


ix = [2 3 4 5  6 7 8 9 10]; % specify that will use 9 April 1 SWE series as X
X=V2.tsm(:,ix); % store potential predictors
tX=V2.time; % store time vector for X
nmX = V2.name(ix);



%-------  TRIM PREDICTOR MATRIX AND PREDICTAND VECTOR TO TIME SEGMENTS
%  WITHOUT MISSING DATA (POSSIBLY TRIM OFF SOME LEADING AND TRAILIG YEARS)

L=isnan(X); % logical matrix, same size as X, with 1 if NaN, 0 if valid data
L = L'; % transpose of L
L1= (any(L))';  % col vector, same row-size as X, with 1 if any of the X are NaN, 0 if all X are valid for the year
X(L1,:)=[];  % removes rows of X containing any NaN
tX(L1) =[]; % likewise trims the vector of years for X

L=isnan(y); % logical col vector, same length as y, with 1 if NaN, 0 otherwise
y(L)=[]; % remove NaNs from y
ty(L) = []; % remove same observations from year vector for y



%-------   QUALITY CONTROL CHECK THAT THE TRIMMED PREDICTORS MATRIX AND
% PREDICTAND MATRIX DO NOT SKIP ANY YEARS (WOULD ONLY DO SO IF THEY HAD
% IMBEDDED NANS)

j = diff(tX); % first difference of year vector for X
if ~(all(j)==1);
    error('tX skips a year');
end;
j = diff(ty); % first difference of year vector for y
if ~(all(j)==1);
    error('tt skips a year');
end;


%----- TRIM PREDICTOR MATRIX AND PREDICTAND TO COMMON TIME PERIOD

yrgo = max([tX(1) ty(1)]); % latest start year of X and y
yrsp = min([tX(end) ty(end)]); % earliest end year of X and y

L = tX>=yrgo & tX<=yrsp; % logical vector, same row-size as X, with 1 if in period yrgo to yrsp, 0 otherwise
X = X(L,:); % pull desired segment of X
tX = tX(L); % and matching years

L = ty>=yrgo & ty<=yrsp; % logical vector, same row-size as y, with 1 if in period yrgo to yrsp, 0 otherwise
y = y(L,:); % pull desired segment of y
ty = ty(L); % and matching years



%------ ADD ANOTHER X VARIABLE THAT IS ONLY SLIGHTLY DIFFERENT THAN ONE OF
% THE X VARIABLES

x= X(:,6);
xstd = std(x);
e = normrnd(0,xstd/20,length(x),1);  % noise with stdev 1/20 that of x
x = x +e;
X=[X x]; % append fake new variable as last column of X



%--------- INITIALIZE INPUT ARGUMENTS AND CALL TO  STEPWISE

[mX,nX]=size(X); % nX is the col-size of X, or the number of predictor series available
inmodel=[];  % initially include NONE of the predictors in the model
alpha1=[0.05]; % critical level for significance of a coefficient for entry
alpha2=0.10;  %... for removal
stepwise(X,y,inmodel,alpha1,alpha2);



