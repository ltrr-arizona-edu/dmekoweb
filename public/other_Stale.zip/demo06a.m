% demo06a -- compute and plot a theoretical AR(1) or AR(2) spectrum
%
% Computes and plots the theoretical spectrum for an AR(1) or AR(2)
% process. User specified the AR parameter values, error variance, and
% sample size.
%
% Check done that specified values of AR parameters consistent with
% stationary process.
%
% Equations for AR spectra given in arspectrum.pdf, after
%
% Reference: Wilks, Daniel S.,  1995.  Statistical methods in the atmospheric sciences.  Academic Press, New York. 467p.
%
% Note that the sign convention for AR parameters follows Matlab (positive
% autocorrelation goes with negative autocorrelation coefficient) rather
% than the convention in Wilks, Chatfield and Box and Jenkins.  So the
% equations in arspectrum.pdf will have some sign changes from those in
% Wilks (1995)
%


%---- CLEAN THE SLATE

close all
clear all;
clc;


%--- ASSIGN FREQUENCIES AT WHICH SPECTRUM WILL BE PLOTTED

f = (linspace(0,0.5,200))'; % column vector of frequencies
omega = 2*pi*f;  % angular frequencies (as radians)


%--- MENU FOR WHETHER AR(1) OR AR(2)

kmen1 = menu('Choose AR Model Order',{'1','2'}); % menu for choosing AR(1) or AR(2) model
if kmen1==1 % AR(1) model
    kwhile=1; % control for while loop
    while kwhile==1  % while loop
        
        % Input dialog to enter specifications for model
        prompt={'Enter time-series length, N:',...
            'Enter the error variance:',...
            'Enter the AR(1) coefficient'};
        name='Specify AR(1) Process';
        numlines=1;
        defaultanswer={'100','1.0','-0.50'};
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        
        % Convert input dialog results to numeric
        N=str2num(answer{1}); % series length
        evar = str2num(answer{2}); % variance of error term
        a1=str2num(answer{3}); % autoregressive parameter of the AR(1) process
        
        % Restriction on parameters for stationarity (See O.D. Anderson, 1975)
        if a1<-1.0 | a1>1;
            error('a1<=-1.0 or a1>=1.0 illegal');
        end
        
        % Compute theoretical spectrum from specified AR parameters
        numer = 4*evar/N;  % numerator, eqn 3, arspectrum.pdf
        denom = 1+ a1*a1 +2*a1*cos(omega); % denominator of eqn 3
        S=numer ./ denom;
        
        %-- Plot spectrum
        hp1=plot(f,S);
        set(hp1,'LineWidth',2)
        set(gca,'YLim',[0 max(S)+0.30*max(S)]); % restrict y-axis range for better-looking plot
        xlabel('Frequency (cycles/time unit)');
        ylabel('Relative variance');
        grid on;
        title({'Theoretical AR(1) Spectrum',...
            ['y(t) + (' num2str(a1,'%5.3f') ') y(t-1) = e(t)']});
        
        % Question dialog to allow to exit while loop
        kquest = questdlg('Change Input?');
        if strcmp(kquest,'Yes');
        else
            kwhile=0;
        end
        
    end; % while kwhile==1;
    figure(1); % bring figure window to front of screen
    
elseif kmen1==2; % AR(2) model
    
    kwhile=1;
    while kwhile==1;
        
        prompt={'Enter time-series length, N:',...
            'Enter the error variance:',...
            'Enter the AR(1) coefficient',...
            'Enter the AR(2) coefficent'};
        name='Specify AR(2) Process';
        numlines=1;
        defaultanswer={'100','1.0','-0.90','0.6'};
        
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        
        N=str2num(answer{1}); % series length
        evar = str2num(answer{2}); % variance of error term
        a1=str2num(answer{3}); % coeffienct on y(t-1) of the AR(2) process
        a2=str2num(answer{4}); % coeffienct on y(t-2) of the AR(2) process
        
        % Restriction on parameters for stationarity (see O.D. Anderson, p.
        % 24).  There are 3 conditions, and all must be satisfied.  State
        % the conditions that would violate stationarity, then test for
        % whether any of those exist
        L1 = (-1.0*a2)<= -1;
        L2 = (-1.0*a1) + (-1.0*a2) >=1;
        L3 = a1 +(-1.0*a2) >=1;
        if L1 | L2 | L3;
            error('specified a1 and a2 values violate stationarity');
        end
        
        
        % Compute AR(2) spectrum from parameter values
        numer = 4*evar/N;  % numerator, eqn 4, arspectrum.doc
        denom=1+a1*a1+a2*a2+2*a1*(1+a2)*cos(omega)+2*a2*cos(2*omega);  % denominator of eqn 4
        S=numer ./ denom;
        
        
        %--- PLOT SPECTRUM
        hp1=plot(f,S);
        set(hp1,'LineWidth',2)
        set(gca,'YLim',[0 max(S)+0.30*max(S)]); % restrict y-axis range for better-looking plot
        xlabel('Frequency (cycles/time unit)');
        ylabel('Relative variance');
        grid on;
        title({'Theoretical AR(2) Spectrum',...
            ['y(t) + (' num2str(a1,'%5.3f') ') y(t-1)   + (' num2str(a2,'%5.3f') ') y(t-2)  = e(t)']});
        
        % Question dialog to allow exit of while loop
        kquest = questdlg('Change Input?');
        if strcmp(kquest,'Yes');
        else
            kwhile=0;
        end
        figure(1); % bring figure forward on screen
    end; % while kwhile==1;
end

