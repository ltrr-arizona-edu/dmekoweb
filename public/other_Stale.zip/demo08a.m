% demo08a.m  illustrate use windowing method of FIR filter design
%
% Window is a applied to truncated inverse Fourier transform of "brick
% wall" filter
%
% Illustrates effects of changing the target 0.50-response wavelength and
% number of filter weights on the following:
% 1- the filter weights
% 2- frequency response of filter
% 2 - smoothed time series
%
% Calling sequence from demo08a
% fltplay2 -- by dmm, interactive filter design
%     freqres1
%         freqz
%     fir1
%     filter
 


%--- CLEAN HOUSE

close all;  % close all figure windows
clear; % clear all variables from workspace
clc; % clear the command window


%------  LOAD FILE WITH TIME SERIES

kser=2;

load Spring19; % load storage file
t=V1.time; % store time vector
x=V1.tsm(:,kser); % store series 13 from the time series matrix-- PC1 of CEAT chrons
id = V1.id{kser}; % store series label
msgbox(id,'Series')

figure(1);
[cL,cB,cW,cH]=figsize(.8,.4);
  set(gcf,'Position',[cL cB cW cH]);
h = plot(t,x,'-o');
xlabel('Year')
ylabel('Flow (maf)')
title('N Fork American River -- want to keep 40 yr wave')

pause

%-------  RESTRICT DATA BY CULLING ONLY THE VALID PART (NOT-NAN)

L=~isnan(x);  % logical pointer to valid data
x=x(L);  % desired data
tx=t(L); % desired time vector
N=length(x); % store sample length as N


%--- FUNCTION CALL FOR INTERACTIVE FILTER DESIGN

prevwind=0; % start the figures with figure 1
[b,p50,y,ty]=fltplay2(x,tx,prevwind); % fltplay2 applies windowing method in filter design
figure(1);
title(id)