function N=ties1(x)
% ties1: identify ties in a time series
% N=ties1(x)
% Last revised 2019-01-16
%
% Identify ties in a time series. 
%
%*** INPUT ARGUMENTS
%
% x (mx x 1) time series, length m
%
%*** OUTPUT ARGUMENTS
%
% N:  structure
%   .ngroups(1x1)i  number of groups of ties
%   .nties  (ngroups x 1)n number of members each group
%
%  If no ties, the fields of N are both set to [].
%
%*** REFERENCES
%
%*** UW FUNCTIONS CALLED -- none
%
%
%*** TOOLBOXES NEEDED -- none
%
%
%*** NOTES  
%

mx = length (x);

j = (1:mx)';

 [c,Ia,Ic] = unique(x) ;

 if length(x)==length(c)
     N.ngroups=[];
     N.nties =[];
     return
 else
 end
 
 L = ~ismember(j,Ia);
 n = length(L);
 f = x(L); % values that had  a tie 
 mf = length(f);
 
v = unique(f);
ngrp = length(v);
N.ngroups=ngrp; % number of groups
 
 V = repmat(v',mf,1);
 F = repmat(f,1,ngrp);
 L = V==F;
 N.nties =1+ (sum(L))'; % add 1 because each tie group has a unique
 
