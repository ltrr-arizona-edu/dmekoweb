% Lbolt = Lightning talk selection of speaker
%
% Uses randsample, a Matlab function that samples from a uniform
% distribution (equal probability). 
%
% Text below explains how to reset the random number seed to
% avoid getting the same numbers when calling various Matlab
% random sampling functions the first time after starting matlab. 
%
%-----------------------------------------------------------------------------------
%This example shows how to avoid repeating the same random number arrays
% when MATLAB® restarts. This technique is useful when you want to 
% combine results from the same random number commands executed 
% different MATLAB sessions. 
%
% All the random number functions, rand, randn, randi, and randperm, 
% draw values from a shared random number generator. Every time you
% start MATLAB, the generator resets itself to the same state. Therefore, 
% a command such as rand(2,2) returns the same result any time you 
% execute it immediately following startup. Also, any script or function
% that calls the random number functions returns the same result whenever
% you restart. 
%
% One way to get different random numbers is to initialize the generator 
% using a different seed every time. Doing so ensures that you don’t 
% repeat results from a previous session. Execute the rng('shuffle') 
% command once in your MATLAB session before calling any of the 
% random number functions.
%-----------------------------------------------------------

clear all
close all
clc
rng('shuffle')


D.names ={'Alice','Chris','David','Julie',...
    'Kyle','Sean','Alex','Carissa',...
    'Emma','Stan','Will','Josh'};

D.bullpen =[1 0 1 1     1 0 0 1    1 1 1 1 ];  % eligible to be called in to pitch
D.pitched =[ 0 0 0 0    0 0 0 1     0 0 0 0]; % already pitched


L = D.bullpen & ~D.pitched; % 1 if eligible and have not yet pitched

nms=D.names(L)'; % col-cell of names in current pool
i1=find(L); %   sequential id number (in D.names) of students in current pool

n = length(i1); % number of students in current pool

k = randsample(n,1);   % index to selected student
iwinner = i1(k); % sequential number (in D.names) of selected student

NextSpeaker= D.names{iwinner};

uiwait(msgbox(NextSpeaker,'Next Speaker','modal'));



