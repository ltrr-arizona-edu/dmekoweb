% demo02a.m -- transformation
%
% Illustrate transformation of a measured tree-ring width series (from V3
% data) by log10 transform and square-root transform
% 1) effect on appearance of time plot
% 2) effect on histogram
% 3) effect on test for normality

clear
close all
clc

% Hard code
m=6; % use V3 series 6


load Spring19.mat; % load mat file with structures V1, V2, V3
tx=V3.time; % store time vector
x=V3.tsm(:,m); % store column m of V3 time series matrix

%-- Get part of series not nan
L = ~isnan(x);
x=x(L);
tx = tx(L);
xmean=mean(x);

nsize=length(x);
str_n = ['N=' num2str(nsize)];

%  TRANSFORMATION AND PLOTS

tran_meths={'Log10','Square root'};
kmen = menu('Choose transformation',tran_meths);
tran_meth=tran_meths{kmen};

if kmen==1
    y = log10(x);
elseif  kmen==2
    y = sqrt(x);
end
ty=tx;
ymean=mean(y);



% TIME PLOTS

figure(1)

xlims=[tx(1) tx(end)+1];

subplot(2,1,1);
h=plot(tx,x,xlims,[xmean xmean]);
set(gca,'XLim',xlims)
ylabel('x');
xlabel('Year')
title('Original time series')
textcorn(str_n,'UL',0.02,0.02,14)

subplot(2,1,2);
h=plot(ty,y,xlims,[ymean ymean]);
set(gca,'XLim',xlims)
ylabel('y');
xlabel('Year')
title(['Series after transform by ' tran_meth]);


%----------- HISTOGRAMS

figure(2)
[cL,cB,cW,cH]=figsize(.8,.5);
set(gcf,'Position',[cL cB cW cH]);


xlimsa=[min(x) max(x)];
xlimsb=[min(y) max(y)];

subplot(1,2,1);
hist(x)
set(gca,'XLim',xlimsa)
ylabel('# Obs');
xlabel('X')
title('Original time series')

subplot(1,2,2);
hist(y)
set(gca,'XLim',xlimsb)
ylabel('# Obs');
xlabel('y')
title(['Series after transform by ' tran_meth]);


%--- LILLIEFORS TEST FOR NORMALITY

[hx,px]=lillietest(x)
[hy,py]=lillietest(y)

